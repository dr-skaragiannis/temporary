import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { Mark } from "./components/mark";
import { contents, TOTAL, questions } from "./data/content";
import {
  AttackTableSlide,
  AtStakeSlide,
  ChallengesSlide,
  DefinitionSlide,
  DomainsDetailA,
  DomainsDetailB,
  DomainsIndexSlide,
  ForensicsSlide,
  NumbersSlide,
  ObjectivesSlide,
  PracticeSlide,
  QuizIntroSlide,
  QuestionSlide,
  ScoreSlide,
  StandardsSlide,
  TakeawaysSlide,
  ThreatsSlide,
  ThreatWheelSlide,
  TitleSlide,
  TrendsSlide,
  TriadDetailSlide,
  TriadSlide,
} from "./slides";

/* Flattened contents index ---------------------------------------- */
const FLAT: { label: string; idx: number; section: string }[] = [];
contents.forEach((g) =>
  g.items.forEach((it) =>
    FLAT.push({ label: it, idx: FLAT.length, section: g.section }),
  ),
);

const SECTION_OF = (i: number) => FLAT[i]?.section ?? "";

export default function App() {
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(
    Array(questions.length).fill(null),
  );
  const [open, setOpen] = useState(false);

  const go = useCallback((n: number) => {
    setI(Math.max(0, Math.min(TOTAL - 1, n)));
    setOpen(false);
  }, []);
  const next = useCallback(() => go(i + 1), [go, i]);
  const prev = useCallback(() => go(i - 1), [go, i]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      if (k === "ArrowRight" || k === "PageDown" || k === " ") {
        e.preventDefault();
        next();
      } else if (k === "ArrowLeft" || k === "PageUp") {
        e.preventDefault();
        prev();
      } else if (k === "Home") {
        go(0);
      } else if (k === "End") {
        go(TOTAL - 1);
      } else if (k === "i" || k === "I") {
        setOpen((o) => !o);
      } else if (k === "Escape") {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [next, prev, go]);

  const score = useMemo(
    () => questions.reduce((a, q, n) => a + (answers[n] === q.answer ? 1 : 0), 0),
    [answers],
  );

  const slide = useMemo(() => {
    switch (i) {
      case 0:
        return <TitleSlide go={go} />;
      case 1:
        return <DefinitionSlide />;
      case 2:
        return <PracticeSlide />;
      case 3:
        return <ObjectivesSlide />;
      case 4:
        return <StandardsSlide />;
      case 5:
        return <AtStakeSlide />;
      case 6:
        return <TriadSlide />;
      case 7:
        return <TriadDetailSlide />;
      case 8:
        return <DomainsIndexSlide />;
      case 9:
        return <DomainsDetailA />;
      case 10:
        return <DomainsDetailB />;
      case 11:
        return <AttackTableSlide />;
      case 12:
        return <ThreatWheelSlide />;
      case 13:
        return <ThreatsSlide />;
      case 14:
        return <NumbersSlide />;
      case 15:
        return <ForensicsSlide />;
      case 16:
        return <TrendsSlide />;
      case 17:
        return <ChallengesSlide />;
      case 18:
        return <QuizIntroSlide go={go} />;
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
        return (
          <QuestionSlide
            n={i - 19}
            selected={answers[i - 19]}
            onAnswer={(c) =>
              setAnswers((a) => {
                const n = [...a];
                n[i - 19] = c;
                return n;
              })
            }
          />
        );
      case 24:
        return <ScoreSlide answers={answers} />;
      default:
        return <TakeawaysSlide />;
    }
  }, [i, answers, go]);

  const pct = ((i + 1) / TOTAL) * 100;
  const inQuiz = i >= 18 && i <= 24;

  return (
    <MotionConfig reducedMotion="user">
      <div className="relative h-dvh w-full overflow-hidden bg-ink">
        {/* ============ LEFT RAIL (md+) ============ */}
        <aside className="absolute inset-y-0 left-0 z-30 hidden w-16 flex-col items-center border-r border-sage/15 bg-panel/50 py-4 md:flex">
          <button
            onClick={() => go(0)}
            aria-label="Back to title slide"
            className="transition-opacity duration-200 hover:opacity-70"
          >
            <Mark size={24} />
          </button>

          <span
            className="mt-5 font-mono text-[9.5px] tracked text-muted"
            style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
          >
            Intro to Cybersecurity
          </span>

          <div className="relative mx-auto mt-5 w-px flex-1 bg-sage/20">
            <motion.div
              className="absolute left-0 top-0 w-px bg-phos"
              animate={{ height: `${pct}%` }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              style={{ boxShadow: "0 0 6px rgba(61,240,122,.8)" }}
            />
          </div>

          <div className="mt-5 flex flex-col items-center leading-none">
            <span className="font-display text-[15px] text-phos tabular-nums">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="mt-1 font-mono text-[9px] text-muted">
              /{TOTAL}
            </span>
          </div>
        </aside>

        {/* ============ TOP BAR (mobile) ============ */}
        <header className="absolute inset-x-0 top-0 z-30 flex h-11 items-center justify-between border-b border-sage/15 bg-panel/80 px-4 md:hidden">
          <button onClick={() => go(0)} className="flex items-center gap-2.5">
            <Mark size={17} />
            <span className="font-mono text-[9.5px] tracked text-muted">
              Intro to Cybersecurity
            </span>
          </button>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[9.5px] tracked text-phos tabular-nums">
              {String(i + 1).padStart(2, "0")}/{TOTAL}
            </span>
            <button
              onClick={() => setOpen(true)}
              aria-label="Open contents"
              className="flex h-6 w-6 flex-col items-center justify-center gap-[3px] border border-sage/30"
            >
              <span className="h-px w-3 bg-sage" />
              <span className="h-px w-3 bg-sage" />
              <span className="h-px w-3 bg-sage" />
            </button>
          </div>
        </header>

        {/* ============ STAGE ============ */}
        <main className="absolute bottom-0 left-0 right-0 top-11 overflow-hidden md:left-16 md:top-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16, ease: "easeOut" }}
              className="h-full w-full"
            >
              {slide}
            </motion.div>
          </AnimatePresence>

          {/* phosphor sweep on slide change */}
          <motion.div
            key={`sweep-${i}`}
            aria-hidden
            initial={{ x: "-30%", opacity: 0.85 }}
            animate={{ x: "135%", opacity: 0 }}
            transition={{ duration: 0.65, ease: "easeOut" }}
            className="pointer-events-none absolute inset-y-0 left-0 z-20 w-[24%] bg-gradient-to-r from-transparent via-phos/[0.14] to-transparent"
          />
          <div
            aria-hidden
            className="scanlines pointer-events-none absolute inset-0 z-10 opacity-[0.22]"
          />
        </main>

        {/* ============ BOTTOM BAR ============ */}
        <nav className="absolute bottom-0 left-0 right-0 z-30 flex h-14 items-center justify-between gap-3 border-t border-sage/20 bg-ink/92 px-4 backdrop-blur-sm md:left-16 md:px-6">
          <div className="flex items-center gap-2">
            <button
              onClick={prev}
              disabled={i === 0}
              className="border border-sage/25 px-3 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos disabled:opacity-25 disabled:hover:border-sage/25 disabled:hover:text-sage"
              style={{ borderRadius: 2 }}
            >
              ← Prev
            </button>
            <button
              onClick={next}
              disabled={i === TOTAL - 1}
              className="border border-phos/70 px-3 py-2 font-mono text-[10px] tracked text-phos transition-colors duration-200 hover:bg-phos hover:text-ink disabled:opacity-25 disabled:hover:bg-transparent disabled:hover:text-phos"
              style={{ borderRadius: 2 }}
            >
              Next →
            </button>
          </div>

          <div className="hidden items-end gap-[5px] sm:flex">
            {Array.from({ length: TOTAL }).map((_, n) => (
              <button
                key={n}
                onClick={() => go(n)}
                title={`${String(n + 1).padStart(2, "0")} · ${FLAT[n]?.label ?? ""}`}
                aria-label={`Go to slide ${n + 1}`}
                className="group relative flex h-6 items-end"
              >
                <span
                  className={`block w-[3px] transition-all duration-200 ${
                    n === i
                      ? "h-5 bg-phos"
                      : n < i
                        ? "h-3 bg-phos/45 group-hover:bg-phos"
                        : "h-2 bg-sage/30 group-hover:bg-sage/70"
                  }`}
                />
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            {inQuiz && (
              <span className="hidden font-mono text-[10px] tracked text-muted sm:block">
                Score{" "}
                <span className="text-phos">
                  {score}/{questions.length}
                </span>
              </span>
            )}
            <span className="hidden font-mono text-[9.5px] tracked text-muted lg:block">
              {SECTION_OF(i)}
            </span>
            <span className="font-mono text-[10px] tracked text-sage tabular-nums">
              {String(i + 1).padStart(2, "0")}
              <span className="text-muted">/{TOTAL}</span>
            </span>
            <button
              onClick={() => setOpen(true)}
              className="hidden border border-sage/25 px-3 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos lg:block"
              style={{ borderRadius: 2 }}
            >
              Index · I
            </button>
          </div>
        </nav>

        {/* ============ CONTENTS DRAWER ============ */}
        <AnimatePresence>
          {open && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                onClick={() => setOpen(false)}
                className="absolute inset-0 z-40 bg-ink/70 backdrop-blur-[2px]"
              />
              <motion.aside
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ duration: 0.32, ease: "easeOut" }}
                className="absolute inset-y-0 right-0 z-50 flex w-[min(380px,88vw)] flex-col border-l border-phos/35 bg-panel"
              >
                <div className="flex items-center justify-between border-b border-sage/20 px-5 py-4">
                  <span className="font-mono text-[10px] tracked text-phos">
                    Contents · Chapter 01
                  </span>
                  <button
                    onClick={() => setOpen(false)}
                    aria-label="Close contents"
                    className="font-mono text-[13px] text-muted transition-colors hover:text-amber"
                  >
                    ✕
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto px-5 py-4">
                  {contents.map((g) => (
                    <div key={g.section} className="mb-5">
                      <div className="font-mono text-[9.5px] tracked text-amber">
                        {g.section}
                      </div>
                      <div className="mt-2 border-b border-sage/15">
                        {FLAT.filter((f) => f.section === g.section).map((f) => (
                          <button
                            key={f.idx}
                            onClick={() => go(f.idx)}
                            className={`flex w-full items-baseline gap-3 border-t border-sage/15 py-2.5 text-left transition-colors duration-150 hover:bg-phos/[0.06] ${
                              f.idx === i ? "bg-phos/[0.09]" : ""
                            }`}
                          >
                            <span
                              className={`font-mono text-[10.5px] tabular-nums ${
                                f.idx === i ? "text-phos" : "text-muted"
                              }`}
                            >
                              {String(f.idx + 1).padStart(2, "0")}
                            </span>
                            <span
                              className={`text-[13px] font-light ${
                                f.idx === i ? "text-phos" : "text-sage/85"
                              }`}
                            >
                              {f.label}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-sage/20 px-5 py-3 font-mono text-[9px] tracked text-muted">
                  ← → navigate · I index · Esc close
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
