import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import aisle from "./assets/aisle.jpg";
import panel from "./assets/panel.jpg";
import human from "./assets/human.jpg";
import {
  atStake,
  attackTable,
  breachCost,
  challenges,
  commonThreats,
  domains,
  evolution,
  forensics,
  objectives,
  pillars,
  practice,
  practiceDefinition,
  practiceNote,
  questions,
  standards,
  threats,
  trends,
} from "./data/content";

/* ==================================================================
   01 · TITLE
================================================================== */
export function TitleSlide({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <img
        src={aisle}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.5]"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_15%_50%,rgba(11,15,13,0.97)_25%,rgba(11,15,13,0.72)_65%,rgba(11,15,13,0.9)_100%)]" />
      <div className="absolute inset-0 scanlines opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 h-8 bg-amber/90 flex items-center justify-between px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Unclassified · Lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 01 of 08
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.01&nbsp;//&nbsp;FOUNDATIONS
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / 26
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-9">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-phos"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Introduction to
              </span>
              <span className="mt-1 block text-[clamp(2.6rem,6vw,7rem)] text-phos glow">
                Cyber
                <br className="sm:hidden" />
                security
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              Chapter one builds the foundations: what cybersecurity protects
              and why, the CIA Triad that anchors every security strategy, the
              seven domains of practice, the threats they defend against — and a
              five-item knowledge check.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(18)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-amber hover:text-amber"
                style={{ borderRadius: 2 }}
              >
                Jump to knowledge check
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-3 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[236px] opacity-90" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-10 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Format", "Lecture + check"],
            ["Duration", "≈ 60 minutes"],
            ["Pillars", "C · I · A"],
            ["Domains", "Seven"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT CYBERSECURITY IS
================================================================== */
export function DefinitionSlide() {
  const lifecycle = ["Anticipate", "Prevent", "Detect", "Respond", "Recover"];
  const surface = [
    "Advanced persistent threats (APTs)",
    "Phishing campaigns",
    "Zero-day exploits",
    "Supply chain attacks",
  ];

  return (
    <Slide
      tag="SEC // CH.01 // DEFINITION"
      num="02"
      title={
        <>
          What cybersecurity{" "}
          <span className="text-phos">actually is</span>
        </>
      }
      lede="A process, not a product — and a matter of trust as much as technology."
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <p className="text-[15px] font-light leading-[1.72] text-sage first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:font-display first-letter:text-[3.6rem] first-letter:leading-[0.72] first-letter:text-phos md:text-[17px]">
            Cybersecurity is the process of protecting networks, systems,
            applications and digital assets from unauthorized access,
            cyberattacks, malware and data breaches. It ensures the
            confidentiality, integrity and availability (CIA) of information
            while supporting secure and sustainable digital infrastructure.
          </p>
          <p className="mt-5 text-[14.5px] font-light leading-[1.7] text-muted md:text-base">
            In modern interconnected environments, cybersecurity is not only a
            technical requirement but a fundamental component of{" "}
            <span className="text-sage">trust, governance and digital
            resilience</span> across organizations and societies.
          </p>

          <div className="mt-7 border-l-2 border-phos/60 pl-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Attack surface · expanding
            </div>
            <p className="mt-2 text-[14px] font-light leading-[1.65] text-muted">
              As digital transformation accelerates, the attack surface expands
              — exposing systems to increasingly sophisticated threats:
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {surface.map((s) => (
                <span
                  key={s}
                  className="border border-amber/35 bg-amber/[0.07] px-2.5 py-1.5 font-mono text-[9.5px] tracked text-amber"
                  style={{ borderRadius: 2 }}
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="relative overflow-hidden border border-sage/15" style={{ borderRadius: 2 }}>
            <img
              src={panel}
              alt="Fiber-optic patch panel glowing in a dark equipment room"
              className="h-[190px] w-full object-cover opacity-80 md:h-[230px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-transparent" />
            <span className="absolute bottom-3 left-3 font-mono text-[9.5px] tracked text-phos">
              Fig. 02 — Physical layer, under observation
            </span>
          </div>

          <p className="mt-5 text-[14.5px] font-light leading-[1.7] text-muted md:text-[15.5px]">
            Cybersecurity encompasses a wide range of technologies, processes
            and practices designed to{" "}
            <span className="text-sage">anticipate, prevent, detect, respond
            to and recover</span> from cyber incidents.
          </p>

          <div className="mt-5 flex flex-wrap items-center gap-x-2 gap-y-2">
            {lifecycle.map((l, n) => (
              <span key={l} className="flex items-center gap-2">
                <span
                  className="border border-phos/35 px-2.5 py-1 font-mono text-[10px] tracked text-phos"
                  style={{ borderRadius: 2 }}
                >
                  {String(n + 1).padStart(2, "0")} {l}
                </span>
                {n < lifecycle.length - 1 && (
                  <span className="font-mono text-[11px] text-muted">→</span>
                )}
              </span>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · KEY OBJECTIVES
================================================================== */
export function ObjectivesSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // OBJECTIVES"
      num="04"
      title={
        <>
          Five key <span className="text-phos">objectives</span>
        </>
      }
      lede="What a cybersecurity programme is ultimately accountable for delivering."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-12">
        <div className="lg:col-span-9">
          <div className="border-b border-sage/15">
            {objectives.map((o) => (
              <Row key={o.i} i={o.i} label={o.label} desc={o.desc} meta={o.meta} />
            ))}
          </div>
        </div>
        <aside className="lg:col-span-3">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Note · Security by Design
            </div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.62] text-muted">
              Objectives 04 and 05 only hold when security is integrated into
              system design from the first line of architecture — not bolted on
              after deployment.
            </p>
            <div className="mt-4 h-px w-full bg-sage/15" />
            <div className="mt-4 space-y-2.5">
              {[
                ["Confidentiality", "only authorized access"],
                ["Integrity", "accurate, unaltered data"],
                ["Availability", "reachable when needed"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-baseline justify-between gap-3">
                  <span className="font-mono text-[10.5px] tracked-sm text-sage">
                    {k}
                  </span>
                  <span className="text-right text-[11.5px] font-light text-muted">
                    {v}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · STANDARDS & THE HUMAN FACTOR
================================================================== */
export function StandardsSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // GOVERNANCE"
      num="05"
      title={
        <>
          Standards, frameworks &{" "}
          <span className="text-phos">the human factor</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="relative overflow-hidden border border-sage/15" style={{ borderRadius: 2 }}>
            <img
              src={human}
              alt="An analyst at a console in a darkened operations room"
              className="h-[240px] w-full object-cover opacity-85 md:h-[300px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
            <blockquote className="absolute inset-x-0 bottom-0 p-5">
              <p className="border-l-2 border-amber pl-4 text-[15px] font-light italic leading-[1.55] text-amber md:text-[16.5px]">
                “Many successful cyberattacks exploit human error rather than
                technical vulnerabilities alone.”
              </p>
              <span className="mt-3 block pl-4 font-mono text-[9.5px] tracked text-muted">
                → Security awareness training &amp; user education
              </span>
            </blockquote>
          </div>
        </div>

        <div className="lg:col-span-7">
          <p className="max-w-[70ch] text-[14.5px] font-light leading-[1.7] text-muted">
            Cybersecurity is closely linked with human behavior,
            organizational policy and regulatory compliance. Structured
            standards give institutions a repeatable way to implement controls
            and to handle data legally and ethically.
          </p>

          <div className="mt-6 border-b border-sage/15">
            {standards.map((s, n) => (
              <motion.div
                key={s.code}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.36, ease: "easeOut", delay: n * 0.06 },
                  },
                }}
                className="grid grid-cols-1 gap-x-6 border-t border-sage/15 py-4 transition-colors duration-200 hover:bg-phos/[0.045] sm:grid-cols-[10.5rem_minmax(0,1fr)]"
              >
                <div>
                  <div className="font-mono text-[13px] font-medium tracked-sm text-phos">
                    {s.code}
                  </div>
                  <div className="mt-1 font-mono text-[9.5px] tracked text-muted">
                    {s.name}
                  </div>
                </div>
                <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85 sm:mt-0">
                  {s.desc}
                </p>
              </motion.div>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap gap-2.5">
            {["Risk assessment", "Access control", "Awareness training", "Audit & assurance"].map(
              (t) => (
                <span
                  key={t}
                  className="border border-sage/25 px-3 py-1.5 font-mono text-[10px] tracked text-sage/80"
                  style={{ borderRadius: 2 }}
                >
                  {t}
                </span>
              ),
            )}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · THE CIA TRIAD — the memorable moment
================================================================== */
export function TriadSlide() {
  const [active, setActive] = useState(0);
  const reduce = useReducedMotion();

  /* Order matches `pillars`: C (top), I (bottom-left), A (bottom-right). */
  const verts = [
    { x: 240, y: 74, label: "Confidentiality", lx: 240, ly: 22 },
    { x: 68, y: 372, label: "Integrity", lx: 68, ly: 436 },
    { x: 412, y: 372, label: "Availability", lx: 412, ly: 436 },
  ];

  return (
    <Slide
      tag="SEC // CH.01 // CORE-PILLARS"
      num="07"
      title={
        <>
          The CIA <span className="text-phos">Triad</span>
        </>
      }
      lede="Cybersecurity is traditionally built upon three fundamental principles known as the CIA Triad: Confidentiality, Integrity, and Availability. These principles form the foundation of all security strategies, architectures, and policies, ensuring that information systems remain secure, reliable, and trustworthy."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        {/* --- Interactive triangle --- */}
        <div className="lg:col-span-5">
          <div className="relative border border-sage/15 bg-panel/50 p-3" style={{ borderRadius: 2 }}>
            <svg viewBox="0 0 480 460" className="h-auto w-full" role="img" aria-label="The CIA triad: confidentiality, integrity, availability">
              <defs>
                <filter id="glowf" x="-60%" y="-60%" width="220%" height="220%">
                  <feGaussianBlur stdDeviation="7" result="b" />
                  <feMerge>
                    <feMergeNode in="b" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              <motion.path
                d="M240 74 68 372H412L240 74Z"
                fill="none"
                stroke="#3DF07A"
                strokeOpacity="0.55"
                strokeWidth="1.6"
                strokeLinejoin="round"
                initial={reduce ? false : { pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.1, ease: "easeOut", delay: 0.25 }}
              />
              <path
                d="M240 132 122 338h236L240 132Z"
                fill="none"
                stroke="#3DF07A"
                strokeOpacity="0.18"
                strokeWidth="1"
                strokeDasharray="4 6"
                strokeLinejoin="round"
              />
              <circle
                cx="240"
                cy="276"
                r="74"
                fill="none"
                stroke="#3DF07A"
                strokeOpacity="0.2"
                strokeWidth="1"
                strokeDasharray="2 8"
              />
              <text
                x="240"
                y="268"
                textAnchor="middle"
                className="font-display"
                fontSize="30"
                fill="#3DF07A"
                fillOpacity="0.85"
              >
                CIA
              </text>
              <text
                x="240"
                y="294"
                textAnchor="middle"
                fontFamily="IBM Plex Mono, monospace"
                fontSize="10"
                letterSpacing="3"
                fill="#7E8F84"
              >
                TRIAD
              </text>

              {verts.map((v, n) => {
                const on = active === n;
                return (
                  <g
                    key={v.label}
                    onMouseEnter={() => setActive(n)}
                    onClick={() => setActive(n)}
                    className="cursor-pointer"
                    tabIndex={0}
                    role="button"
                    aria-label={v.label}
                    onFocus={() => setActive(n)}
                  >
                    <text
                      x={v.lx}
                      y={v.ly}
                      textAnchor="middle"
                      fontFamily="IBM Plex Mono, monospace"
                      fontSize="11"
                      letterSpacing="2.6"
                      fill={on ? "#3DF07A" : "#7E8F84"}
                    >
                      {v.label.toUpperCase()}
                    </text>
                    <circle
                      cx={v.x}
                      cy={v.y}
                      r="42"
                      fill={on ? "#0E3B22" : "#0B0F0D"}
                      stroke="#3DF07A"
                      strokeOpacity={on ? 1 : 0.45}
                      strokeWidth={on ? 2 : 1.2}
                      filter={on ? "url(#glowf)" : undefined}
                      style={{ transition: "all .25s ease" }}
                    />
                    <text
                      x={v.x}
                      y={v.y + 13}
                      textAnchor="middle"
                      className="font-display"
                      fontSize="34"
                      fill={on ? "#3DF07A" : "#C7D2C9"}
                      fillOpacity={on ? 1 : 0.6}
                      style={{ pointerEvents: "none" }}
                    >
                      {"CIA"[n]}
                    </text>
                  </g>
                );
              })}
            </svg>
            <div className="mt-1 flex items-center justify-between px-1 pb-1">
              <span className="font-mono text-[9.5px] tracked text-muted">
                Hover a vertex to inspect
              </span>
              <span className="font-mono text-[9.5px] tracked text-phos">
                0{active + 1} · {pillars[active].name}
              </span>
            </div>
          </div>
        </div>

        {/* --- Panels --- */}
        <div className="lg:col-span-7">
          <div className="space-y-3">
            {pillars.map((p, n) => {
              const on = active === n;
              return (
                <button
                  key={p.key}
                  onMouseEnter={() => setActive(n)}
                  onFocus={() => setActive(n)}
                  onClick={() => setActive(n)}
                  className={`block w-full border p-5 text-left transition-all duration-300 ${
                    on
                      ? "border-phos bg-panel2 shadow-[0_0_0_1px_rgba(61,240,122,0.25)]"
                      : "border-sage/15 bg-panel/40 hover:border-sage/30"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-3">
                    <span
                      className={`font-display text-[clamp(1.1rem,2vw,1.6rem)] uppercase leading-none ${
                        on ? "text-phos" : "text-sage/75"
                      }`}
                    >
                      {p.name}
                    </span>
                    <span className="font-mono text-[9.5px] tracked text-muted">
                      {p.tag}
                    </span>
                  </div>
                  <p className="mt-3 max-w-[74ch] text-[13.5px] font-light leading-[1.62] text-muted">
                    {p.definition}
                  </p>

                  <motion.div
                    initial={false}
                    animate={{
                      height: on ? "auto" : 0,
                      opacity: on ? 1 : 0,
                    }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className="overflow-hidden"
                  >
                    <div className="mt-4 border-t border-sage/15 pt-4">
                      <div className="font-mono text-[9.5px] tracked text-phos">
                        Enforced by
                      </div>
                      <div className="mt-2.5 flex flex-wrap gap-2">
                        {p.mechanisms.map((m) => (
                          <span
                            key={m}
                            className="border border-sage/25 px-2.5 py-1 font-mono text-[10px] text-sage/85"
                            style={{ borderRadius: 2 }}
                          >
                            {m}
                          </span>
                        ))}
                      </div>
                      <p className="mt-3.5 text-[13px] font-light italic leading-[1.55] text-sage/70">
                        {p.sectors}
                      </p>
                    </div>
                  </motion.div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · CIA IN DETAIL
================================================================== */
export function TriadDetailSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // CORE-PILLARS/DETAIL"
      num="08"
      title={
        <>
          Confidentiality · Integrity ·{" "}
          <span className="text-phos">Availability</span>
        </>
      }
      lede="Each pillar has its own mechanisms, its own failure modes and the sectors where failure is unacceptable."
      dense
    >
      <div className="grid gap-px bg-sage/15 md:grid-cols-3">
        {pillars.map((p, n) => (
          <motion.div
            key={p.key}
            variants={{
              hidden: { opacity: 0, y: 12 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, ease: "easeOut", delay: n * 0.08 },
              },
            }}
            className="bg-ink p-5 md:p-6"
          >
            <div className="flex items-start justify-between">
              <span className="font-display text-[3.6rem] leading-[0.8] text-phos/85">
                {p.key}
              </span>
              <span className="mt-2 border border-phos/35 px-2 py-1 font-mono text-[9px] tracked text-phos">
                0{n + 1}
              </span>
            </div>
            <h3 className="mt-4 font-display text-[1.25rem] uppercase leading-tight tracking-tight text-sage">
              {p.name}
            </h3>
            <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
              {p.definition}
            </p>

            <div className="mt-5 h-px w-full bg-sage/15" />
            <div className="mt-4 font-mono text-[9.5px] tracked text-phos">
              Enforced by
            </div>
            <ul className="mt-2.5 space-y-1.5">
              {p.mechanisms.map((m) => (
                <li
                  key={m}
                  className="flex items-start gap-2.5 text-[13px] font-light text-sage/85"
                >
                  <span className="mt-[7px] h-px w-3 shrink-0 bg-phos/70" />
                  {m}
                </li>
              ))}
            </ul>
            <p className="mt-4 border-t border-sage/15 pt-3.5 text-[12.5px] font-light italic leading-[1.55] text-muted">
              {p.sectors}
            </p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · SEVEN DOMAINS — INDEX
================================================================== */
export function DomainsIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // DOMAINS/INDEX"
      num="09"
      title={
        <>
          Seven types of <span className="text-phos">cybersecurity</span>
        </>
      }
      lede="Cybersecurity is a broad field composed of multiple specialized domains, each focusing on protecting different layers of digital systems and infrastructure. Together, these domains form a comprehensive security ecosystem that helps organizations defend against evolving cyber threats."
      dense
    >
      <div className="border-b border-sage/15">
        {domains.map((d) => (
          <Row key={d.i} i={d.i} label={d.name} desc={d.short} meta={`DOMAIN ${d.i}`} />
        ))}
      </div>
      <p className="mt-5 font-mono text-[10px] tracked text-muted">
        → Each domain detailed on the following two slides
      </p>
    </Slide>
  );
}

function DomainCard({ d, n }: { d: (typeof domains)[number]; n: number }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 12 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.4, ease: "easeOut", delay: n * 0.07 },
        },
      }}
      className="flex flex-col border border-sage/15 bg-panel/50 p-5 transition-colors duration-200 hover:border-phos/45"
      style={{ borderRadius: 2 }}
    >
      <div className="flex items-center justify-between">
        <span className="font-mono text-[11px] text-phos/70">{d.i}</span>
        <span className="font-mono text-[9px] tracked text-muted">Domain</span>
      </div>
      <h3 className="mt-3 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
        {d.name}
      </h3>
      <p className="mt-3 text-[13px] font-light leading-[1.62] text-muted">
        {d.desc}
      </p>
      <div className="mt-4 flex flex-wrap gap-1.5">
        {d.tools.map((t) => (
          <span
            key={t}
            className="border border-sage/22 px-2 py-1 font-mono text-[9.5px] text-sage/80"
            style={{ borderRadius: 2 }}
          >
            {t}
          </span>
        ))}
      </div>
      <div className="mt-auto border-t border-sage/15 pt-3.5">
        <span className="font-mono text-[9.5px] tracked text-phos">{d.stops}</span>
      </div>
    </motion.div>
  );
}

export function DomainsDetailA() {
  return (
    <Slide
      tag="SEC // CH.01 // DOMAINS 01–03"
      num="10"
      title={
        <>
          Network · Application ·{" "}
          <span className="text-phos">Data</span>
        </>
      }
      dense
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {domains.slice(0, 3).map((d, n) => (
          <DomainCard key={d.i} d={d} n={n} />
        ))}
      </div>
    </Slide>
  );
}

export function DomainsDetailB() {
  return (
    <Slide
      tag="SEC // CH.01 // DOMAINS 04–07"
      num="11"
      title={
        <>
          Cloud · Endpoint · OpSec ·{" "}
          <span className="text-phos">IoT</span>
        </>
      }
      dense
    >
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {domains.slice(3).map((d, n) => (
          <DomainCard key={d.i} d={d} n={n} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · MAJOR THREATS
================================================================== */
export function ThreatsSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // THREAT-VECTORS"
      num="14"
      title={
        <>
          Major cyber threats{" "}
          <span className="text-amber">&amp; attacks</span>
        </>
      }
      lede="Cybersecurity threats are malicious activities designed to compromise systems, networks, and data. These attacks exploit technical vulnerabilities as well as human weaknesses, and they continue to evolve in sophistication and scale."
      dense
    >
      <div className="grid gap-4 md:grid-cols-2">
        {threats.map((t, n) => (
          <motion.div
            key={t.i}
            variants={{
              hidden: { opacity: 0, y: 12 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, ease: "easeOut", delay: n * 0.07 },
              },
            }}
            className="relative border border-amber/30 bg-panel/50 p-5 transition-colors duration-200 hover:border-amber/70"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-baseline gap-3">
                <span className="font-mono text-[11px] text-amber/75">{t.i}</span>
                <h3 className="font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
                  {t.name}
                </h3>
              </div>
              <span
                className={`shrink-0 px-2 py-1 font-mono text-[9px] tracked ${
                  t.severity === "CRITICAL"
                    ? "bg-amber text-ink"
                    : "border border-amber/50 text-amber"
                }`}
                style={{ borderRadius: 2 }}
              >
                {t.severity}
              </span>
            </div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.62] text-muted">
              {t.desc}
            </p>
            <div className="mt-4 grid gap-2 border-t border-sage/15 pt-3.5">
              <div className="flex items-start gap-3">
                <span className="w-[62px] shrink-0 font-mono text-[9px] tracked text-phos/70">
                  Vector
                </span>
                <span className="font-mono text-[10.5px] tracked-sm text-sage/85">
                  {t.vector}
                </span>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-[62px] shrink-0 font-mono text-[9px] tracked text-phos/70">
                  Note
                </span>
                <span className="text-[12.5px] font-light leading-[1.5] text-muted">
                  {t.spread}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · COST & EVOLUTION
================================================================== */
export function NumbersSlide() {
  const reduce = useReducedMotion();
  const max = 10;
  const x0 = 172;
  const barMax = 320;

  return (
    <Slide
      tag="SEC // CH.01 // THREAT-LANDSCAPE"
      num="15"
      title={
        <>
          The landscape,{" "}
          <span className="text-phos">by the numbers</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Fig. 15.1 — Average cost of a data breach by industry · USD millions
          </div>
          <svg viewBox="0 0 572 300" className="mt-3 h-auto w-full" role="img" aria-label="Bar chart of average data breach cost by industry">
            {[0, 2, 4, 6, 8, 10].map((v) => {
              const x = x0 + (v / max) * barMax;
              return (
                <g key={v}>
                  <line
                    x1={x}
                    y1={8}
                    x2={x}
                    y2={266}
                    stroke="#C7D2C9"
                    strokeOpacity={v === 0 ? 0.4 : 0.11}
                    strokeWidth="1"
                  />
                  <text
                    x={x}
                    y={286}
                    textAnchor="middle"
                    fontFamily="IBM Plex Mono, monospace"
                    fontSize="10"
                    fill="#7E8F84"
                  >
                    {v === 0 ? "0" : `${v}M`}
                  </text>
                </g>
              );
            })}

            {breachCost.map((b, n) => {
              const y = 22 + n * 49;
              const w = (b.value / max) * barMax;
              const hot = n === 0;
              return (
                <g key={b.label}>
                  <text
                    x={x0 - 14}
                    y={y + 17}
                    textAnchor="end"
                    fontFamily="IBM Plex Mono, monospace"
                    fontSize="11.5"
                    letterSpacing="1"
                    fill="#C7D2C9"
                  >
                    {b.label}
                  </text>
                  <motion.rect
                    x={x0}
                    y={y}
                    height={24}
                    rx={1}
                    fill={hot ? "#FFB020" : "#3DF07A"}
                    fillOpacity={hot ? 0.95 : 0.72}
                    initial={reduce ? false : { width: 0 }}
                    animate={{ width: w }}
                    transition={{
                      duration: 0.7,
                      ease: "easeOut",
                      delay: 0.2 + n * 0.09,
                    }}
                  />
                  <motion.text
                    x={x0 + w + 10}
                    y={y + 17}
                    fontFamily="IBM Plex Mono, monospace"
                    fontSize="12.5"
                    fontWeight="600"
                    fill={hot ? "#FFB020" : "#3DF07A"}
                    initial={reduce ? false : { opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3, delay: 0.7 + n * 0.09 }}
                  >
                    ${b.value.toFixed(2)}M
                  </motion.text>
                </g>
              );
            })}
          </svg>
          <p className="mt-2 font-mono text-[9.5px] tracked text-muted">
            Higher education sits fourth — research data, grants and identity
            records make campuses a target.
          </p>
        </div>

        <div className="lg:col-span-5">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Fig. 15.2 — Cybersecurity evolution, 1990 → 2025
          </div>
          <div className="mt-3 border-b border-sage/15">
            {evolution.map((e, n) => (
              <motion.div
                key={`${e.era}-${e.label}`}
                variants={{
                  hidden: { opacity: 0, x: -8 },
                  show: {
                    opacity: 1,
                    x: 0,
                    transition: { duration: 0.35, ease: "easeOut", delay: 0.15 + n * 0.06 },
                  },
                }}
                className="grid grid-cols-[4.6rem_1fr] items-baseline gap-4 border-t border-sage/15 py-3"
              >
                <span className="font-mono text-[12px] tabular-nums text-phos">
                  {e.era}
                </span>
                <span className="text-[13.5px] font-light text-sage/85">
                  {e.label}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · TRENDS  ·  13 · CHALLENGES
================================================================== */
export function TrendsSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // HORIZON"
      num="17"
      title={
        <>
          Emerging trends in{" "}
          <span className="text-phos">cybersecurity</span>
        </>
      }
      lede="Cybersecurity continues to evolve rapidly in response to increasingly sophisticated threats and the adoption of new digital technologies. Organizations must adapt their security strategies to keep pace with these changes and ensure resilient protection of systems and data."
      dense
    >
      <div className="border-b border-sage/15">
        {trends.map((t) => (
          <Row key={t.i} i={t.i} label={t.name} desc={t.desc} meta={t.meta} />
        ))}
      </div>
      <div className="mt-5 flex flex-wrap items-center gap-3 border border-phos/35 bg-deep/40 px-4 py-3" style={{ borderRadius: 2 }}>
        <span className="font-mono text-[9.5px] tracked text-phos">Zero Trust</span>
        <span className="font-display text-[13px] uppercase tracking-tight text-sage">
          “Never trust, always verify.”
        </span>
        <span className="hidden text-[13px] font-light text-muted sm:block">
          Every access request is continuously verified — cutting lateral movement after a breach.
        </span>
      </div>
    </Slide>
  );
}

export function ChallengesSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // OPEN-PROBLEMS"
      num="18"
      title={
        <>
          Persistent <span className="text-phos">challenges</span>
        </>
      }
      lede="Despite technological advancements, cybersecurity still faces several ongoing challenges that complicate effective protection strategies."
      dense
    >
      <div className="grid gap-4 md:grid-cols-2">
        {challenges.map((c, n) => (
          <motion.div
            key={c.i}
            variants={{
              hidden: { opacity: 0, y: 12 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, ease: "easeOut", delay: n * 0.07 },
              },
            }}
            className="border border-sage/15 bg-panel/45 p-5 transition-colors duration-200 hover:border-phos/40"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-baseline gap-3">
              <span className="font-mono text-[11px] text-phos/70">{c.i}</span>
              <h3 className="font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
                {c.name}
              </h3>
            </div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.62] text-muted">
              {c.desc}
            </p>
            <div className="mt-4 flex items-start gap-3 border-t border-sage/15 pt-3">
              <span className="font-mono text-[9px] tracked text-phos/70">
                Counter
              </span>
              <span className="font-mono text-[10px] tracked-sm text-sage/85">
                {c.counter}
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · KNOWLEDGE CHECK INTRO
================================================================== */
export function QuizIntroSlide({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="absolute inset-0 grid-etch opacity-60" />
      <div className="absolute inset-x-0 top-0 h-8 flex items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.01 // Check</span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.4rem,7vw,5.5rem)] uppercase leading-[0.88] tracking-[-0.02em] text-sage"
        >
          Five questions.<br />
          <span className="text-phos glow">No pressure.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          One multiple-choice item per slide. Select an answer to reveal it
          instantly — the rationale appears underneath, and your running score
          is kept in the header. You can change an answer until you advance.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(19)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   15–19 · QUESTION SLIDE
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (choice: number) => void;
}) {
  const q = questions[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.01 // CHECK // Q0${n + 1}`}
      num={String(20 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.15rem,2.3vw,1.7rem)] font-normal leading-[1.35] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            <div className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
              <span className="font-mono text-[9.5px] tracked text-muted">
                Status
              </span>
              <span
                className={`font-mono text-[10px] tracked ${
                  !answered ? "text-muted" : correct ? "text-phos" : "text-amber"
                }`}
              >
                {!answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"}
              </span>
            </div>
            <div className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
              <span className="font-mono text-[9.5px] tracked text-muted">
                Domain
              </span>
              <span className="font-mono text-[10px] tracked text-sage/80">
                Foundations
              </span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: {
                        duration: 0.34,
                        ease: "easeOut",
                        delay: 0.06 * i,
                      },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · SCORE
================================================================== */
export function ScoreSlide({ answers }: { answers: (number | null)[] }) {
  const score = questions.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions.length) * 100);
  const verdict =
    pct === 100
      ? "Chapter mastered."
      : pct >= 60
        ? "Solid foundation — revisit the misses."
        : "Re-read the CIA Triad and the domains.";

  return (
    <Slide
      tag="SEC // CH.01 // CHECK // RESULT"
      num="25"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">
              Result
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions.length}
              </span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>{score} of {questions.length} correct</span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: 0.05 * i },
                    },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok
                        ? "border-phos/60 text-phos"
                        : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   21 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide() {
  const items = [
    ["01", "Cybersecurity is a process", "Anticipate · prevent · detect · respond · recover — not a product you install."],
    ["02", "CIA is the foundation", "Confidentiality, Integrity, Availability anchor every strategy, architecture and policy."],
    ["03", "Seven domains, one ecosystem", "Network, application, data, cloud, endpoint, operational and IoT security overlap by design."],
    ["04", "People are the soft surface", "Most successful attacks exploit human error — awareness training is a control, not a nicety."],
    ["05", "Threats keep evolving", "Malware, phishing, ransomware and DDoS now arrive with AI speed and scale."],
    ["06", "Verify by default", "Zero Trust — never trust, always verify — is the operating model for what comes next."],
  ];

  return (
    <Slide
      tag="SEC // CH.01 // CLOSE"
      num="26"
      title={
        <>
          Chapter 01 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-phos/70">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 01
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Next: Chapter 02 — Cryptography &amp; Public-Key Infrastructure
        </span>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · PROTECTION IN PRACTICE  (second half of the introduction)
================================================================== */
export function PracticeSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // DEFINITION/02"
      num="03"
      title={
        <>
          Applying best practices{" "}
          <span className="text-phos">&amp; technology</span>
        </>
      }
      dense
    >
      <div className="border-y border-phos/45 py-5 md:py-6">
        <p className="max-w-[96ch] text-[clamp(1rem,1.35vw,1.28rem)] font-light leading-[1.62] text-sage">
          {practiceDefinition}
        </p>
      </div>

      <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Scope of the mission
          </div>
          <p className="mt-3 text-[14px] font-light leading-[1.68] text-muted">
            {practiceNote}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {["Personal assets", "Organizational assets", "National assets"].map(
              (a) => (
                <span
                  key={a}
                  className="border border-sage/25 px-2.5 py-1.5 font-mono text-[9.5px] tracked text-sage/85"
                  style={{ borderRadius: 2 }}
                >
                  {a}
                </span>
              ),
            )}
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-phos">
              Key objectives of cybersecurity
            </span>
            <span className="font-mono text-[9.5px] tracked text-muted">
              Continued · see slide 04
            </span>
          </div>
          <div className="mt-3 border-b border-sage/15">
            {practice.map((p) => (
              <Row key={p.i} i={p.i} label={p.label} desc={p.desc} meta={p.meta} />
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · SECURITY RISK — WHAT IS AT STAKE
================================================================== */
export function AtStakeSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // SECURITY-RISK"
      num="06"
      title={
        <>
          Security risk —{" "}
          <span className="text-phos">what is at stake</span>
        </>
      }
      lede="Cybersecurity is only abstract until something is lost. These are the assets the whole programme exists to defend."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {atStake.map((r) => (
              <Row key={r.i} i={r.i} label={r.label} desc={r.desc} meta={r.meta} />
            ))}
          </div>
        </div>

        <aside className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Mapping · CIA triad
            </div>
            <div className="mt-4 space-y-3.5">
              {[
                ["C", "Confidentiality", "Data reaches no one who is not authorized to see it."],
                ["I", "Integrity", "Data stays accurate, complete and unaltered."],
                ["A", "Availability", "Systems are reachable whenever they are needed."],
              ].map(([k, n, d]) => (
                <div key={k} className="flex gap-3.5">
                  <span className="mt-[2px] flex h-7 w-7 shrink-0 items-center justify-center border border-phos/60 font-display text-[13px] text-phos">
                    {k}
                  </span>
                  <div className="min-w-0">
                    <div className="font-mono text-[11px] tracked-sm text-sage">
                      {n}
                    </div>
                    <p className="mt-1 text-[12.5px] font-light leading-[1.5] text-muted">
                      {d}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-5 h-px w-full bg-sage/15" />
            <p className="mt-4 border-l-2 border-amber pl-4 text-[13px] font-light italic leading-[1.55] text-amber">
              Every item in this list fails through exactly one of those three
              doors.
            </p>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · MAJOR CYBER ATTACKS — REFERENCE TABLE
================================================================== */
export function AttackTableSlide() {
  const head = ["#", "Attack vector", "Class", "Function", "Primary layer"];
  return (
    <Slide
      tag="SEC // CH.01 // ATTACK-TABLE"
      num="12"
      title={
        <>
          Major cyber <span className="text-amber">attacks</span>
        </>
      }
      lede="Six attack classes every defence has to cover — the compact reference version."
      dense
    >
      <div className="mb-3 flex items-center justify-between gap-4">
        <span className="font-mono text-[9.5px] tracked text-phos">
          Tab. 12 — Attack classes at a glance
        </span>
        <span className="font-mono text-[9.5px] tracked text-muted sm:hidden">
          Scroll →
        </span>
      </div>

      <div className="overflow-x-auto border border-sage/20 bg-panel/40" style={{ borderRadius: 2 }}>
        <table className="w-full min-w-[780px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              {head.map((h) => (
                <th
                  key={h}
                  scope="col"
                  className="px-4 py-3 font-mono text-[9.5px] tracked text-phos"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {attackTable.map((r) => (
              <motion.tr
                key={r.i}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, ease: "easeOut" },
                  },
                }}
                className="border-b border-sage/15 transition-colors duration-200 last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-3.5 align-middle font-mono text-[11px] text-phos/70">
                  {r.i}
                </td>
                <td className="px-4 py-3.5 align-middle font-display text-[14px] uppercase leading-tight tracking-tight text-sage">
                  {r.name}
                </td>
                <td className="px-4 py-3.5 align-middle font-mono text-[11px] tracked-sm text-muted">
                  {r.klass}
                </td>
                <td className="px-4 py-3.5 align-middle text-[13.5px] font-light text-sage/90">
                  {r.fn}
                </td>
                <td className="px-4 py-3.5 align-middle">
                  <span
                    className="inline-block border border-sage/30 px-2 py-1 font-mono text-[9.5px] tracked text-sage/85"
                    style={{ borderRadius: 2 }}
                  >
                    {r.layer}
                  </span>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-4 max-w-[86ch] text-[13.5px] font-light leading-[1.6] text-muted">
        These six recur across the section: malware, phishing, ransomware and
        DDoS each get a full treatment in the profiles that follow, while SQL
        injection and zero-day exploitation cut across every layer of the stack.
      </p>
    </Slide>
  );
}

/* ==================================================================
   12 · COMMON THREATS & ATTACKS — FIVE SHAPES (pinwheel)
================================================================== */
export function ThreatWheelSlide() {
  const [active, setActive] = useState("mal");
  const reduce = useReducedMotion();

  const C = { x: 270, y: 210 };
  const DEG = [-90, -18, 54, 126, 198];
  const pol = (cx: number, cy: number, r: number, d: number) => {
    const a = (d * Math.PI) / 180;
    return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
  };

  const current =
    commonThreats.find((t) => t.key === active) ?? commonThreats[2];

  return (
    <Slide
      tag="SEC // CH.01 // THREAT-SHAPES"
      num="13"
      title={
        <>
          Common threats{" "}
          <span className="text-amber">&amp; attacks</span>
        </>
      }
      lede="Five recurring shapes of attack. Select a blade to read how each one lands."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="border border-sage/15 bg-panel/45 p-2" style={{ borderRadius: 2 }}>
            <svg
              viewBox="0 0 540 420"
              className="h-auto w-full"
              role="img"
              aria-label="Pinwheel diagram of five common threat types"
            >
              <defs>
                <filter id="wheelGlow" x="-70%" y="-70%" width="240%" height="240%">
                  <feGaussianBlur stdDeviation="6" result="b" />
                  <feMerge>
                    <feMergeNode in="b" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              <circle
                cx={C.x}
                cy={C.y}
                r="66"
                fill="none"
                stroke="#3DF07A"
                strokeOpacity="0.22"
                strokeWidth="1"
                strokeDasharray="2 8"
              />

              {commonThreats.map((t, n) => {
                const a = DEG[n];
                const p = pol(C.x, C.y, 118, a);
                const s = pol(C.x, C.y, 52, a + 62);
                const cp = pol(C.x, C.y, 116, a + 14);
                const e = pol(p.x, p.y, 54, a + 118);
                return (
                  <path
                    key={`sp-${t.key}`}
                    d={`M${s.x.toFixed(1)} ${s.y.toFixed(1)} Q${cp.x.toFixed(1)} ${cp.y.toFixed(1)} ${e.x.toFixed(1)} ${e.y.toFixed(1)}`}
                    fill="none"
                    stroke="#3DF07A"
                    strokeOpacity={active === t.key ? 0.5 : 0.16}
                    strokeWidth={active === t.key ? 13 : 10}
                    strokeLinecap="round"
                    style={{ transition: "all .3s ease" }}
                  />
                );
              })}

              {/* centre — the attack core */}
              <circle cx={C.x} cy={C.y} r="47" fill="#0B0F0D" stroke="#FFB020" strokeWidth="1.6" />
              <path
                d={`M${C.x} ${C.y - 22} L${C.x + 21} ${C.y + 15} L${C.x - 21} ${C.y + 15} Z`}
                fill="none"
                stroke="#FFB020"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
              <rect x={C.x - 1.6} y={C.y - 10} width="3.2" height="13" rx="1.4" fill="#FFB020" />
              <circle cx={C.x} cy={C.y + 9} r="1.9" fill="#FFB020" />

              {commonThreats.map((t, n) => {
                const a = DEG[n];
                const p = pol(C.x, C.y, 118, a);
                const on = active === t.key;
                const y0 = p.y - (t.lines.length - 1) * 8 + 4;
                return (
                  <g
                    key={t.key}
                    className="cursor-pointer"
                    tabIndex={0}
                    role="button"
                    aria-label={t.full}
                    onMouseEnter={() => setActive(t.key)}
                    onFocus={() => setActive(t.key)}
                    onClick={() => setActive(t.key)}
                  >
                    <circle
                      cx={p.x}
                      cy={p.y}
                      r="50"
                      fill={on ? "#0E3B22" : "#121815"}
                      stroke="#3DF07A"
                      strokeOpacity={on ? 1 : 0.4}
                      strokeWidth={on ? 2 : 1.2}
                      filter={on ? "url(#wheelGlow)" : undefined}
                      style={{ transition: "all .28s ease" }}
                    />
                    {t.lines.map((ln, k) => (
                      <text
                        key={ln}
                        x={p.x}
                        y={y0 + k * 16}
                        textAnchor="middle"
                        fontFamily="IBM Plex Mono, monospace"
                        fontSize="11.5"
                        letterSpacing="1.2"
                        fill={on ? "#3DF07A" : "#C7D2C9"}
                        fillOpacity={on ? 1 : 0.7}
                        style={{ pointerEvents: "none" }}
                      >
                        {ln.toUpperCase()}
                      </text>
                    ))}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="border border-phos/40 bg-panel/60 p-5" style={{ borderRadius: 2 }}>
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <span className="font-display text-[clamp(1.15rem,2vw,1.5rem)] uppercase leading-none text-phos">
                {current.full}
              </span>
              <span className="border border-sage/30 px-2 py-1 font-mono text-[9px] tracked text-sage/80" style={{ borderRadius: 2 }}>
                {current.meta}
              </span>
            </div>
            <p className="mt-4 text-[14px] font-light leading-[1.65] text-sage/85">
              {current.blurb}
            </p>
          </div>

          <div className="mt-4 border-b border-sage/15">
            {commonThreats.map((t, n) => (
              <button
                key={t.key}
                onClick={() => setActive(t.key)}
                onMouseEnter={() => setActive(t.key)}
                className={`grid w-full grid-cols-[2.1rem_minmax(0,1fr)_auto] items-center gap-x-4 border-t border-sage/15 px-1 py-3 text-left transition-colors duration-200 ${
                  active === t.key ? "bg-phos/[0.07]" : "hover:bg-phos/[0.045]"
                }`}
              >
                <span className="font-mono text-[11px] text-phos/70">
                  {String(n + 1).padStart(2, "0")}
                </span>
                <span className="font-mono text-[12.5px] tracked-sm text-sage">
                  {t.full}
                </span>
                <span className="font-mono text-[9.5px] tracked text-muted">
                  {t.meta}
                </span>
              </button>
            ))}
          </div>

          {!reduce && (
            <p className="mt-4 font-mono text-[9.5px] tracked text-muted">
              Hover or focus a blade · five shapes, one objective
            </p>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · DIGITAL FORENSICS & INVESTIGATION
================================================================== */
export function ForensicsSlide() {
  return (
    <Slide
      tag="SEC // CH.01 // RESPONSE/FORENSICS"
      num="16"
      title={
        <>
          Forensics &amp;{" "}
          <span className="text-phos">investigation</span>
        </>
      }
      lede="When prevention fails, the response has to be provable. Digital forensics converts an incident into evidence, a report and a root cause."
      dense
    >
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {forensics.map((f, n) => (
          <motion.div
            key={f.i}
            variants={{
              hidden: { opacity: 0, y: 12 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, ease: "easeOut", delay: n * 0.08 },
              },
            }}
            className="relative flex flex-col border border-sage/15 bg-panel/50 p-5 transition-colors duration-200 hover:border-phos/45"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{f.i}</span>
              <span className="font-mono text-[9px] tracked text-muted">
                {f.meta}
              </span>
            </div>
            <h3 className="mt-3 font-display text-[1.02rem] uppercase leading-tight tracking-tight text-sage">
              {f.name}
            </h3>
            <p className="mt-3 text-[13px] font-light leading-[1.62] text-muted">
              {f.desc}
            </p>
            <div className="mt-auto flex items-center gap-2 pt-4">
              <span className="h-px flex-1 bg-sage/20" />
              {n < forensics.length - 1 && (
                <span className="font-mono text-[11px] text-phos/60">→</span>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 grid gap-6 border-t border-phos/40 pt-5 md:grid-cols-3">
        {[
          ["Preserve", "Nothing is analysed on the live system — images are taken first, hashes recorded."],
          ["Prove", "Every step is logged so the chain of custody holds up to audit and to court."],
          ["Prevent", "Root cause feeds directly back into patching, policy and awareness training."],
        ].map(([k, v]) => (
          <div key={k}>
            <div className="font-mono text-[9.5px] tracked text-phos">{k}</div>
            <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">
              {v}
            </p>
          </div>
        ))}
      </div>
    </Slide>
  );
}
