import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch13Bullets,
  ch13Intro,
  ch13Stamp,
  contents13,
  examples,
  malTypes,
  protection,
  purposes,
  questions13,
  removal,
  signs,
  tools,
  TOTAL13,
} from "./data/ch13";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "corrupted hex dump" backdrop
================================================================== */
function HexBackdrop() {
  const rows = 14;
  const cols = 22;
  const cells: { x: number; y: number; bad: boolean; hot: boolean }[] = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const seed = (r * 31 + c * 17) % 23;
      cells.push({ x: 640 + c * 26, y: 120 + r * 34, bad: seed < 4, hot: seed === 0 });
    }
  const hex = ["4D", "5A", "90", "00", "FF", "E8", "C3", "8B", "EC", "48", "0F", "B8"];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="hxFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="hxGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      <g fontFamily="IBM Plex Mono, monospace" fontSize="12">
        {cells.map((c, n) => (
          <text key={n} x={c.x} y={c.y} fill={c.hot ? "#FFB020" : c.bad ? "#3DF07A" : "#C7D2C9"} fillOpacity={c.hot ? 0.95 : c.bad ? 0.7 : 0.16} filter={c.hot ? "url(#hxGlow)" : undefined}>
            {hex[(n * 7) % hex.length]}
          </text>
        ))}
      </g>
      {/* infection bloom */}
      <g transform="translate(900 340)">
        {[60, 120, 190].map((r, n) => (
          <circle key={r} r={r} fill="none" stroke="#FFB020" strokeOpacity={0.35 - n * 0.1} strokeDasharray={n === 1 ? "5 8" : undefined} />
        ))}
      </g>
      <rect width="1200" height="700" fill="url(#hxFade)" />
    </svg>
  );
}

export function TitleSlide13({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <HexBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Malicious code briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 13 of 16</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.13&nbsp;//&nbsp;MALWARE</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL13}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 13</span>
              <span className="mt-1 block text-[clamp(2.6rem,8vw,6.6rem)] text-phos glow">Malware</span>
              <span className="mt-1 block text-[clamp(1.4rem,3.6vw,3rem)] text-sage/80">&amp; its types</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch13Intro} Six families, five symptoms, four purposes, four
              named outbreaks — then how to prevent, remove and verify.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(8)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to removal</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Malware types", "Six"], ["Infection signs", "Five"], ["Removal steps", "Eight"], ["Doc revision", ch13Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT MALWARE IS
================================================================== */
export function IntroSlide13() {
  return (
    <Slide tag="SEC // CH.13 // DEFINITION" num="02" title={<>What <span className="text-phos">malware</span> is</>} lede={ch13Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch13Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Three things malware does</div>
            <div className="mt-3 grid gap-px bg-sage/15">
              {[["Harm", "Disrupt normal operations"], ["Exploit", "Steal sensitive data"], ["Control", "Let attackers operate the system remotely"]].map(([h, d]) => (
                <div key={h} className="grid grid-cols-[5rem_1fr] gap-3 bg-ink p-3">
                  <span className="font-display text-[0.95rem] uppercase text-phos">{h}</span>
                  <span className="text-[12.5px] font-light text-sage/85">{d}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">
              Why it matters: malware is the payload behind most of the
              attacks in earlier chapters — botnets, ransomware, spyware,
              APTs.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · SIX TYPES
================================================================== */
export function TypesSlide13() {
  return (
    <Slide tag="SEC // CH.13 // TYPES" num="03" title={<>Six <span className="text-phos">types of malware</span></>} lede="Each family is defined by what it does once it runs. Green marks self-spreading or network-scale families; amber marks those built to steal or extort." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {malTypes.map((t, n) => (
          <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="flex flex-col bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px]" style={{ color: TONE[t.tone] }}>{t.i}</span>
              <Tag tone={t.tone === "amber" ? "amber" : t.tone === "phos" ? "phos" : "muted"}>{t.goal}</Tag>
            </div>
            <h3 className="mt-3 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 flex-1 text-[13px] font-light leading-[1.6] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · TYPE COMPARISON
================================================================== */
export function CompareSlide13() {
  return (
    <Slide tag="SEC // CH.13 // COMPARE" num="04" title={<>Type <span className="text-phos">comparison</span></>} lede="The single most useful distinction: does it need the user to do something? Only the worm spreads on its own." dense>
      <div className="overflow-x-auto">
        <div className="min-w-[680px]">
          <div className="grid grid-cols-[minmax(0,1fr)_9rem_11rem_8rem] gap-x-4 border-b border-sage/20 pb-2 font-mono text-[9.5px] tracked text-muted">
            <span>Type</span><span>Goal</span><span>How it spreads</span><span className="text-center">User action</span>
          </div>
          {malTypes.map((t, n) => (
            <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="grid grid-cols-[minmax(0,1fr)_9rem_11rem_8rem] items-center gap-x-4 border-t border-sage/10 py-3 hover:bg-phos/[0.04]">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[11px]" style={{ color: TONE[t.tone] }}>{t.i}</span>
                <span className="font-mono text-[12.5px] text-sage">{t.name}</span>
              </div>
              <span className="text-[13px] font-light text-sage/85">{t.goal}</span>
              <span className="text-[13px] font-light text-sage/85">{t.spread}</span>
              <span className="flex justify-center">
                <span className={`border px-2 py-[3px] font-mono text-[9px] tracked ${t.userAction === "Required" ? "border-sage/30 text-sage/70" : "border-amber text-amber"}`} style={{ borderRadius: 2 }}>{t.userAction}</span>
              </span>
            </motion.div>
          ))}
        </div>
      </div>
      <motion.div variants={rise} className="mt-5 grid gap-px bg-sage/15 sm:grid-cols-2">
        <div className="bg-panel/70 p-4">
          <div className="font-mono text-[9.5px] tracked text-phos">Worm vs. virus</div>
          <p className="mt-1.5 text-[12.5px] font-light leading-[1.55] text-muted">A virus attaches to a host file and needs it to be run. A worm is standalone and moves across the network by itself.</p>
        </div>
        <div className="bg-panel/70 p-4">
          <div className="font-mono text-[9.5px] tracked text-amber">Trojan vs. everything else</div>
          <p className="mt-1.5 text-[12.5px] font-light leading-[1.55] text-muted">A Trojan is defined by its disguise, not its payload. Spyware, ransomware or a bot client can all arrive inside one.</p>
        </div>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   05 · SIGNS OF INFECTION
================================================================== */
export function SignsSlide13() {
  return (
    <Slide tag="SEC // CH.13 // SYMPTOMS" num="05" title={<>Signs your device is <span className="text-phos">infected</span></>} lede="Common indicators include poor performance, unexpected browser redirects, fake infection warnings, startup/shutdown problems and persistent pop-up ads." dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {signs.map((s, n) => (
            <Row key={s.i} i={s.i} label={s.name} desc={s.desc} meta={s.hint} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">The trap inside a symptom</div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">
              Sign 03 is a symptom that is also an attack. A pop-up that says
              "you are infected — buy this fix" is the infection. Never install
              the tool a warning offers you; open your own scanner instead.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · PURPOSE
================================================================== */
export function PurposeSlide13() {
  return (
    <Slide tag="SEC // CH.13 // MOTIVE" num="06" title={<>Purpose of <span className="text-phos">malware attacks</span></>} lede="Cybercriminals use malware — including all forms of malicious software, viruses among them — for a handful of recurring purposes." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {purposes.map((p, n) => (
          <motion.div key={p.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n < 2 ? TONE.amber : TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n < 2 ? TONE.amber : TONE.phos }}>Purpose {p.i}</span>
            <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-6 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[9.5px] tracked text-muted">
        <span className="flex items-center gap-2"><span className="inline-block h-2 w-5 bg-amber" /> Steal from the victim</span>
        <span className="flex items-center gap-2"><span className="inline-block h-2 w-5 bg-phos" /> Use the victim's machine against others</span>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   07 · REAL-WORLD EXAMPLES
================================================================== */
export function ExamplesSlide13() {
  return (
    <Slide tag="SEC // CH.13 // CASES" num="07" title={<>Real-world <span className="text-phos">examples</span></>} lede="Four named specimens, one per family, showing how malware has affected systems, organizations and individuals." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {examples.map((x, n) => (
          <motion.div key={x.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[x.tone] }}>
            <div className="p-5">
              <div className="flex items-center justify-between">
                <Tag tone={x.tone === "amber" ? "amber" : x.tone === "phos" ? "phos" : "muted"}>{x.type}</Tag>
                <span className="font-mono text-[10px] text-muted">{x.year}</span>
              </div>
              <h3 className="mt-3 font-display text-[1.5rem] uppercase leading-none tracking-tight text-sage">{x.name}</h3>
            </div>
            <p className="flex-1 border-t border-sage/15 bg-ink p-4 text-[12.5px] font-light leading-[1.6] text-sage/85">{x.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · PROTECTION
================================================================== */
export function ProtectionSlide13() {
  return (
    <Slide tag="SEC // CH.13 // PROTECTION" num="08" title={<>Protection against <span className="text-phos">malware</span></>} lede="Organised by the way malware arrives. Close each entry point and most infections never happen." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {protection.map((p, n) => (
          <motion.div key={p.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="flex flex-col bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{p.i}</span>
              <span className="border border-phos/50 px-1.5 py-[2px] font-mono text-[9px] tracked text-phos" style={{ borderRadius: 2 }}>✓</span>
            </div>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.vector}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
          </motion.div>
        ))}
        <motion.div variants={rise} className="bg-panel/70 p-5">
          <div className="font-mono text-[9.5px] tracked text-amber">Entry points covered</div>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Email", "Web", "Unpatched software", "USB", "Pop-ups", "App stores"].map((t) => (
              <Tag key={t} tone="muted">{t}</Tag>
            ))}
          </div>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · REMOVAL STEPS
================================================================== */
export function RemovalSlide13() {
  return (
    <Slide tag="SEC // CH.13 // REMOVAL" num="09" title={<>Steps to <span className="text-phos">remove malware</span></>} lede="An eight-step procedure using a trusted anti-malware scanner. The order matters: update before you scan, quarantine before you delete, verify after you reboot." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {removal.map((r, n) => (
            <motion.div key={r.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.05 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 w-9 items-center justify-center border bg-ink font-mono text-[12px]" style={{ borderColor: n === 7 ? TONE.amber : TONE.phos, color: n === 7 ? TONE.amber : TONE.phos, borderRadius: 2 }}>{r.i}</span>
              </div>
              <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{r.name}</h3>
              <p className="mt-2 text-[12.5px] font-light leading-[1.5] text-muted">{r.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · TOOLS
================================================================== */
export function ToolsSlide13() {
  return (
    <Slide tag="SEC // CH.13 // TOOLS" num="10" title={<>Tools used to <span className="text-phos">remove malware</span></>} lede="Six commonly used free scanners and what each is best at." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="flex flex-col bg-ink p-5">
            <div className="flex items-start justify-between gap-3">
              <h3 className="font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              <span className="font-mono text-[11px] text-phos/70">{String(n + 1).padStart(2, "0")}</span>
            </div>
            <div className="mt-1.5 font-mono text-[9.5px] tracked text-amber/80">{t.platform}</div>
            <p className="mt-2.5 flex-1 text-[13px] font-light leading-[1.6] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide13({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 6 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.13 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Classify the specimen.
          <br />
          <span className="text-phos glow">Then disinfect.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Six items covering ransomware, worms, Trojans, infection signs,
          protection and keyloggers. Select an answer to reveal it instantly —
          the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(11)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   12–17 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide13({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions13[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.13 // CHECK // Q0${n + 1}`} num={String(12 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 06</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Malware"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   18 · SCORE
================================================================== */
export function ScoreSlide13({ answers }: { answers: (number | null)[] }) {
  const score = questions13.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions13.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every specimen classified." : pct >= 60 ? "Solid. Re-read the type comparison for the family you missed." : "Revisit the six types and the signs of infection, then retake.";
  return (
    <Slide tag="SEC // CH.13 // CHECK // RESULT" num="18" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions13.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions13.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions13.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide13() {
  const items = [
    ["01", "Malware is the payload", "Botnets, ransomware, spyware and APTs from earlier chapters all run on malicious code."],
    ["02", "Classify by behaviour", "Spy, extort, advertise, disguise, replicate, enlist — six families, six verbs."],
    ["03", "Only the worm moves alone", "Every other family needs a click, an install or a plug-in. That is where prevention works."],
    ["04", "Symptoms can be attacks", "A pop-up offering to fix an infection is the infection. Use your own scanner."],
    ["05", "Named outbreaks teach scale", "WannaCry hit hospitals, Stuxnet broke centrifuges, Pegasus read journalists' phones."],
    ["06", "Update → scan → quarantine → verify", "Removal is a procedure, not a button. Confirm the system is clean after the reboot."],
  ];
  return (
    <Slide tag="SEC // CH.13 // CLOSE" num="19" title={<>Chapter 13 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 13 · Malware &amp; its types</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents13.length} sections · {TOTAL13} slides</span>
      </div>
    </Slide>
  );
}
