import { useEffect, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import pay from "./assets/pay.jpg";
import iot from "./assets/iot.jpg";
import {
  applications,
  availability,
  ciaBullets,
  ciaIntro,
  ciaStamp,
  confidentiality,
  contents3,
  integrity,
  matrix,
  questions3,
  tools,
  TOTAL3,
} from "./data/ch3";

/* ==================================================================
   01 · TITLE
================================================================== */
export function TitleSlide3({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <img
        src={pay}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.45]"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_18%_50%,rgba(11,15,13,0.97)_25%,rgba(11,15,13,0.7)_65%,rgba(11,15,13,0.92)_100%)]" />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Unclassified · Lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 03 of 16
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.03&nbsp;//&nbsp;APPLICATIONS
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL3}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-9">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-phos"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 03
              </span>
              <span className="mt-1 block text-[clamp(2.4rem,7vw,6rem)] text-phos glow">
                Applications of
                <br />
                Cybersecurity
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              Where security actually meets daily life — personal data,
              payments, browsing, devices, email and social accounts — followed
              by the tooling that backs it and a working demonstration of how
              hash functions prove integrity.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(8)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Jump to the hash lab
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-3 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-80" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Applications", "Six domains"],
            ["Tools listed", "Seven"],
            ["Pillars", "C · I · A"],
            ["Lab", "SHA-256 integrity"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · APPLICATIONS — INDEX
================================================================== */
export function ApplicationsIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.03 // APPLICATIONS"
      num="02"
      title={
        <>
          Applications of{" "}
          <span className="text-phos">cybersecurity</span>
        </>
      }
      lede="Six places where the principles of Chapter 01 show up as shipped, working protection."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {applications.map((a) => (
              <Row key={a.i} i={a.i} label={a.name} desc={a.intro} meta={a.tag} />
            ))}
          </div>
        </div>
        <aside className="lg:col-span-4">
          <div
            className="relative overflow-hidden border border-sage/15"
            style={{ borderRadius: 2 }}
          >
            <img
              src={iot}
              alt="Smart-home devices on a dark shelf, status LEDs glowing green"
              className="h-[220px] w-full object-cover opacity-85 md:h-[250px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/35 to-transparent" />
            <span className="absolute bottom-3 left-3 right-3 font-mono text-[9.5px] tracked text-phos">
              Fig. 02 — The everyday attack surface
            </span>
          </div>
          <Panel className="mt-4 p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Read a card like this
            </div>
            <ul className="mt-3 space-y-2.5">
              {[
                ["Threat", "what it stops"],
                ["Mechanism", "how it stops it"],
                ["Example", "where you have seen it"],
              ].map(([k, v]) => (
                <li key={k} className="flex items-baseline justify-between gap-3">
                  <span className="font-mono text-[10.5px] tracked-sm text-sage">
                    {k}
                  </span>
                  <span className="text-right text-[11.5px] font-light text-muted">
                    {v}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 / 04 · APPLICATION DETAIL CARDS
================================================================== */
function AppCard({ a, n }: { a: (typeof applications)[number]; n: number }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.4, delay: n * 0.08, ease: "easeOut" },
        },
      }}
      className="flex flex-col border border-sage/15 bg-panel/50 p-5 transition-colors duration-200 hover:border-phos/45"
      style={{ borderRadius: 2 }}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="font-display text-[2rem] leading-none text-phos/85">
          {a.i}
        </span>
        <span
          className="border border-sage/30 px-2 py-1 font-mono text-[9px] tracked text-muted"
          style={{ borderRadius: 2 }}
        >
          {a.tag}
        </span>
      </div>

      <h3 className="mt-4 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
        {a.name}
      </h3>
      <p className="mt-3 text-[13.5px] font-light leading-[1.62] text-muted">
        {a.intro}
      </p>

      <div className="mt-4 border-t border-sage/15 pt-3.5">
        <div className="font-mono text-[9.5px] tracked text-phos">Uses</div>
        <ul className="mt-2.5 space-y-2">
          {a.uses.map((u) => (
            <li
              key={u}
              className="flex items-start gap-2.5 text-[13px] font-light leading-[1.55] text-sage/85"
            >
              <span className="mt-[8px] h-px w-3 shrink-0 bg-phos/70" />
              {u}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-4 border-l-2 border-amber pl-4">
        <div className="font-mono text-[9px] tracked text-amber">Example</div>
        <p className="mt-1.5 text-[13px] font-light italic leading-[1.55] text-amber/90">
          {a.example}
        </p>
      </div>
    </motion.div>
  );
}

export function ApplicationsDetailA() {
  return (
    <Slide
      tag="SEC // CH.03 // APPLICATIONS 01–03"
      num="03"
      title={
        <>
          Data, payments &amp;{" "}
          <span className="text-phos">browsing</span>
        </>
      }
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {applications.slice(0, 3).map((a, n) => (
          <AppCard key={a.i} a={a} n={n} />
        ))}
      </div>
    </Slide>
  );
}

export function ApplicationsDetailB() {
  return (
    <Slide
      tag="SEC // CH.03 // APPLICATIONS 04–06"
      num="04"
      title={
        <>
          Devices, email &amp;{" "}
          <span className="text-phos">social accounts</span>
        </>
      }
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {applications.slice(3).map((a, n) => (
          <AppCard key={a.i} a={a} n={n} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · KEY TOOLS & TECHNOLOGIES
================================================================== */
export function ToolsSlide() {
  return (
    <Slide
      tag="SEC // CH.03 // TOOLKIT"
      num="05"
      title={
        <>
          Key cybersecurity{" "}
          <span className="text-phos">tools &amp; technologies</span>
        </>
      }
      lede="Seven capability areas that back the six applications — from absorbing traffic floods to writing the policy that makes it all enforceable."
      dense
    >
      <div className="border-b border-sage/15">
        {tools.map((t, n) => (
          <motion.div
            key={t.i}
            variants={{
              hidden: { opacity: 0, y: 8 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.34, delay: n * 0.05, ease: "easeOut" },
              },
            }}
            className="group grid grid-cols-[3rem_minmax(0,1fr)] items-start gap-x-4 border-t border-sage/15 py-4 transition-colors duration-200 hover:bg-phos/[0.045] md:grid-cols-[3.5rem_minmax(0,1fr)_auto] md:gap-x-6"
          >
            <span
              className="flex h-9 w-9 items-center justify-center border border-phos/50 font-mono text-[12px] text-phos transition-colors group-hover:bg-phos group-hover:text-ink"
              style={{ borderRadius: 2 }}
            >
              {t.i}
            </span>
            <div className="min-w-0">
              <div className="font-mono text-[13px] font-medium tracked-sm text-sage">
                {t.name}
              </div>
              <p className="mt-1.5 text-[13.5px] font-light leading-[1.55] text-muted">
                {t.desc}
              </p>
            </div>
            <span className="col-start-2 mt-2 font-mono text-[9.5px] tracked text-phos/60 md:col-start-3 md:mt-1 md:text-right">
              {t.cat}
            </span>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · UNDERSTANDING THE CIA TRIAD
================================================================== */
export function CiaIntroSlide() {
  return (
    <Slide
      tag="SEC // CH.03 // CIA/INTRO"
      num="06"
      title={
        <>
          Understanding the{" "}
          <span className="text-phos">CIA Triad</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="border-y border-phos/45 py-5">
            <p className="max-w-[92ch] text-[clamp(1rem,1.35vw,1.25rem)] font-light leading-[1.62] text-sage">
              {ciaIntro}
            </p>
          </div>

          <div className="mt-6 border-b border-sage/15">
            {ciaBullets.map((b, n) => (
              <motion.div
                key={b}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: n * 0.07 },
                  },
                }}
                className="grid grid-cols-[2.1rem_minmax(0,1fr)] gap-x-4 border-t border-sage/15 py-3.5"
              >
                <span className="font-mono text-[11px] text-phos/70">
                  {String(n + 1).padStart(2, "0")}
                </span>
                <span className="text-[14px] font-light leading-[1.55] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-muted">
              Course reference note
            </span>
            <span className="font-mono text-[9.5px] tracked text-phos/70">
              {ciaStamp}
            </span>
          </div>
        </div>

        <div className="lg:col-span-5">
          <Panel className="p-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="font-mono text-[9.5px] tracked text-phos">
                  The three goals
                </div>
                <p className="mt-2 max-w-[34ch] text-[13px] font-light leading-[1.55] text-muted">
                  Confidential, accurate, accessible — and the sections that
                  follow take each one apart.
                </p>
              </div>
              <TriadSeal className="h-[112px] w-[122px] shrink-0 opacity-90" />
            </div>

            <div className="mt-5 space-y-0 border-t border-sage/15">
              {[
                ["C", "Confidentiality", "only authorized eyes"],
                ["I", "Integrity", "accurate and unaltered"],
                ["A", "Availability", "reachable when needed"],
              ].map(([k, n, d]) => (
                <div
                  key={k}
                  className="flex items-center gap-4 border-b border-sage/15 py-3 last:border-b-0"
                >
                  <span className="font-display text-[1.5rem] leading-none text-phos">
                    {k}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="font-mono text-[11.5px] tracked-sm text-sage">
                      {n}
                    </div>
                    <div className="mt-0.5 text-[12px] font-light text-muted">
                      {d}
                    </div>
                  </div>
                  <span className="font-mono text-[9px] tracked text-phos/60">
                    0{k === "C" ? 1 : k === "I" ? 2 : 3}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Pillar slide shell — risks (amber) vs controls (phosphor)
================================================================== */
function PillarSlide({
  tag,
  num,
  title,
  def,
  risks,
  fixes,
  footer,
}: {
  tag: string;
  num: string;
  title: ReactNode;
  def: string;
  risks: string[][];
  fixes: string[][];
  footer?: ReactNode;
}) {
  return (
    <Slide tag={tag} num={num} title={title} dense>
      <div className="border-y border-phos/45 py-5">
        <p className="max-w-[96ch] text-[clamp(0.95rem,1.25vw,1.15rem)] font-light leading-[1.65] text-sage">
          {def}
        </p>
      </div>

      <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="flex items-baseline justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-amber">
              Risks
            </span>
            <span className="font-mono text-[9.5px] tracked text-muted">
              {String(risks.length).padStart(2, "0")} identified
            </span>
          </div>
          <div className="mt-3 border-b border-sage/15">
            {risks.map(([k, v], n) => (
              <motion.div
                key={k}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: n * 0.06 },
                  },
                }}
                className="border-t border-sage/15 py-3.5"
              >
                <div className="flex items-start gap-3">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-amber" />
                  <div className="min-w-0">
                    <div className="font-mono text-[12.5px] tracked-sm text-amber/95">
                      {k}
                    </div>
                    <p className="mt-1.5 text-[13.5px] font-light leading-[1.6] text-muted">
                      {v}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="flex items-baseline justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-phos">
              How it is ensured
            </span>
            <span className="font-mono text-[9.5px] tracked text-muted">
              {String(fixes.length).padStart(2, "0")} controls
            </span>
          </div>
          <div className="mt-3 border-b border-sage/15">
            {fixes.map(([k, v], n) => (
              <motion.div
                key={k}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: 0.06 + n * 0.06 },
                  },
                }}
                className="grid grid-cols-1 gap-x-6 border-t border-sage/15 py-3.5 transition-colors duration-200 hover:bg-phos/[0.045] sm:grid-cols-[9.5rem_minmax(0,1fr)]"
              >
                <span className="font-mono text-[12.5px] font-medium tracked-sm text-phos">
                  {k}
                </span>
                <p className="mt-1.5 text-[13.5px] font-light leading-[1.6] text-sage/85 sm:mt-0">
                  {v}
                </p>
              </motion.div>
            ))}
          </div>
          {footer}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · CONFIDENTIALITY
================================================================== */
export function ConfidentialitySlide() {
  return (
    <PillarSlide
      tag="SEC // CH.03 // CIA/CONFIDENTIALITY"
      num="07"
      title={
        <>
          Confidentiality — <span className="text-phos">only authorized eyes</span>
        </>
      }
      def={confidentiality.def}
      risks={confidentiality.risks}
      fixes={confidentiality.fixes}
      footer={
        <div className="mt-5 flex flex-wrap gap-2.5">
          {["AES", "RSA", "avoid DES", "TLS tunnel", "MFA", "least privilege"].map(
            (t) => (
              <span
                key={t}
                className="border border-sage/25 px-2.5 py-1.5 font-mono text-[10px] tracked text-sage/85"
                style={{ borderRadius: 2 }}
              >
                {t}
              </span>
            ),
          )}
        </div>
      }
    />
  );
}

/* ==================================================================
   08 · INTEGRITY
================================================================== */
export function IntegritySlide() {
  return (
    <PillarSlide
      tag="SEC // CH.03 // CIA/INTEGRITY"
      num="08"
      title={
        <>
          Integrity — <span className="text-phos">accurate and unaltered</span>
        </>
      }
      def={integrity.def}
      risks={integrity.risks}
      fixes={integrity.fixes}
      footer={
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          {integrity.hashes.map(([k, v]) => (
            <div
              key={k}
              className="border border-phos/35 bg-deep/25 p-4"
              style={{ borderRadius: 2 }}
            >
              <div className="font-display text-[1.1rem] uppercase text-phos">
                {k}
              </div>
              <p className="mt-2 text-[13px] font-light leading-[1.55] text-muted">
                {v}
              </p>
            </div>
          ))}
        </div>
      }
    />
  );
}

/* ==================================================================
   09 · HASH FUNCTIONS IN ACTION — live SHA-256 lab
================================================================== */
async function digest(
  text: string,
): Promise<{ hash: string; algo: string }> {
  const subtle = globalThis.crypto?.subtle;
  if (subtle && typeof subtle.digest === "function") {
    try {
      const buf = await subtle.digest(
        "SHA-256",
        new TextEncoder().encode(text),
      );
      return {
        hash: Array.from(new Uint8Array(buf))
          .map((b) => b.toString(16).padStart(2, "0"))
          .join(""),
        algo: "SHA-256",
      };
    } catch {
      /* fall through to the offline fallback */
    }
  }
  let a = 0x811c9dc5;
  let b = 0x01000193;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    a = Math.imul(a ^ c, 0x01000193) >>> 0;
    b = Math.imul(b ^ ((c + i) & 0xff), 0x85ebca6b) >>> 0;
    b = ((b << 13) | (b >>> 19)) >>> 0;
  }
  const h =
    a.toString(16).padStart(8, "0") + b.toString(16).padStart(8, "0");
  return { hash: h.repeat(4), algo: "FNV hybrid · SHA-256 unavailable" };
}

function flipChar(s: string): string {
  if (!s.length) return s;
  const i = Math.floor(Math.random() * s.length);
  const c = s[i];
  let nc: string;
  if (/[0-9]/.test(c)) nc = c === "9" ? "8" : String((Number(c) + 1) % 10);
  else if (/[a-z]/.test(c)) nc = c === "z" ? "a" : String.fromCharCode(c.charCodeAt(0) + 1);
  else nc = c === "." ? "," : ".";
  return s.slice(0, i) + nc + s.slice(i + 1);
}

/* Declared at module scope on purpose: an inline component would be a new
   type on every render and the input would lose focus on each keystroke. */
function HashField({
  label,
  who,
  value,
  onChange,
}: {
  label: string;
  who: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <span className="font-mono text-[9.5px] tracked text-phos">{label}</span>
        <span className="font-mono text-[9.5px] tracked text-muted">{who}</span>
      </div>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-label={label}
        spellCheck={false}
        className="mt-2 w-full border border-sage/25 bg-[#060A08] px-3 py-2.5 font-mono text-[13px] text-sage caret-phos outline-none transition-colors focus:border-phos"
        style={{ borderRadius: 2 }}
      />
    </div>
  );
}

function HashLab() {
  const DEFAULT = "Transfer 100 USD to Alice";
  const [sent, setSent] = useState(DEFAULT);
  const [recv, setRecv] = useState(DEFAULT);
  const [h1, setH1] = useState<{ hash: string; algo: string } | null>(null);
  const [h2, setH2] = useState<{ hash: string; algo: string } | null>(null);

  useEffect(() => {
    let alive = true;
    digest(sent).then((r) => alive && setH1(r));
    digest(recv).then((r) => alive && setH2(r));
    return () => {
      alive = false;
    };
  }, [sent, recv]);

  const match = !!h1 && !!h2 && h1.hash === h2.hash;
  let diff = -1;
  if (!match && h1 && h2) {
    for (let i = 0; i < Math.min(h1.hash.length, h2.hash.length); i++) {
      if (h1.hash[i] !== h2.hash[i]) {
        diff = i;
        break;
      }
    }
    if (diff < 0) diff = Math.min(h1.hash.length, h2.hash.length);
  }

  return (
    <div
      className="border border-phos/40 bg-panel/55 p-5"
      style={{ borderRadius: 2 }}
    >
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <span className="font-mono text-[9.5px] tracked text-phos">
          Live hash lab · {h1?.algo ?? "…"}
        </span>
        <span className="font-mono text-[9.5px] tracked text-muted">
          edit either side
        </span>
      </div>

      <div className="mt-4 space-y-4">
        <HashField
          label="H1 — Host A payload"
          who="transmitted"
          value={sent}
          onChange={setSent}
        />
        <div
          className={`break-all border px-3 py-2.5 font-mono text-[10.5px] leading-[1.5] ${
            match
              ? "border-phos/40 bg-deep/30 text-phos/90"
              : "border-amber/40 bg-amber/[0.07] text-amber"
          }`}
          style={{ borderRadius: 2 }}
        >
          {h1 ? h1.hash : "computing…"}
        </div>

        <div className="flex items-center gap-3">
          <span className="h-px flex-1 bg-sage/20" />
          <span className="font-mono text-[9.5px] tracked text-muted">
            transmit
          </span>
          <span className="h-px flex-1 bg-sage/20" />
        </div>

        <HashField
          label="H2 — Host B received payload"
          who="after transit"
          value={recv}
          onChange={setRecv}
        />
        <div
          className={`break-all border px-3 py-2.5 font-mono text-[10.5px] leading-[1.5] ${
            match
              ? "border-phos/40 bg-deep/30 text-phos/90"
              : "border-amber/40 bg-amber/[0.07] text-amber"
          }`}
          style={{ borderRadius: 2 }}
        >
          {h2 ? h2.hash : "computing…"}
        </div>
      </div>

      <div
        className={`mt-4 border-l-2 p-3.5 ${
          match ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
        }`}
      >
        <div
          className={`font-mono text-[10px] tracked ${
            match ? "text-phos" : "text-amber"
          }`}
        >
          {match ? "H1 = H2" : "H1 ≠ H2"}
        </div>
        <p className="mt-1.5 text-[13.5px] font-light leading-[1.55] text-sage/90">
          {match
            ? "The data is unchanged — integrity preserved."
            : `The data was altered or corrupted — first hash difference at index ${diff}.`}
        </p>
      </div>

      <div className="mt-4 flex flex-wrap gap-2.5">
        <button
          onClick={() => setRecv((r) => flipChar(r))}
          className="border border-amber/60 px-3 py-2 font-mono text-[10px] tracked text-amber transition-colors hover:bg-amber hover:text-ink"
          style={{ borderRadius: 2 }}
        >
          Tamper with one character
        </button>
        <button
          onClick={() => {
            setSent(DEFAULT);
            setRecv(DEFAULT);
          }}
          className="border border-sage/25 px-3 py-2 font-mono text-[10px] tracked text-sage transition-colors hover:border-phos hover:text-phos"
          style={{ borderRadius: 2 }}
        >
          Reset
        </button>
      </div>
    </div>
  );
}

export function HashSlide() {
  return (
    <Slide
      tag="SEC // CH.03 // INTEGRITY/HASH"
      num="09"
      title={
        <>
          Hash functions{" "}
          <span className="text-phos">in action</span>
        </>
      }
      lede="How Integrity is proven across a network: hash the payload on both sides, then compare the two values."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Working of hash functions
          </div>
          <div className="mt-3 border-b border-sage/15">
            {integrity.steps.map(([k, v], n) => (
              <motion.div
                key={k}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: n * 0.07 },
                  },
                }}
                className="grid grid-cols-[2.4rem_minmax(0,1fr)] gap-x-4 border-t border-sage/15 py-3.5"
              >
                <span
                  className={`flex h-7 w-7 items-center justify-center border font-mono text-[11px] ${
                    n === 3
                      ? "border-amber/70 text-amber"
                      : "border-phos/60 text-phos"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  {n + 1}
                </span>
                <div className="min-w-0">
                  <div className="font-mono text-[12.5px] tracked-sm text-sage">
                    {k}
                  </div>
                  <p className="mt-1.5 text-[13.5px] font-light leading-[1.6] text-muted">
                    {v}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-5 border-l-2 border-amber pl-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Note</div>
            <p className="mt-2 max-w-[62ch] text-[14px] font-light italic leading-[1.6] text-amber/90">
              {integrity.note}
            </p>
          </div>
        </div>

        <div className="lg:col-span-7">
          <HashLab />
          <p className="mt-4 max-w-[80ch] text-[13.5px] font-light leading-[1.6] text-muted">
            Change a single character on either side and the entire digest
            changes — that avalanche effect is exactly what makes a hash
            trustworthy as an integrity check.
          </p>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · AVAILABILITY
================================================================== */
export function AvailabilitySlide() {
  return (
    <PillarSlide
      tag="SEC // CH.03 // CIA/AVAILABILITY"
      num="10"
      title={
        <>
          Availability — <span className="text-phos">reachable when needed</span>
        </>
      }
      def={availability.def}
      risks={availability.risks}
      fixes={availability.fixes}
      footer={
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          {["99.9%", "failover", "no bottleneck"].map((t) => (
            <div
              key={t}
              className="border border-phos/30 bg-deep/25 px-3 py-2.5 text-center font-mono text-[11px] tracked text-phos"
              style={{ borderRadius: 2 }}
            >
              {t}
            </div>
          ))}
        </div>
      }
    />
  );
}

/* ==================================================================
   11 · RISK & CONTROL MATRIX
================================================================== */
export function MatrixSlide() {
  return (
    <Slide
      tag="SEC // CH.03 // CIA/MATRIX"
      num="11"
      title={
        <>
          Risk &amp; control <span className="text-phos">matrix</span>
        </>
      }
      lede="Every threat in this chapter lands on exactly one pillar — and every control on this table answers one back."
      dense
    >
      <div
        className="overflow-x-auto border border-sage/20 bg-panel/45"
        style={{ borderRadius: 2 }}
      >
        <table className="w-full min-w-[760px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              {["Pillar", "Primary risks", "Primary controls"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 font-mono text-[9.5px] tracked text-phos"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {matrix.map((m) => (
              <tr
                key={m.name}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-5">
                  <div className="flex items-center gap-3">
                    <span className="font-display text-[1.7rem] leading-none text-phos glow">
                      {m.pillar}
                    </span>
                    <span className="font-mono text-[12.5px] tracked-sm text-sage">
                      {m.name}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-5 text-[13.5px] font-light leading-[1.6] text-amber/90">
                  {m.risk}
                </td>
                <td className="px-4 py-5 text-[13.5px] font-light leading-[1.6] text-sage/85">
                  {m.control}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {[
          ["Confidentiality", "who may see it"],
          ["Integrity", "whether it changed"],
          ["Availability", "whether it is there"],
        ].map(([k, v]) => (
          <div key={k} className="border-l-2 border-phos/60 pl-4">
            <div className="font-mono text-[11.5px] tracked-sm text-phos">
              {k}
            </div>
            <div className="mt-1 font-display text-[13px] uppercase tracking-tight text-sage/85">
              {v}
            </div>
          </div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide3({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 6 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">
          Sec // CH.03 // Check
        </span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Six questions.
          <br />
          <span className="text-phos glow">Pillar by pillar.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Applications, tooling and the CIA Triad in depth. Select an answer to
          reveal it instantly — the rationale appears underneath and your
          running score is kept in the footer.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(12)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   13–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide3({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions3[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.03 // CHECK // Q0${n + 1}`}
      num={String(13 + n)}
      title={
        <>
          Question{" "}
          <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 06</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              [
                "Status",
                !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect",
              ],
              ["Domain", "CIA Triad"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex items-baseline justify-between border-t border-sage/15 pt-2.5"
              >
                <span className="font-mono text-[9.5px] tracked text-muted">
                  {k}
                </span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.06 },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide3({ answers }: { answers: (number | null)[] }) {
  const score = questions3.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions3.length) * 100);
  const verdict =
    pct === 100
      ? "Applications, tooling and all three pillars — clean sweep."
      : pct >= 60
        ? "Good. Re-read the pillar that caught you out."
        : "Revisit Confidentiality, Integrity and Availability, then retake.";

  return (
    <Slide
      tag="SEC // CH.03 // CHECK // RESULT"
      num="19"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div
            className="border border-phos/40 bg-panel/60 p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions3.length}
              </span>
            </div>
            <div
              className="mt-5 h-2 w-full bg-sage/12"
              style={{ borderRadius: 2 }}
            >
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions3.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions3.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.05 },
                    },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide3() {
  const items = [
    ["01", "Security is a product feature now", "Banking, payments, browsing, devices, email and social accounts all ship with it built in."],
    ["02", "Six applications, one toolkit", "WAF, bot protection, DDoS absorption, antivirus and threat management back all six."],
    ["03", "CIA is the checklist", "Every control on the tool list answers a confidentiality, integrity or availability risk."],
    ["04", "Weak crypto is a confidentiality risk", "AES and RSA hold; DES and stale algorithms do not. Encryption plus access control plus VPN."],
    ["05", "Hashing proves integrity", "H1 = H2 means untouched; a single changed character destroys the match."],
    ["06", "Availability is operational", "Maintenance, upgrades, failover planning and traffic management — not a single server."],
  ];

  return (
    <Slide
      tag="SEC // CH.03 // CLOSE"
      num="20"
      title={
        <>
          Chapter 03 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-phos/70">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 03 · Applications of Cybersecurity
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents3.length} sections · {TOTAL3} slides
        </span>
      </div>
    </Slide>
  );
}
