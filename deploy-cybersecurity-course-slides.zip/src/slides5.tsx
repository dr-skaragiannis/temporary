import { useState } from "react";
import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import chair from "./assets/chair.jpg";
import iot from "./assets/iot.jpg";
import {
  certs,
  ch5Bullets,
  ch5Intro,
  ch5Stamp,
  contents5,
  devices,
  devicesExtra,
  hardening,
  hats,
  insiderControls,
  insiderSignals,
  insiderTypes,
  methodology,
  otherHackers,
  primaryLead,
  prevention,
  questions5,
  roles,
  spectrum,
  teams,
  TOTAL5,
} from "./data/ch5";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE
================================================================== */
export function TitleSlide5({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <img
        src={chair}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.42]"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_15%_50%,rgba(11,15,13,0.97)_25%,rgba(11,15,13,0.7)_65%,rgba(11,15,13,0.92)_100%)]" />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Threat briefing · lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 05 of 16
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.05&nbsp;//&nbsp;HACKERS
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL5}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-9">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-amber"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 05
              </span>
              <span className="mt-1 block text-[clamp(2.4rem,7vw,6rem)] text-phos glow">
                Hackers and
                <br />
                Their Types
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              {ch5Intro} Three primary hats, seven more categories, the devices
              attackers reach for first, and the defences that stop them — plus
              an interactive spectrum that separates intent from authorization.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(2)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Open the hacker spectrum
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-3 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Primary hats", "Three"],
            ["Other types", "Seven"],
            ["Most targeted device", "Smart devices"],
            ["Doc revision", "12 Jun 2026"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT A HACKER IS
================================================================== */
export function IntroSlide5() {
  return (
    <Slide
      tag="SEC // CH.05 // DEFINITION"
      num="02"
      title={
        <>
          Hackers and <span className="text-phos">their types</span>
        </>
      }
      dense
    >
      <div className="border-y border-phos/45 py-5 md:py-6">
        <p className="max-w-[96ch] text-[clamp(1rem,1.35vw,1.25rem)] font-light leading-[1.62] text-sage">
          {ch5Intro}
        </p>
      </div>

      <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="font-mono text-[9.5px] tracked text-phos">
            What defines the activity
          </div>
          <div className="mt-3 grid gap-px bg-sage/15 sm:grid-cols-2">
            {ch5Bullets.map((b, n) => (
              <motion.div
                key={b}
                variants={{
                  hidden: { opacity: 0, y: 10 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.36, delay: n * 0.07 },
                  },
                }}
                className="flex items-start gap-3 bg-ink p-4"
              >
                <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-amber" />
                <span className="text-[13.5px] font-light leading-[1.6] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-sage/20 pt-4">
            <span className="font-mono text-[9.5px] tracked text-muted">
              Section 01 · the people behind the attack
            </span>
            <span className="font-mono text-[9.5px] tracked text-amber/80">
              {ch5Stamp}
            </span>
          </div>
        </div>

        <aside className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Extension · hacker vs cracker
            </div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
              Inside the computing community,{" "}
              <span className="text-phos">hacker</span> has always meant someone
              who builds clever things and pushes systems past their stated
              limits. The malicious role is properly a{" "}
              <span className="text-amber">cracker</span>. Popular media merged
              the two — so in security documentation “hacker” now covers both,
              and the hat colour is what tells you which is meant.
            </p>
            <div className="mt-4 h-px w-full bg-sage/15" />
            <div className="mt-4 font-mono text-[9.5px] tracked text-phos">
              Rule of thumb
            </div>
            <p className="mt-2 text-[13px] font-light leading-[1.6] text-sage/85">
              Ask two questions of any actor:{" "}
              <span className="text-sage">were they authorized?</span> and{" "}
              <span className="text-sage">what was the intent?</span> Skill and
              toolset are identical across all three hats.
            </p>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · THE HACKER SPECTRUM — interactive two-axis plot
================================================================== */
const LABEL: Record<string, { dx: number; dy: number; a: "start" | "middle" | "end" }> = {
  black: { dx: 0, dy: 32, a: "middle" },
  white: { dx: 0, dy: -26, a: "middle" },
  gray: { dx: 0, dy: 30, a: "middle" },
  script: { dx: 0, dy: 26, a: "middle" },
  green: { dx: 0, dy: 26, a: "middle" },
  blue: { dx: 0, dy: -24, a: "middle" },
  red: { dx: 20, dy: 5, a: "start" },
  state: { dx: 0, dy: -24, a: "middle" },
  hacktivist: { dx: 0, dy: -22, a: "middle" },
  insider: { dx: 0, dy: 32, a: "middle" },
};

function Spectrum() {
  const [active, setActive] = useState("black");
  const W = 560;
  const H = 420;
  const pad = { l: 68, r: 26, t: 36, b: 58 };
  const px = (x: number) => pad.l + x * (W - pad.l - pad.r);
  const py = (y: number) => H - pad.b - y * (H - pad.t - pad.b);
  const cur = spectrum.find((s) => s.key === active) ?? spectrum[0];

  return (
    <div className="grid gap-6 lg:grid-cols-12 lg:gap-8">
      <div className="lg:col-span-7">
        <div
          className="border border-sage/20 bg-panel/50 p-2"
          style={{ borderRadius: 2 }}
        >
          <svg
            viewBox={`0 0 ${W} ${H}`}
            className="h-auto w-full"
            role="img"
            aria-label="Hacker types plotted by authorization and intent"
          >
            <defs>
              <filter id="spGlow" x="-80%" y="-80%" width="260%" height="260%">
                <feGaussianBlur stdDeviation="6" result="b" />
                <feMerge>
                  <feMergeNode in="b" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* quadrant wash */}
            <rect
              x={px(0)}
              y={pad.t}
              width={px(0.5) - px(0)}
              height={py(0.5) - pad.t}
              fill="#C7D2C9"
              fillOpacity="0.02"
            />
            <rect
              x={px(0.5)}
              y={pad.t}
              width={px(1) - px(0.5)}
              height={py(0.5) - pad.t}
              fill="#3DF07A"
              fillOpacity="0.05"
            />
            <rect
              x={px(0)}
              y={py(0.5)}
              width={px(0.5) - px(0)}
              height={py(0) - py(0.5)}
              fill="#FFB020"
              fillOpacity="0.05"
            />
            <rect
              x={px(0.5)}
              y={py(0.5)}
              width={px(1) - px(0.5)}
              height={py(0) - py(0.5)}
              fill="#FFB020"
              fillOpacity="0.03"
            />

            {/* frame + dividing cross */}
            <rect
              x={pad.l}
              y={pad.t}
              width={W - pad.l - pad.r}
              height={H - pad.t - pad.b}
              fill="none"
              stroke="#C7D2C9"
              strokeOpacity="0.22"
            />
            <line
              x1={px(0.5)}
              y1={pad.t}
              x2={px(0.5)}
              y2={py(0)}
              stroke="#C7D2C9"
              strokeOpacity="0.18"
              strokeDasharray="3 5"
            />
            <line
              x1={pad.l}
              y1={py(0.5)}
              x2={px(1)}
              y2={py(0.5)}
              stroke="#C7D2C9"
              strokeOpacity="0.18"
              strokeDasharray="3 5"
            />

            {/* quadrant labels */}
            {[
              ["UNAUTHORIZED · DEFENSIVE", pad.l + 8, pad.t + 16, "start"],
              ["AUTHORIZED · DEFENSIVE", px(1) - 8, pad.t + 16, "end"],
              ["UNAUTHORIZED · OFFENSIVE", pad.l + 8, py(0) - 10, "start"],
              ["AUTHORIZED · OFFENSIVE", px(1) - 8, py(0) - 10, "end"],
            ].map(([t, x, y, a]) => (
              <text
                key={t as string}
                x={x as number}
                y={y as number}
                textAnchor={a as "start" | "end"}
                fontFamily="IBM Plex Mono, monospace"
                fontSize="8.5"
                letterSpacing="1.6"
                fill="#7E8F84"
              >
                {t as string}
              </text>
            ))}

            {/* axis captions */}
            <text
              x={(pad.l + px(1)) / 2}
              y={H - 26}
              textAnchor="middle"
              fontFamily="IBM Plex Mono, monospace"
              fontSize="9.5"
              letterSpacing="2.4"
              fill="#3DF07A"
            >
              AUTHORIZATION →
            </text>
            <text
              x={16}
              y={(pad.t + py(0)) / 2}
              textAnchor="middle"
              fontFamily="IBM Plex Mono, monospace"
              fontSize="9.5"
              letterSpacing="2.4"
              fill="#3DF07A"
              transform={`rotate(-90 16 ${(pad.t + py(0)) / 2})`}
            >
              INTENT → DEFENSIVE
            </text>

            {/* points */}
            {spectrum.map((s) => {
              const on = active === s.key;
              const L = LABEL[s.key];
              return (
                <g
                  key={s.key}
                  className="cursor-pointer"
                  tabIndex={0}
                  role="button"
                  aria-label={s.name}
                  onMouseEnter={() => setActive(s.key)}
                  onFocus={() => setActive(s.key)}
                  onClick={() => setActive(s.key)}
                >
                  <line
                    x1={px(s.x)}
                    y1={py(s.y)}
                    x2={px(s.x)}
                    y2={py(s.y) + (L.dy > 0 ? L.dy - 6 : L.dy + 6)}
                    stroke={TONE[s.tone]}
                    strokeOpacity="0.3"
                  />
                  <circle
                    cx={px(s.x)}
                    cy={py(s.y)}
                    r={on ? s.r + 4 : s.r}
                    fill={TONE[s.tone]}
                    fillOpacity={on ? 0.9 : 0.55}
                    stroke={TONE[s.tone]}
                    strokeWidth={on ? 2.4 : 1.4}
                    filter={on ? "url(#spGlow)" : undefined}
                    style={{ transition: "all .25s ease" }}
                  />
                  {s.primary && (
                    <text
                      x={px(s.x)}
                      y={py(s.y) + 4}
                      textAnchor="middle"
                      fontFamily="Archivo Black, sans-serif"
                      fontSize="11"
                      fill="#0B0F0D"
                      style={{ pointerEvents: "none" }}
                    >
                      {s.name[0]}
                    </text>
                  )}
                  <text
                    x={px(s.x) + L.dx}
                    y={py(s.y) + L.dy}
                    textAnchor={L.a}
                    fontFamily="IBM Plex Mono, monospace"
                    fontSize="10"
                    letterSpacing="1"
                    fill={on ? TONE[s.tone] : "#C7D2C9"}
                    fillOpacity={on ? 1 : 0.65}
                    style={{ pointerEvents: "none" }}
                  >
                    {s.name.toUpperCase()}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
          {[
            ["phos", "defensive intent"],
            ["sage", "mixed / cause-driven"],
            ["amber", "offensive intent"],
          ].map(([k, v]) => (
            <span key={k} className="flex items-center gap-2">
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{ background: TONE[k] }}
              />
              <span className="font-mono text-[9.5px] tracked text-muted">{v}</span>
            </span>
          ))}
        </div>
      </div>

      <div className="lg:col-span-5">
        <div
          className="border border-phos/40 bg-panel/60 p-5"
          style={{ borderRadius: 2 }}
        >
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <span
              className="font-display text-[clamp(1.15rem,2vw,1.5rem)] uppercase leading-none"
              style={{ color: TONE[cur.tone] }}
            >
              {cur.name}
            </span>
            <span
              className="border px-2 py-1 font-mono text-[9px] tracked"
              style={{
                borderRadius: 2,
                borderColor: `${TONE[cur.tone]}66`,
                color: TONE[cur.tone],
              }}
            >
              {cur.primary ? "Primary type" : "Other type"}
            </span>
          </div>
          <p className="mt-4 text-[14px] font-light leading-[1.65] text-sage/90">
            {cur.note}
          </p>

          <div className="mt-5 space-y-3 border-t border-sage/15 pt-4">
            <div>
              <div className="flex items-baseline justify-between font-mono text-[9.5px] tracked text-muted">
                <span>Authorization</span>
                <span className="text-sage tabular-nums">
                  {Math.round(cur.x * 100)}%
                </span>
              </div>
              <div className="mt-1.5 h-1.5 w-full bg-sage/15" style={{ borderRadius: 2 }}>
                <div
                  className="h-full"
                  style={{
                    width: `${cur.x * 100}%`,
                    background: TONE[cur.tone],
                  }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-baseline justify-between font-mono text-[9.5px] tracked text-muted">
                <span>Defensive intent</span>
                <span className="text-sage tabular-nums">
                  {Math.round(cur.y * 100)}%
                </span>
              </div>
              <div className="mt-1.5 h-1.5 w-full bg-sage/15" style={{ borderRadius: 2 }}>
                <div
                  className="h-full"
                  style={{
                    width: `${cur.y * 100}%`,
                    background: TONE[cur.tone],
                  }}
                />
              </div>
            </div>
          </div>

          <p className="mt-5 border-t border-sage/15 pt-4 font-mono text-[11px] leading-relaxed text-phos/80">
            The two axes are independent: a state-sponsored actor is fully
            authorized and still offensive; a malicious insider already holds
            valid access.
          </p>
        </div>
      </div>
    </div>
  );
}

export function SpectrumSlide() {
  return (
    <Slide
      tag="SEC // CH.05 // SPECTRUM"
      num="03"
      title={
        <>
          The hacker <span className="text-phos">spectrum</span>
        </>
      }
      lede="Skill and toolset are identical across every category. Two axes separate them: were they authorized, and what was the intent?"
      dense
    >
      <Spectrum />
    </Slide>
  );
}

/* ==================================================================
   04 · PRIMARY TYPES — three cards
================================================================== */
function HatCard({ h, n }: { h: (typeof hats)[number]; n: number }) {
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.42, delay: n * 0.1, ease: "easeOut" },
        },
      }}
      className="flex flex-col border bg-panel/50 p-5 transition-colors duration-200 md:p-6"
      style={{ borderRadius: 2, borderColor: `${TONE[h.tone]}55` }}
    >
      <div className="flex items-start justify-between gap-4">
        <span
          className="font-display text-[2.4rem] leading-none"
          style={{ color: TONE[h.tone] }}
        >
          {h.short.split(" ")[0]}
        </span>
        <span
          className="border px-2 py-1 font-mono text-[9px] tracked"
          style={{
            borderRadius: 2,
            borderColor: `${TONE[h.tone]}66`,
            color: TONE[h.tone],
          }}
        >
          {h.authorized}
        </span>
      </div>

      <h3 className="mt-4 font-display text-[clamp(1.05rem,1.7vw,1.3rem)] uppercase leading-tight tracking-tight text-sage">
        {h.name}
      </h3>
      <p className="mt-3 text-[14px] font-light leading-[1.65] text-muted">
        {h.intro}
      </p>

      <ul className="mt-4 space-y-2 border-t border-sage/15 pt-3.5">
        {h.bullets.map((b) => (
          <li
            key={b}
            className="flex items-start gap-2.5 text-[13.5px] font-light leading-[1.55] text-sage/85"
          >
            <span
              className="mt-[8px] h-px w-3 shrink-0"
              style={{ background: TONE[h.tone] }}
            />
            {b}
          </li>
        ))}
      </ul>

      <div
        className="mt-4 border-l-2 pl-4"
        style={{ borderColor: TONE[h.tone] }}
      >
        <div
          className="font-mono text-[9px] tracked"
          style={{ color: TONE[h.tone] }}
        >
          Example
        </div>
        <p className="mt-1.5 text-[13.5px] font-light italic leading-[1.55] text-sage/90">
          {h.example}
        </p>
      </div>

      <div className="mt-auto grid grid-cols-2 gap-3 border-t border-sage/15 pt-3.5">
        <div>
          <div className="font-mono text-[9px] tracked text-muted">Legal</div>
          <div className="mt-1 text-[12.5px] font-light text-sage/85">
            {h.legal}
          </div>
        </div>
        <div>
          <div className="font-mono text-[9px] tracked text-muted">Intent</div>
          <div className="mt-1 text-[12.5px] font-light text-sage/85">
            {h.intent}
          </div>
        </div>
      </div>
    </motion.article>
  );
}

export function PrimaryTypesSlide() {
  return (
    <Slide
      tag="SEC // CH.05 // PRIMARY-TYPES"
      num="04"
      title={
        <>
          Primary types of <span className="text-phos">hackers</span>
        </>
      }
      lede={primaryLead}
      dense
    >
      <div className="grid items-start gap-4 md:grid-cols-3">
        {hats.map((h, n) => (
          <HatCard key={h.key} h={h} n={n} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · HAT COMPARISON MATRIX
================================================================== */
const extraRows = [
  {
    name: "Red Hat",
    auth: "No",
    legal: "No — vigilantism",
    intent: "Disrupt cybercriminals",
    action: "Attacks criminal infrastructure directly",
    tone: "sage",
  },
  {
    name: "State-Sponsored",
    auth: "Yes — by a state",
    legal: "Protected by that state",
    intent: "Espionage · national security",
    action: "Coordinated cyber operations abroad",
    tone: "amber",
  },
  {
    name: "Hacktivist",
    auth: "No",
    legal: "No",
    intent: "Political or social cause",
    action: "Defaces or exposes targets to make a point",
    tone: "sage",
  },
];

export function HatMatrixSlide() {
  const rows = [
    ...hats.map((h) => ({
      name: h.short,
      auth: h.authorized,
      legal: h.legal,
      intent: h.intent,
      action: h.example.split(".")[0] + ".",
      tone: h.tone as string,
    })),
    ...extraRows,
  ];

  return (
    <Slide
      tag="SEC // CH.05 // COMPARISON"
      num="05"
      title={
        <>
          Hat comparison —{" "}
          <span className="text-phos">authorization vs intent</span>
        </>
      }
      lede="The three primary hats plus three closely related actors, compared on the two questions that define them."
      dense
    >
      <div
        className="overflow-x-auto border border-sage/20 bg-panel/45"
        style={{ borderRadius: 2 }}
      >
        <table className="w-full min-w-[820px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              {["Type", "Authorized", "Legal standing", "Primary intent", "Typical action"].map(
                (h) => (
                  <th
                    key={h}
                    className="px-4 py-3 font-mono text-[9.5px] tracked text-phos"
                  >
                    {h}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr
                key={r.name}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-3.5">
                  <span
                    className="font-display text-[14px] uppercase tracking-tight"
                    style={{ color: TONE[r.tone] }}
                  >
                    {r.name}
                  </span>
                </td>
                <td className="px-4 py-3.5 font-mono text-[11.5px] tracked-sm text-sage/85">
                  {r.auth}
                </td>
                <td className="px-4 py-3.5 text-[13px] font-light text-muted">
                  {r.legal}
                </td>
                <td className="px-4 py-3.5 text-[13px] font-light text-sage/85">
                  {r.intent}
                </td>
                <td className="px-4 py-3.5 text-[13px] font-light text-muted">
                  {r.action}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-4 max-w-[92ch] font-mono text-[11.5px] leading-relaxed text-phos/80">
        Note · Gray hat is the only category whose legality changes with
        jurisdiction — unauthorized access is a crime in most statutes even when
        no damage follows.
      </p>
    </Slide>
  );
}

/* ==================================================================
   06 · OTHER TYPES — INDEX
================================================================== */
export function OtherIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.05 // OTHER-TYPES"
      num="06"
      title={
        <>
          Other types of <span className="text-phos">hackers</span>
        </>
      }
      lede="Beyond the main categories, hackers can take diverse forms depending on their skills, motivations and targets."
      dense
    >
      <div className="border-b border-sage/15">
        {otherHackers.map((o) => (
          <Row
            key={o.i}
            i={o.i}
            label={o.name}
            desc={o.desc}
            meta={o.motive}
          />
        ))}
      </div>
    </Slide>
  );
}

function OtherCard({
  o,
  n,
}: {
  o: (typeof otherHackers)[number];
  n: number;
}) {
  const invited = o.auth.startsWith("Yes");
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.42, delay: n * 0.1, ease: "easeOut" },
        },
      }}
      className="flex flex-col border bg-panel/50 p-5 transition-colors duration-200"
      style={{
        borderRadius: 2,
        borderColor: invited ? "rgba(61,240,122,.4)" : "rgba(255,176,32,.35)",
      }}
    >
      <div className="flex items-start justify-between gap-4">
        <span
          className="font-display text-[2rem] leading-none"
          style={{ color: invited ? TONE.phos : TONE.amber }}
        >
          {o.i}
        </span>
        <span
          className="border px-2 py-1 font-mono text-[9px] tracked"
          style={{
            borderRadius: 2,
            borderColor: invited ? "rgba(61,240,122,.5)" : "rgba(255,176,32,.5)",
            color: invited ? TONE.phos : TONE.amber,
          }}
        >
          {o.auth}
        </span>
      </div>
      <h3 className="mt-3.5 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
        {o.name}
      </h3>
      <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
        {o.desc}
      </p>
      <div className="mt-auto flex items-baseline justify-between gap-3 border-t border-sage/15 pt-3.5">
        <span className="font-mono text-[9px] tracked text-muted">Motive</span>
        <span className="font-mono text-[10px] tracked-sm text-sage/85">
          {o.motive}
        </span>
      </div>
    </motion.article>
  );
}

export function OtherDetailA() {
  return (
    <Slide
      tag="SEC // CH.05 // OTHER 01–03"
      num="07"
      title={
        <>
          Script Kiddie · Green ·{" "}
          <span className="text-phos">Blue Hat</span>
        </>
      }
      dense
    >
      <div className="grid items-start gap-4 md:grid-cols-3">
        {otherHackers.slice(0, 3).map((o, n) => (
          <OtherCard key={o.i} o={o} n={n} />
        ))}
      </div>
    </Slide>
  );
}

export function OtherDetailB() {
  return (
    <Slide
      tag="SEC // CH.05 // OTHER 04–06"
      num="08"
      title={
        <>
          Red Hat · State ·{" "}
          <span className="text-amber">Hacktivist</span>
        </>
      }
      dense
    >
      <div className="grid items-start gap-4 md:grid-cols-3">
        {otherHackers.slice(3, 6).map((o, n) => (
          <OtherCard key={o.i} o={o} n={n} />
        ))}
      </div>

      <div className="mt-6 border-l-2 border-amber pl-5">
        <span className="font-mono text-[9.5px] tracked text-amber">
          Worth remembering
        </span>
        <p className="mt-2 max-w-[88ch] text-[14px] font-light leading-[1.65] text-sage/85">
          Red Hat and Hacktivist occupy opposite ends of the same axis: both act
          without authorization, but one targets criminals and the other
          targets organisations it disagrees with. Motive never changes the
          legality of unauthorized access.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · MALICIOUS INSIDERS (+ extension)
================================================================== */
export function InsiderSlide() {
  const o = otherHackers[6];
  return (
    <Slide
      tag="SEC // CH.05 // OTHER 07"
      num="09"
      title={
        <>
          Malicious insiders{" "}
          <span className="text-phos">&amp; whistleblowers</span>
        </>
      }
      lede={o.desc}
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        <motion.div
          variants={rise}
          className="border border-phos/35 bg-panel/50 p-5"
          style={{ borderRadius: 2 }}
        >
          <div className="font-mono text-[9.5px] tracked text-phos">
            Three kinds of insider
          </div>
          <div className="mt-3.5 space-y-3.5">
            {insiderTypes.map(([k, v]) => (
              <div key={k} className="border-t border-sage/15 pt-3">
                <div className="font-mono text-[12px] tracked-sm text-sage">
                  {k}
                </div>
                <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-muted">
                  {v}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          variants={rise}
          className="border border-amber/35 bg-panel/50 p-5"
          style={{ borderRadius: 2 }}
        >
          <div className="font-mono text-[9.5px] tracked text-amber">
            Warning signals
          </div>
          <ul className="mt-3.5 space-y-2.5">
            {insiderSignals.map((s) => (
              <li
                key={s}
                className="flex items-start gap-2.5 text-[13px] font-light leading-[1.55] text-sage/85"
              >
                <span className="mt-[8px] h-1.5 w-1.5 shrink-0 bg-amber" />
                {s}
              </li>
            ))}
          </ul>
        </motion.div>

        <motion.div
          variants={rise}
          className="border border-sage/25 bg-panel/50 p-5"
          style={{ borderRadius: 2 }}
        >
          <div className="font-mono text-[9.5px] tracked text-phos">
            Controls that work
          </div>
          <ul className="mt-3.5 space-y-2.5">
            {insiderControls.map((c) => (
              <li
                key={c}
                className="flex items-start gap-2.5 text-[13px] font-light leading-[1.55] text-sage/85"
              >
                <span className="mt-[8px] h-px w-3 shrink-0 bg-phos/70" />
                {c}
              </li>
            ))}
          </ul>
        </motion.div>
      </div>

      <div className="mt-6 border-l-2 border-phos pl-5">
        <span className="font-mono text-[9.5px] tracked text-phos">
          Extension · why insiders are hard
        </span>
        <p className="mt-2 max-w-[90ch] text-[14px] font-light leading-[1.65] text-sage/85">
          An insider's credentials are valid and their activity looks like
          legitimate work in isolation — detection depends on baseline
          behaviour rather than on an obvious break-in. This is Chapter 01's{" "}
          <span className="text-phos">Operational Security</span> problem: the
          control is policy and monitoring, not a firewall rule.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · VULNERABLE DEVICES
================================================================== */
export function DevicesSlide() {
  return (
    <Slide
      tag="SEC // CH.05 // VECTORS"
      num="10"
      title={
        <>
          Devices that are most{" "}
          <span className="text-amber">vulnerable to hacking</span>
        </>
      }
      lede="Four device classes attackers reach for first — and why each one is exposed."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="grid gap-4 sm:grid-cols-2">
            {devices.map((d, n) => (
              <motion.div
                key={d.i}
                variants={{
                  hidden: { opacity: 0, y: 14 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.4, delay: n * 0.08 },
                  },
                }}
                className="flex flex-col border border-amber/30 bg-panel/50 p-5 transition-colors hover:border-amber/70"
                style={{ borderRadius: 2 }}
              >
                <div className="flex items-start justify-between">
                  <span className="font-display text-[1.9rem] leading-none text-amber">
                    {d.i}
                  </span>
                  <span
                    className="border border-sage/30 px-2 py-1 font-mono text-[9px] tracked text-muted"
                    style={{ borderRadius: 2 }}
                  >
                    {d.why}
                  </span>
                </div>
                <h3 className="mt-3.5 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
                  {d.name}
                </h3>
                <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
                  {d.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        <aside className="lg:col-span-4">
          <div
            className="relative overflow-hidden border border-sage/15"
            style={{ borderRadius: 2 }}
          >
            <img
              src={iot}
              alt="Smart-home hub, sensor and camera on a dark shelf"
              className="h-[200px] w-full object-cover opacity-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/35 to-transparent" />
            <span className="absolute bottom-3 left-3 right-3 font-mono text-[9.5px] tracked text-amber">
              Fig. 10 — Always connected, rarely patched
            </span>
          </div>

          <Panel className="mt-4 p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Extension · also exposed
            </div>
            <ul className="mt-3 space-y-2">
              {devicesExtra.map((e) => (
                <li
                  key={e}
                  className="flex items-start gap-2.5 text-[13px] font-light leading-[1.55] text-sage/85"
                >
                  <span className="mt-[8px] h-px w-3 shrink-0 bg-amber/70" />
                  {e}
                </li>
              ))}
            </ul>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · PREVENTION
================================================================== */
export function PreventionSlide() {
  return (
    <Slide
      tag="SEC // CH.05 // PREVENTION"
      num="11"
      title={
        <>
          Prevention from{" "}
          <span className="text-phos">getting hacked</span>
        </>
      }
      lede="Five habits that cut off the attack paths this chapter described."
      dense
    >
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {prevention.map((p, n) => (
          <motion.div
            key={p.i}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.07 },
              },
            }}
            className={`flex flex-col border border-phos/35 bg-panel/50 p-5 transition-colors hover:border-phos/70 ${
              n === 4 ? "md:col-span-2 lg:col-span-1" : ""
            }`}
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between gap-3">
              <span className="font-display text-[2rem] leading-none text-phos">
                {p.i}
              </span>
              <span
                className="border border-amber/45 px-2 py-1 text-right font-mono text-[9px] tracked text-amber"
                style={{ borderRadius: 2 }}
              >
                {p.blocks}
              </span>
            </div>
            <h3 className="mt-3.5 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
              {p.name}
            </h3>
            <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
              {p.desc}
            </p>
            <div className="mt-auto border-t border-sage/15 pt-3.5">
              <span className="font-mono text-[9px] tracked text-phos">
                In practice
              </span>
              <p className="mt-1.5 text-[13px] font-light leading-[1.5] text-sage/85">
                {p.tip}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · EXTENDED HARDENING
================================================================== */
export function HardeningSlide() {
  return (
    <Slide
      tag="SEC // CH.05 // EXTENSION/HARDENING"
      num="12"
      title={
        <>
          Extension —{" "}
          <span className="text-phos">eight more hardening steps</span>
        </>
      }
      lede="Course material covered five. These eight round the list out to a defensible personal baseline."
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {hardening.map(([k, v], n) => (
          <motion.div
            key={k}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[10px] text-phos/70">
              {String(n + 1).padStart(2, "0")}
            </span>
            <h3 className="mt-2.5 font-mono text-[12.5px] font-medium tracked-sm text-sage">
              {k}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {v}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 border-l-2 border-amber pl-5">
        <span className="font-mono text-[9.5px] tracked text-amber">
          The order matters
        </span>
        <p className="mt-2 max-w-[88ch] text-[14px] font-light leading-[1.65] text-sage/85">
          Updates close the door, unique passwords limit the blast radius, MFA
          makes a stolen password useless, and backups make ransomware
          irrelevant. Do those four first — the rest is hardening around them.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · THE HACKING METHODOLOGY
================================================================== */
export function MethodologySlide() {
  return (
    <Slide
      tag="SEC // CH.05 // EXTENSION/METHODOLOGY"
      num="13"
      title={
        <>
          The hacking <span className="text-phos">methodology</span>
        </>
      }
      lede="The same five phases run whether the actor is a criminal or a contracted tester. Only the final phase differs — and that difference is everything."
      dense
    >
      <div className="border-b border-sage/15">
        {methodology.map((m, n) => (
          <motion.div
            key={m.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.06 },
              },
            }}
            className="grid grid-cols-1 gap-x-6 gap-y-2 border-t border-sage/15 py-4 transition-colors duration-200 hover:bg-phos/[0.045] md:grid-cols-[3rem_minmax(0,1fr)_auto]"
          >
            <span
              className={`flex h-9 w-9 items-center justify-center border font-mono text-[12px] ${
                n === 4
                  ? "border-amber/70 text-amber"
                  : "border-phos/60 text-phos"
              }`}
              style={{ borderRadius: 2 }}
            >
              {m.i}
            </span>
            <div className="min-w-0">
              <div className="font-mono text-[13px] font-medium tracked-sm text-sage">
                {m.name}
              </div>
              <p className="mt-1.5 max-w-[70ch] text-[13.5px] font-light leading-[1.6] text-muted">
                {m.desc}
              </p>
              <p className="mt-1.5 font-mono text-[11px] text-phos/70">
                {m.tools}
              </p>
            </div>
            <p className="max-w-[34ch] border-l-2 border-sage/25 pl-4 text-[12.5px] font-light italic leading-[1.5] text-sage/70 md:text-right md:border-l-0 md:border-r-2 md:pl-0 md:pr-4">
              {m.note}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="border-l-2 border-amber pl-4">
          <div className="font-mono text-[9.5px] tracked text-amber">
            Black hat path
          </div>
          <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-muted">
            Continues past phase 05 by clearing logs and timestamps — which is
            exactly what makes the activity a crime.
          </p>
        </div>
        <div className="border-l-2 border-phos pl-4">
          <div className="font-mono text-[9.5px] tracked text-phos">
            White hat path
          </div>
          <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-muted">
            Stops at phase 05 with a written report: what was reached, how, the
            business impact, and the fix — under a signed scope of work.
          </p>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · TEAMS & CAREERS
================================================================== */
export function TeamsSlide() {
  const colorMap: Record<string, string> = {
    amber: TONE.amber,
    phos: TONE.phos,
    sage: TONE.sage,
  };
  return (
    <Slide
      tag="SEC // CH.05 // EXTENSION/CAREERS"
      num="14"
      title={
        <>
          Where these skills <span className="text-phos">actually work</span>
        </>
      }
      lede="Ethical hacking is a profession with defined teams. Knowing which one you are joining changes what a good day looks like."
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {teams.map((t, n) => (
          <motion.div
            key={t.name}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.42, delay: n * 0.1 },
              },
            }}
            className="flex flex-col border bg-panel/50 p-5 md:p-6"
            style={{
              borderRadius: 2,
              borderColor: `${colorMap[t.color]}55`,
            }}
          >
            <div className="flex items-start justify-between gap-3">
              <span
                className="font-display text-[1.6rem] uppercase leading-none"
                style={{ color: colorMap[t.color] }}
              >
                {t.name}
              </span>
              <span
                className="border px-2 py-1 font-mono text-[9px] tracked"
                style={{
                  borderRadius: 2,
                  borderColor: `${colorMap[t.color]}66`,
                  color: colorMap[t.color],
                }}
              >
                {t.role}
              </span>
            </div>
            <p className="mt-4 text-[14px] font-light leading-[1.65] text-muted">
              {t.desc}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 grid gap-6 lg:grid-cols-2">
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">
            Roles this leads to
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {roles.map((r) => (
              <span
                key={r}
                className="border border-sage/25 px-2.5 py-1.5 font-mono text-[10.5px] text-sage/85"
                style={{ borderRadius: 2 }}
              >
                {r}
              </span>
            ))}
          </div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">
            Common certifications
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {certs.map((c) => (
              <span
                key={c}
                className="border border-phos/40 bg-deep/30 px-2.5 py-1.5 font-mono text-[10.5px] text-phos"
                style={{ borderRadius: 2 }}
              >
                {c}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 border-l-2 border-amber pl-5">
        <span className="font-mono text-[9.5px] tracked text-amber">
          Legality, once and for all
        </span>
        <p className="mt-2 max-w-[88ch] text-[14px] font-light leading-[1.65] text-sage/85">
          Penetration testing is only legal under written authorization that
          defines scope, timing and rules of engagement. “I didn't cause damage”
          is not a defence — authorization is.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide5({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">
          Sec // CH.05 // Check
        </span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Name the hat.
          <br />
          <span className="text-phos glow">Then answer.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Five multiple-choice items covering hacker definitions, the
          white/black distinction, script kiddies, green hats and account
          hygiene. Select an answer to reveal it instantly — the rationale
          appears underneath and your running score is kept in the footer.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(15)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   16–20 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide5({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions5[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.05 // CHECK // Q0${n + 1}`}
      num={String(16 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              [
                "Status",
                !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect",
              ],
              ["Domain", "Hacker types"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex items-baseline justify-between border-t border-sage/15 pt-2.5"
              >
                <span className="font-mono text-[9.5px] tracked text-muted">
                  {k}
                </span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.06 },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   21 · SCORE
================================================================== */
export function ScoreSlide5({ answers }: { answers: (number | null)[] }) {
  const score = questions5.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions5.length) * 100);
  const verdict =
    pct === 100
      ? "Every hat, correctly identified — clean sweep."
      : pct >= 60
        ? "Solid. Re-read the profile you missed and the spectrum plot."
        : "Revisit the spectrum and the hat comparison matrix, then retake.";

  return (
    <Slide
      tag="SEC // CH.05 // CHECK // RESULT"
      num="21"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div
            className="border border-phos/40 bg-panel/60 p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions5.length}
              </span>
            </div>
            <div
              className="mt-5 h-2 w-full bg-sage/12"
              style={{ borderRadius: 2 }}
            >
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions5.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions5.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.05 },
                    },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   22 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide5() {
  const items = [
    ["01", "Intent and authorization decide the label", "Skill and toolset are the same across black, gray and white."],
    ["02", "White hats are the same job, contracted", "Penetration testing is offensive work performed with written scope."],
    ["03", "Gray hats live in the legal gap", "Reporting a flaw you found unauthorized rarely makes it legal."],
    ["04", "Ten categories, not three", "Script kiddies, green, blue, red, state, hacktivists and insiders all behave differently."],
    ["05", "Insiders already pass the firewall", "Detection relies on behaviour baselines, not on an intrusion signature."],
    ["06", "Defence is mostly hygiene", "Updates, unique passwords, MFA and backups beat most of what is on the spectrum."],
  ];

  return (
    <Slide
      tag="SEC // CH.05 // CLOSE"
      num="22"
      title={
        <>
          Chapter 05 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-phos/70">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 05 · Hackers and Their Types
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents5.length} sections · {TOTAL5} slides
        </span>
      </div>
    </Slide>
  );
}
