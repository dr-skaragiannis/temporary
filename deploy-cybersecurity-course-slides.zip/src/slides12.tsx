import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  attacks,
  botTypes,
  ch12Bullets,
  ch12Intro,
  ch12Stamp,
  contents12,
  glossary,
  prevention,
  questions12,
  steps,
  TOTAL12,
  type BotType,
} from "./data/ch12";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "hub-and-zombies" backdrop
================================================================== */
function BotBackdrop() {
  const bots = Array.from({ length: 14 }).map((_, n) => {
    const a = (n / 14) * Math.PI * 2 + 0.3;
    const r = 150 + (n % 3) * 55;
    return { x: 930 + Math.cos(a) * r, y: 350 + Math.sin(a) * r * 0.8, warm: n % 4 === 0 };
  });
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="btFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="btGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {bots.map((b, n) => (
        <line key={`l${n}`} x1="930" y1="350" x2={b.x} y2={b.y} stroke={b.warm ? "#FFB020" : "#3DF07A"} strokeOpacity="0.35" strokeDasharray="4 6" />
      ))}
      {bots.map((b, n) => (
        <g key={`b${n}`} filter="url(#btGlow)">
          <rect x={b.x - 6} y={b.y - 6} width="12" height="12" fill={b.warm ? "#FFB020" : "#3DF07A"} fillOpacity="0.85" />
        </g>
      ))}
      <g transform="translate(930 350)" filter="url(#btGlow)">
        <rect x="-16" y="-16" width="32" height="32" fill="#FFB020" />
        <rect x="-26" y="-26" width="52" height="52" fill="none" stroke="#FFB020" strokeOpacity="0.5" />
      </g>
      <text x="930" y="410" textAnchor="middle" fill="#FFB020" fillOpacity="0.8" fontFamily="IBM Plex Mono, monospace" fontSize="11" letterSpacing="2">C&amp;C</text>
      <rect width="1200" height="700" fill="url(#btFade)" />
    </svg>
  );
}

export function TitleSlide12({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <BotBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Network threat briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 12 of 16</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.12&nbsp;//&nbsp;BOTNET</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL12}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 12</span>
              <span className="mt-1 block text-[clamp(3rem,9vw,7.5rem)] text-phos glow">Botnets</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch12Intro} This chapter walks the six-step lifecycle from scan
              to self-propagation, compares the three C&amp;C topologies, and
              maps the attacks botnets deliver to the controls that break the
              chain.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(5)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to botnet types</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Lifecycle steps", "Six"], ["C&C topologies", "Three"], ["Attack types", "Five"], ["Doc revision", ch12Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT A BOTNET IS
================================================================== */
export function IntroSlide12() {
  return (
    <Slide tag="SEC // CH.12 // DEFINITION" num="02" title={<>What a <span className="text-phos">botnet</span> is</>} lede={ch12Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch12Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Vocabulary</div>
            <div className="mt-3">
              {glossary.map((g) => (
                <div key={g.term} className="grid grid-cols-[7rem_1fr] gap-3 border-t border-sage/10 py-2.5 first:border-t-0">
                  <span className="font-mono text-[11.5px] text-phos">{g.term}</span>
                  <span className="text-[12.5px] font-light leading-[1.5] text-sage/85">{g.def}</span>
                </div>
              ))}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · LIFECYCLE OVERVIEW
================================================================== */
export function LifecycleSlide12() {
  return (
    <Slide tag="SEC // CH.12 // LIFECYCLE" num="03" title={<>Working &amp; <span className="text-phos">communication</span></>} lede="The process involves infection, connection, communication, execution of commands and expansion of the botnet — a loop, not a line." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {steps.map((s, n) => (
            <motion.div key={s.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 w-9 items-center justify-center border bg-ink font-mono text-[12px]" style={{ borderColor: n === 5 ? TONE.amber : TONE.phos, color: n === 5 ? TONE.amber : TONE.phos, borderRadius: 2 }}>{s.i}</span>
              </div>
              <div className="mt-2 font-mono text-[9.5px] tracked text-muted">{s.label}</div>
              <h3 className="mt-1 font-display text-[0.9rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-2 text-[12px] font-light leading-[1.5] text-muted">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <motion.div variants={rise} className="mt-6 flex items-center gap-3 border-t border-sage/15 pt-4 font-mono text-[10px] tracked text-amber/85">
        <span>↻</span>
        <span>Step 06 feeds Step 01: every new bot scans for the next victim.</span>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   Shared step-detail slide
================================================================== */
function StepDetail({ from, to, num, head }: { from: number; to: number; num: string; head: string }) {
  const slice = steps.slice(from, to);
  return (
    <Slide tag={`SEC // CH.12 // STEPS ${slice[0].i}–${slice[slice.length - 1].i}`} num={num} title={<>Steps — <span className="text-phos">{head}</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {slice.map((s, n) => (
          <motion.div
            key={s.i}
            variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }}
            className="flex flex-col border border-sage/15 bg-panel/60"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: from + n === 5 ? TONE.amber : TONE.phos }}
          >
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: from + n === 5 ? TONE.amber : TONE.phos }}>Step {s.i} · {s.label}</span>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{s.desc}</p>
            </div>
            <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
              {s.points.map((p) => (
                <li key={p} className="flex gap-2.5 border-t border-sage/10 py-2 text-[12.5px] font-light leading-[1.5] text-sage/85 first:border-t-0 first:pt-0">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-phos" />
                  {p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

export const StepsA12 = () => <StepDetail from={0} to={3} num="04" head="scan, infect, connect" />;
export const StepsB12 = () => <StepDetail from={3} to={6} num="05" head="talk, execute, grow" />;

/* ==================================================================
   Topology diagrams
================================================================== */
function Topology({ kind, color }: { kind: BotType["topology"]; color: string }) {
  const bots = [
    [20, 20], [100, 14], [180, 24], [26, 96], [176, 100], [40, 168], [100, 180], [166, 170],
  ];
  return (
    <svg viewBox="0 0 200 200" className="h-auto w-full max-w-[200px]" aria-hidden>
      {kind === "central" && (
        <>
          {bots.map(([x, y], n) => <line key={n} x1="100" y1="100" x2={x} y2={y} stroke={color} strokeOpacity="0.45" />)}
          <rect x="88" y="88" width="24" height="24" fill={color} />
        </>
      )}
      {kind === "p2p" && (
        <>
          {bots.map(([x1, y1], a) =>
            bots.map(([x2, y2], b) =>
              b > a && (a + b) % 3 !== 0 ? <line key={`${a}-${b}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeOpacity="0.3" /> : null,
            ),
          )}
        </>
      )}
      {kind === "web" && (
        <>
          {bots.map(([x, y], n) => <line key={n} x1="100" y1="100" x2={x} y2={y} stroke={color} strokeOpacity="0.45" strokeDasharray="3 4" />)}
          <circle cx="100" cy="100" r="14" fill="none" stroke={color} strokeWidth="2" />
          <text x="100" y="104" textAnchor="middle" fill={color} fontFamily="IBM Plex Mono, monospace" fontSize="9">www</text>
        </>
      )}
      {bots.map(([x, y], n) => <rect key={`b${n}`} x={x - 6} y={y - 6} width="12" height="12" fill="#C7D2C9" fillOpacity="0.85" />)}
    </svg>
  );
}

/* ==================================================================
   06 · THREE TYPES
================================================================== */
export function TypesSlide12() {
  return (
    <Slide tag="SEC // CH.12 // TYPES" num="06" title={<>Types of <span className="text-phos">botnets</span></>} lede="Botnets are classified by the communication channel used between the bots and the Command and Control server." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {botTypes.map((t, n) => (
          <motion.div
            key={t.i}
            variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }}
            className="flex flex-col border border-sage/15 bg-panel/60"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[t.tone] }}
          >
            <div className="flex items-start justify-between gap-4 p-5">
              <div>
                <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[t.tone] }}>Type {t.i} · {t.era}</span>
                <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              </div>
              <div className="w-[88px] shrink-0"><Topology kind={t.topology} color={TONE[t.tone]} /></div>
            </div>
            <p className="px-5 pb-4 text-[13px] font-light leading-[1.6] text-muted">{t.desc}</p>
            <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[t.tone] }} />
                  {p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · TOPOLOGY COMPARISON
================================================================== */
export function CompareSlide12() {
  const rows: [string, (t: BotType) => string][] = [
    ["Structure", (t) => (t.topology === "central" ? "Centralized" : t.topology === "p2p" ? "Decentralized" : "Centralized · web")],
    ["Channel", (t) => (t.topology === "central" ? "IRC chat messages" : t.topology === "p2p" ? "Bot-to-bot" : "HTTP/HTTPS polling")],
    ["Resilience", (t) => t.resilience],
    ["Stealth", (t) => t.stealth],
    ["Takedown", (t) => (t.topology === "central" ? "Seize the IRC server" : t.topology === "p2p" ? "Very hard — no single point" : "Sinkhole the domains")],
  ];
  return (
    <Slide tag="SEC // CH.12 // COMPARE" num="07" title={<>Topology <span className="text-phos">comparison</span></>} lede="Why the P2P botnet is the hardest to shut down — and why HTTP botnets are the hardest to see." dense>
      <div className="overflow-x-auto">
        <div className="min-w-[640px]">
          <div className="grid grid-cols-[8rem_repeat(3,1fr)] gap-x-4 border-b border-sage/20 pb-3">
            <span className="font-mono text-[9.5px] tracked text-muted">Dimension</span>
            {botTypes.map((t) => (
              <div key={t.i} className="flex items-center gap-2">
                <span className="inline-block h-2 w-2" style={{ background: TONE[t.tone] }} />
                <span className="font-display text-[0.95rem] uppercase text-sage">{t.short}</span>
              </div>
            ))}
          </div>
          {rows.map(([k, fn], n) => (
            <motion.div key={k} variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="grid grid-cols-[8rem_repeat(3,1fr)] gap-x-4 border-t border-sage/10 py-3 hover:bg-phos/[0.04]">
              <span className="font-mono text-[10px] tracked text-muted">{k}</span>
              {botTypes.map((t) => (
                <span key={t.i} className={`text-[13px] font-light leading-[1.45] ${k === "Resilience" && t.topology === "p2p" ? "text-amber" : k === "Stealth" && t.topology === "web" ? "text-phos" : "text-sage/85"}`}>{fn(t)}</span>
              ))}
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · ATTACKS
================================================================== */
export function AttacksSlide12() {
  return (
    <Slide tag="SEC // CH.12 // ATTACKS" num="08" title={<>Types of <span className="text-phos">botnet attacks</span></>} lede="Once assembled, a botnet is a rentable capability. These are the five jobs it is most often given." dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {attacks.map((a, n) => (
            <Row key={a.i} i={a.i} label={a.name} desc={a.desc} meta={a.meta} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">DDoS techniques named</div>
            <div className="mt-3 grid grid-cols-2 gap-px bg-sage/15">
              <div className="bg-ink p-3">
                <div className="font-mono text-[12px] text-sage">SYN Flood</div>
                <p className="mt-1 text-[11.5px] font-light leading-[1.5] text-muted">Half-open TCP connections exhaust the server's connection table.</p>
              </div>
              <div className="bg-ink p-3">
                <div className="font-mono text-[12px] text-sage">UDP Flood</div>
                <p className="mt-1 text-[11.5px] font-light leading-[1.5] text-muted">Random-port UDP packets force the target to reply with ICMP unreachable until it saturates.</p>
              </div>
            </div>
            <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">
              Scale is the whole point: thousands of bots make every technique
              overwhelming and the true source hard to trace.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · PREVENTION
================================================================== */
export function PreventionSlide12() {
  return (
    <Slide tag="SEC // CH.12 // PREVENTION" num="09" title={<>Botnet <span className="text-phos">prevention</span></>} lede="Seven habits, each mapped to the lifecycle step it breaks. Stop recruitment and the botnet cannot grow." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {prevention.map((p, n) => (
          <motion.div key={p.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className={`flex flex-col bg-ink p-5 ${n === 6 ? "sm:col-span-2 lg:col-span-1" : ""}`}>
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{p.i}</span>
              <span className="border border-phos/50 px-1.5 py-[2px] font-mono text-[9px] tracked text-phos" style={{ borderRadius: 2 }}>✓</span>
            </div>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 flex-1 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
            <div className="mt-3 border-t border-sage/10 pt-2 font-mono text-[9.5px] leading-[1.5] tracked text-amber/80">Breaks: {p.breaks}</div>
          </motion.div>
        ))}
        <motion.div variants={rise} className="bg-panel/70 p-5">
          <div className="font-mono text-[9.5px] tracked text-amber">Am I already a bot?</div>
          <ul className="mt-3 space-y-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
            <li>· Unexplained outbound traffic when idle</li>
            <li>· Sluggish system, fans spinning with nothing open</li>
            <li>· Connections to unfamiliar hosts in <span className="font-mono">netstat</span></li>
            <li>· Contacts receiving spam "from you"</li>
          </ul>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide12({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 4 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.12 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Find the botmaster.
          <br />
          <span className="text-phos glow">Break the chain.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Four items covering the definition, the hardest topology to take
          down, the signature botnet attack and the one habit that is not a
          defence. Select an answer to reveal it instantly — the rationale
          appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(10)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   11–14 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide12({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions12[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.12 // CHECK // Q0${n + 1}`} num={String(11 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 04</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Botnets"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · SCORE
================================================================== */
export function ScoreSlide12({ answers }: { answers: (number | null)[] }) {
  const score = questions12.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions12.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — botmaster found, chain broken." : pct >= 50 ? "Solid. Re-read the topology comparison and the prevention map." : "Revisit the six-step lifecycle and the three types, then retake.";
  return (
    <Slide tag="SEC // CH.12 // CHECK // RESULT" num="15" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions12.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions12.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions12.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide12() {
  const items = [
    ["01", "A botnet is borrowed compute", "Thousands of machines, one operator — the victim's hardware becomes the attacker's infrastructure."],
    ["02", "Recruitment is the weak point", "Every bot was once a vulnerable, unpatched or careless host. Fix that and the botnet starves."],
    ["03", "Topology decides takedown", "IRC: seize the server. HTTP: sinkhole the domain. P2P: there is nothing central to seize."],
    ["04", "Blending in is the design goal", "HTTP polling looks like browsing; that is why it is now the most common channel."],
    ["05", "DDoS is the product", "SYN and UDP floods only work at scale — scale is what the botnet provides."],
    ["06", "Seven habits break the loop", "Patch, don't click, strong passwords, 2FA, endpoint protection, firewall, trusted sources."],
  ];
  return (
    <Slide tag="SEC // CH.12 // CLOSE" num="16" title={<>Chapter 12 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 12 · Botnets</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents12.length} sections · {TOTAL12} slides</span>
      </div>
    </Slide>
  );
}
