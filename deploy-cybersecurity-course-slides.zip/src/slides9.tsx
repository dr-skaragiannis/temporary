import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  catALead,
  catBLead,
  ch9Intro,
  ch9Stamp,
  challenges,
  contents9,
  crimesA,
  crimesB,
  evidence,
  protections,
  questions9,
  reporting,
  reportingLead,
  TOTAL9,
  type Crime,
} from "./data/ch9";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "network under siege" backdrop
================================================================== */
function CrimeBackdrop() {
  const nodes = [
    [880, 200],
    [1010, 260],
    [960, 400],
    [820, 360],
    [1100, 420],
    [1060, 140],
    [760, 240],
    [900, 520],
  ];
  const links = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 0],
    [1, 4],
    [4, 2],
    [0, 5],
    [5, 1],
    [3, 6],
    [6, 0],
    [2, 7],
    [3, 7],
  ];
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 1200 700"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
    >
      <defs>
        <radialGradient id="crFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="crGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="6" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => (
          <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />
        ))}
        {Array.from({ length: 15 }).map((_, n) => (
          <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />
        ))}
      </g>
      {links.map(([a, b], n) => (
        <line
          key={n}
          x1={nodes[a][0]}
          y1={nodes[a][1]}
          x2={nodes[b][0]}
          y2={nodes[b][1]}
          stroke={n % 4 === 0 ? "#FFB020" : "#3DF07A"}
          strokeOpacity={n % 4 === 0 ? 0.55 : 0.3}
          strokeDasharray={n % 3 === 0 ? "5 7" : undefined}
        />
      ))}
      {nodes.map(([x, y], n) => (
        <g key={n} filter="url(#crGlow)">
          <circle cx={x} cy={y} r={n === 2 ? 10 : 6} fill={n % 3 === 0 ? "#FFB020" : "#3DF07A"} />
          <circle cx={x} cy={y} r={n === 2 ? 22 : 14} fill="none" stroke={n % 3 === 0 ? "#FFB020" : "#3DF07A"} strokeOpacity="0.3" />
        </g>
      ))}
      {/* caution stripes */}
      <g transform="translate(700 600)">
        {Array.from({ length: 22 }).map((_, n) => (
          <rect key={n} x={n * 26} y="0" width="13" height="14" fill="#FFB020" fillOpacity="0.35" transform={`skewX(-30)`} />
        ))}
      </g>
      <rect width="1200" height="700" fill="url(#crFade)" />
    </svg>
  );
}

export function TitleSlide9({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <CrimeBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Crime briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 09 of 16</span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.09&nbsp;//&nbsp;CYBER-CRIME
            </span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">
            01 / {TOTAL9}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">
              University course · Introduction to Cybersecurity
            </motion.p>
            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 09</span>
              <span className="mt-1 block text-[clamp(2.2rem,6.8vw,5.8rem)] text-phos glow">
                Types of Cyber Crime
              </span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p
              variants={rise}
              className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              {ch9Intro} This chapter maps twelve crime types across those two
              categories, the challenges that make them hard to stop, six
              personal defences and how to report an incident.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(7)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos"
              >
                Jump to protection
              </button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Categories", "Two"],
            ["Crime types", "Twelve"],
            ["Defences", "Six"],
            ["Doc revision", ch9Stamp.replace("Last Updated : ", "")],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT CYBER CRIME IS
================================================================== */
export function IntroSlide9() {
  return (
    <Slide
      tag="SEC // CH.09 // DEFINITION"
      num="02"
      title={
        <>
          What <span className="text-phos">cyber crime</span> is
        </>
      }
      lede="Cyber crime includes a wide range of illegal activities that exploit computers, networks and the internet."
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <Row i="01" label="Exploits computers" desc="The device itself is the tool or the target — malware, exploits, unpatched systems." meta="Host" />
          <Row i="02" label="Exploits networks" desc="Traffic is flooded, intercepted or redirected — DDoS, botnets, interception." meta="Transit" />
          <Row i="03" label="Exploits the internet" desc="The web becomes a venue for fraud, extortion, harassment and espionage." meta="Venue" />
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">The dividing line</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              Ask one question of any incident: <em>is the computer the target, or
              the means?</em> The answer places it in one of the two categories
              on the next slide — and tells you whether you are defending a
              system or a person.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · TWO CATEGORIES
================================================================== */
export function CategoriesSlide9() {
  const cats = [
    {
      k: "A",
      name: "Crimes targeting computer networks or devices",
      lead: catALead,
      list: crimesA,
      tone: "amber",
    },
    {
      k: "B",
      name: "Crimes using computer networks to commit other criminal activities",
      lead: catBLead,
      list: crimesB,
      tone: "phos",
    },
  ];
  return (
    <Slide
      tag="SEC // CH.09 // TAXONOMY"
      num="03"
      title={
        <>
          Two <span className="text-phos">categories</span>
        </>
      }
      lede="These crimes are broadly categorized into two main types."
      dense
    >
      <div className="grid gap-4 lg:grid-cols-2">
        {cats.map((c, n) => (
          <motion.div
            key={c.k}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } },
            }}
            className="border border-sage/15 bg-panel/60 p-5"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[c.tone] }}
          >
            <div className="flex items-baseline gap-4">
              <span className="font-display text-[3rem] leading-none" style={{ color: TONE[c.tone] }}>
                {c.k}
              </span>
              <h3 className="font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
                {c.name}
              </h3>
            </div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{c.lead}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {c.list.map((x) => (
                <Tag key={x.name} tone={c.tone === "amber" ? "amber" : "phos"}>
                  {x.name}
                </Tag>
              ))}
            </div>
            <div className="mt-4 font-mono text-[9.5px] tracked text-muted">
              {c.list.length} types · computer is the {c.k === "A" ? "target" : "means"}
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared crime-list slide
================================================================== */
function CrimeList({
  num,
  tag,
  head,
  lead,
  list,
  side,
}: {
  num: string;
  tag: string;
  head: React.ReactNode;
  lead: string;
  list: Crime[];
  side: { h: string; p: string };
}) {
  return (
    <Slide tag={tag} num={num} title={head} lede={lead} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {list.map((c, n) => (
            <Row key={c.i} i={c.i} label={c.name} desc={c.desc} meta={c.tag} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">{side.h}</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{side.p}</p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

export const CategoryASlide9 = () => (
  <CrimeList
    num="04"
    tag="SEC // CH.09 // CATEGORY A"
    head={
      <>
        Targeting <span className="text-phos">networks &amp; devices</span>
      </>
    }
    lead={catALead}
    list={crimesA}
    side={{
      h: "Common thread",
      p: "Each of these breaks one leg of the CIA triad: malware and exploits attack integrity and confidentiality, DoS attacks availability, phishing steals the credentials that guard all three. Botnets are the delivery vehicle for the rest.",
    }}
  />
);

export const CategoryBSlide9 = () => (
  <CrimeList
    num="05"
    tag="SEC // CH.09 // CATEGORY B"
    head={
      <>
        Networks as <span className="text-phos">a means</span>
      </>
    }
    lead={catBLead}
    list={crimesB}
    side={{
      h: "Old crimes, new venue",
      p: "Fraud, extortion, stalking and espionage all predate the internet. What changed is reach, speed and anonymity: one actor can now target millions, cross borders instantly and hide behind proxies.",
    }}
  />
);

/* ==================================================================
   06 · CRIME MATRIX
================================================================== */
export function MatrixSlide9() {
  const all = [
    ...crimesA.map((c) => ({ ...c, cat: "A" })),
    ...crimesB.map((c) => ({ ...c, cat: "B" })),
  ];
  const motives = ["Money", "Disruption", "Secrets", "People"];
  const map: Record<string, string[]> = {
    "Malware Attacks": ["Money", "Disruption", "Secrets"],
    "DoS and DDoS Attacks": ["Disruption"],
    "Phishing Attacks": ["Money", "Secrets"],
    Botnets: ["Money", "Disruption"],
    "Exploits and Vulnerabilities": ["Secrets", "Disruption"],
    "Cyber Terrorism": ["Disruption", "People"],
    "Cyber Extortion (Ransomware)": ["Money", "Disruption"],
    "Cyber Warfare": ["Disruption", "Secrets"],
    "Internet Fraud": ["Money"],
    "Cyberstalking & Online Harassment": ["People"],
    "Financial Fraud": ["Money"],
    "Cyber Espionage": ["Secrets"],
  };
  return (
    <Slide
      tag="SEC // CH.09 // MATRIX"
      num="06"
      title={
        <>
          Crime <span className="text-phos">matrix</span>
        </>
      }
      lede="Twelve crime types against the outcome the attacker is after. Most crimes serve more than one goal — and money is the most common."
      dense
    >
      <div className="overflow-x-auto">
        <div className="min-w-[640px]">
          <div className="grid grid-cols-[2.5rem_minmax(0,1fr)_repeat(4,6rem)] gap-x-3 border-b border-sage/20 pb-2 font-mono text-[9.5px] tracked text-muted">
            <span>Cat</span>
            <span>Crime</span>
            {motives.map((m) => (
              <span key={m} className="text-center">
                {m}
              </span>
            ))}
          </div>
          {all.map((c, n) => (
            <motion.div
              key={c.name}
              variants={{
                hidden: { opacity: 0, y: 6 },
                show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.035 } },
              }}
              className="grid grid-cols-[2.5rem_minmax(0,1fr)_repeat(4,6rem)] items-center gap-x-3 border-t border-sage/10 py-2 hover:bg-phos/[0.04]"
            >
              <span className="font-mono text-[11px]" style={{ color: c.cat === "A" ? TONE.amber : TONE.phos }}>
                {c.cat}
              </span>
              <span className="font-mono text-[12px] text-sage">{c.name}</span>
              {motives.map((m) => {
                const on = map[c.name]?.includes(m);
                return (
                  <span key={m} className="flex justify-center">
                    <span
                      className="inline-block h-3 w-3"
                      style={{
                        background: on ? (m === "Money" ? TONE.amber : TONE.phos) : "transparent",
                        border: on ? "none" : "1px solid rgba(199,210,201,0.15)",
                      }}
                    />
                  </span>
                );
              })}
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · CHALLENGES & IMPACT
================================================================== */
export function ChallengesSlide9() {
  const ch = challenges.filter((c) => c.kind === "Challenge");
  const im = challenges.filter((c) => c.kind === "Impact");
  return (
    <Slide
      tag="SEC // CH.09 // CHALLENGES"
      num="07"
      title={
        <>
          Challenges &amp; <span className="text-phos">impact</span>
        </>
      }
      lede="Why cyber crime is hard to stop — and what it costs when it succeeds."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <div className="font-mono text-[9.5px] tracked text-amber">Why it is hard to stop</div>
          <div className="mt-2">
            {ch.map((c, n) => (
              <Row key={c.i} i={c.i} label={c.name} desc={c.desc} meta="Challenge" delay={n * 0.04} />
            ))}
          </div>
        </div>
        <div className="lg:col-span-5">
          <div className="font-mono text-[9.5px] tracked text-phos">What it costs</div>
          <div className="mt-2 grid gap-px bg-sage/15">
            {im.map((c, n) => (
              <motion.div
                key={c.i}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: 0.2 + n * 0.06 } },
                }}
                className="bg-ink p-5"
              >
                <span className="font-mono text-[11px] text-phos/70">{c.i}</span>
                <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
                  {c.name}
                </h3>
                <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">{c.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · PROTECT YOURSELF
================================================================== */
export function ProtectSlide9() {
  return (
    <Slide
      tag="SEC // CH.09 // PROTECTION"
      num="08"
      title={
        <>
          Protect <span className="text-phos">yourself</span>
        </>
      }
      lede="Six habits that close off the most common entry points used by cyber criminals."
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {protections.map((p, n) => (
          <motion.div
            key={p.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className="flex flex-col bg-ink p-5"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{p.i}</span>
              <span className="border border-phos/50 px-1.5 py-[2px] font-mono text-[9px] tracked text-phos" style={{ borderRadius: 2 }}>
                ✓
              </span>
            </div>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {p.name}
            </h3>
            <p className="mt-2.5 flex-1 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
            <div className="mt-3 border-t border-sage/10 pt-2 font-mono text-[9.5px] tracked text-amber/80">
              Stops: {p.stops}
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · REPORTING
================================================================== */
export function ReportingSlide9() {
  return (
    <Slide
      tag="SEC // CH.09 // REPORTING"
      num="09"
      title={
        <>
          Cyber crime <span className="text-phos">reporting process</span>
        </>
      }
      lede={reportingLead}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {reporting.map((r, n) => (
            <Row
              key={r.i}
              i={r.i}
              label={
                <>
                  <span className="text-phos">{r.region}</span> · {r.name}
                </>
              }
              desc={r.desc}
              meta={r.link}
              delay={n * 0.05}
            />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Preserve before you report</div>
            <ul className="mt-3">
              {evidence.map((e) => (
                <li key={e} className="flex items-center gap-3 border-t border-sage/10 py-2 font-mono text-[12px] text-sage/90">
                  <span className="inline-block h-1.5 w-1.5 bg-amber" />
                  {e}
                </li>
              ))}
            </ul>
            <p className="mt-4 text-[12.5px] font-light leading-[1.55] text-muted">
              Speed matters: fast reporting reduces damage, keeps digital
              evidence intact and gives investigators something to work with.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide9({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.09 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Name the crime.
          <br />
          <span className="text-phos glow">Pick the defence.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering cyberstalking, phishing, botnets, a DDoS scenario
          and personal protection. Select an answer to reveal it instantly —
          the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(10)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   11–15 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide9({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions9[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.09 // CHECK // Q0${n + 1}`}
      num={String(11 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              ["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"],
              ["Domain", "Cyber crime"],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}
            >
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · SCORE
================================================================== */
export function ScoreSlide9({ answers }: { answers: (number | null)[] }) {
  const score = questions9.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions9.length) * 100);
  const verdict =
    pct === 100
      ? "Clean sweep — every crime named, every defence picked."
      : pct >= 60
        ? "Solid. Re-read the category the missed item belongs to."
        : "Revisit the two categories and the protection slide, then retake.";

  return (
    <Slide
      tag="SEC // CH.09 // CHECK // RESULT"
      num="16"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions9.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions9.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions9.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null || picked === undefined ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   17 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide9() {
  const items = [
    ["01", "Target or means?", "Every cyber crime is either aimed at a system or uses a system to reach a person or a bank account."],
    ["02", "Money drives most of it", "Fraud, extortion, financial theft and botnets-for-hire all trace back to profit."],
    ["03", "Anonymity is the attacker's shield", "VPNs, proxies and fake identities make tracing slow — and underreporting makes it slower."],
    ["04", "Impact is more than money", "Downtime, breaches, lawsuits, regulatory penalties and lost trust follow the initial loss."],
    ["05", "Six habits close most doors", "Strong passwords, 2FA, updates, antivirus, secure networks and email caution."],
    ["06", "Report fast, preserve evidence", "IC3 in the US, Europol links in the EU, local units everywhere — with logs and screenshots in hand."],
  ];
  return (
    <Slide
      tag="SEC // CH.09 // CLOSE"
      num="17"
      title={
        <>
          Chapter 09 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 09 · Types of Cyber Crime</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents9.length} sections · {TOTAL9} slides
        </span>
      </div>
    </Slide>
  );
}
