import { useState } from "react";
import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import { CliLab } from "./components/CliLab";
import kbd from "./assets/kbd.jpg";
import {
  CH2_TITLE,
  classRef,
  chmodIntro,
  contents2,
  lsBreakdown,
  lsInput,
  lsOutput,
  modeReading,
  nameiBlock,
  nineChars,
  octalIntro,
  octalMap,
  operators,
  operatorNote,
  ownership,
  ownershipBlocks,
  questions2,
  specialPerms,
  statBlock,
  symbolicExamples,
  symbolicSteps,
  threePermissions,
  TOTAL2,
  whyPermissions,
  whyQuestions,
} from "./data/ch2";

/* ==================================================================
   01 · TITLE
================================================================== */
export function TitleSlide2({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <img
        src={kbd}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.45]"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_20%_55%,rgba(11,15,13,0.97)_25%,rgba(11,15,13,0.7)_65%,rgba(11,15,13,0.92)_100%)]" />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Unclassified · Lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 02 of 16
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.02&nbsp;//&nbsp;LINUX-PERMISSIONS
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL2}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-9">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-phos"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 02
              </span>
              <span className="mt-1 block text-[clamp(2.4rem,7vw,6rem)] text-phos glow">
                Linux Permissions
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              {whyPermissions} From the three basic permissions and the nine
              character mode string, through <code className="font-mono text-phos">chmod</code>, octal
              notation and the special bits — ending at a live terminal you can
              actually type into.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(15)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Jump to the CLI lab
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-3 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-80" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Mode string", "9–12 characters"],
            ["Notation", "Symbolic · Octal"],
            ["Weights", "r4 · w2 · x1"],
            ["Special bits", "suid · sgid · t"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   Static terminal block used by several slides
================================================================== */
function Term({
  label,
  input,
  output,
  accent = false,
}: {
  label: string;
  input: string;
  output: string[];
  accent?: boolean;
}) {
  return (
    <div
      className={`border ${accent ? "border-phos/50" : "border-sage/25"} bg-[#060A08]`}
      style={{ borderRadius: 2 }}
    >
      <div className="flex items-center justify-between border-b border-sage/20 bg-panel px-3 py-1.5">
        <span className="font-mono text-[9.5px] tracked text-phos">{label}</span>
        <span className="font-mono text-[9px] tracked text-muted">bash</span>
      </div>
      <div className="overflow-x-auto px-3 py-3 font-mono text-[12.5px] leading-[1.6]">
        <div className="whitespace-pre">
          <span className="text-phos">narx@lab</span>
          <span className="text-muted">:~$ </span>
          <span className="text-sage">{input}</span>
        </div>
        {output.map((l, i) => (
          <div key={i} className="whitespace-pre text-muted">
            {l || "\u00A0"}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ==================================================================
   02 · WHY PERMISSIONS MATTER
================================================================== */
export function WhySlide() {
  return (
    <Slide
      tag="SEC // CH.02 // FOUNDATIONS"
      num="02"
      title={
        <>
          Why permissions <span className="text-phos">matter</span>
        </>
      }
      lede={whyPermissions}
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {whyQuestions.map(([h, d], n) => (
          <motion.div
            key={h}
            variants={{
              hidden: { opacity: 0, y: 12 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.08, ease: "easeOut" },
              },
            }}
            className="border border-sage/15 bg-panel/50 p-5"
            style={{ borderRadius: 2 }}
          >
            <span className="font-display text-[2.4rem] leading-none text-phos glow">
              {h.split(" ").pop()}
            </span>
            <h3 className="mt-3 font-mono text-[12px] tracked-sm text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13.5px] font-light leading-[1.62] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 border-l-2 border-phos/60 pl-5">
        <div className="font-mono text-[9.5px] tracked text-phos">
          The model in one line
        </div>
        <p className="mt-2 max-w-[86ch] text-[15px] font-light leading-[1.65] text-sage/90">
          Every file carries a set of nine bits, split into three groups of
          three. Those bits are matched against the accessing user's{" "}
          <span className="text-phos">class</span> — owner, group or other — and
          that single comparison decides whether the operation is allowed.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · THE THREE BASIC PERMISSIONS
================================================================== */
export function ThreePermsSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // PERMISSIONS/01"
      num="03"
      title={
        <>
          The three basic <span className="text-phos">permissions</span>
        </>
      }
      lede="Every file or directory has three types of permissions — and each one means something different for a file than it does for a directory."
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {threePermissions.map((p, n) => (
          <motion.div
            key={p.key}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.08, ease: "easeOut" },
              },
            }}
            className="flex flex-col border border-sage/15 bg-panel/50 p-5 transition-colors duration-200 hover:border-phos/50"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between">
              <span className="font-display text-[3.6rem] leading-[0.8] text-phos glow">
                {p.key}
              </span>
              <span
                className="border border-phos/45 px-2 py-1 font-mono text-[10px] text-phos"
                style={{ borderRadius: 2 }}
              >
                {p.octal}
              </span>
            </div>
            <h3 className="mt-4 font-display text-[1.15rem] uppercase tracking-tight text-sage">
              {p.name}
            </h3>

            <div className="mt-4 space-y-3">
              <div>
                <div className="font-mono text-[9.5px] tracked text-muted">
                  On a file
                </div>
                <p className="mt-1 text-[13px] font-light leading-[1.55] text-sage/85">
                  {p.file}
                </p>
              </div>
              <div className="border-t border-sage/15 pt-3">
                <div className="font-mono text-[9.5px] tracked text-muted">
                  On a directory
                </div>
                <p className="mt-1 text-[13px] font-light leading-[1.55] text-sage/85">
                  {p.dir}
                </p>
              </div>
            </div>

            <div className="mt-auto border-t border-sage/15 pt-3.5">
              <code className="font-mono text-[11px] text-phos/85">
                {p.shell}
              </code>
            </div>
          </motion.div>
        ))}
      </div>

      <p className="mt-5 font-mono text-[10px] tracked text-muted">
        → r = 4 · w = 2 · x = 1 — these weights are the whole of octal notation
      </p>
    </Slide>
  );
}

/* ==================================================================
   04 · OWNERSHIP & PERMISSION GROUPS
================================================================== */
export function OwnershipSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // OWNERSHIP"
      num="04"
      title={
        <>
          Ownership &amp; permission{" "}
          <span className="text-phos">groups</span>
        </>
      }
      lede="Permissions are assigned to three categories of users. ls -l always shows you the first two by name."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {ownership.map((o) => (
              <Row key={o.i} i={o.i} label={o.label} desc={o.desc} meta={o.meta} />
            ))}
          </div>
        </div>
        <aside className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Where to look
            </div>
            <div className="mt-3.5 overflow-x-auto">
              <div className="whitespace-pre font-mono text-[12.5px] leading-relaxed">
                <span className="text-phos">-rw-r--r--</span>{" "}
                <span className="text-muted">1</span>{" "}
                <span className="text-sage">narx</span>{" "}
                <span className="text-sage">users</span>{" "}
                <span className="text-muted">46</span>{" "}
                <span className="text-muted">NarX.txt</span>
              </div>
            </div>
            <div className="mt-3 space-y-1.5 border-t border-sage/15 pt-3">
              {[
                ["3rd column", "the owner"],
                ["4th column", "the group owner"],
                ["bits 4–6", "what the group may do"],
                ["bits 7–9", "what everyone else may do"],
              ].map(([a, b]) => (
                <div key={a} className="flex justify-between gap-3">
                  <span className="font-mono text-[10px] text-muted">{a}</span>
                  <span className="font-mono text-[10px] text-sage/85">{b}</span>
                </div>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · OPERATORS
================================================================== */
export function OperatorsSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // OPERATORS"
      num="05"
      title={
        <>
          The file permission{" "}
          <span className="text-phos">operation chart</span>
        </>
      }
      lede={operatorNote}
      dense
    >
      <div className="overflow-x-auto border border-sage/20 bg-panel/45" style={{ borderRadius: 2 }}>
        <table className="w-full min-w-[640px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              <th className="w-20 px-4 py-3 font-mono text-[9.5px] tracked text-phos">
                Op
              </th>
              <th className="px-4 py-3 font-mono text-[9.5px] tracked text-phos">
                Definition
              </th>
              <th className="px-4 py-3 font-mono text-[9.5px] tracked text-phos">
                Example
              </th>
            </tr>
          </thead>
          <tbody>
            {operators.map((o) => (
              <tr
                key={o.op}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-4">
                  <span className="font-display text-[1.8rem] leading-none text-phos glow">
                    {o.op}
                  </span>
                </td>
                <td className="px-4 py-4 text-[14px] font-light text-sage/90">
                  {o.name}
                </td>
                <td className="px-4 py-4">
                  <code className="font-mono text-[12.5px] text-phos/85">
                    {o.ex}
                  </code>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {[
          ["+", "adds the named bits, leaves the rest alone"],
          ["-", "clears the named bits, leaves the rest alone"],
          ["=", "replaces the whole class — nothing else survives"],
        ].map(([k, v]) => (
          <div
            key={k}
            className="border-l-2 border-phos/50 bg-panel/40 px-4 py-3"
          >
            <span className="font-mono text-[12px] text-phos">{k}</span>
            <p className="mt-1.5 text-[13px] font-light leading-snug text-muted">
              {v}
            </p>
          </div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · THE NINE CHARACTERS
================================================================== */
export function NineCharsSlide() {
  const groups = [
    { label: "user", sub: "owner" },
    { label: "group", sub: "assigned group" },
    { label: "other", sub: "everyone else" },
  ];
  return (
    <Slide
      tag="SEC // CH.02 // MODE-STRING"
      num="06"
      title={
        <>
          The nine <span className="text-phos">characters</span>
        </>
      }
      lede={nineChars}
      dense
    >
      <div
        className="border border-sage/20 bg-panel/50 px-4 py-8 md:px-8 md:py-12"
        style={{ borderRadius: 2 }}
      >
        <div className="flex flex-wrap items-start justify-center gap-8 md:gap-16">
          {groups.map((g, i) => (
            <motion.div
              key={g.label}
              variants={{
                hidden: { opacity: 0, y: 14 },
                show: {
                  opacity: 1,
                  y: 0,
                  transition: { duration: 0.42, delay: i * 0.1, ease: "easeOut" },
                },
              }}
              className="min-w-[92px] text-center"
            >
              <div className="font-mono text-[clamp(1.3rem,3.4vw,2.1rem)] leading-none text-phos/35">
                ---
              </div>
              <div className="mt-3 font-mono text-[clamp(1.9rem,5.5vw,3.4rem)] leading-none tracking-[0.14em] text-phos glow">
                rwx
              </div>
              <div className="mx-auto mt-4 h-px w-full bg-sage/30" />
              <div className="mt-2.5 font-mono text-[11px] tracked text-sage">
                {g.label}
              </div>
              <div className="mt-1 font-mono text-[9px] tracked text-muted">
                {g.sub}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-9 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 border-t border-sage/20 pt-5">
          {[
            ["r", "read", "4"],
            ["w", "write", "2"],
            ["x", "execute", "1"],
          ].map(([s, n, v]) => (
            <span key={s} className="flex items-baseline gap-2.5">
              <span className="font-display text-[1.4rem] text-phos">{s}</span>
              <span className="font-mono text-[10px] tracked text-muted">
                {n}
              </span>
              <span className="border border-phos/45 px-1.5 py-0.5 font-mono text-[10px] text-phos">
                = {v}
              </span>
            </span>
          ))}
        </div>
      </div>

      <p className="mt-5 font-mono text-[10px] tracked text-muted">
        → nine characters = three groups × three operations. Read it left to
        right: who you are, then what you may do.
      </p>
    </Slide>
  );
}

/* ==================================================================
   07 · u, g, o, a REFERENCE
================================================================== */
export function ClassRefSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // REFERENCE"
      num="07"
      title={
        <>
          User, group &amp; others —{" "}
          <span className="text-phos">the letters</span>
        </>
      }
      lede="Four letters name the classes you are acting on when you run chmod."
      dense
    >
      <div className="overflow-x-auto border border-sage/20 bg-panel/45" style={{ borderRadius: 2 }}>
        <table className="w-full min-w-[700px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              {["Ref", "Class", "Description"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 font-mono text-[9.5px] tracked text-phos"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {classRef.map((c) => (
              <tr
                key={c.sym}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-4">
                  <span className="font-display text-[1.7rem] leading-none text-phos glow">
                    {c.sym}
                  </span>
                </td>
                <td className="px-4 py-4 font-mono text-[12px] tracked-sm text-sage">
                  {c.cls}
                </td>
                <td className="px-4 py-4 text-[13.5px] font-light leading-[1.6] text-muted">
                  {c.desc}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-5 flex flex-wrap gap-2.5">
        {["chmod u+x f", "chmod g-w f", "chmod o=r f", "chmod a+r f", "chmod ug+rw f"].map(
          (c) => (
            <code
              key={c}
              className="border border-sage/25 px-3 py-1.5 font-mono text-[11.5px] text-sage/85"
              style={{ borderRadius: 2 }}
            >
              {c}
            </code>
          ),
        )}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · ls -l
================================================================== */
export function LsSlide() {
  const segs = [
    { t: "-", c: "text-amber", i: "1" },
    { t: "rw-r--r--", c: "text-phos glow", i: "2" },
    { t: "1", c: "text-muted", i: "" },
    { t: "user", c: "text-sage", i: "3" },
    { t: "group", c: "text-sage", i: "4" },
    { t: "46", c: "text-phos/80", i: "5" },
    { t: "Apr 14 16:37", c: "text-muted", i: "6" },
    { t: "NarX.txt", c: "text-sage font-medium", i: "" },
  ];
  return (
    <Slide
      tag="SEC // CH.02 // INSPECT/LS"
      num="08"
      title={
        <>
          Checking permissions —{" "}
          <span className="text-phos">the ls command</span>
        </>
      }
      lede='Let us dive in to understand the possible methods to check all the desired details of a file, including its file permission. We are taking “NarX” as the default file name.'
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <Term label="ls -l" input={lsInput} output={[lsOutput]} accent />

          <div className="mt-5 overflow-x-auto border border-phos/40 bg-[#060A08] px-4 py-5" style={{ borderRadius: 2 }}>
            <div className="flex min-w-max items-baseline gap-3 font-mono text-[clamp(1rem,2.2vw,1.5rem)] leading-none">
              {segs.map((s, n) => (
                <span key={n} className={`${s.c} relative`}>
                  {s.t}
                  {s.i && (
                    <span className="absolute -bottom-3 left-0 font-mono text-[10px] text-phos/70">
                      {s.i}
                    </span>
                  )}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {[
              ["-", "regular file"],
              ["d", "directory"],
              ["l", "symbolic link"],
            ].map(([k, v]) => (
              <span
                key={k}
                className="border border-sage/25 px-2.5 py-1.5 font-mono text-[10px] tracked text-sage/85"
                style={{ borderRadius: 2 }}
              >
                <span className="text-amber">{k}</span> · {v}
              </span>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="font-mono text-[9.5px] tracked text-phos">
            The above command represents the following information
          </div>
          <div className="mt-3 border-b border-sage/15">
            {lsBreakdown.map((b, n) => (
              <motion.div
                key={n}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: n * 0.06 },
                  },
                }}
                className="grid grid-cols-[1.8rem_minmax(0,1fr)] gap-x-4 border-t border-sage/15 py-3"
              >
                <span className="font-mono text-[11px] text-phos/70">
                  {String(n + 1).padStart(2, "0")}
                </span>
                <span className="text-[13.5px] font-light leading-[1.55] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · namei & stat
================================================================== */
export function NameiStatSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // INSPECT/PATH"
      num="09"
      title={
        <>
          The <span className="text-phos">namei</span> &amp;{" "}
          <span className="text-phos">stat</span> commands
        </>
      }
      lede="Two deeper ways to interrogate a file: one walks the whole path, the other pinpoints the exact inode."
      dense
    >
      <div className="grid gap-5 lg:grid-cols-2">
        <motion.div variants={rise}>
          <div className="mb-2.5 font-mono text-[9.5px] tracked text-phos">
            namei — every component of a path
          </div>
          <Term label="namei -l" input={nameiBlock.input} output={nameiBlock.output} />
          <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-muted">
            The namei command checks the file path through each component of the
            file path — every directory in the chain must grant execute, or the
            file below it is unreachable no matter what its own mode says.
          </p>
        </motion.div>

        <motion.div variants={rise}>
          <div className="mb-2.5 font-mono text-[9.5px] tracked text-phos">
            stat — pinpoints the file location
          </div>
          <Term label="stat" input={statBlock.input} output={statBlock.output} />
          <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-muted">
            Unlike the ls -l command, the stat command is used to pin point the
            file location — device, inode, block count, link count and all three
            timestamps in one view.
          </p>
        </motion.div>
      </div>

      <div className="mt-7 grid gap-4 border-t border-sage/20 pt-5 md:grid-cols-3">
        {inspectNotesLocal().map((x) => (
          <div key={x.cmd}>
            <code className="font-mono text-[12.5px] text-phos">{x.cmd}</code>
            <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">
              {x.desc}
            </p>
          </div>
        ))}
      </div>
    </Slide>
  );
}

function inspectNotesLocal() {
  return [
    {
      cmd: "ls -l",
      desc: "The everyday view — type, mode, owner, group, size, mtime and name in one column-aligned row.",
    },
    {
      cmd: "namei -l /path/to/your/file",
      desc: "Walks the path component by component, printing the mode of every directory that must be traversed.",
    },
    {
      cmd: "stat example.txt",
      desc: "Metadata beyond the mode: inode, device, blocks, links and the access / modify / change / birth times.",
    },
  ];
}

/* ==================================================================
   10 · chmod — SYMBOLIC NOTATION
================================================================== */
export function ChmodSymbolicSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // CHMOD/SYMBOLIC"
      num="10"
      title={
        <>
          chmod &amp;{" "}
          <span className="text-phos">symbolic notation</span>
        </>
      }
      lede={chmodIntro}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Example 1 — give “execute” to others on xyz.txt, one piece at a time
          </div>
          <div
            className="mt-3 border border-phos/40 bg-[#060A08] px-4 py-4"
            style={{ borderRadius: 2 }}
          >
            {symbolicSteps.map((s, n) => (
              <motion.div
                key={s.n}
                variants={{
                  hidden: { opacity: 0, x: -10 },
                  show: {
                    opacity: 1,
                    x: 0,
                    transition: { duration: 0.36, delay: n * 0.12 },
                  },
                }}
                className={`grid grid-cols-[2rem_minmax(0,1fr)] gap-x-4 py-2.5 ${
                  n ? "border-t border-sage/12" : ""
                }`}
              >
                <span className="font-mono text-[11px] text-phos/70">{s.n}</span>
                <div>
                  <div className="font-mono text-[13.5px]">
                    <span className="text-phos">narx@lab</span>
                    <span className="text-muted">:~$ </span>
                    <span className="text-sage">{s.cmd}</span>
                    <span className="ml-2 text-phos/70">▊</span>
                  </div>
                  <div className="mt-1 text-[12.5px] font-light text-muted">
                    {s.note}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Anatomy of a symbolic mode
            </div>
            <div className="mt-4 text-center font-mono text-[clamp(1.4rem,3vw,2rem)] leading-none">
              <span className="text-sage">chmod </span>
              <span className="text-phos glow">o</span>
              <span className="text-amber glow">+</span>
              <span className="text-phos glow">x</span>
              <span className="text-sage"> file</span>
            </div>
            <div className="mt-5 space-y-2.5">
              {[
                ["class", "o — which group (u, g, o, a)"],
                ["operator", "+ — add, − remove, = assign"],
                ["symbol", "x — r, w, x (and s, t for special)"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-baseline gap-3 border-t border-sage/15 pt-2.5">
                  <span className="w-16 shrink-0 font-mono text-[9.5px] tracked text-phos">
                    {k}
                  </span>
                  <span className="text-[13px] font-light text-sage/85">{v}</span>
                </div>
              ))}
            </div>
          </Panel>

          <div className="mt-4 border-l-2 border-amber pl-5">
            <div className="font-mono text-[9.5px] tracked text-amber">
              Watch out
            </div>
            <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">
              A mode written without a class letter is not portable —{" "}
              <code className="font-mono text-sage">chmod +x file</code> relies on
              the implementation's default. Always write{" "}
              <code className="font-mono text-phos">o+x</code> or{" "}
              <code className="font-mono text-phos">a+x</code> explicitly.
            </p>
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · MORE SYMBOLIC EXAMPLES
================================================================== */
export function SymbolicExamplesSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // CHMOD/EXAMPLES"
      num="11"
      title={
        <>
          More{" "}
          <span className="text-phos">symbolic combinations</span>
        </>
      }
      lede="Classes can be combined with commas on a single line — revoke, assign and add in one invocation."
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {symbolicExamples.map((e, n) => (
          <motion.div
            key={e.cmd}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.08, ease: "easeOut" },
              },
            }}
            className="flex flex-col border border-sage/15 bg-panel/50 p-5 transition-colors hover:border-phos/45"
            style={{ borderRadius: 2 }}
          >
            <div className="font-mono text-[9.5px] tracked text-phos">
              {e.title}
            </div>
            <code className="mt-3 block break-words font-mono text-[14px] text-sage">
              {e.cmd}
            </code>
            <div className="mt-4 border-y border-sage/15 py-3 text-center font-mono text-[1.35rem] tracking-[0.1em] text-phos glow">
              {e.result}
            </div>
            <p className="mt-4 text-[13px] font-light leading-[1.6] text-muted">
              {e.desc}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 border-l-2 border-phos/60 pl-5">
        <p className="max-w-[88ch] text-[14.5px] font-light leading-[1.65] text-sage/85">
          There can be numerous combinations of file permissions you can invoke,
          revoke and assign. Try some on your own Linux system —{" "}
          <code className="font-mono text-phos">ls -l</code> before and after is
          the fastest way to build the intuition.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · OCTAL NOTATION + interactive calculator
================================================================== */
function OctalCalc() {
  const [perms, setPerms] = useState(0o644);
  const classes: { key: string; label: string; shift: number }[] = [
    { key: "u", label: "user", shift: 6 },
    { key: "g", label: "group", shift: 3 },
    { key: "o", label: "other", shift: 0 },
  ];
  const maskFor = (shift: number, i: number) => 1 << (shift + (2 - i));
  const digits = classes.map((c) => (perms >> c.shift) & 7);

  return (
    <div
      className="border border-phos/40 bg-panel/55 p-5"
      style={{ borderRadius: 2 }}
    >
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <span className="font-mono text-[9.5px] tracked text-phos">
          Octal calculator
        </span>
        <span className="font-mono text-[9.5px] tracked text-muted">
          tap to toggle
        </span>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-3">
        {classes.map((c, ci) => (
          <div key={c.key} className="text-center">
            <div className="font-display text-[clamp(1.8rem,5vw,3rem)] leading-none text-phos glow tabular-nums">
              {digits[ci]}
            </div>
            <div className="mt-1.5 font-mono text-[9.5px] tracked text-muted">
              {c.label}
            </div>
            <div className="mt-3 space-y-1.5">
              {["r", "w", "x"].map((s, i) => {
                const m = maskFor(c.shift, i);
                const on = (perms & m) !== 0;
                return (
                  <button
                    key={s}
                    onClick={() => setPerms((p) => p ^ m)}
                    aria-pressed={on}
                    className={`flex w-full items-center justify-between border px-2.5 py-1.5 transition-colors ${
                      on
                        ? "border-phos bg-deep text-phos"
                        : "border-sage/25 text-muted hover:border-phos/50"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    <span className="font-mono text-[12px]">{s}</span>
                    <span className="font-mono text-[11px] tabular-nums">
                      {on ? [4, 2, 1][i] : 0}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5 border-t border-sage/20 pt-4 text-center font-mono text-[clamp(1.1rem,2.4vw,1.6rem)] text-sage">
        <span className="text-phos">{digits.join("")}</span>
        <span className="text-muted"> / </span>
        <span className="text-sage/80">
          {classes.map((_, i) => ["r", "w", "x"].map((s, j) => (((perms >> ((2 - i) * 3 + (2 - j)) & 1) ? s : "-")).toString()).join("")).join("")}
        </span>
      </div>
      <div className="mt-2 text-center font-mono text-[12.5px] text-phos/85">
        chmod {digits.join("")} file.txt
      </div>

      <button
        onClick={() => setPerms((p) => (p === 0o644 ? 0o755 : 0o644))}
        className="mt-4 w-full border border-sage/25 py-2 font-mono text-[10px] tracked text-sage transition-colors hover:border-phos hover:text-phos"
        style={{ borderRadius: 2 }}
      >
        Toggle 644 ↔ 755
      </button>
    </div>
  );
}

export function OctalSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // CHMOD/OCTAL"
      num="12"
      title={
        <>
          Octal notation <span className="text-phos">permissions</span>
        </>
      }
      lede={octalIntro}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="grid gap-3 sm:grid-cols-3">
            {octalMap.map((o, n) => (
              <motion.div
                key={o.sym}
                variants={{
                  hidden: { opacity: 0, y: 12 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.38, delay: n * 0.08 },
                  },
                }}
                className="border border-sage/15 bg-panel/50 p-5 text-center"
                style={{ borderRadius: 2 }}
              >
                <div className="font-display text-[3rem] leading-none text-phos glow">
                  {o.sym}
                </div>
                <div className="mt-2 font-mono text-[10px] tracked text-muted">
                  {o.name}
                </div>
                <div className="mt-3 border-t border-sage/15 pt-3 font-display text-[1.5rem] text-sage">
                  {o.value}
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-5 space-y-3">
            {[
              ["Read (r) = 4", "the bit that lets you see contents"],
              ["Write (w) = 2", "the bit that lets you change them"],
              ["Execute (x) = 1", "the bit that lets you run it"],
            ].map(([a, b]) => (
              <div
                key={a}
                className="flex flex-wrap items-baseline justify-between gap-2 border-t border-sage/15 pt-3"
              >
                <span className="font-mono text-[13px] text-phos">{a}</span>
                <span className="font-mono text-[11px] text-muted">{b}</span>
              </div>
            ))}
          </div>

          <div className="mt-5 border-l-2 border-phos/60 pl-5">
            <p className="max-w-[80ch] text-[14.5px] font-light leading-[1.65] text-sage/85">
              Permissions for owner, group and others are represented by a
              three-digit octal value. The sum of the permissions in each group
              gives that digit — and each of the three digits stands in for one
              of the classes <code className="font-mono text-phos">u</code>,{" "}
              <code className="font-mono text-phos">g</code> or{" "}
              <code className="font-mono text-phos">o</code>, used in place of
              r, w and x.
            </p>
          </div>
        </div>

        <div className="lg:col-span-5">
          <OctalCalc />
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · READING A MODE
================================================================== */
export function ModeReadingSlide() {
  const [active, setActive] = useState(0);
  return (
    <Slide
      tag="SEC // CH.02 // INTERPRETATION"
      num="13"
      title={
        <>
          Security permissions —{" "}
          <span className="text-phos">reading a mode</span>
        </>
      }
      lede='The combination for the permissions is r, w, x and -. Take the example "rw- r-x r--" and read it one group at a time.'
      dense
    >
      <div className="grid gap-6 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-6">
          <div className="flex gap-3 sm:gap-5">
            {modeReading.map((m, n) => (
              <button
                key={m.who}
                onClick={() => setActive(n)}
                onMouseEnter={() => setActive(n)}
                className={`flex-1 border p-4 text-center transition-all duration-200 ${
                  active === n
                    ? "border-phos bg-deep/70"
                    : "border-sage/20 bg-panel/45 hover:border-sage/40"
                }`}
                style={{ borderRadius: 2 }}
              >
                <div
                  className={`font-mono text-[clamp(1.4rem,4vw,2.4rem)] leading-none tracking-[0.08em] ${
                    active === n ? "text-phos glow" : "text-sage/70"
                  }`}
                >
                  {m.bits}
                </div>
                <div className="mt-3 font-mono text-[9.5px] tracked text-muted">
                  {m.who}
                </div>
              </button>
            ))}
          </div>

          <div
            className="mt-4 font-mono text-[clamp(1.6rem,5vw,3rem)] leading-none tracking-[0.1em]"
            aria-hidden
          >
            <span className="text-phos/35">rw- </span>
            <span className="text-phos/35">r-x </span>
            <span className="text-phos/35">r--</span>
          </div>
          <div className="mt-2 font-mono text-[10px] tracked text-muted">
            chars 1–3 owner · 4–6 group · 7–9 others
          </div>
        </div>

        <div className="lg:col-span-6">
          <Panel className="p-6">
            <div className="flex items-baseline justify-between gap-4">
              <span className="font-display text-[clamp(1.3rem,3vw,2rem)] leading-none text-phos">
                “{modeReading[active].bits}”
              </span>
              <span className="font-mono text-[9.5px] tracked text-muted">
                {modeReading[active].who} · {modeReading[active].title}
              </span>
            </div>
            <p className="mt-5 text-[15px] font-light leading-[1.7] text-sage/90">
              {modeReading[active].desc}
            </p>
            <div className="mt-5 h-px w-full bg-sage/15" />
            <p className="mt-4 font-mono text-[11px] leading-relaxed tracked text-phos/80">
              {active === 0 && "ls -l → -rw-r--r--  (0644)"}
              {active === 1 && "ls -l → -rw-r-x---  (0650)"}
              {active === 2 && "ls -l → -rw-r-----  (0640)"}
            </p>
          </Panel>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · SPECIAL PERMISSIONS
================================================================== */
export function SpecialPermsSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // SPECIAL-BITS"
      num="14"
      title={
        <>
          Special permissions <span className="text-amber">in Linux</span>
        </>
      }
      lede="Besides the usual methods, Linux also offers special permission types to give more complex control over files."
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {specialPerms.map((s, n) => (
          <motion.div
            key={s.i}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.08, ease: "easeOut" },
              },
            }}
            className="flex flex-col border border-amber/35 bg-panel/50 p-5 transition-colors hover:border-amber/70"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between">
              <span className="font-mono text-[11px] text-amber/80">{s.i}</span>
              <span
                className="border border-amber/50 px-2 py-1 font-display text-[13px] text-amber"
                style={{ borderRadius: 2 }}
              >
                {s.octal}
              </span>
            </div>
            <h3 className="mt-3 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
              {s.name}
            </h3>
            <p className="mt-3 text-[13.5px] font-light leading-[1.62] text-muted">
              {s.desc}
            </p>
            <div className="mt-4 border-t border-sage/15 pt-3.5">
              <code className="font-mono text-[12.5px] text-phos">{s.cmd}</code>
            </div>
            <div className="mt-auto pt-3.5">
              <span className="font-mono text-[9px] tracked text-amber/80">
                {s.risk}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 grid gap-3 border-t border-sage/20 pt-5 sm:grid-cols-3">
        {[
          ["4xxx", "setuid — the leading 4 in a four-digit octal mode"],
          ["2xxx", "setgid — the leading 2"],
          ["1xxx", "sticky — the leading 1"],
        ].map(([k, v]) => (
          <div key={k} className="flex items-baseline gap-3">
            <span className="font-display text-[1.1rem] text-phos">{k}</span>
            <span className="text-[13px] font-light text-muted">{v}</span>
          </div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · chown
================================================================== */
export function ChownSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // CHOWN"
      num="15"
      title={
        <>
          Setting permissions for a{" "}
          <span className="text-phos">specific user</span>
        </>
      }
      lede="To set permissions for a specific user or group, ownership itself may have to move first."
      dense
    >
      <div className="grid gap-4 md:grid-cols-2">
        {ownershipBlocks.map((b, n) => (
          <motion.div
            key={b.tool}
            variants={{
              hidden: { opacity: 0, y: 12 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.1, ease: "easeOut" },
              },
            }}
            className="border border-sage/15 bg-panel/50 p-5"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-baseline justify-between gap-4">
              <span className="font-display text-[1.6rem] uppercase text-phos">
                {b.tool}
              </span>
              <span className="font-mono text-[9px] tracked text-muted">
                {n === 0 ? "ownership" : "mode"}
              </span>
            </div>
            <p className="mt-3 text-[14px] font-light leading-[1.6] text-muted">
              {b.desc}
            </p>
            <div className="mt-4 border-y border-sage/15 py-3 text-center font-mono text-[13.5px] text-sage">
              {b.cmd}
            </div>
            <p className="mt-4 border-l-2 border-amber pl-4 text-[13px] font-light italic leading-[1.55] text-amber/90">
              {b.note}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 border border-phos/35 bg-deep/25 p-5" style={{ borderRadius: 2 }}>
        <div className="font-mono text-[9.5px] tracked text-phos">
          The shortest working recipe
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-2 font-mono text-[13.5px] text-sage">
          {[
            "chown narx:devs report.log",
            "chmod 640 report.log",
            "ls -l report.log",
          ].map((c, i) => (
            <span key={c} className="flex items-center gap-3">
              <code className="text-phos">{c}</code>
              {i < 2 && <span className="text-muted">→</span>}
            </span>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · HANDS-ON SIMULATOR
================================================================== */
export function SimulatorSlide() {
  return (
    <Slide
      tag="SEC // CH.02 // PRACTICE / CLI-LAB"
      num="16"
      title={
        <>
          Hands-on —{" "}
          <span className="text-phos">the permission lab</span>
        </>
      }
      lede="A real shell, a virtual filesystem and three exercises. Switch identity to feel how the same mode string behaves for owner, group member and stranger."
      dense
    >
      <CliLab />
    </Slide>
  );
}

/* ==================================================================
   17 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide2({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">
          Sec // CH.02 // Check
        </span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Read the mode.
          <br />
          <span className="text-phos glow">Then answer.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Five multiple-choice items on modes, chmod, octal notation and the
          special bits. Select an answer to reveal it instantly — the rationale
          appears underneath and your running score is kept in the footer.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(17)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   18–22 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide2({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions2[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.02 // CHECK // Q0${n + 1}`}
      num={String(18 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              ["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"],
              ["Domain", "Linux permissions"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex items-baseline justify-between border-t border-sage/15 pt-2.5"
              >
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.06 },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words font-mono text-[13.5px] leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   23 · SCORE
================================================================== */
export function ScoreSlide2({ answers }: { answers: (number | null)[] }) {
  const score = questions2.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions2.length) * 100);
  const verdict =
    pct === 100
      ? "Modes, classes and special bits — all correct."
      : pct >= 60
        ? "Solid. Re-read the octal sums and the sticky bit."
        : "Run the CLI lab again, then revisit octal notation.";

  return (
    <Slide
      tag="SEC // CH.02 // CHECK // RESULT"
      num="23"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions2.length}
              </span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions2.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions2.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   24 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide2() {
  const items = [
    ["01", "Nine bits, three groups", "rwx × owner, group, other — that string is the whole file mode."],
    ["02", "r, w, x mean different things on directories", "Write on a directory is create and delete, not edit."],
    ["03", "u, g, o, a pick the class", "+ adds, − removes, = replaces that class outright."],
    ["04", "Octal is just arithmetic", "r = 4, w = 2, x = 1; sum each column of three."],
    ["05", "The path must be traversable", "Every directory on the way needs execute, or the file is unreachable."],
    ["06", "Special bits change who you run as", "setuid, setgid and the sticky bit — powerful, and worth auditing."],
  ];

  return (
    <Slide
      tag="SEC // CH.02 // CLOSE"
      num="24"
      title={
        <>
          Chapter 02 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-phos/70">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 02 · {CH2_TITLE}
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents2.length} sections · {TOTAL2} slides
        </span>
      </div>
    </Slide>
  );
}
