import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import crack from "./assets/crack.jpg";
import {
  cveNotes,
  ch6Bullets,
  ch6Intro,
  ch6Stamp,
  contents6,
  cvssBands,
  questions6,
  testingLifecycle,
  TOTAL6,
  vulns,
} from "./data/ch6";

/* ==================================================================
   01 · TITLE
================================================================== */
export function TitleSlide6({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <img
        src={crack}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.45]"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_15%_50%,rgba(11,15,13,0.97)_25%,rgba(11,15,13,0.7)_65%,rgba(11,15,13,0.92)_100%)]" />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Threat briefing · lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 06 of 16
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.06&nbsp;//&nbsp;VULNERABILITIES
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL6}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-9">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-amber"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 06
              </span>
              <span className="mt-1 block text-[clamp(2.2rem,6.2vw,5.4rem)] text-amber glow">
                Vulnerabilities in
                <br />
                Information Security
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-amber/60"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              {ch6Intro} Five classes of weakness — hardware, software,
              network, procedural and human — each with its own examples,
              causes and countermeasures.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(3)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-amber hover:text-amber"
                style={{ borderRadius: 2 }}
              >
                Jump to hardware vulnerabilities
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-3 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Vulnerability types", "Five"],
            ["Documented examples", "Fifteen"],
            ["Countermeasures", "Twenty"],
            ["Doc revision", "8 Jun 2026"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT A VULNERABILITY IS
================================================================== */
export function IntroSlide6() {
  const chain = [
    ["Threat", "the actor or event with intent"],
    ["Vulnerability", "the weakness it gets through"],
    ["Exploit", "the technique used"],
    ["Impact", "C · I · A compromised"],
  ];
  return (
    <Slide
      tag="SEC // CH.06 // DEFINITION"
      num="02"
      title={
        <>
          Vulnerabilities in{" "}
          <span className="text-phos">information security</span>
        </>
      }
      dense
    >
      <div className="border-y border-phos/45 py-5 md:py-6">
        <p className="max-w-[96ch] text-[clamp(1rem,1.35vw,1.25rem)] font-light leading-[1.62] text-sage">
          {ch6Intro}
        </p>
      </div>

      <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="font-mono text-[9.5px] tracked text-phos">
            What defines it
          </div>
          <div className="mt-3 border-b border-sage/15">
            {ch6Bullets.map((b, n) => (
              <motion.div
                key={b}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: n * 0.07 },
                  },
                }}
                className="grid grid-cols-[2.1rem_minmax(0,1fr)] gap-x-4 border-t border-sage/15 py-3.5"
              >
                <span className="font-mono text-[11px] text-phos/70">
                  {String(n + 1).padStart(2, "0")}
                </span>
                <span className="text-[14px] font-light leading-[1.55] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-muted">
              Section 01 · the weakness itself
            </span>
            <span className="font-mono text-[9.5px] tracked text-amber/80">
              {ch6Stamp}
            </span>
          </div>
        </div>

        <aside className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Anatomy · how a weakness becomes an incident
            </div>
            <div className="mt-4 space-y-0">
              {chain.map(([k, v], n) => (
                <div
                  key={k}
                  className="flex items-center gap-3 border-t border-sage/15 py-3 first:border-t-0"
                >
                  <span
                    className={`font-mono text-[11px] ${
                      n === 1 ? "text-amber" : "text-phos/70"
                    }`}
                  >
                    {String(n + 1).padStart(2, "0")}
                  </span>
                  <span
                    className={`w-[7.5rem] shrink-0 font-mono text-[12px] tracked-sm ${
                      n === 1 ? "text-amber" : "text-sage"
                    }`}
                  >
                    {k}
                  </span>
                  <span className="text-[12.5px] font-light text-muted">{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 h-px w-full bg-sage/15" />
            <p className="mt-4 text-[13px] font-light leading-[1.6] text-muted">
              Security work sits at step 02: remove the weakness, or the threat
              reaches the asset regardless of everything else you have bought.
            </p>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · FIVE TYPES — INDEX
================================================================== */
export function VulnIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.06 // TAXONOMY"
      num="03"
      title={
        <>
          Type of <span className="text-amber">vulnerabilities</span>
        </>
      }
      lede="Five classes, each profiled across two slides: what goes wrong, then what causes it and what stops it."
      dense
    >
      <div className="border-b border-sage/15">
        {vulns.map((v) => (
          <Row
            key={v.key}
            i={v.i}
            label={v.name}
            desc={v.def}
            meta={`${v.examples.length} ex · ${v.prevents.length} fix`}
          />
        ))}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {vulns.map((v) => (
          <div
            key={v.key}
            className="border-l-2 border-phos/50 bg-panel/40 px-4 py-3"
          >
            <div className="font-mono text-[9.5px] tracked text-phos">
              {v.short}
            </div>
            <p className="mt-1.5 font-mono text-[11px] leading-snug text-muted">
              {v.causes.length
                ? `${v.causes.length} documented causes`
                : "process & people"}
            </p>
          </div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Per-type slides
================================================================== */
function ExamplesFor({ idx, num }: { idx: number; num: string }) {
  const v = vulns[idx];
  const orphan = v.examples.length === 3;
  return (
    <Slide
      tag={`SEC // CH.06 // ${v.short.toUpperCase()} / EXAMPLES`}
      num={num}
      title={
        <>
          {v.short} <span className="text-amber">vulnerability</span>
        </>
      }
      lede={v.def}
      dense
    >
      <div className="font-mono text-[9.5px] tracked text-amber">
        For example
      </div>
      <div className="mt-3 grid gap-4 md:grid-cols-2">
        {v.examples.map((e, n) => (
          <motion.div
            key={e.title}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.42, delay: n * 0.1, ease: "easeOut" },
              },
            }}
            className={`flex flex-col border border-amber/30 bg-panel/50 p-5 transition-colors duration-200 hover:border-amber/70 ${
              orphan && n === 2 ? "md:col-span-2" : ""
            }`}
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between gap-4">
              <span className="font-mono text-[11px] text-amber/80">
                {String(n + 1).padStart(2, "0")}
              </span>
              <span
                className="border border-amber/45 px-2 py-1 font-mono text-[9px] tracked text-amber"
                style={{ borderRadius: 2 }}
              >
                {v.short}
              </span>
            </div>
            <h3 className="mt-3 font-display text-[1.02rem] uppercase leading-tight tracking-tight text-sage">
              {e.title}
            </h3>
            <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
              {e.desc}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 border-l-2 border-phos pl-5">
        <span className="font-mono text-[9.5px] tracked text-phos">
          Where this sits
        </span>
        <p className="mt-2 max-w-[88ch] text-[14px] font-light leading-[1.65] text-sage/85">
          {v.short} weaknesses are the “entry point” in the definition above —
          a threat only reaches confidentiality, integrity or availability by
          coming through one of them.
        </p>
      </div>
    </Slide>
  );
}

function CausesPreventionFor({
  idx,
  num,
  causesLabel,
}: {
  idx: number;
  num: string;
  causesLabel: string;
}) {
  const v = vulns[idx];
  const hasCauses = v.causes.length > 0;
  return (
    <Slide
      tag={`SEC // CH.06 // ${v.short.toUpperCase()} / DEFENCE`}
      num={num}
      title={
        <>
          {hasCauses ? "Causes & prevention — " : "Prevention — "}
          <span className="text-phos">{v.short}</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        {hasCauses && (
          <div className="lg:col-span-4">
            <div className="flex items-baseline justify-between gap-3">
              <span className="font-mono text-[9.5px] tracked text-amber">
                {causesLabel}
              </span>
              <span className="font-mono text-[9.5px] tracked text-muted">
                {String(v.causes.length).padStart(2, "0")}
              </span>
            </div>
            <div className="mt-3 border-b border-sage/15">
              {v.causes.map((c, n) => (
                <motion.div
                  key={c}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: n * 0.06 },
                    },
                  }}
                  className="grid grid-cols-[1.8rem_minmax(0,1fr)] gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="font-mono text-[11px] text-amber/75">
                    {String(n + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[13.5px] font-light leading-[1.55] text-sage/85">
                    {c}
                  </span>
                </motion.div>
              ))}
            </div>
            <div className="mt-5 border-l-2 border-amber pl-4">
              <span className="font-mono text-[9.5px] tracked text-amber">
                Root cause
              </span>
              <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">
                These are configuration and hygiene failures, not exotic
                exploits — which is exactly why they remain so common.
              </p>
            </div>
          </div>
        )}

        <div className={hasCauses ? "lg:col-span-8" : "lg:col-span-12"}>
          <div className="flex items-baseline justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-phos">
              Prevention of {v.short.toLowerCase()} vulnerability
            </span>
            <span className="font-mono text-[9.5px] tracked text-muted">
              {String(v.prevents.length).padStart(2, "0")} controls
            </span>
          </div>

          <div className="mt-3 grid gap-4 md:grid-cols-2">
            {v.prevents.map((p, n) => (
              <motion.div
                key={p.title}
                variants={{
                  hidden: { opacity: 0, y: 14 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: {
                      duration: 0.4,
                      delay: 0.06 + n * 0.08,
                      ease: "easeOut",
                    },
                  },
                }}
                className="flex flex-col border border-phos/35 bg-panel/50 p-5 transition-colors duration-200 hover:border-phos/70"
                style={{ borderRadius: 2 }}
              >
                <div className="flex items-start justify-between gap-3">
                  <span className="font-display text-[1.7rem] leading-none text-phos">
                    {String(n + 1).padStart(2, "0")}
                  </span>
                  <span
                    className="border border-phos/40 px-2 py-1 font-mono text-[9px] tracked text-phos"
                    style={{ borderRadius: 2 }}
                  >
                    Control
                  </span>
                </div>
                <h3 className="mt-3 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
                  {p.title}
                </h3>
                <p className="mt-2.5 text-[13.5px] font-light leading-[1.65] text-muted">
                  {p.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

export const HardwareExamples = () => <ExamplesFor idx={0} num="04" />;
export const HardwareDefence = () => (
  <CausesPreventionFor idx={0} num="05" causesLabel="Causes of hardware vulnerability" />
);
export const SoftwareExamples = () => <ExamplesFor idx={1} num="06" />;
export const SoftwareDefence = () => (
  <CausesPreventionFor idx={1} num="07" causesLabel="Causes of software vulnerabilities" />
);
export const NetworkExamples = () => <ExamplesFor idx={2} num="08" />;
export const NetworkDefence = () => (
  <CausesPreventionFor idx={2} num="09" causesLabel="Causes of network vulnerability" />
);
export const ProceduralExamples = () => <ExamplesFor idx={3} num="10" />;
export const ProceduralDefence = () => (
  <CausesPreventionFor idx={3} num="11" causesLabel="" />
);
export const HumanExamples = () => <ExamplesFor idx={4} num="12" />;
export const HumanDefence = () => (
  <CausesPreventionFor idx={4} num="13" causesLabel="" />
);

/* ==================================================================
   14 · HOW VULNERABILITIES ARE FOUND  (extension)
================================================================== */
export function TestingSlide() {
  return (
    <Slide
      tag="SEC // CH.06 // EXTENSION/TESTING"
      num="14"
      title={
        <>
          How vulnerabilities are{" "}
          <span className="text-phos">actually found</span>
        </>
      }
      lede="“Identified and reduced through regular security testing” is the fourth bullet of this chapter's definition. This is what that testing looks like in practice."
      dense
    >
      <div className="border-b border-sage/15">
        {testingLifecycle.map((t, n) => (
          <motion.div
            key={t.i}
            variants={{
              hidden: { opacity: 0, y: 8 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.34, delay: n * 0.05 },
              },
            }}
            className="grid grid-cols-[2.6rem_minmax(0,1fr)] gap-x-5 border-t border-sage/15 py-4 transition-colors duration-200 hover:bg-phos/[0.045] md:grid-cols-[2.6rem_minmax(0,1fr)_auto]"
          >
            <span
              className={`flex h-9 w-9 items-center justify-center border font-mono text-[12px] ${
                n >= 4 ? "border-amber/70 text-amber" : "border-phos/60 text-phos"
              }`}
              style={{ borderRadius: 2 }}
            >
              {t.i}
            </span>
            <div className="min-w-0">
              <div className="font-mono text-[13px] font-medium tracked-sm text-sage">
                {t.name}
              </div>
              <p className="mt-1.5 max-w-[74ch] text-[13.5px] font-light leading-[1.6] text-muted">
                {t.desc}
              </p>
            </div>
            <span className="col-start-2 mt-2 font-mono text-[9.5px] tracked text-phos/60 md:col-start-3 md:mt-1 md:text-right">
              {t.when}
            </span>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="border-l-2 border-phos pl-4">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Shift left
          </div>
          <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-muted">
            The earlier a weakness is caught, the cheaper it is to fix — a
            design flaw caught in threat modelling costs a fraction of the same
            flaw found in production.
          </p>
        </div>
        <div className="border-l-2 border-amber pl-4">
          <div className="font-mono text-[9.5px] tracked text-amber">
            No single tool is enough
          </div>
          <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-muted">
            SAST cannot see runtime behaviour, DAST cannot see dead code, and
            neither can judge business logic. The phases overlap deliberately.
          </p>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · CVE & CVSS  (extension)
================================================================== */
export function CveSlide() {
  const widths: Record<string, number> = {
    Low: 3.9,
    Medium: 3.0,
    High: 2.0,
    Critical: 1.1,
  };
  return (
    <Slide
      tag="SEC // CH.06 // EXTENSION/SCORING"
      num="15"
      title={
        <>
          Naming and scoring —{" "}
          <span className="text-phos">CVE &amp; CVSS</span>
        </>
      }
      lede="Once a vulnerability is found it needs a name everyone shares and a number everyone agrees on. That is what these two systems do."
      dense
    >
      <div className="font-mono text-[9.5px] tracked text-phos">
        CVSS v3.1 base score bands
      </div>
      <div className="mt-3 overflow-x-auto border border-sage/20 bg-panel/45 p-4" style={{ borderRadius: 2 }}>
        <div className="flex min-w-[560px] gap-1">
          {cvssBands
            .filter(([n]) => n !== "None")
            .map(([name, range, color]) => (
              <div
                key={name}
                style={{
                  width: `${(widths[name] / 10) * 100}%`,
                  background: `${color}1f`,
                  borderTop: `2px solid ${color}`,
                }}
                className="px-3 py-3"
              >
                <div
                  className="font-mono text-[11px] tracked-sm"
                  style={{ color }}
                >
                  {name}
                </div>
                <div className="mt-1.5 font-mono text-[12.5px] tabular-nums text-sage/85">
                  {range}
                </div>
              </div>
            ))}
        </div>
        <div className="mt-2 flex min-w-[560px] justify-between font-mono text-[10px] text-muted">
          <span>0.0</span>
          <span>5.0</span>
          <span>10.0</span>
        </div>
      </div>

      <div className="mt-6 grid gap-px bg-sage/15 sm:grid-cols-2">
        {cveNotes.map(([k, v], n) => (
          <motion.div
            key={k}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.06 },
              },
            }}
            className="bg-ink p-5"
          >
            <div className="font-mono text-[12px] tracked-sm text-phos">
              {k}
            </div>
            <p className="mt-2.5 text-[13.5px] font-light leading-[1.62] text-muted">
              {v}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 border-l-2 border-amber pl-5">
        <span className="font-mono text-[9.5px] tracked text-amber">
          Tie-back
        </span>
        <p className="mt-2 max-w-[88ch] text-[14px] font-light leading-[1.65] text-sage/85">
          Every CVE belongs to one of the five classes in this chapter — a
          scoring system tells you how urgent it is, but the class tells you
          which team owns the fix.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide6({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">
          Sec // CH.06 // Check
        </span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Find the weakness.
          <br />
          <span className="text-amber glow">Then answer.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Five scenarios drawn from this chapter — a stolen laptop, an input
          overrun, a missed patch, an open port and a default credential. Each
          one maps to a single class and a single control.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(16)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   17–21 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide6({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions6[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.06 // CHECK // Q0${n + 1}`}
      num={String(17 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-amber pl-5">
            <p className="text-[clamp(1.05rem,2vw,1.5rem)] leading-[1.4] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              [
                "Status",
                !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect",
              ],
              ["Domain", "Vulnerability class"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex items-baseline justify-between border-t border-sage/15 pt-2.5"
              >
                <span className="font-mono text-[9.5px] tracked text-muted">
                  {k}
                </span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.06 },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   22 · SCORE
================================================================== */
export function ScoreSlide6({ answers }: { answers: (number | null)[] }) {
  const score = questions6.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions6.length) * 100);
  const verdict =
    pct === 100
      ? "All five classes, correctly matched to their controls."
      : pct >= 60
        ? "Solid. Re-read the class you missed and its prevention list."
        : "Work back through the five type slides, then retake.";

  return (
    <Slide
      tag="SEC // CH.06 // CHECK // RESULT"
      num="22"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div
            className="border border-phos/40 bg-panel/60 p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions6.length}
              </span>
            </div>
            <div
              className="mt-5 h-2 w-full bg-sage/12"
              style={{ borderRadius: 2 }}
            >
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions6.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions6.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.05 },
                    },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   23 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide6() {
  const items = [
    ["01", "A weakness, not an attack", "The vulnerability exists quietly — the threat is what turns it into an incident."],
    ["02", "Five places it can live", "Hardware, software, network, procedural and human — all five at once in a real organization."],
    ["03", "Most causes are hygiene", "Old systems, unencrypted devices, open ports and default credentials."],
    ["04", "Process is a vulnerability", "RBAC, least privilege and monitoring are security controls, not admin chores."],
    ["05", "The human layer is still the softest", "Training, MFA and cautious clicking defend against social engineering."],
    ["06", "Found by testing, tracked by CVE", "Regular security testing finds them; CVSS tells you which to fix first."],
  ];

  return (
    <Slide
      tag="SEC // CH.06 // CLOSE"
      num="23"
      title={
        <>
          Chapter 06 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 06 · Vulnerabilities in Information Security
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents6.length} sections · {TOTAL6} slides
        </span>
      </div>
    </Slide>
  );
}
