import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  careerPaths,
  certs,
  certsLead,
  ch8Intro,
  ch8Stamp,
  companies,
  companiesLead,
  contents8,
  drivers,
  driversLead,
  factors,
  factorsLead,
  headline,
  marketBullets,
  marketLead,
  platforms,
  practiceLead,
  projects,
  questions8,
  roadmap,
  roadmapLead,
  roles,
  skills,
  TOTAL8,
  type Role,
} from "./data/ch8";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "market chart" backdrop
================================================================== */
function MarketBackdrop() {
  const pts = [
    [0, 560],
    [120, 540],
    [240, 505],
    [360, 480],
    [480, 430],
    [600, 400],
    [720, 340],
    [840, 300],
    [960, 230],
    [1080, 170],
    [1200, 90],
  ];
  const d = pts.map(([x, y], n) => `${n === 0 ? "M" : "L"}${x} ${y}`).join(" ");
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 1200 700"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
    >
      <defs>
        <linearGradient id="mkFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3DF07A" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#3DF07A" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="mkFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => (
          <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />
        ))}
        {Array.from({ length: 15 }).map((_, n) => (
          <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />
        ))}
      </g>
      <path d={`${d} L1200 700 L0 700 Z`} fill="url(#mkFill)" />
      <path d={d} fill="none" stroke="#3DF07A" strokeOpacity="0.7" strokeWidth="2" />
      {pts.map(([x, y]) => (
        <circle key={x} cx={x} cy={y} r="4" fill="#3DF07A" fillOpacity="0.8" />
      ))}
      {/* bars */}
      {[
        [700, 120],
        [780, 170],
        [860, 210],
        [940, 290],
        [1020, 350],
        [1100, 430],
      ].map(([x, h]) => (
        <rect
          key={x}
          x={x}
          y={700 - h}
          width="40"
          height={h}
          fill="#FFB020"
          fillOpacity="0.12"
          stroke="#FFB020"
          strokeOpacity="0.35"
        />
      ))}
      <rect width="1200" height="700" fill="url(#mkFade)" />
    </svg>
  );
}

export function TitleSlide8({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <MarketBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Career briefing · lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 08 of 16
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.08&nbsp;//&nbsp;CAREERS
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL8}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 08
              </span>
              <span className="mt-1 block text-[clamp(2.4rem,7.2vw,6rem)] text-phos glow">
                Careers &amp; Roadmap
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              {ch8Intro} This chapter covers salary trends, the global market
              outlook, the skills employers pay for, and a stage-by-stage
              roadmap from fundamentals to a first security role.
            </motion.p>

            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(7)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos"
              >
                Jump to the roadmap
              </button>
            </motion.div>
          </div>

          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Avg. US salary", "$130–136k"],
            ["Market by 2034", "$878.5B"],
            ["Roadmap stages", "Ten"],
            ["Doc revision", ch8Stamp.replace("Last Updated : ", "")],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · MARKET AT A GLANCE
================================================================== */
export function GlanceSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // MARKET"
      num="02"
      title={
        <>
          The market <span className="text-phos">at a glance</span>
        </>
      }
      lede={ch8Intro}
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-5">
        {headline.map((h, n) => (
          <motion.div
            key={h.k}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } },
            }}
            className="bg-ink p-5"
          >
            <div className="font-mono text-[9.5px] tracked text-muted">{h.k}</div>
            <div
              className={`mt-3 font-display text-[clamp(1.6rem,2.6vw,2.3rem)] leading-none ${
                n === 4 ? "text-amber" : "text-phos glow"
              }`}
            >
              {h.v}
            </div>
            <div className="mt-2 font-mono text-[10px] tracked text-sage/70">{h.sub}</div>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <Row
            i="01"
            label="Average US cybersecurity salary"
            desc="Around USD 130,000 – USD 136,000 per year across all experience levels."
            meta="Compensation"
          />
          <Row
            i="02"
            label="Entry-level starting band"
            desc="Entry-level cybersecurity roles usually start between USD 65,000 – USD 85,000 annually."
            meta="Junior"
          />
          <Row
            i="03"
            label="Global market by 2034"
            desc="The global cybersecurity market is projected to reach approximately USD 878.5 billion by 2034."
            meta="Outlook"
          />
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Why it keeps growing</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              Cloud computing, AI, remote work and digital infrastructure all
              expand the attack surface. Every new system needs someone to
              secure it — and there are far fewer qualified defenders than open
              positions.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · SALARY FACTORS
================================================================== */
export function FactorsSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // SALARY"
      num="03"
      title={
        <>
          What moves <span className="text-phos">the number</span>
        </>
      }
      lede={factorsLead}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {factors.map((f, n) => (
            <Row key={f.i} i={f.i} label={f.name} desc={f.desc} meta={f.meta} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">Compounding effect</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              The factors stack. An experienced, certified cloud-security
              engineer in finance, based in a tech hub, sits at the top of every
              range on the next slide.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {["CISSP", "OSCP", "CEH", "CISM", "Security+"].map((c) => (
                <Tag key={c} tone="muted">
                  {c}
                </Tag>
              ))}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared salary-range bar chart
================================================================== */
function RangeBars({ rows, max, unit = "k" }: { rows: Role[]; max: number; unit?: string }) {
  return (
    <div className="border-b border-sage/15">
      <div className="hidden grid-cols-[minmax(0,14rem)_1fr_auto] gap-x-6 pb-2 font-mono text-[9.5px] tracked text-muted md:grid">
        <span>Role</span>
        <span>Range (USD / year)</span>
        <span>Low – High</span>
      </div>
      {rows.map((r, n) => {
        const left = (r.lo / max) * 100;
        const width = ((r.hi - r.lo) / max) * 100;
        return (
          <motion.div
            key={r.role}
            variants={{
              hidden: { opacity: 0, y: 8 },
              show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.05 } },
            }}
            className="grid grid-cols-1 items-center gap-x-6 gap-y-2 border-t border-sage/15 py-3.5 md:grid-cols-[minmax(0,14rem)_1fr_auto]"
          >
            <div className="flex items-center gap-3">
              <span className="font-mono text-[11px] text-phos/70">
                {String(n + 1).padStart(2, "0")}
              </span>
              <span className="font-mono text-[12.5px] font-medium tracked-sm text-sage">
                {r.role}
              </span>
            </div>
            <div className="relative h-5 w-full bg-sage/[0.07]">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${width}%` }}
                transition={{ duration: 0.7, ease: "easeOut", delay: 0.15 + n * 0.05 }}
                className={`absolute top-0 h-full ${r.plus ? "bg-amber" : "bg-phos"}`}
                style={{ left: `${left}%` }}
              />
              {r.plus && (
                <span
                  className="absolute top-0 h-full w-4 bg-gradient-to-r from-amber to-transparent"
                  style={{ left: `calc(${left + width}% )` }}
                />
              )}
            </div>
            <span
              className={`font-mono text-[11px] tabular-nums ${r.plus ? "text-amber" : "text-sage/85"}`}
            >
              ${r.lo}
              {unit} – ${r.hi}
              {unit}
              {r.plus ? "+" : ""}
            </span>
          </motion.div>
        );
      })}
    </div>
  );
}

/* ==================================================================
   04 · JOB ROLES
================================================================== */
export function RolesSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // ROLES"
      num="04"
      title={
        <>
          Job roles &amp; <span className="text-phos">what they pay</span>
        </>
      }
      lede="A closer look at key cybersecurity roles and how much they typically earn. Bars show the low-to-high band; the CISO band is open-ended."
      dense
    >
      <RangeBars rows={roles} max={450} />
      <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[9.5px] tracked text-muted">
        <span className="flex items-center gap-2">
          <span className="inline-block h-2 w-5 bg-phos" /> Individual contributor &amp; management bands
        </span>
        <span className="flex items-center gap-2">
          <span className="inline-block h-2 w-5 bg-amber" /> Executive · USD 420k+
        </span>
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · MARKET OUTLOOK & DRIVERS
================================================================== */
export function OutlookSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // OUTLOOK"
      num="05"
      title={
        <>
          Global outlook &amp; <span className="text-phos">growth drivers</span>
        </>
      }
      lede={marketLead}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">Market trajectory</div>
            <div className="mt-4 flex items-end gap-6">
              {[
                ["2025", 301.9, "sage"],
                ["2034", 878.5, "phos"],
              ].map(([y, v, t]) => (
                <div key={y as string} className="flex-1">
                  <div
                    className="w-full"
                    style={{
                      height: `${((v as number) / 878.5) * 120}px`,
                      background: TONE[t as string],
                      opacity: t === "sage" ? 0.35 : 0.9,
                    }}
                  />
                  <div className="mt-2 font-display text-[1.2rem] leading-none text-sage">
                    ${v as number}B
                  </div>
                  <div className="mt-1 font-mono text-[9.5px] tracked text-muted">{y as string}</div>
                </div>
              ))}
              <div className="flex-1">
                <div className="font-display text-[1.6rem] leading-none text-amber">12.6%</div>
                <div className="mt-1 font-mono text-[9.5px] tracked text-muted">CAGR</div>
                <div className="mt-4 font-display text-[1.6rem] leading-none text-amber">4.8M</div>
                <div className="mt-1 font-mono text-[9.5px] tracked text-muted">unfilled roles</div>
              </div>
            </div>
          </Panel>
          <ul className="mt-5 space-y-2.5">
            {marketBullets.map((b) => (
              <motion.li
                key={b}
                variants={rise}
                className="flex gap-3 text-[13px] font-light leading-[1.55] text-muted"
              >
                <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-phos" />
                {b}
              </motion.li>
            ))}
          </ul>
        </div>
        <div className="lg:col-span-7">
          <motion.p variants={rise} className="text-[13.5px] font-light leading-[1.6] text-sage/85">
            {driversLead}
          </motion.p>
          <div className="mt-4">
            {drivers.map((d, n) => (
              <Row key={d.i} i={d.i} label={d.name} desc={d.desc} meta="Driver" delay={n * 0.05} />
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · TOP COMPANIES
================================================================== */
export function CompaniesSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // EMPLOYERS"
      num="06"
      title={
        <>
          Who is <span className="text-phos">hiring</span>
        </>
      }
      lede={companiesLead}
      dense
    >
      <RangeBars rows={companies} max={300} />
      <motion.p variants={rise} className="mt-5 max-w-[70ch] text-[13px] font-light leading-[1.6] text-muted">
        Estimated salary ranges in USD per year. Product companies tend to top
        out higher; consulting firms hire in larger volumes across more
        entry-level bands.
      </motion.p>
    </Slide>
  );
}

/* ==================================================================
   07 · TOP SKILLS
================================================================== */
export function SkillsSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // SKILLS"
      num="07"
      title={
        <>
          Top skills <span className="text-phos">employers pay for</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {skills.map((s, n) => (
          <motion.div
            key={s.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className={`bg-ink p-5 ${n === 6 ? "sm:col-span-2 lg:col-span-1" : ""}`}
          >
            <span className={`font-mono text-[11px] ${n === 6 ? "text-amber/80" : "text-phos/70"}`}>
              {s.i}
            </span>
            <h3 className="mt-2.5 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">
              {s.name}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{s.desc}</p>
          </motion.div>
        ))}
        <motion.div variants={rise} className="bg-panel/70 p-5">
          <span className="font-mono text-[9.5px] tracked text-phos">Tooling named</span>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Metasploit", "Burp Suite", "Nmap", "SIEM", "PKI", "SSL/TLS", "Python", "Bash", "PowerShell", "Kubernetes"].map(
              (t) => (
                <Tag key={t} tone="muted">
                  {t}
                </Tag>
              ),
            )}
          </div>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · ROADMAP OVERVIEW
================================================================== */
export function RoadmapIndexSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // ROADMAP"
      num="08"
      title={
        <>
          The learning <span className="text-phos">roadmap</span>
        </>
      }
      lede={roadmapLead}
      dense
    >
      <div className="relative">
        <div className="absolute left-[11px] top-3 hidden h-[calc(100%-1.5rem)] w-px bg-sage/20 md:block" />
        <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-5">
          {roadmap.map((s, n) => (
            <motion.div
              key={s.i}
              variants={{
                hidden: { opacity: 0, y: 10 },
                show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.04 } },
              }}
              className="bg-ink p-4"
            >
              <div className="flex items-center gap-2">
                <span
                  className="inline-block h-2 w-2"
                  style={{ background: TONE[s.tone] }}
                />
                <span className="font-mono text-[11px] text-sage/60">Stage {s.i}</span>
              </div>
              <h3 className="mt-2 font-display text-[0.9rem] uppercase leading-tight tracking-tight text-sage">
                {s.name}
              </h3>
              <p className="mt-2 line-clamp-3 text-[12px] font-light leading-[1.5] text-muted">
                {s.lead}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
      <div className="mt-5 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[9.5px] tracked text-muted">
        {[
          ["sage", "Foundations & tooling"],
          ["phos", "Security core & operations"],
          ["amber", "Offensive & hardening"],
        ].map(([t, l]) => (
          <span key={t} className="flex items-center gap-2">
            <span className="inline-block h-2 w-5" style={{ background: TONE[t] }} /> {l}
          </span>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared roadmap-detail slide
================================================================== */
function StageCard({ s, delay }: { s: (typeof roadmap)[number]; delay: number }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 10 },
        show: { opacity: 1, y: 0, transition: { duration: 0.36, delay } },
      }}
      className="flex h-full flex-col border border-sage/15 bg-panel/60"
      style={{ borderRadius: 2, borderTopColor: TONE[s.tone], borderTopWidth: 2 }}
    >
      <div className="p-5 pb-3">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[s.tone] }}>
            Stage {s.i}
          </span>
        </div>
        <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">
          {s.name}
        </h3>
        <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{s.lead}</p>
      </div>
      <div className="grid flex-1 gap-px border-t border-sage/15 bg-sage/10 sm:grid-cols-2">
        {s.groups.map((g) => (
          <div key={g.h} className={`bg-ink p-4 ${s.groups.length === 1 ? "sm:col-span-2" : ""}`}>
            <div className="font-mono text-[9.5px] tracked text-sage/70">{g.h}</div>
            <ul className={`mt-2 ${s.groups.length === 1 ? "grid gap-x-6 sm:grid-cols-2" : ""}`}>
              {g.items.map((it) => (
                <li
                  key={it}
                  className="flex gap-2.5 border-t border-sage/10 py-1.5 text-[12.5px] font-light leading-[1.45] text-sage/85"
                >
                  <span className="mt-[7px] h-1 w-1 shrink-0" style={{ background: TONE[s.tone] }} />
                  {it}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function RoadmapFor({ from, to, num, head }: { from: number; to: number; num: string; head: string }) {
  const slice = roadmap.slice(from, to);
  return (
    <Slide
      tag={`SEC // CH.08 // ROADMAP // ${slice[0].i}–${slice[slice.length - 1].i}`}
      num={num}
      title={
        <>
          Roadmap — <span className="text-phos">{head}</span>
        </>
      }
      dense
    >
      <div className={`grid gap-4 ${slice.length === 3 ? "lg:grid-cols-3" : "lg:grid-cols-2"}`}>
        {slice.map((s, n) => (
          <StageCard key={s.i} s={s} delay={n * 0.07} />
        ))}
      </div>
    </Slide>
  );
}

export const RoadmapA8 = () => <RoadmapFor from={0} to={2} num="09" head="foundations & networking" />;
export const RoadmapB8 = () => <RoadmapFor from={2} to={4} num="10" head="security & programming" />;
export const RoadmapC8 = () => <RoadmapFor from={4} to={7} num="11" head="hacking, web & system" />;
export const RoadmapD8 = () => <RoadmapFor from={7} to={10} num="12" head="cloud, SecOps & Git" />;

/* ==================================================================
   13 · CERTIFICATIONS & PRACTICE
================================================================== */
export function CertsPracticeSlide8() {
  return (
    <Slide
      tag="SEC // CH.08 // CERTS & PRACTICE"
      num="13"
      title={
        <>
          Certifications, projects &amp; <span className="text-phos">career paths</span>
        </>
      }
      dense
    >
      <div className="grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <motion.p variants={rise} className="text-[13px] font-light leading-[1.6] text-muted">
            {certsLead}
          </motion.p>
          <div className="mt-3 grid gap-px bg-sage/15">
            {certs.map((c, n) => (
              <motion.div
                key={c.level}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } },
                }}
                className="grid grid-cols-[6.5rem_1fr] gap-4 bg-ink p-4"
              >
                <div>
                  <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[c.tone] }}>
                    {c.level}
                  </span>
                  <div className="mt-2 h-1 w-10" style={{ background: TONE[c.tone] }} />
                </div>
                <ul className="space-y-1">
                  {c.items.map((it) => (
                    <li key={it} className="font-mono text-[12px] text-sage/90">
                      {it}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <motion.p variants={rise} className="text-[13px] font-light leading-[1.6] text-muted">
            {practiceLead}
          </motion.p>
          <div className="mt-3 grid gap-4 sm:grid-cols-3">
            <motion.div variants={rise}>
              <Panel className="h-full p-4">
                <div className="font-mono text-[9.5px] tracked text-phos">Beginner projects</div>
                <ul className="mt-2">
                  {projects.map((p) => (
                    <li key={p} className="border-t border-sage/10 py-1.5 text-[12.5px] font-light text-sage/85">
                      {p}
                    </li>
                  ))}
                </ul>
              </Panel>
            </motion.div>
            <motion.div variants={rise}>
              <Panel className="h-full p-4">
                <div className="font-mono text-[9.5px] tracked text-amber">Practice platforms</div>
                <ul className="mt-2">
                  {platforms.map((p) => (
                    <li key={p} className="border-t border-sage/10 py-1.5 font-mono text-[12px] text-sage/90">
                      {p}
                    </li>
                  ))}
                </ul>
              </Panel>
            </motion.div>
            <motion.div variants={rise}>
              <Panel className="h-full p-4">
                <div className="font-mono text-[9.5px] tracked text-sage/80">Career paths</div>
                <ul className="mt-2">
                  {careerPaths.map((p) => (
                    <li key={p} className="border-t border-sage/10 py-1.5 text-[12.5px] font-light text-sage/85">
                      {p}
                    </li>
                  ))}
                </ul>
              </Panel>
            </motion.div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide8({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.08 // Check</span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Know the market.
          <br />
          <span className="text-phos glow">Plan the path.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Five items covering average salaries, market projections, the
          highest-paid role, the order of the roadmap and the certification
          tiers. Select an answer to reveal it instantly — the rationale
          appears underneath.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(14)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   15–19 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide8({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions8[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.08 // CHECK // Q0${n + 1}`}
      num={String(15 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              ["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"],
              ["Domain", "Careers & roadmap"],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · SCORE
================================================================== */
export function ScoreSlide8({ answers }: { answers: (number | null)[] }) {
  const score = questions8.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions8.length) * 100);
  const verdict =
    pct === 100
      ? "Full marks — you know the market and the path through it."
      : pct >= 60
        ? "Solid. Re-check the salary bands and the certification tiers."
        : "Revisit the market overview and the roadmap order, then retake.";

  return (
    <Slide
      tag="SEC // CH.08 // CHECK // RESULT"
      num="20"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions8.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions8.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions8.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null || picked === undefined ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   21 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide8() {
  const items = [
    ["01", "Demand outruns supply", "4.8 million unfilled roles and a market tripling by 2034 — scarcity sets the price."],
    ["02", "Experience compounds", "Seniority, certifications, skills, industry and location stack on top of each other."],
    ["03", "Cloud and offense pay a premium", "Cloud security, Kubernetes, pen testing and threat hunting sit at the top of the bands."],
    ["04", "Fundamentals first", "Computers, Linux and networking before security concepts; concepts before exploitation."],
    ["05", "Certify in tiers", "Security+ → CEH / CySA+ → CISSP / OSCP / CISM, matched to where you are."],
    ["06", "Build, break, repeat", "Small projects and CTF platforms turn reading into demonstrable skill."],
  ];

  return (
    <Slide
      tag="SEC // CH.08 // CLOSE"
      num="21"
      title={
        <>
          Chapter 08 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 08 · Careers &amp; Roadmap · End of course
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents8.length} sections · {TOTAL8} slides
        </span>
      </div>
    </Slide>
  );
}
