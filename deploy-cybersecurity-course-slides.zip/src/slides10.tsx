import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch10Stamp,
  contents10,
  csBullets,
  csConsequences,
  csIntro,
  csLaw,
  csProtection,
  csReporting,
  csReportingLead,
  csStat,
  csTechniques,
  csTechniquesLead,
  phases,
  questions10,
  seBullets,
  seImpact,
  seImpactLead,
  seIntro,
  sePrevention,
  sePreventionLead,
  seTypes,
  seWorkingLead,
  TOTAL10,
} from "./data/ch10";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "human as attack surface" backdrop
================================================================== */
function HumanBackdrop() {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 1200 700"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
    >
      <defs>
        <radialGradient id="hbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="hbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="6" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => (
          <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />
        ))}
        {Array.from({ length: 15 }).map((_, n) => (
          <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />
        ))}
      </g>
      {/* abstract head silhouette (circle + shoulders) as the target */}
      <g transform="translate(940 330)">
        <circle r="70" fill="none" stroke="#C7D2C9" strokeOpacity="0.35" strokeWidth="1.5" />
        <path d="M-150 200 Q-150 100 -60 85 Q0 130 60 85 Q150 100 150 200" fill="none" stroke="#C7D2C9" strokeOpacity="0.3" strokeWidth="1.5" />
        {[0, 60, 120, 180, 240, 300].map((a) => {
          const r = (a * Math.PI) / 180;
          const x1 = Math.cos(r) * 110;
          const y1 = Math.sin(r) * 110;
          const x2 = Math.cos(r) * 230;
          const y2 = Math.sin(r) * 230;
          const warm = a % 120 === 0;
          return (
            <g key={a}>
              <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={warm ? "#FFB020" : "#3DF07A"} strokeOpacity="0.4" strokeDasharray="4 6" />
              <g filter="url(#hbGlow)">
                <circle cx={x2} cy={y2} r="5" fill={warm ? "#FFB020" : "#3DF07A"} />
              </g>
              <polygon
                points={`${x1},${y1} ${x1 + Math.cos(r + 2.6) * 10},${y1 + Math.sin(r + 2.6) * 10} ${x1 + Math.cos(r - 2.6) * 10},${y1 + Math.sin(r - 2.6) * 10}`}
                fill={warm ? "#FFB020" : "#3DF07A"}
                fillOpacity="0.7"
              />
            </g>
          );
        })}
        <circle r="95" fill="none" stroke="#3DF07A" strokeOpacity="0.2" strokeDasharray="6 9" />
      </g>
      <rect width="1200" height="700" fill="url(#hbFade)" />
    </svg>
  );
}

export function TitleSlide10({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <HumanBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Human-factor briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 10 of 16</span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.10&nbsp;//&nbsp;HUMAN-FACTOR</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">
            01 / {TOTAL10}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">
              University course · Introduction to Cybersecurity
            </motion.p>
            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 10</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Social Engineering</span>
              <span className="mt-1 block text-[clamp(1.4rem,3.6vw,3rem)] text-sage/80">&amp; Cyberstalking</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              Two attacks that target the person, not the machine. Part A: how
              social engineers research, pretext, engage and exploit — five
              attack types, prevention and organizational impact. Part B:
              cyberstalking — its consequences, the stalker's toolkit, and how
              to protect yourself and report it.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>
                Begin chapter →
              </button>
              <button onClick={() => go(8)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">
                Jump to cyberstalking
              </button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[
            ["Attack phases", "Six"],
            ["SE attack types", "Five"],
            ["Stalker techniques", "Five"],
            ["Doc revision", ch10Stamp.replace("Last Updated : ", "")],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT SOCIAL ENGINEERING IS
================================================================== */
export function SEIntroSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART A // DEFINITION"
      num="02"
      title={<>What <span className="text-phos">social engineering</span> is</>}
      lede={seIntro}
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {seBullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">The levers</div>
            <div className="mt-3 grid grid-cols-3 gap-px bg-sage/15">
              {["Trust", "Fear", "Curiosity"].map((l) => (
                <div key={l} className="bg-ink p-3 text-center">
                  <div className="font-display text-[1rem] uppercase text-sage">{l}</div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">
              No exploit code, no zero-day. The vulnerability is a normal human
              reaction — and it cannot be patched, only trained.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · HOW IT WORKS — OVERVIEW
================================================================== */
export function SEWorkflowSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART A // WORKFLOW"
      num="03"
      title={<>How it <span className="text-phos">works</span></>}
      lede={seWorkingLead}
      dense
    >
      <div className="relative">
        <div className="absolute left-0 right-0 top-[26px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {phases.map((p, n) => (
            <motion.div
              key={p.i}
              variants={{
                hidden: { opacity: 0, y: 10 },
                show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } },
              }}
              className="relative"
            >
              <div className="relative z-10 flex h-[52px] items-center">
                <span className="flex h-9 w-9 items-center justify-center border bg-ink font-mono text-[12px]" style={{ borderColor: n >= 3 ? TONE.amber : TONE.phos, color: n >= 3 ? TONE.amber : TONE.phos, borderRadius: 2 }}>
                  {p.i}
                </span>
              </div>
              <div className="font-mono text-[9.5px] tracked text-muted">{p.label}</div>
              <h3 className="mt-1 font-display text-[0.9rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
              <p className="mt-2 text-[12px] font-light leading-[1.5] text-muted">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[9.5px] tracked text-muted">
        <span className="flex items-center gap-2"><span className="inline-block h-2 w-5 bg-phos" /> Before contact — preparation and approach</span>
        <span className="flex items-center gap-2"><span className="inline-block h-2 w-5 bg-amber" /> After contact — exploitation and exit</span>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared phase-detail slide
================================================================== */
function PhaseDetail({ from, to, num, head }: { from: number; to: number; num: string; head: string }) {
  const slice = phases.slice(from, to);
  return (
    <Slide
      tag={`SEC // CH.10 // PART A // PHASES ${slice[0].i}–${slice[slice.length - 1].i}`}
      num={num}
      title={<>Phases — <span className="text-phos">{head}</span></>}
      dense
    >
      <div className="grid gap-4 lg:grid-cols-3">
        {slice.map((p, n) => (
          <motion.div
            key={p.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } },
            }}
            className="flex flex-col border border-sage/15 bg-panel/60"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: from >= 3 ? TONE.amber : TONE.phos }}
          >
            <div className="p-5 pb-3">
              <span className="font-mono text-[9.5px] tracked" style={{ color: from >= 3 ? TONE.amber : TONE.phos }}>
                Phase {p.i} · {p.label}
              </span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
              <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{p.desc}</p>
            </div>
            <div className="flex-1 border-t border-sage/15 bg-ink p-4">
              {p.points.map((pt) => (
                <div key={pt.h} className="border-t border-sage/10 py-2 first:border-t-0 first:pt-0">
                  <div className="font-mono text-[11px] font-medium text-sage">{pt.h}</div>
                  <p className="mt-1 text-[12px] font-light leading-[1.5] text-muted">{pt.d}</p>
                </div>
              ))}
            </div>
            {p.note && (
              <div className="border-t border-sage/15 p-4 font-mono text-[10px] leading-[1.5] text-amber/85">→ {p.note}</div>
            )}
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

export const PhasesA10 = () => <PhaseDetail from={0} to={3} num="04" head="research, pretext, engage" />;
export const PhasesB10 = () => <PhaseDetail from={3} to={6} num="05" head="exploit, monetize, cover" />;

/* ==================================================================
   06 · FIVE TYPES
================================================================== */
export function SETypesSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART A // TYPES"
      num="06"
      title={<>Five <span className="text-phos">attack types</span></>}
      lede="Each type uses a different approach to exploit human weakness and gain access to sensitive information."
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-5">
        {seTypes.map((t, n) => (
          <motion.div
            key={t.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } },
            }}
            className="flex flex-col bg-ink p-5"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px]" style={{ color: TONE[t.tone] }}>{t.i}</span>
              <span className="h-1.5 w-6" style={{ background: TONE[t.tone] }} />
            </div>
            <h3 className="mt-3 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-3 flex-1 text-[12.5px] font-light leading-[1.6] text-muted">{t.desc}</p>
            <div className="mt-4 space-y-1.5 border-t border-sage/10 pt-3">
              <div className="flex justify-between font-mono text-[9.5px] tracked">
                <span className="text-muted">Vector</span>
                <span className="text-sage/80">{t.vector}</span>
              </div>
              <div className="flex justify-between font-mono text-[9.5px] tracked">
                <span className="text-muted">Lever</span>
                <span className="text-amber/85">{t.lever}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · PREVENTION
================================================================== */
export function SEPreventionSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART A // PREVENTION"
      num="07"
      title={<>Prevention against <span className="text-phos">social engineering</span></>}
      lede={sePreventionLead}
      dense
    >
      <div className="grid gap-4 lg:grid-cols-3">
        {sePrevention.map((p, n) => (
          <motion.div
            key={p.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } },
            }}
            className="border border-sage/15 bg-panel/60 p-5"
            style={{ borderRadius: 2 }}
          >
            <span className="font-mono text-[11px] text-phos/70">{p.i}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{p.desc}</p>
            <ul className="mt-4 border-t border-sage/15 pt-2">
              {p.steps.map((s) => (
                <li key={s} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.45] text-sage/85">
                  <span className="mt-[6px] inline-block h-1.5 w-1.5 shrink-0 bg-phos" />
                  {s}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · IMPACT ON ORGANIZATIONS
================================================================== */
export function SEImpactSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART A // IMPACT"
      num="08"
      title={<>Impact on the <span className="text-phos">organization</span></>}
      lede={seImpactLead}
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {seImpact.map((x, n) => (
          <motion.div
            key={x.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className="bg-ink p-5"
          >
            <span className={`font-mono text-[11px] ${n === 5 ? "text-amber/80" : "text-phos/70"}`}>{x.i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{x.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{x.desc}</p>
          </motion.div>
        ))}
      </div>
      <motion.p variants={rise} className="mt-5 font-mono text-[10px] tracked text-muted">
        Escalation path: financial loss → goodwill → privacy → legal action → closure.
      </motion.p>
    </Slide>
  );
}

/* ==================================================================
   09 · WHAT CYBERSTALKING IS
================================================================== */
export function CSIntroSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART B // DEFINITION"
      num="09"
      title={<>What <span className="text-phos">cyberstalking</span> is</>}
      lede={csIntro}
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {csBullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Note</div>
            <div className="mt-3 flex items-baseline gap-3">
              <span className="font-display text-[3.4rem] leading-[0.85] text-amber glow">{csStat.n}</span>
            </div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">{csStat.text}</p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · CONSEQUENCES
================================================================== */
export function CSConsequencesSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART B // CONSEQUENCES"
      num="10"
      title={<>Consequences of <span className="text-phos">cyberstalking</span></>}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">The law · United States</div>
            <div className="mt-3 font-display text-[1.3rem] uppercase leading-tight text-sage">18 U.S.C. § 2261A</div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{csLaw}</p>
          </Panel>
        </motion.div>
        <div className="lg:col-span-8">
          {csConsequences.map((c, n) => (
            <Row key={c.i} i={c.i} label={c.name} desc={c.desc} meta={n === 6 ? "Severe" : n === 0 ? "Legal" : "Personal"} delay={n * 0.035} />
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · TECHNIQUES
================================================================== */
export function CSTechniquesSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART B // TECHNIQUES"
      num="11"
      title={<>Techniques used by <span className="text-phos">cyberstalkers</span></>}
      lede={csTechniquesLead}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {csTechniques.map((t, n) => (
            <Row key={t.i} i={t.i} label={t.name} desc={t.desc} meta={t.meta} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Two halves of every technique</div>
            <div className="mt-3 grid grid-cols-2 gap-px bg-sage/15">
              <div className="bg-ink p-3">
                <div className="font-mono text-[9.5px] tracked text-phos">Technology</div>
                <p className="mt-1 text-[12px] font-light text-muted">Malware, stalkerware, EXIF metadata, platform features.</p>
              </div>
              <div className="bg-ink p-3">
                <div className="font-mono text-[9.5px] tracked text-amber">Manipulation</div>
                <p className="mt-1 text-[12px] font-light text-muted">Fake identities, trust, over-sharing habits.</p>
              </div>
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · PROTECTION
================================================================== */
export function CSProtectionSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART B // PROTECTION"
      num="12"
      title={<>Protecting yourself from <span className="text-phos">cyberstalking</span></>}
      lede="Simple precautions and staying alert online significantly reduce the risk of becoming a victim."
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {csProtection.map((p, n) => (
          <motion.div
            key={p.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } },
            }}
            className="bg-ink p-5"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{p.i}</span>
              <span className="border border-phos/50 px-1.5 py-[2px] font-mono text-[9px] tracked text-phos" style={{ borderRadius: 2 }}>✓</span>
            </div>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · REPORTING
================================================================== */
export function CSReportingSlide10() {
  return (
    <Slide
      tag="SEC // CH.10 // PART B // REPORTING"
      num="13"
      title={<>Reporting <span className="text-phos">cyberstalking incidents</span></>}
      lede={csReportingLead}
      dense
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        {csReporting.map((r, n) => (
          <motion.div
            key={r.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } },
            }}
            className="border border-sage/15 bg-panel/60 p-4"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 5 ? TONE.amber : TONE.phos }}
          >
            <span className="font-mono text-[9.5px] tracked" style={{ color: n === 5 ? TONE.amber : TONE.phos }}>Step {r.i}</span>
            <h3 className="mt-2 font-display text-[0.9rem] uppercase leading-tight tracking-tight text-sage">{r.name}</h3>
            <p className="mt-2 text-[12px] font-light leading-[1.5] text-muted">{r.desc}</p>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-6 border-l-2 border-amber bg-amber/[0.07] p-4">
        <div className="font-mono text-[9.5px] tracked text-amber">If you feel unsafe right now</div>
        <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">
          Skip the portal. Contact emergency services immediately — evidence can be submitted afterwards.
        </p>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   14 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide10({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 11 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.10 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Spot the manipulation.
          <br />
          <span className="text-phos glow">Two parts.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Part A — six items on social engineering: definition, baiting,
          research sources, tailgating, pretexting and prevention. Part B —
          five items on cyberstalking: definition, stalker behaviours,
          catfishing, EXIF metadata and first response.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(14)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>
            Start Part A →
          </button>
          <button onClick={() => go(20)} className="border border-sage/30 px-6 py-3.5 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos" style={{ borderRadius: 2 }}>
            Skip to Part B
          </button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   15–25 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide10({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions10[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  const partLabel = q.part === "A" ? "Part A · Social engineering" : "Part B · Cyberstalking";

  return (
    <Slide
      tag={`SEC // CH.10 // CHECK // PART ${q.part} // Q${String(n + 1).padStart(2, "0")}`}
      num={String(15 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / {questions10.length}</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              ["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"],
              ["Domain", partLabel],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   26 · SCORE
================================================================== */
export function ScoreSlide10({ answers }: { answers: (number | null)[] }) {
  const score = questions10.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions10.length) * 100);
  const partScore = (p: "A" | "B") =>
    questions10.reduce((a, q, i) => a + (q.part === p && answers[i] === q.answer ? 1 : 0), 0);
  const partTotal = (p: "A" | "B") => questions10.filter((q) => q.part === p).length;
  const verdict =
    pct === 100 ? "Clean sweep across both parts." : pct >= 60 ? "Solid. Re-read the part where you dropped points." : "Revisit the six phases and the stalker techniques, then retake.";

  return (
    <Slide tag="SEC // CH.10 // CHECK // RESULT" num="26" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions10.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>{score} of {questions10.length} correct</span>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-px bg-sage/15">
              {(["A", "B"] as const).map((p) => (
                <div key={p} className="bg-ink p-3">
                  <div className="font-mono text-[9.5px] tracked text-muted">Part {p}</div>
                  <div className="mt-1 font-display text-[1.2rem] text-sage">
                    {partScore(p)}<span className="text-sage/50"> / {partTotal(p)}</span>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions10.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: i * 0.035 } } }}
                  className="grid grid-cols-[2.6rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-2.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">{q.part}{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[10.5px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   27 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide10() {
  const items = [
    ["01", "The human is the exploit", "Trust, fear and curiosity are the vulnerabilities — and they cannot be patched, only trained."],
    ["02", "Attacks are researched, not random", "Public information becomes a tailored pretext long before the first message arrives."],
    ["03", "Urgency is the tell", "Pressure to act now is the single most reliable signal that a request should be verified elsewhere."],
    ["04", "Verify through a second channel", "Call the official number. MFA turns a stolen password into a dead end."],
    ["05", "Stalking is repetition plus technology", "Fake identities, stalkerware and photo metadata turn ordinary sharing into a tracking feed."],
    ["06", "Evidence first, then report", "Screenshots, logs and messages — preserved, then submitted through official channels. Emergency services if unsafe."],
  ];
  return (
    <Slide tag="SEC // CH.10 // CLOSE" num="27" title={<>Chapter 10 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 10 · Social Engineering &amp; Cyberstalking</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents10.length} sections · {TOTAL10} slides</span>
      </div>
    </Slide>
  );
}
