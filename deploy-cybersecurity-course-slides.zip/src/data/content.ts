/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 01
   All lecture content, structured for the deck.
------------------------------------------------------------------ */

export type Check = { i: string; label: string; desc: string; meta?: string };

/* --- Slide 03 · Key objectives ------------------------------------ */
export const objectives: Check[] = [
  {
    i: "01",
    label: "Protect sensitive data",
    desc: "Encryption, authentication and access-control mechanisms ensure only authorized users can reach critical resources.",
    meta: "CIA · C",
  },
  {
    i: "02",
    label: "Secure networks & systems",
    desc: "Continuous monitoring, intrusion detection systems and proactive defense against malware, ransomware and cyber threats.",
    meta: "CIA · I",
  },
  {
    i: "03",
    label: "Support safe digital transformation",
    desc: "Secure cloud computing, virtualization and resilient IT design that enables scale without compromising security.",
    meta: "SCALE",
  },
  {
    i: "04",
    label: "Reduce downtime & operational risk",
    desc: "Rapid incident response, system recovery and business continuity planning cut resource misuse and service loss.",
    meta: "CIA · A",
  },
  {
    i: "05",
    label: "Enhance reliability & resilience",
    desc: "Security by Design — integrating protection into system architecture with continuous risk assessment and management.",
    meta: "BY DESIGN",
  },
];

/* --- Slide 03 · Protection in practice (second half of the intro) - */
export const practiceDefinition =
  "Cybersecurity is the process of applying best practices, technologies, and policies to protect computers, servers, systems, networks, and software applications from digital attacks. These attacks may include viruses, worms, ransomware, phishing, spyware, and other forms of malicious activity designed to access, alter, destroy, or steal sensitive data, extort money from users, or disrupt normal business operations.";

export const practiceNote =
  "In today's interconnected digital environment, cybersecurity plays a critical role in safeguarding personal, organizational, and national assets. It not only focuses on preventing attacks but also on detecting, responding to, and recovering from security incidents in an efficient and timely manner.";

export const practice: Check[] = [
  {
    i: "01",
    label: "Identify & fix security vulnerabilities",
    desc: "In systems, applications and network infrastructure — through regular audits, penetration testing and patch management.",
    meta: "AUDIT",
  },
  {
    i: "02",
    label: "Prevent unauthorized access & data breaches",
    desc: "Using strong authentication mechanisms, encryption, access control policies and continuous monitoring.",
    meta: "PREVENT",
  },
  {
    i: "03",
    label: "Protect systems from attacks & disruption",
    desc: "By deploying firewalls, intrusion detection systems, endpoint protection and security awareness training.",
    meta: "DETECT",
  },
  {
    i: "04",
    label: "Ensure confidentiality, integrity & availability",
    desc: "So that data remains secure, accurate and accessible to authorized users whenever needed.",
    meta: "CIA",
  },
];

/* --- Slide 06 · Security Risk — what is actually at stake --------- */
export const atStake = [
  {
    i: "01",
    label: "PII Protection",
    desc: "Personally identifiable information — names, identifiers, health and financial records — must never reach unauthorized disclosure.",
    meta: "CIA · C",
  },
  {
    i: "02",
    label: "IP Security",
    desc: "Trade secrets, research output and product design are concentrated organizational value, and a standing target for theft.",
    meta: "CIA · C",
  },
  {
    i: "03",
    label: "Financial Safety",
    desc: "Payment systems, fraud and extortion losses land directly on the balance sheet — and on customers.",
    meta: "CIA · I",
  },
  {
    i: "04",
    label: "Government Defense",
    desc: "Public systems hold national records and critical infrastructure; their compromise is a matter of public security.",
    meta: "CIA · A",
  },
  {
    i: "05",
    label: "Regulatory Compliance",
    desc: "GDPR, ISO/IEC 27001 and the NIST CSF demand demonstrable controls and auditable, lawful handling of data.",
    meta: "CIA · C",
  },
  {
    i: "06",
    label: "Operational Continuity",
    desc: "Services have to keep running. Downtime is itself a security failure with cascading economic cost.",
    meta: "CIA · A",
  },
];

/* --- Slide 11 · Major cyber attacks — reference table ------------- */
export const attackTable = [
  {
    i: "01",
    name: "Malware Attacks",
    klass: "Malicious code",
    fn: "Harmful software damages the system",
    layer: "Endpoint",
  },
  {
    i: "02",
    name: "Phishing Attacks",
    klass: "Social engineering",
    fn: "Fake messages steal information",
    layer: "Human",
  },
  {
    i: "03",
    name: "Ransomware Attacks",
    klass: "Extortion",
    fn: "Data locked for money",
    layer: "Endpoint",
  },
  {
    i: "04",
    name: "DDoS Attacks",
    klass: "Volumetric",
    fn: "Too much traffic overwhelms the service",
    layer: "Network",
  },
  {
    i: "05",
    name: "SQL Injection",
    klass: "Application",
    fn: "Database commands misused",
    layer: "Application",
  },
  {
    i: "06",
    name: "Zero-Day Exploits",
    klass: "Unknown vulnerability",
    fn: "Unknown security weakness exploited",
    layer: "All layers",
  },
];

/* --- Slide 12 · Common threats & attacks — the five shapes -------- */
export const commonThreats = [
  {
    key: "sql",
    lines: ["SQL", "Injection"],
    full: "SQL Injection",
    blurb:
      "Malicious SQL submitted through a form, URL or header tricks the database into returning or altering records it should never expose — the classic route to a full customer-table breach.",
    meta: "APPLICATION",
  },
  {
    key: "phish",
    lines: ["Phishing"],
    full: "Phishing",
    blurb:
      "A deceptive email, message or look-alike site harvests credentials, card details and personal data from a user who is acting in good faith.",
    meta: "HUMAN",
  },
  {
    key: "mal",
    lines: ["Malware"],
    full: "Malware",
    blurb:
      "Viruses, worms, trojans, ransomware and spyware that damage systems, exfiltrate data, monitor activity or hand the attacker remote control.",
    meta: "CODE",
  },
  {
    key: "id",
    lines: ["Identity", "Theft"],
    full: "Identity Theft",
    blurb:
      "Stolen personal data is used to impersonate the victim — opening accounts, filing claims and laundering trust that the attacker never earned.",
    meta: "CREDENTIALS",
  },
  {
    key: "ddos",
    lines: ["DDoS"],
    full: "DDoS",
    blurb:
      "Traffic coordinated across a botnet drowns a service so legitimate users cannot reach it, inflicting direct financial and reputational loss.",
    meta: "NETWORK",
  },
];

/* --- Slide 15 · Forensics & investigation ------------------------- */
export const forensics = [
  {
    i: "01",
    name: "Forensics lifecycle",
    desc: "A defined chain running from identification and preservation through analysis to presentation — so evidence survives legal and executive scrutiny.",
    meta: "CHAIN OF CUSTODY",
  },
  {
    i: "02",
    name: "Evidence Collection",
    desc: "Acquiring volatile memory, disk images and logs without altering them, hash-verified at the moment of capture.",
    meta: "IMAGING",
  },
  {
    i: "03",
    name: "Report",
    desc: "Findings written as a clear, timeline-ordered record that a court, an auditor or a non-technical board can actually read.",
    meta: "DELIVERABLE",
  },
  {
    i: "04",
    name: "Analysis",
    desc: "Reconstructing the event, attributing activity to an actor, and establishing root cause and blast radius.",
    meta: "ROOT CAUSE",
  },
];

/* --- Slide 04 · Standards & the human factor ---------------------- */
export const standards = [
  {
    code: "ISO/IEC 27001",
    name: "Information Security Management",
    desc: "Specified requirements for establishing, implementing and continually improving an Information Security Management System (ISMS).",
  },
  {
    code: "NIST CSF",
    name: "Cybersecurity Framework",
    desc: "A voluntary framework built on five functions: Identify · Protect · Detect · Respond · Recover.",
  },
  {
    code: "GDPR",
    name: "Data Protection Regulation",
    desc: "EU regulation guaranteeing lawful, fair and transparent processing — and the legal handling of personal data.",
  },
];

/* --- Slide 05 / 06 · The CIA Triad -------------------------------- */
export const pillars = [
  {
    key: "C",
    name: "Confidentiality",
    tag: "PREVENTS UNAUTHORIZED ACCESS",
    definition:
      "Ensures sensitive information is accessible only to authorized individuals, systems or processes — preventing unauthorized disclosure, whether intentional or accidental.",
    mechanisms: [
      "Encryption",
      "Secure authentication",
      "Role-based access control (RBAC)",
      "Multi-factor authentication (MFA)",
      "Secure communication protocols",
    ],
    sectors: "Especially critical in sectors such as healthcare, finance and government, where data exposure can lead to serious privacy violations, financial loss or legal consequences.",
  },
  {
    key: "I",
    name: "Integrity",
    tag: "ENSURES DATA ACCURACY",
    definition:
      "Ensures data remains accurate, complete and unaltered during storage, processing and transmission — and is never modified or tampered with by unauthorized entities.",
    mechanisms: [
      "Cryptographic hashing",
      "Digital signatures",
      "Checksums",
      "Version control systems",
    ],
    sectors: "Essential for financial transactions, medical records and software updates — where even small unauthorized changes can have significant consequences.",
  },
  {
    key: "A",
    name: "Availability",
    tag: "ENSURES SYSTEM ACCESS",
    definition:
      "Ensures systems, applications and data are accessible to authorized users whenever needed — maintaining continuous operation under failure, attack or overload.",
    mechanisms: [
      "Redundant architectures",
      "Failover mechanisms",
      "Load balancing",
      "Regular backups",
      "Disaster recovery plans",
      "DoS attack protection",
    ],
    sectors: "High availability is critical for essential services such as emergency systems, banking platforms and cloud-based applications, where downtime can lead to operational and economic disruption.",
  },
] as const;

/* --- Slides 07–09 · The seven domains ----------------------------- */
export type Domain = {
  i: string;
  name: string;
  short: string;
  desc: string;
  tools: string[];
  stops: string;
};

export const domains: Domain[] = [
  {
    i: "01",
    name: "Network Security",
    short: "Protects network connections and data in transit",
    desc: "Protects computer networks and their communication channels from unauthorized access, misuse and cyberattack — ensuring safe transmission of data across internal and external networks.",
    tools: ["Firewalls", "VPNs", "IDS / IPS", "Network segmentation", "Traffic monitoring"],
    stops: "Stops man-in-the-middle, DoS and unauthorized network intrusion.",
  },
  {
    i: "02",
    name: "Application Security",
    short: "Protects software from attacks across its lifecycle",
    desc: "Protects software applications from vulnerabilities throughout their lifecycle — development, deployment and maintenance — preventing exploitation of coding flaws and design weaknesses.",
    tools: ["Secure coding practices", "SAST / DAST", "Regular patching", "Vulnerability management"],
    stops: "Stops SQL injection, cross-site scripting (XSS) and buffer overflows.",
  },
  {
    i: "03",
    name: "Information / Data Security",
    short: "Protects sensitive information at rest, in transit, in use",
    desc: "Focuses on protecting data in all forms — at rest, in transit or in use — so sensitive information stays confidential, accurate and available only to authorized users.",
    tools: ["Encryption", "Data masking", "Access control policies", "Data classification", "Backup & recovery"],
    stops: "Shields personal data, intellectual property and organizational knowledge assets.",
  },
  {
    i: "04",
    name: "Cloud Security",
    short: "Secures online-stored data, apps and infrastructure",
    desc: "Protects data, applications and infrastructure hosted in cloud environments — a first-order concern as organizations accelerate cloud adoption.",
    tools: ["Identity & access management (IAM)", "Encryption", "Secure cloud configuration", "Compliance monitoring", "Threat detection"],
    stops: "Addresses misconfiguration, data leakage and insecure APIs.",
  },
  {
    i: "05",
    name: "Endpoint Security",
    short: "Secures user devices and systems",
    desc: "Protects end-user devices — laptops, desktops, smartphones, servers and IoT devices — that connect to a network and are often the first target of an attack.",
    tools: ["Antivirus / anti-malware", "Endpoint detection & response (EDR)", "Device encryption", "Application control", "System updates"],
    stops: "Prevents malware infection, ransomware and unauthorized device access.",
  },
  {
    i: "06",
    name: "Operational Security (OpSec)",
    short: "Secures processes, policies and human factors",
    desc: "Focuses on the processes, policies and human factors that protect organizational information and assets — ensuring sensitive data is not exposed through everyday operations.",
    tools: [
      "Risk assessment",
      "Security policies",
      "Access management",
      "Employee awareness training",
      "Incident response planning",
      "Compliance enforcement",
    ],
    stops: "Emphasizes human behavior as the hinge of overall cybersecurity.",
  },
  {
    i: "07",
    name: "IoT Security",
    short: "Secures smart connected devices",
    desc: "Protects interconnected smart devices — home automation, wearables, industrial sensors and smart-city infrastructure — often limited in processing power and highly vulnerable.",
    tools: ["Device authentication", "Secure firmware updates", "Encrypted communication", "Network segmentation", "Continuous monitoring"],
    stops: "Prevents large-scale attacks that exploit weakly secured connected devices.",
  },
];

/* --- Slide 10 · Major threats ------------------------------------- */
export const threats = [
  {
    i: "01",
    name: "Malware Attacks",
    vector: "EMAIL · DOWNLOAD",
    severity: "HIGH",
    desc: "A broad category of malicious software — viruses, worms, trojans, ransomware and spyware — that deletes files, steals information, monitors activity or hands attackers remote control of an infected system.",
    spread: "Spreads through malicious downloads, infected email attachments and compromised websites.",
  },
  {
    i: "02",
    name: "Phishing & Spear Phishing",
    vector: "HUMAN · SOCIAL ENGINEERING",
    severity: "HIGH",
    desc: "Deceptive emails, messages or fake websites that trick users into revealing passwords, credit-card details or personal data. Spear phishing customises the lure for a specific individual or organisation.",
    spread: "Relies on human trust — the most-successful attacks exploit error, not code.",
  },
  {
    i: "03",
    name: "Ransomware Attacks",
    vector: "MALWARE · EXTORTION",
    severity: "CRITICAL",
    desc: "Encrypts a victim's files or locks access to systems and demands a ransom in exchange for restoring access. Frequently targets business, healthcare and government because their data is critical.",
    spread: "Payment gives no guarantee of recovery — prevention and backups are essential.",
  },
  {
    i: "04",
    name: "DDoS Attacks",
    vector: "NETWORK TRAFFIC",
    severity: "HIGH",
    desc: "Distributed Denial-of-Service attacks overwhelm servers, networks or applications with massive traffic from multiple compromised systems (botnets), so legitimate users cannot reach the service.",
    spread: "Disrupts websites, online services and critical infrastructure — financial and reputational damage.",
  },
];

/* --- Slide 11 · Cost + evolution ---------------------------------- */
export const breachCost = [
  { label: "Healthcare", value: 9.77 },
  { label: "Financial Services", value: 6.08 },
  { label: "Manufacturing", value: 5.56 },
  { label: "Higher Education", value: 3.65 },
  { label: "Retail", value: 3.48 },
];

export const evolution = [
  { era: "1990s", label: "Antivirus" },
  { era: "2000s", label: "Firewalls & IDS/IPS" },
  { era: "2010s", label: "Next-Gen Security" },
  { era: "2020s", label: "Advanced threat detection" },
  { era: "2020s", label: "AI-powered security" },
  { era: "2025", label: "AI attacks & deepfakes" },
];

/* --- Slide 12 · Trends -------------------------------------------- */
export const trends = [
  {
    i: "01",
    name: "Rise of AI & Machine Learning",
    desc: "AI/ML analyse vast volumes of data in real time — identifying unusual patterns, detecting anomalies and responding automatically.",
    meta: "DETECT",
  },
  {
    i: "02",
    name: "Rising ransomware attacks",
    desc: "Growing in frequency and sophistication across every sector. Mitigation: backups, endpoint protection, awareness training, incident response.",
    meta: "DEFEND",
  },
  {
    i: "03",
    name: "Cloud security",
    desc: "As cloud adoption grows, misconfiguration and insecure APIs remain among the most common cloud-related vulnerabilities.",
    meta: "CONFIGURE",
  },
  {
    i: "04",
    name: "IoT security challenges",
    desc: "Expanding device fleets with limited built-in security can be turned into botnets, breach points and surveillance tools.",
    meta: "SEGMENT",
  },
  {
    i: "05",
    name: "Zero Trust security",
    desc: "“Never trust, always verify.” It assumes that no user or device — inside or outside the network — should be trusted by default; every access request is continuously verified using identity validation, MFA and strict access controls, significantly reducing lateral movement after an initial breach.",
    meta: "VERIFY",
  },
];

/* --- Slide 13 · Challenges ---------------------------------------- */
export const challenges = [
  {
    i: "01",
    name: "Evolving threats",
    desc: "Attackers constantly build new tools and techniques to bypass defenses. Systems must be patched, updated and monitored without pause.",
    counter: "CONTINUOUS PATCHING & MONITORING",
  },
  {
    i: "02",
    name: "Limited budgets",
    desc: "Financial constraints cap investment in advanced tooling and skilled personnel — critical assets must be prioritized.",
    counter: "RISK-BASED PRIORITIZATION",
  },
  {
    i: "03",
    name: "Insider threats",
    desc: "Employees or authorized users misusing access — intentionally or by accident — and difficult to detect from the outside.",
    counter: "ACCESS CONTROL · MONITORING · TRAINING",
  },
  {
    i: "04",
    name: "Complex technology environments",
    desc: "Cloud, IoT, legacy systems and hybrid infrastructure coexist, making consistent security and visibility hard to maintain.",
    counter: "SIMPLIFY · UNIFY POLICY · AUDIT",
  },
];

/* --- Slides 15–19 · Knowledge check ------------------------------- */
export type Question = {
  q: string;
  options: string[];
  answer: number;
  why: string;
};

export const questions: Question[] = [
  {
    q: "What is cybersecurity mainly used for?",
    options: ["Playing games", "Protecting systems and data", "Editing videos", "Designing websites"],
    answer: 1,
    why: "Cybersecurity protects networks, systems, applications and digital assets from unauthorized access and attack.",
  },
  {
    q: "Which cybersecurity type protects devices like laptops, smartphones and IoT devices?",
    options: ["Cloud Security", "Endpoint Security", "Application Security", "Operational Security"],
    answer: 1,
    why: "Endpoint security covers laptops, desktops, smartphones, servers and IoT devices — often the first target.",
  },
  {
    q: "Why are regular software updates important?",
    options: ["To change device color", "To increase internet speed", "To fix security vulnerabilities", "To delete files"],
    answer: 2,
    why: "Updates and security patches close known vulnerabilities before attackers can exploit them.",
  },
  {
    q: "Which core pillar of cybersecurity ensures that data is accessible whenever needed?",
    options: ["Integrity", "Confidentiality", "Availability", "Authentication"],
    answer: 2,
    why: "Availability is the pillar that keeps systems and data reachable by authorized users whenever needed.",
  },
  {
    q: "What is the purpose of a security patch in cybersecurity?",
    options: [
      "To enhance the performance of hardware",
      "To fix vulnerabilities and security flaws in software",
      "To improve the user interface of an application",
      "To create backup copies of critical system files",
    ],
    answer: 1,
    why: "A patch remediates a discovered vulnerability or flaw — the core of vulnerability management.",
  },
];

/* --- Contents / index drawer -------------------------------------- */
export const contents: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: [
      "Title",
      "What cybersecurity is",
      "Protection in practice",
      "Key objectives",
      "Standards & the human factor",
      "Security risk — what's at stake",
    ],
  },
  {
    section: "Core Pillars",
    items: ["The CIA Triad", "CIA — in detail"],
  },
  {
    section: "Domains",
    items: ["Seven domains — index", "Domains 01–03", "Domains 04–07"],
  },
  {
    section: "Threat Landscape",
    items: [
      "Major cyber attacks — table",
      "Common threats — five shapes",
      "Threats in depth",
      "Cost & evolution",
    ],
  },
  {
    section: "Response",
    items: ["Digital forensics & investigation"],
  },
  {
    section: "Horizon",
    items: ["Emerging trends", "Challenges"],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Score", "Takeaways"],
  },
];

/** Total number of slides in the deck. */
export const TOTAL = 26;
