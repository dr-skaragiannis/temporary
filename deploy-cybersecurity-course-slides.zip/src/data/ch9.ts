/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 09
   Types of Cyber Crime
------------------------------------------------------------------ */

export const CH9_TITLE = "Types of Cyber Crime";
export const ch9Stamp = "Last Updated : 13 Jun, 2026";

export const ch9Intro =
  "Cyber crime includes a wide range of illegal activities that exploit computers, networks and the internet. These crimes are broadly categorized into two main types: crimes that target computer networks or devices, and crimes that use computer networks to commit other criminal activities.";

export type Crime = {
  i: string;
  name: string;
  desc: string;
  tag: string;
  tone: "phos" | "amber" | "sage";
};

/* --- Category A: targeting networks or devices ---------------------- */
export const catALead =
  "These attacks directly target systems, networks or devices to steal data, damage infrastructure or disrupt services.";

export const crimesA: Crime[] = [
  {
    i: "01",
    name: "Malware Attacks",
    desc: "Malicious software such as viruses, Trojans, worms and ransomware used to damage systems or steal data.",
    tag: "Code",
    tone: "amber",
  },
  {
    i: "02",
    name: "DoS and DDoS Attacks",
    desc: "Flooding servers with excessive traffic to make websites or services unavailable.",
    tag: "Availability",
    tone: "amber",
  },
  {
    i: "03",
    name: "Phishing Attacks",
    desc: "Fake emails or websites designed to steal passwords, banking details or sensitive information.",
    tag: "Deception",
    tone: "phos",
  },
  {
    i: "04",
    name: "Botnets",
    desc: "Networks of infected devices remotely controlled to perform spam campaigns or cyberattacks.",
    tag: "Scale",
    tone: "phos",
  },
  {
    i: "05",
    name: "Exploits and Vulnerabilities",
    desc: "Attackers misuse software weaknesses or unpatched systems to gain unauthorized access.",
    tag: "Access",
    tone: "sage",
  },
];

/* --- Category B: networks as a means ---------------------------------- */
export const catBLead =
  "These crimes use the internet to perform traditional illegal activities such as fraud, harassment or identity theft.";

export const crimesB: Crime[] = [
  {
    i: "01",
    name: "Cyber Terrorism",
    desc: "Attacks targeting critical infrastructure, government systems or communication networks.",
    tag: "Infrastructure",
    tone: "amber",
  },
  {
    i: "02",
    name: "Cyber Extortion (Ransomware)",
    desc: "Encrypting files or disrupting systems to demand ransom payments.",
    tag: "Money",
    tone: "amber",
  },
  {
    i: "03",
    name: "Cyber Warfare",
    desc: "State-sponsored cyberattacks used for espionage, disruption or digital sabotage.",
    tag: "State",
    tone: "amber",
  },
  {
    i: "04",
    name: "Internet Fraud",
    desc: "Online scams, fake websites and deceptive transactions used to steal money or data.",
    tag: "Money",
    tone: "phos",
  },
  {
    i: "05",
    name: "Cyberstalking & Online Harassment",
    desc: "Continuous online threats, monitoring or abusive digital communication.",
    tag: "People",
    tone: "phos",
  },
  {
    i: "06",
    name: "Financial Fraud",
    desc: "Unauthorized financial transactions, banking fraud and credential theft attacks.",
    tag: "Money",
    tone: "phos",
  },
  {
    i: "07",
    name: "Cyber Espionage",
    desc: "Unauthorized access to confidential business, military or government information.",
    tag: "Secrets",
    tone: "sage",
  },
];

/* --- Challenges & impact ------------------------------------------------ */
export const challenges = [
  {
    i: "01",
    name: "Lack of Cyber Awareness",
    desc: "Limited knowledge of cybersecurity practices increases vulnerability to attacks.",
    kind: "Challenge",
  },
  {
    i: "02",
    name: "Anonymous Threat Actors",
    desc: "VPNs, proxy servers and fake identities make cybercriminal tracing difficult.",
    kind: "Challenge",
  },
  {
    i: "03",
    name: "Underreporting of Incidents",
    desc: "Many cyber crimes remain unreported due to fear, reputation concerns or lack of awareness.",
    kind: "Challenge",
  },
  {
    i: "04",
    name: "Advanced Attack Techniques",
    desc: "Skilled attackers use sophisticated tools, malware and social engineering methods.",
    kind: "Challenge",
  },
  {
    i: "05",
    name: "Weak Cyber Law Enforcement",
    desc: "Limited penalties and legal challenges reduce deterrence against cyber crimes.",
    kind: "Challenge",
  },
  {
    i: "06",
    name: "Financial & Operational Damage",
    desc: "Cyber attacks cause financial losses, data breaches, downtime and business disruption.",
    kind: "Impact",
  },
  {
    i: "07",
    name: "Reputational & Legal Risks",
    desc: "Organizations may face trust issues, compliance violations, lawsuits and regulatory penalties.",
    kind: "Impact",
  },
];

/* --- Protection ----------------------------------------------------------- */
export const protections = [
  {
    i: "01",
    name: "Use Strong Passwords",
    desc: "Use unique and complex passwords with uppercase letters, numbers and special characters to prevent brute-force and credential attacks.",
    stops: "Brute force · credential stuffing",
  },
  {
    i: "02",
    name: "Use Trusted Antivirus Software",
    desc: "Install updated antivirus and endpoint protection tools to detect and block malware, spyware and ransomware.",
    stops: "Malware · spyware · ransomware",
  },
  {
    i: "03",
    name: "Enable Two-Factor Authentication (2FA)",
    desc: "Activate 2FA or MFA on critical accounts to add an extra authentication layer using OTPs or biometrics.",
    stops: "Stolen passwords",
  },
  {
    i: "04",
    name: "Keep Systems Updated",
    desc: "Regularly update operating systems, applications and firmware to patch known security vulnerabilities.",
    stops: "Exploits · unpatched flaws",
  },
  {
    i: "05",
    name: "Use Secure Networks",
    desc: "Avoid unsecured public Wi-Fi for sensitive activities and use encrypted connections or VPN services.",
    stops: "Eavesdropping · interception",
  },
  {
    i: "06",
    name: "Be Careful with Emails and Attachments",
    desc: "Avoid clicking suspicious links or downloading unknown attachments to prevent phishing and malware infections.",
    stops: "Phishing · malware delivery",
  },
];

/* --- Reporting -------------------------------------------------------------- */
export const reportingLead =
  "Reporting cyber crime quickly helps reduce damage, preserve digital evidence and support law enforcement investigations.";

export const reporting = [
  {
    i: "01",
    region: "United States",
    name: "FBI Internet Crime Complaint Center (IC3)",
    desc: "Report cyber crimes through the FBI's Internet Crime Complaint Center at ic3.gov.",
    link: "ic3.gov",
  },
  {
    i: "02",
    region: "European Union",
    name: "Europol reporting links",
    desc: "Europol provides country-specific cyber crime reporting links for EU member states.",
    link: "europol.europa.eu",
  },
  {
    i: "03",
    region: "Everywhere",
    name: "Local law enforcement / cyber crime unit",
    desc: "Contact local law enforcement or cyber crime units immediately and preserve logs, screenshots, emails and transaction records as evidence.",
    link: "Preserve evidence",
  },
];

export const evidence = ["Logs", "Screenshots", "Emails", "Transaction records"];

/* --- Knowledge check ---------------------------------------------------- */
export type Q9 = { q: string; options: string[]; answer: number; why: string };

export const questions9: Q9[] = [
  {
    q: "Which cyber crime involves repeatedly threatening, monitoring or harassing someone online?",
    options: ["Cyberstalking", "Phishing", "Identity theft", "Spoofing"],
    answer: 0,
    why: "Cyberstalking and online harassment are defined by continuous online threats, monitoring or abusive digital communication aimed at a person.",
  },
  {
    q: "Which attack uses fake emails or messages to steal information?",
    options: ["Phishing", "DDoS attack", "SQL Injection", "Botnet"],
    answer: 0,
    why: "Phishing relies on fake emails or websites designed to trick the victim into handing over passwords, banking details or other sensitive data.",
  },
  {
    q: "What is a botnet?",
    options: [
      "A type of firewall",
      "A network of infected computers controlled by attackers",
      "A password manager",
      "A software update tool",
    ],
    answer: 1,
    why: "A botnet is a network of infected devices remotely controlled by an attacker to perform spam campaigns or launch cyberattacks.",
  },
  {
    q: "A company website suddenly becomes unavailable because thousands of compromised computers are sending traffic to the server simultaneously. Which attack is most likely occurring?",
    options: [
      "Denial-of-Service (DoS)",
      "Distributed Denial-of-Service (DDoS)",
      "Man-in-the-Middle Attack",
      "SQL Injection",
    ],
    answer: 1,
    why: "Traffic arriving from thousands of compromised machines at once is the signature of a Distributed DoS — the 'distributed' part is the botnet.",
  },
  {
    q: "What is one way to protect yourself from cyber crime?",
    options: [
      "Click unknown links",
      "Use strong and unique passwords",
      "Share passwords publicly",
      "Ignore software updates",
    ],
    answer: 1,
    why: "Strong, unique passwords defeat brute-force and credential-stuffing attacks. The other three options are precisely the behaviours attackers rely on.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents9: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What cyber crime is", "Two categories"],
  },
  {
    section: "Types",
    items: ["Targeting networks & devices", "Networks as a means", "Crime matrix"],
  },
  {
    section: "Impact & defence",
    items: ["Challenges & impact", "Protect yourself", "Reporting process"],
  },
  {
    section: "Knowledge check",
    items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"],
  },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL9 = 17;
