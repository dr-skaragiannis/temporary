/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 11
   Emerging Attack Vectors
------------------------------------------------------------------ */

export const CH11_TITLE = "Emerging Attack Vectors";
export const ch11Stamp = "Last Updated : 13 Jun, 2026";

export const ch11Intro =
  "Emerging attack vectors are new and evolving methods used by cyber attackers to exploit modern technologies and system weaknesses. They are harder to detect because they use advanced tools and continuously changing techniques.";

export const ch11Bullets = [
  "Target modern technologies like cloud, AI, IoT.",
  "Exploit both technical flaws and human behavior.",
  "Can target web, mobile or network systems.",
  "Used by attackers and ethical hackers for testing security.",
];

/* --- Six emerging vectors ------------------------------------------- */
export type Vector = {
  i: string;
  name: string;
  short: string;
  desc: string;
  example: string;
  impact: string;
  surface: string;
  tone: "phos" | "amber" | "sage";
};

export const vectors: Vector[] = [
  {
    i: "01",
    name: "AI-Powered Attacks",
    short: "AI",
    desc: "Cybercriminals use artificial intelligence to automate attacks, create advanced phishing emails and bypass security systems.",
    example: "AI-generated phishing emails that look highly realistic.",
    impact: "Harder to detect and prevent.",
    surface: "People · defences",
    tone: "amber",
  },
  {
    i: "02",
    name: "IoT-Based Attacks",
    short: "IoT",
    desc: "Internet of Things devices like smart cameras and home devices are often poorly secured.",
    example: "Botnets created using IoT devices.",
    impact: "Large-scale attacks like DDoS.",
    surface: "Devices",
    tone: "phos",
  },
  {
    i: "03",
    name: "Cloud Security Exploits",
    short: "Cloud",
    desc: "Misconfigured cloud settings can expose sensitive data.",
    example: "Publicly accessible storage buckets.",
    impact: "Data breaches and data leaks.",
    surface: "Configuration",
    tone: "phos",
  },
  {
    i: "04",
    name: "Deepfake & Social Engineering",
    short: "Deepfake",
    desc: "Attackers use deepfake technology to impersonate individuals.",
    example: "Fake video/audio of a CEO requesting money.",
    impact: "Financial fraud and trust exploitation.",
    surface: "People",
    tone: "amber",
  },
  {
    i: "05",
    name: "Supply Chain Attacks",
    short: "Supply chain",
    desc: "Attackers target third-party vendors to access larger systems.",
    example: "Compromising software updates.",
    impact: "Widespread organizational damage.",
    surface: "Third parties",
    tone: "amber",
  },
  {
    i: "06",
    name: "Fileless Malware Attacks",
    short: "Fileless",
    desc: "These attacks run in memory without leaving traditional files.",
    example: "Using PowerShell scripts.",
    impact: "Difficult to detect with antivirus.",
    surface: "Memory · endpoints",
    tone: "sage",
  },
];

/* --- Common (established) vectors ------------------------------------ */
export const commonVectors = [
  {
    i: "01",
    name: "Phishing",
    desc: "The most common mode is spam email that appears authentic, harvesting the victim's credentials.",
    meta: "Human",
  },
  {
    i: "02",
    name: "Malware",
    desc: "Short for malicious software — any software designed to cause harm to computer systems, networks or users.",
    meta: "Code",
  },
  {
    i: "03",
    name: "Man-in-the-Middle (MITM)",
    desc: "An unwanted proxy sits in the network intercepting and modifying requests and responses.",
    meta: "Transit",
  },
  {
    i: "04",
    name: "Denial of Service",
    desc: "An attack on an individual computer or website intended to disrupt network operations by denying access to its users.",
    meta: "Availability",
  },
  {
    i: "05",
    name: "Insider Attacks",
    desc: "Caused by insiders — former employees, business partners, contractors or security admins — who previously had access to confidential information.",
    meta: "Trust",
  },
  {
    i: "06",
    name: "Ransomware",
    desc: "Malicious software that prevents users from accessing their data by encrypting it.",
    meta: "Extortion",
  },
  {
    i: "07",
    name: "SQL Injection",
    desc: "A code injection technique that gains unauthorized database access by injecting malicious SQL commands into web page inputs.",
    meta: "Web",
  },
];

/* --- Recent incidents -------------------------------------------------- */
export const incidents = [
  {
    year: "2023",
    org: "Infosys",
    kind: "Data breach",
    points: [
      "The Indian IT company faced a data breach affecting its US unit, Infosys McCamish Systems.",
      "Several applications became unavailable; the full impact remains under investigation.",
    ],
    tone: "phos" as const,
  },
  {
    year: "2023",
    org: "Indian Council of Medical Research",
    kind: "Mass data breach",
    points: [
      "Health records of around 815 million Indian citizens were exposed.",
      "The data was allegedly put up for sale by a threat actor known as “pwn0001”.",
    ],
    tone: "amber" as const,
  },
  {
    year: "2024",
    org: "Hyundai Motor Europe",
    kind: "Ransomware · Black Basta",
    points: [
      "Targeted by the Black Basta ransomware group.",
      "Attackers claimed to have stolen approximately 3 TB of sensitive corporate data.",
    ],
    tone: "amber" as const,
  },
  {
    year: "2024",
    org: "Boeing",
    kind: "Ransomware · LockBit",
    points: [
      "Experienced a cyberattack linked to the LockBit ransomware group.",
      "Parts of business operations were affected; flight safety was not impacted.",
    ],
    tone: "phos" as const,
  },
];

/* --- Defences ------------------------------------------------------------ */
export const defences = [
  {
    i: "01",
    name: "Network Segmentation",
    desc: "Dividing a computer network into smaller, isolated segments or subnetworks so a breach in one cannot freely spread to the rest.",
    counters: "Lateral movement · IoT botnets · supply chain",
  },
  {
    i: "02",
    name: "Intrusion Detection & Prevention System",
    desc: "Identifies malicious activity, collects information about it, reports it and attempts to block or stop it — in real time.",
    counters: "MITM · DoS · fileless behaviour",
  },
  {
    i: "03",
    name: "Antivirus / Anti-Malware",
    desc: "Software that helps protect the computer system from viruses and malware.",
    counters: "Malware · ransomware payloads",
  },
  {
    i: "04",
    name: "Encryption",
    desc: "Preserves data confidentiality by transforming it into ciphertext that can only be decoded with a unique decryption key.",
    counters: "Cloud leaks · interception · data theft",
  },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q11 = { q: string; options: string[]; answer: number; why: string };

export const questions11: Q11[] = [
  {
    q: "Which statement best describes an attack vector?",
    options: [
      "A tool used to encrypt data",
      "A method used to monitor networks",
      "A path used by attackers to exploit vulnerabilities",
      "A firewall configuration rule",
    ],
    answer: 2,
    why: "An attack vector is the path or method an attacker uses to reach and exploit a vulnerability in a system or a person.",
  },
  {
    q: "Which of the following is a key feature of emerging attack vectors?",
    options: [
      "They are well-documented and easy to detect",
      "They rely only on physical access",
      "They use modern technologies and evolving techniques",
      "They are limited to database attacks",
    ],
    answer: 2,
    why: "Emerging vectors target modern technologies — cloud, AI, IoT — and keep changing, which is exactly why they are harder to detect.",
  },
  {
    q: "An attacker intercepts communication between a user and a website and modifies the data in transit. What type of attack is this?",
    options: ["SQL Injection", "MITM Attack", "Ransomware", "Insider Attack"],
    answer: 1,
    why: "A Man-in-the-Middle attack places an unwanted proxy in the path, intercepting and modifying requests and responses.",
  },
  {
    q: "A ransomware group encrypts company data and demands payment, similar to attacks on large organizations like Hyundai. What is the main goal of this attack?",
    options: ["Data monitoring", "Service optimization", "Financial extortion", "Network analysis"],
    answer: 2,
    why: "Ransomware denies access to data through encryption so the attacker can extort a payment for the decryption key.",
  },
  {
    q: "An organization wants to detect suspicious activities and automatically block threats in real time. Which solution is most suitable?",
    options: [
      "Antivirus only",
      "Encryption tools",
      "Intrusion Detection and Prevention System (IDPS)",
      "Backup system",
    ],
    answer: 2,
    why: "An IDPS identifies malicious activity, reports it and actively attempts to block it. Antivirus is endpoint-only; encryption and backups protect data but do not block live threats.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents11: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What an attack vector is", "Six emerging vectors"],
  },
  {
    section: "Emerging vectors",
    items: ["AI · IoT · Cloud", "Deepfake · Supply chain · Fileless", "Vector matrix"],
  },
  {
    section: "Landscape",
    items: ["Common vectors", "Recent incidents", "Defences"],
  },
  {
    section: "Knowledge check",
    items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"],
  },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL11 = 17;
