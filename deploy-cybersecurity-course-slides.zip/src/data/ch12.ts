/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 12
   Botnets in Computer Networks
------------------------------------------------------------------ */

export const CH12_TITLE = "Botnets";
export const ch12Stamp = "Last Updated : 13 Jun, 2026";

export const ch12Intro =
  "A botnet is a network of compromised computers or devices infected with malware and remotely controlled by an attacker (botmaster) through a Command and Control (C&C) system. These infected devices are called bots or zombies.";

export const ch12Bullets = [
  "Botnets are created using malware such as trojans, worms or spyware.",
  "Each infected device becomes part of a remotely controlled network.",
  "Bots operate in the background without user knowledge.",
];

export const glossary = [
  { term: "Botmaster", def: "The attacker who controls the botnet." },
  { term: "Bot / Zombie", def: "An infected device under remote control." },
  { term: "C&C server", def: "The Command and Control system that issues instructions." },
];

/* --- Working: six steps ------------------------------------------- */
export type Step = {
  i: string;
  name: string;
  label: string;
  desc: string;
  points: string[];
};

export const steps: Step[] = [
  {
    i: "01",
    name: "Identifying Vulnerable Systems",
    label: "SCAN",
    desc: "The attacker first scans and identifies devices that can be easily compromised. These systems usually have weak security or outdated protection, making them easy entry points.",
    points: [
      "Outdated operating systems or unpatched software.",
      "Weak or default passwords and poorly configured security settings.",
      "Users who frequently click unknown links or download unsafe files.",
    ],
  },
  {
    i: "02",
    name: "Malware Infection",
    label: "INFECT",
    desc: "The attacker spreads malicious software to the identified systems. Once executed, the malware installs itself silently and turns the device into a bot without the user noticing.",
    points: [
      "Phishing emails with malicious attachments or links.",
      "Fake software updates or cracked software downloads.",
      "Infected websites (drive-by downloads).",
    ],
  },
  {
    i: "03",
    name: "Connection to C&C Server",
    label: "CONNECT",
    desc: "After infection, the device connects to a Command and Control server — the control center where the attacker manages all infected devices remotely.",
    points: [
      "Bot registers itself with the C&C server.",
      "Sends device information like IP address and system details.",
      "Waits for instructions from the botmaster; enables remote control.",
    ],
  },
  {
    i: "04",
    name: "Communication Using Common Protocols",
    label: "TALK",
    desc: "Botnets communicate using standard internet protocols to avoid detection. The traffic is designed to look normal so it blends with regular network activity.",
    points: [
      "IRC (Internet Relay Chat) — used in older botnets.",
      "HTTP/HTTPS traffic to mimic normal web browsing.",
      "Peer-to-Peer (P2P) communication without central server dependency.",
    ],
  },
  {
    i: "05",
    name: "Execution of Commands",
    label: "EXECUTE",
    desc: "The botmaster sends instructions through the C&C system and infected devices carry out tasks automatically. These actions are often large-scale and coordinated.",
    points: [
      "Sending spam emails in bulk.",
      "Launching Distributed Denial-of-Service attacks.",
      "Redirecting users to phishing or malicious websites.",
    ],
  },
  {
    i: "06",
    name: "Botnet Expansion (Self-Propagation)",
    label: "GROW",
    desc: "The botnet continues to grow by infecting more vulnerable systems. Each newly infected device increases its strength and reach.",
    points: [
      "Infecting new systems using similar attack methods.",
      "Increasing overall size and attack capability of the botnet.",
    ],
  },
];

/* --- Types by C&C channel ------------------------------------------- */
export type BotType = {
  i: string;
  name: string;
  short: string;
  desc: string;
  points: string[];
  topology: "central" | "p2p" | "web";
  resilience: string;
  stealth: string;
  era: string;
  tone: "phos" | "amber" | "sage";
};

export const botTypes: BotType[] = [
  {
    i: "01",
    name: "IRC Botnet",
    short: "IRC",
    desc: "Uses Internet Relay Chat servers as the C&C channel through which the botmaster sends instructions to infected devices.",
    points: [
      "Uses centralized communication structure.",
      "Bots connect to an IRC server to receive instructions.",
      "Commands are transmitted as normal chat messages.",
    ],
    topology: "central",
    resilience: "Low — one server to take down",
    stealth: "Low — IRC traffic stands out",
    era: "Older botnets",
    tone: "sage",
  },
  {
    i: "02",
    name: "Peer-to-Peer (P2P) Botnet",
    short: "P2P",
    desc: "Operates on a decentralized structure where each infected device communicates directly with other bots instead of relying on a central server.",
    points: [
      "Does not depend on a central Command and Control server.",
      "Each bot acts as both client and server.",
      "Bots share commands with each other across the network.",
    ],
    topology: "p2p",
    resilience: "High — no single point of failure",
    stealth: "Medium — unusual peer traffic",
    era: "Modern, hard to dismantle",
    tone: "amber",
  },
  {
    i: "03",
    name: "HTTP/HTTPS Botnet",
    short: "HTTP",
    desc: "Bots periodically connect to specific URLs to receive instructions, making the traffic appear similar to normal web browsing activity.",
    points: [
      "Uses web protocols for communication.",
      "Bots connect to web servers at regular intervals.",
      "Communication blends with normal internet traffic.",
    ],
    topology: "web",
    resilience: "Medium — domains can rotate",
    stealth: "High — looks like browsing",
    era: "Most common today",
    tone: "phos",
  },
];

/* --- Attacks ---------------------------------------------------------- */
export const attacks = [
  {
    i: "01",
    name: "Phishing Attack",
    desc: "Botnets send fraudulent messages that trick users into revealing sensitive information such as passwords, credit card details or login credentials.",
    meta: "Credentials",
  },
  {
    i: "02",
    name: "DDoS Attack",
    desc: "Multiple bots send a large amount of traffic to a target server, making the website or service slow or unavailable to legitimate users. Common techniques include SYN Flood and UDP Flood.",
    meta: "Availability",
  },
  {
    i: "03",
    name: "Spamming",
    desc: "Botnets send a large number of unwanted emails or messages automatically.",
    meta: "Volume",
  },
  {
    i: "04",
    name: "Data Theft",
    desc: "Stealing confidential or sensitive information using botnets.",
    meta: "Confidentiality",
  },
  {
    i: "05",
    name: "Targeted Intrusion",
    desc: "Focuses on a specific organization or individual to gain unauthorized access to valuable data or systems.",
    meta: "Precision",
  },
];

/* --- Prevention -------------------------------------------------------- */
export const prevention = [
  { i: "01", name: "Patch everything", desc: "Keep operating system and software updated with the latest security patches.", breaks: "Step 1 · scanning for outdated systems" },
  { i: "02", name: "Don't click blind", desc: "Avoid clicking suspicious links, emails or unknown attachments.", breaks: "Step 2 · phishing delivery" },
  { i: "03", name: "Strong, unique passwords", desc: "Use strong and unique passwords for different accounts.", breaks: "Step 1 · default credentials" },
  { i: "04", name: "Enable 2FA", desc: "Enable two-factor authentication for additional security.", breaks: "Credential reuse" },
  { i: "05", name: "Endpoint protection", desc: "Install trusted antivirus or endpoint security software.", breaks: "Step 2 · silent install" },
  { i: "06", name: "Firewall", desc: "Use a firewall to monitor and control incoming and outgoing network traffic.", breaks: "Step 3–4 · C&C connection" },
  { i: "07", name: "Trusted sources only", desc: "Download software only from trusted and official sources.", breaks: "Step 2 · fake updates & cracks" },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q12 = { q: string; options: string[]; answer: number; why: string };

export const questions12: Q12[] = [
  {
    q: "What is a botnet in computer networks?",
    options: [
      "A secure communication protocol",
      "A network of compromised computers controlled by a botmaster",
      "A firewall system protecting against malware",
      "A decentralized peer-to-peer file-sharing system",
    ],
    answer: 1,
    why: "A botnet is a network of malware-infected devices (bots or zombies) remotely controlled by an attacker — the botmaster — through a C&C system.",
  },
  {
    q: "Which type of botnet is hardest to shut down due to its decentralized structure?",
    options: ["IRC Botnet", "HTTP Botnet", "P2P Botnet", "DNS Botnet"],
    answer: 2,
    why: "A P2P botnet has no central C&C server; each bot is both client and server, so there is no single point to take down.",
  },
  {
    q: "Which of the following is a common attack performed by botnets?",
    options: [
      "SYN Floods in Distributed Denial-of-Service (DDoS) attacks",
      "Encrypting user files for ransom",
      "Translating domain names into IP addresses",
      "Synchronizing system clocks",
    ],
    answer: 0,
    why: "DDoS is the signature botnet attack — many bots flood a target with traffic, using techniques such as SYN Flood and UDP Flood.",
  },
  {
    q: "Which of the following is NOT a recommended way to protect against botnets?",
    options: [
      "Regularly updating system software",
      "Using two-factor authentication",
      "Training users to identify suspicious links",
      "Allowing default passwords to remain unchanged",
    ],
    answer: 3,
    why: "Default passwords are exactly what attackers scan for in Step 1. Updates, 2FA and user awareness are all recommended controls.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents12: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What a botnet is", "Lifecycle overview"],
  },
  {
    section: "How it works",
    items: ["Scan · Infect · Connect", "Talk · Execute · Grow"],
  },
  {
    section: "Types & attacks",
    items: ["Three C&C topologies", "Topology comparison", "Botnet attacks", "Prevention"],
  },
  {
    section: "Knowledge check",
    items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Score"],
  },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL12 = 16;
