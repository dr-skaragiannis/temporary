/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 02
   Linux Permissions
------------------------------------------------------------------ */

export const CH2_TITLE = "Linux Permissions";

/* --- 02 · Why permissions matter ---------------------------------- */
export const whyPermissions =
  "Linux file permissions form the foundation of the system's security model. They define who can read, write, or execute files and directories.";

export const whyQuestions = [
  ["Who can READ", "View the contents of a file, or list the entries of a directory."],
  ["Who can WRITE", "Modify a file, or create and delete entries inside a directory."],
  ["Who can EXECUTE", "Run a file as a program, or traverse into a directory."],
];

/* --- 03 · The three basic permissions ----------------------------- */
export const threePermissions = [
  {
    key: "r",
    name: "Read",
    octal: 4,
    file: "Open and view the contents of the file.",
    dir: "List the entries inside the directory — but not modify them.",
    shell: "cat notes.md",
  },
  {
    key: "w",
    name: "Write",
    octal: 2,
    file: "Modify, overwrite or truncate the file's contents.",
    dir: "Create, delete or rename entries inside the directory.",
    shell: "echo more >> notes.md",
  },
  {
    key: "x",
    name: "Execute",
    octal: 1,
    file: "Run the file as a program or shell script.",
    dir: "Traverse into the directory — required for cd and for any path beneath it.",
    shell: "./run.sh",
  },
];

/* --- 04 · Ownership & permission groups --------------------------- */
export const ownership = [
  {
    i: "01",
    label: "Owner (user)",
    desc: "The user who created the file. Shown in the third column of ls -l. The owner is the only account that can hand this file away with chown.",
    meta: "u",
  },
  {
    i: "02",
    label: "Group",
    desc: "The collection of users assigned to the file. Every member inherits the middle three characters of the mode string.",
    meta: "g",
  },
  {
    i: "03",
    label: "Others",
    desc: "Every remaining account on the system. This is the permission group that you want to watch the most.",
    meta: "o",
  },
];

/* --- 05 · Operators ----------------------------------------------- */
export const operators = [
  { op: "+", name: "Add permissions", ex: "chmod u+x program" },
  { op: "-", name: "Remove permissions", ex: "chmod o-w notes.md" },
  { op: "=", name: "Set the permissions to the specified values", ex: "chmod g=rx project" },
];

export const operatorNote =
  "All of these permissions are granted at three different levels, based on their group.";

/* --- 06 / 07 · Permission groups ---------------------------------- */
export const nineChars =
  "Permissions are represented as nine characters. Each of the three “rwx” characters refers to a different operation you can perform on the file.";

export const classRef = [
  {
    sym: "u",
    cls: "user",
    desc: "The user permissions apply only to the owner of the file or directory — they will not impact the actions of other users.",
  },
  {
    sym: "g",
    cls: "group",
    desc: "The group permissions apply only to the group that has been assigned to the file or directory — they will not affect the actions of other users.",
  },
  {
    sym: "o",
    cls: "others",
    desc: "The other permissions apply to all other users on the system — this is the permission group that you want to watch the most.",
  },
  {
    sym: "a",
    cls: "All three",
    desc: "All three (owner, groups, others) at once — the short form of ugo.",
  },
];

/* --- 08 · ls -l ---------------------------------------------------- */
export const lsInput = "ls -l NarX.txt";
export const lsOutput = "-rw-r--r-- 1 user group 46 Apr 14 16:37 NarX.txt";

export const lsBreakdown = [
  "The first character “-” indicates a file; a “d” indicates a directory.",
  "The next nine characters (rw-r--r--) show the security mode of the file.",
  "The next column shows the owner of the file.",
  "The next column shows the group owner of the file — which has special access to these files.",
  "The next column shows the size of the file in bytes.",
  "The next column shows the date and time the file was last modified.",
];

/* --- 09 · namei & stat -------------------------------------------- */
export const nameiBlock = {
  input: "namei -l /home/narx/project/plan.txt",
  output: [
    "f: /home/narx/project/plan.txt",
    "drwxr-xr-x root root /",
    "drwxr-xr-x root root home",
    "drwxr-xr-x narx users narx",
    "drwxr-xr-x narx users project",
    "-rw-rw-r-- narx users plan.txt",
  ],
};

export const statBlock = {
  input: "stat example.txt",
  output: [
    "  File: example.txt",
    "  Size: 2210       Blocks: 8          IO Block: 4096  regular file",
    "Device: 802h/2050d    Inode: 1288496     Links: 1",
    "Access: 2024-11-18 10:50:56.000000000 +0000",
    "Modify: 2024-11-18 10:50:56.000000000 +0000",
    "Change: 2024-11-18 10:50:56.000000000 +0000",
    " Birth: -",
  ],
};

export const inspectNotes = [
  {
    cmd: "ls -l",
    desc: "The everyday view — type, mode, links, owner, group, size, mtime and name, in one column-aligned row.",
  },
  {
    cmd: "namei -l /path/to/file",
    desc: "Walks the path component by component, printing the permissions of every directory that must be traversed to reach the file.",
  },
  {
    cmd: "stat example.txt",
    desc: "Unlike ls -l, stat pinpoints the exact file location — inode, device, blocks, links and all three timestamps.",
  },
];

/* --- 10 · chmod & symbolic notation ------------------------------- */
export const chmodIntro =
  'The command you use to change the security permissions on files is called "chmod", which stands for "change mode" — because the nine security characters are collectively called the security "mode" of the file. You can modify permissions using symbolic notation or octal notation.';

export const symbolicSteps = [
  { n: "01", cmd: "chmod o", note: "Name the class — “other” users." },
  { n: "02", cmd: "chmod o+", note: "Add a “+” to say that you are adding permission." },
  { n: "03", cmd: "chmod o+x", note: "Add an “x” — the execute permission." },
  { n: "04", cmd: "chmod o+x xyz.txt", note: "Specify which file you are changing." },
];

/* --- 11 · More symbolic examples ---------------------------------- */
export const symbolicExamples = [
  {
    cmd: "chmod ugo-rwx xyz.txt",
    title: "Revoke everything",
    desc: "Takes all read, write and execute permissions away from user, group and others for xyz.txt — leaving 0000 (---------).",
    result: "---------",
  },
  {
    cmd: "chmod ug+rw,o-x abc.mp4",
    title: "Two classes at once",
    desc: "Adds read and write to both user and group, and revokes execute from others, for abc.mp4.",
    result: "rw-rw----",
  },
  {
    cmd: "chmod ug=rx,o+r abc.c",
    title: "Assignment with =",
    desc: "Assigns read and execute to both user and group, and adds read for others, on abc.c.",
    result: "r-xr-xr--",
  },
];

/* --- 12 · Octal notation ------------------------------------------ */
export const octalMap = [
  { sym: "r", name: "Read", value: 4 },
  { sym: "w", name: "Write", value: 2 },
  { sym: "x", name: "Execute", value: 1 },
];

export const octalIntro =
  "The octal notation represents a file's permissions using three digits — one each for user, group and other users. The sum of the permissions in each group gives that digit.";

/* --- 13 · Reading a mode ------------------------------------------ */
export const modeReading = [
  {
    bits: "rw-",
    who: "Owner",
    title: "Read + write",
    desc: 'The owner can read it (look at its contents) and write it (modify its contents). It cannot be executed because it is not a program but a text file.',
  },
  {
    bits: "r-x",
    who: "Group",
    title: "Read + execute",
    desc: "The members of the group can only read and execute the file.",
  },
  {
    bits: "r--",
    who: "Others",
    title: "Read only",
    desc: "Anyone else with a UserID on this system can read, but cannot modify or execute the file's contents.",
  },
];

/* --- 14 · Special permissions -------------------------------------- */
export const specialPerms = [
  {
    i: "01",
    name: "setuid — SET User ID",
    cmd: "chmod u+s program",
    octal: "4",
    desc: "Allows a user to execute the program with the privileges of its owner — the classic example is passwd, which must write to /etc/shadow.",
    risk: "RISK · a setuid root binary with a flaw is a privilege-escalation hole.",
  },
  {
    i: "02",
    name: "setgid — Set Group ID",
    cmd: "chmod g+s directoryname",
    octal: "2",
    desc: "Allows files to run under the file's group permissions — or ensures the files created in a directory inherit the group of that directory.",
    risk: "USE · shared project folders where the team group must stick.",
  },
  {
    i: "03",
    name: "sticky bit",
    cmd: "chmod +t directoryname",
    octal: "1",
    desc: "Allows the user (only the owner) to delete or rename files within the directory, regardless of other users' permissions on it.",
    risk: "USE · /tmp — everyone can write, nobody can delete your files.",
  },
];

/* --- 15 · chown ----------------------------------------------------- */
export const ownershipBlocks = [
  {
    tool: "chown",
    desc: "Change file ownership — user, group, or both at once.",
    cmd: "chown user:group file.txt",
    note: "Only root can hand a file to another user; an owner may only change the group, and only to a group they belong to.",
  },
  {
    tool: "chmod",
    desc: "Modify the permission bits of an already-owned file.",
    cmd: "chmod 755 file.txt",
    note: "Any user can chmod their own files — nobody else's.",
  },
];

/* --- 17+ · Knowledge check ----------------------------------------- */
export type Q2 = { q: string; options: string[]; answer: number; why: string };

export const questions2: Q2[] = [
  {
    q: "Which permission set allows a user to read a file but prevents any modification or execution?",
    options: ["rwx", "r--", "--x", "rw-"],
    answer: 1,
    why: "r-- sets the read bit only: the contents can be viewed, but neither written nor executed.",
  },
  {
    q: "Which command adds write permission only for the group, while keeping all other permissions unchanged?",
    options: ["chmod g+w file.txt", "chmod u+w file.txt", "chmod o+w file.txt", "chmod a+w file.txt"],
    answer: 0,
    why: "g targets the group class and + adds write without touching the owner's or others' bits.",
  },
  {
    q: "Which octal number represents this permission set: User = rwx, Group = r-x, Others = r--?",
    options: ["765", "754", "744", "734"],
    answer: 1,
    why: "rwx = 4+2+1 = 7 · r-x = 4+0+1 = 5 · r-- = 4+0+0 = 4 → 754.",
  },
  {
    q: "Which command sets a directory so that new files inherit the directory's group, while keeping default user permissions untouched?",
    options: ["chmod +t project/", "chmod g+s project/", "chmod u+s project/", "chmod 777 project/"],
    answer: 1,
    why: "setgid (g+s) on a directory makes new entries inherit its group. +t is the sticky bit and u+s is setuid.",
  },
  {
    q: "A script must be executable by everyone, but only the owner may modify it, and the directory containing it must allow only the file owner to delete files. Which combination satisfies this?",
    options: [
      "chmod 777 script.sh ; chmod +t dirname",
      "chmod 755 script.sh ; chmod +t dirname",
      "chmod 777 script.sh ; chmod g+s dirname",
      "chmod 744 script.sh ; chmod 777 dirname",
    ],
    answer: 1,
    why: "755 is rwxr-xr-x — executable by all, writable only by the owner; +t adds the sticky bit so only the owner can delete or rename entries.",
  },
];

/* --- Contents ------------------------------------------------------- */
export const contents2: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: [
      "Title",
      "Why permissions matter",
      "The three basic permissions",
      "Ownership & permission groups",
    ],
  },
  {
    section: "The mode string",
    items: ["Operators + − =", "The nine characters", "Reference: u, g, o, a"],
  },
  {
    section: "Inspecting",
    items: ["ls -l", "namei & stat"],
  },
  {
    section: "Changing permissions",
    items: [
      "chmod — symbolic",
      "More symbolic examples",
      "Octal notation",
      "Reading a mode",
      "Special permissions",
      "chown & ownership",
    ],
  },
  {
    section: "Practice",
    items: ["Hands-on simulator"],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Score", "Takeaways"],
  },
];

export const TOTAL2 = 24;
