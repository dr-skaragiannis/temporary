/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 04
   Types of Cyber Attacks
------------------------------------------------------------------ */

export const CH4_TITLE = "Types of Cyber Attacks";

export const ch4Intro =
  "Cyber attacks are malicious attempts to gain unauthorized access to computer systems, networks or data. They are carried out to steal sensitive information, disrupt services or damage digital systems. Understanding these attacks helps organizations and individuals improve cybersecurity and protect critical information.";

export const ch4Bullets = [
  "Performed by hackers, cybercriminal groups or insiders.",
  "Targets computers, networks, websites or databases.",
  "Aims to steal sensitive information, disrupt services or damage data.",
  "Awareness helps strengthen cybersecurity measures.",
];

export const ch4Stamp = "Last Updated : 12 Jun, 2026";

/* --- The eight major attack types ---------------------------------- */
export type Attack = {
  i: string;
  name: string;
  intro: string;
  bullets: string[];
  example: string;
  layer: string;
  vector: string;
};

export const attacks: Attack[] = [
  {
    i: "01",
    name: "Malware Attack",
    intro:
      "Malware refers to malicious software designed to damage, disrupt or gain unauthorized access to computer systems or take control of a system without the user's knowledge.",
    bullets: [
      "Malware is installed through infected files, software downloads or email attachments.",
      "It can steal personal information, passwords or financial data.",
    ],
    example:
      "A Trojan malware hidden inside a cracked software installer steals browser-stored passwords after execution.",
    layer: "Endpoint",
    vector: "Infected files · downloads · attachments",
  },
  {
    i: "02",
    name: "Phishing Attack",
    intro:
      "A phishing attack is a social engineering technique where attackers trick users into revealing sensitive information such as passwords, banking details or login credentials.",
    bullets: [
      "Attackers send fake emails, SMS or messages pretending to be trusted companies.",
      "These messages contain malicious links or attachments.",
      "Victims are redirected to fake websites that look like real login pages.",
    ],
    example:
      "An attacker sends a fake Microsoft 365 login page link to capture employee credentials.",
    layer: "Human",
    vector: "Email · SMS · messaging",
  },
  {
    i: "03",
    name: "Ransomware Attack",
    intro:
      "Ransomware is a type of malware that encrypts a victim's files or locks their computer system. The attacker demands a ransom payment to restore access to the files.",
    bullets: [
      "Usually spreads through phishing emails or malicious downloads.",
      "Files are encrypted so the victim cannot access them.",
    ],
    example:
      "WannaCry ransomware encrypts system files and demands Bitcoin payment for decryption.",
    layer: "Endpoint · Server",
    vector: "Phishing · malicious downloads",
  },
  {
    i: "04",
    name: "Distributed Denial of Service (DDoS) Attack",
    intro:
      "A DDoS attack attempts to make a website or online service unavailable by flooding it with massive traffic from multiple systems.",
    bullets: [
      "Attackers use thousands of infected devices called a botnet.",
      "The botnet sends huge amounts of traffic to a target server.",
      "Legitimate users cannot access the website or service.",
    ],
    example:
      "A botnet floods a web server with millions of HTTP requests, causing service downtime.",
    layer: "Network",
    vector: "Botnet traffic",
  },
  {
    i: "05",
    name: "SQL Injection",
    intro:
      "SQL Injection is a web application attack where attackers insert malicious SQL commands into input fields to manipulate the database.",
    bullets: [
      "Attackers exploit poorly secured input fields.",
      "Allow attackers to view, modify or delete database data.",
      "Sensitive data like usernames and passwords may be exposed.",
    ],
    example:
      "An attacker enters ' OR '1'='1 in a login form to bypass database authentication.",
    layer: "Application",
    vector: "Input fields · forms",
  },
  {
    i: "06",
    name: "Zero-Day Attack",
    intro:
      "A zero-day attack exploits a previously unknown vulnerability in software before developers release a patch or fix.",
    bullets: [
      "Targets undiscovered or unpatched software vulnerabilities.",
      "Developers are unaware of the flaw when the attack occurs.",
      "Security defenses may not detect the attack immediately.",
    ],
    example:
      "Attackers exploit an unpatched browser vulnerability before the vendor releases a security update.",
    layer: "All layers",
    vector: "Unknown vulnerability",
  },
  {
    i: "07",
    name: "Man-in-the-Middle (MITM) Attack",
    intro:
      "A MITM attack occurs when an attacker secretly intercepts communication between two parties. The attacker can monitor, steal or alter the transmitted data.",
    bullets: [
      "Often occurs on unsecured public Wi-Fi networks.",
      "The attacker intercepts data between the user and the server.",
      "Sensitive information such as passwords can be stolen.",
    ],
    example:
      "A hacker intercepts user credentials over an unsecured public Wi-Fi network using packet sniffing.",
    layer: "Network · Transport",
    vector: "Interception · packet sniffing",
  },
  {
    i: "08",
    name: "Password Attack",
    intro:
      "A password attack is when attackers attempt to obtain or crack a user's password to gain unauthorized access to a system or account.",
    bullets: [
      "Attackers use automated tools to guess passwords.",
      "Weak passwords make systems easier to compromise.",
      "Common techniques include brute force and dictionary attacks.",
    ],
    example:
      "A brute-force tool repeatedly tests password combinations to gain unauthorized SSH access.",
    layer: "Identity",
    vector: "Brute force · dictionary",
  },
];

/* --- Five prevention strategies ------------------------------------ */
export type Strategy = {
  i: string;
  name: string;
  desc: string;
  bullets: string[];
  example: string;
  breaks: string[];
};

export const strategies: Strategy[] = [
  {
    i: "01",
    name: "Use Strong Passwords",
    desc: "Avoid using easily guessable information like birthdays or common words. Regularly update passwords and never reuse them across multiple accounts.",
    bullets: [
      "Create complex passwords using a combination of letters, numbers and symbols to make them harder to guess.",
    ],
    example:
      'Instead of using “password123”, use something stronger like “P@ssw0rd!2026”.',
    breaks: ["Password Attack"],
  },
  {
    i: "02",
    name: "Enable Multi-Factor Authentication (MFA)",
    desc: "This ensures that even if a password is compromised, unauthorized access is still prevented.",
    bullets: [
      "MFA adds an extra layer of security by requiring a second verification step in addition to the password.",
    ],
    example:
      "Enter a code sent to your phone along with your password when logging in.",
    breaks: ["Password Attack", "Phishing Attack"],
  },
  {
    i: "03",
    name: "Keep Software Updated",
    desc: "Cybercriminals often exploit outdated software to gain unauthorized access.",
    bullets: [
      "Regularly updating operating systems and applications helps fix security vulnerabilities.",
      "Enable automatic updates wherever possible to stay protected without manual intervention.",
    ],
    example:
      "Install the latest Windows or browser updates to protect against newly discovered security flaws.",
    breaks: ["Zero-Day Attack", "Malware Attack"],
  },
  {
    i: "04",
    name: "Avoid Suspicious Links and Downloads",
    desc: "Phishing emails, fake websites or infected attachments are common ways malware spreads.",
    bullets: [
      "Do not click on unknown links or download files from untrusted sources.",
      "Hover over links to check URLs before clicking and verify the sender's email address.",
    ],
    example:
      "Ignore emails claiming you won a prize and asking you to click a link.",
    breaks: ["Phishing Attack", "Malware Attack", "Ransomware Attack"],
  },
  {
    i: "05",
    name: "Use Antivirus and Firewall Protection",
    desc: "Security software helps protect systems from malware, viruses and unauthorized access attempts. Firewalls monitor incoming and outgoing network traffic to block suspicious activity and prevent attacks.",
    bullets: [
      "Keep antivirus software updated and run regular system scans to maintain protection.",
      "Enable real-time protection features to detect and stop threats instantly while using the system.",
    ],
    example:
      "Antivirus scans downloaded files to prevent infections and alerts you to suspicious activity.",
    breaks: ["Malware Attack", "DDoS Attack", "Password Attack"],
  },
];

/* --- Knowledge check ------------------------------------------------ */
export type Q4 = { q: string; options: string[]; answer: number; why: string };

export const questions4: Q4[] = [
  {
    q: "What is the primary goal of a cyber attack?",
    options: [
      "Speed up internet connections",
      "Steal, damage, or disrupt systems and data",
      "Install new software automatically",
      "Clean infected devices",
    ],
    answer: 1,
    why: "Cyber attacks are carried out to steal sensitive information, disrupt services or damage digital systems.",
  },
  {
    q: "Which attack uses fake emails or messages to steal information?",
    options: ["Phishing", "DDoS attack", "SQL Injection", "Botnet"],
    answer: 0,
    why: "Phishing sends fake emails, SMS or messages that imitate trusted companies to harvest credentials.",
  },
  {
    q: "How do attackers use artificial intelligence in cyberattacks today?",
    options: [
      "To fix security weaknesses",
      "To automate backups",
      "To update software",
      "To create highly personalized phishing and social engineering attacks",
    ],
    answer: 3,
    why: "AI lets attackers tailor lures to a specific target at scale — covered in Chapter 01 · Emerging trends (Rise of AI and Machine Learning).",
  },
  {
    q: "What does ransomware do?",
    options: [
      "Speeds up internet connection",
      "Encrypts files and demands money",
      "Cleans infected files",
      "Updates software automatically",
    ],
    answer: 1,
    why: "Ransomware encrypts the victim's files or locks the system, then demands a ransom payment to restore access.",
  },
  {
    q: "Which cyber attack technique manipulates human psychology to obtain confidential information such as passwords or financial details?",
    options: ["Social engineering", "Packet sniffing", "Port scanning", "Data fragmentation"],
    answer: 0,
    why: "Social engineering manipulates people rather than systems — phishing is its most common form.",
  },
];

/* --- Contents -------------------------------------------------------- */
export const contents4: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "Types of cyber attacks", "Major types — index"],
  },
  {
    section: "The eight attacks",
    items: [
      "Malware & Phishing",
      "Ransomware & DDoS",
      "SQL Injection & Zero-Day",
      "MITM & Password",
      "Attack matrix",
    ],
  },
  {
    section: "Prevention",
    items: [
      "Strategies — index",
      "Strategies 01–03",
      "Strategies 04–05",
      "Defence matrix",
    ],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Score", "Takeaways"],
  },
];

export const TOTAL4 = 20;
