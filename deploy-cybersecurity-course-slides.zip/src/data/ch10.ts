/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 10
   Social Engineering & Cyberstalking
------------------------------------------------------------------ */

export const CH10_TITLE = "Social Engineering & Cyberstalking";
export const ch10Stamp = "Last Updated : 13 Jun, 2026";

/* ================= PART A · SOCIAL ENGINEERING ================= */

export const seIntro =
  "Social engineering is a type of cyber attack where hackers trick people into sharing sensitive information like passwords, bank details, or personal data. Instead of breaking into systems, attackers manipulate human emotions such as trust, fear, or curiosity to gain access.";

export const seBullets = [
  "Targets human psychology instead of technical vulnerabilities.",
  "Used to steal passwords, personal data, or financial information.",
  "Often done through emails, phone calls, messages, or fake websites.",
  "Can lead to data breaches, identity theft, or financial loss.",
];

export const seWorkingLead =
  "Social engineering attacks don't follow a fixed strategy — attackers adapt their tactics to the victim, situation and context — but most attacks share the same six elements.";

export type Phase = {
  i: string;
  name: string;
  label: string;
  desc: string;
  points: { h: string; d: string }[];
  note?: string;
};

export const phases: Phase[] = [
  {
    i: "01",
    name: "Planning and Research",
    label: "RESEARCH",
    desc: "Before launching an attack, the attacker spends time gathering information. This phase is critical to success. Publicly available information is collected through:",
    points: [
      { h: "Social Media", d: "LinkedIn, Facebook or Twitter reveal personal details, job roles, contacts and interests." },
      { h: "Company Websites", d: "Details about employees, company structure and operational processes." },
      { h: "Public Records", d: "Employee directories, email addresses and phone numbers from company sites or government databases." },
    ],
    note: "This information helps the attacker craft a believable, tailored message.",
  },
  {
    i: "02",
    name: "Creating a Convincing Pretext",
    label: "PRETEXT",
    desc: "The attacker develops a pretext — a story designed to gain the trust of the victim.",
    points: [
      { h: "Impersonation", d: "Posing as a company executive, technical support or a trusted colleague to ask for sensitive information or access." },
      { h: "Urgency or Pressure", d: "Claiming immediate action is needed to fix a system issue or resolve an account problem." },
      { h: "Familiarity", d: "Referencing the target's recent social media posts or common connections to seem genuine." },
    ],
    note: "The goal is to exploit the victim's natural tendency to trust familiar sources.",
  },
  {
    i: "03",
    name: "Engaging with the Victim",
    label: "ENGAGE",
    desc: "After the pretext is established, the attacker makes contact. The attack may take different forms:",
    points: [
      { h: "Phishing Emails", d: "A legitimate-looking email asks the victim to click a malicious link, open an infected attachment or supply credentials." },
      { h: "Phone Calls", d: "The attacker pretends to be IT support or a trusted institution and asks for personal or financial information." },
      { h: "SMS Messages", d: "A text mimics a legitimate service and prompts the victim to click a link or provide confidential information." },
    ],
  },
  {
    i: "04",
    name: "Exploiting the Trust",
    label: "EXPLOIT",
    desc: "Once the victim responds, the attacker exploits the trust established through the pretext.",
    points: [
      { h: "Stealing Information", d: "Login credentials, financial information or personal identifiers." },
      { h: "Gaining Unauthorized Access", d: "Tricking the victim into granting access to critical systems, networks or databases." },
      { h: "Installing Malware", d: "Convincing the victim to download malware disguised as legitimate software or documents." },
    ],
  },
  {
    i: "05",
    name: "Taking Advantage of the Information",
    label: "MONETIZE",
    desc: "After obtaining the desired information or access, the attacker can:",
    points: [
      { h: "Perform Financial Fraud", d: "Unauthorized transactions using stolen credentials or data." },
      { h: "Access Sensitive Systems", d: "Move laterally through the network using compromised accounts." },
      { h: "Install Ransomware", d: "Deploy ransomware on critical systems and demand payment for decryption." },
      { h: "Sell Stolen Data", d: "Personal records, intellectual property or financial data sold on the dark web." },
    ],
  },
  {
    i: "06",
    name: "Covering Their Tracks",
    label: "COVER",
    desc: "Social engineers are often skilled at erasing signs of their presence.",
    points: [
      { h: "Delete or Modify Logs", d: "Remove communication logs or traces of malware to avoid detection." },
      { h: "Use Encryption", d: "Encrypt sensitive data to prevent the victim from accessing it or identifying the breach." },
    ],
    note: "This ensures the attacker remains undetected longer, allowing continued exploitation or sale of stolen data.",
  },
];

export type SEType = {
  i: string;
  name: string;
  desc: string;
  vector: string;
  lever: string;
  tone: "phos" | "amber" | "sage";
};

export const seTypes: SEType[] = [
  {
    i: "01",
    name: "Phishing",
    desc: "Sending an email or message that appears to be from a legitimate source, such as a bank, to trick the recipient into revealing login credentials or other sensitive information.",
    vector: "Email · message",
    lever: "Trust · urgency",
    tone: "amber",
  },
  {
    i: "02",
    name: "Baiting",
    desc: "Leaving a tempting item, such as a USB drive, in a public place in the hope that someone will pick it up and plug it into their computer — infecting it with malware.",
    vector: "Physical media · offers",
    lever: "Curiosity · greed",
    tone: "amber",
  },
  {
    i: "03",
    name: "Tailgating",
    desc: "Following an authorized individual into a secure area, such as a building or data center, without proper authorization.",
    vector: "Physical entry",
    lever: "Politeness",
    tone: "phos",
  },
  {
    i: "04",
    name: "Pretexting",
    desc: "Creating a false identity or situation to trick an individual into revealing sensitive information — for example, posing as a customer service representative to obtain login credentials.",
    vector: "Phone · chat · in person",
    lever: "Authority · familiarity",
    tone: "phos",
  },
  {
    i: "05",
    name: "Scareware",
    desc: "Sending false messages claiming the victim's system is infected or outdated and suggesting they download software to fix it. The download gives the attacker access.",
    vector: "Pop-ups · alerts",
    lever: "Fear",
    tone: "sage",
  },
];

export const sePreventionLead =
  "Social engineering attacks rely on manipulating human psychology rather than exploiting technical vulnerabilities, so vigilance matters more than tooling.";

export const sePrevention = [
  {
    i: "01",
    name: "Avoid Suspicious Emails and Attachments",
    desc: "Phishing emails often appear legitimate but contain malicious links or attachments. Be cautious with unsolicited emails, especially those requesting sensitive data or action.",
    steps: [
      "Check the sender's email address carefully.",
      "Avoid clicking on suspicious links or downloading attachments.",
      "Verify requests through alternative channels — call or message the official number.",
    ],
  },
  {
    i: "02",
    name: "Enable Multi-Factor Authentication (MFA)",
    desc: "MFA adds an extra layer of security by requiring more than just a password, reducing the risk of unauthorized access even if your password is compromised.",
    steps: [
      "Enable MFA for critical accounts — email, banking, social media.",
      "Use authentication apps like Google Authenticator.",
      "Enable biometric authentication where possible.",
    ],
  },
  {
    i: "03",
    name: "Beware of Tempting Baits",
    desc: "Attackers use enticing offers to lure victims into clicking malicious links or downloading infected files. Be cautious of 'too good to be true' deals.",
    steps: [
      "Be wary of unsolicited offers, discounts or free downloads.",
      "Avoid unknown links or files from unfamiliar sources.",
      "Always verify the legitimacy of offers before acting.",
    ],
  },
];

export const seImpactLead =
  "Social engineering attacks exploit human behaviour, and the impact of a successful attack can range from financial losses and data breaches to long-term reputational damage.";

export const seImpact = [
  { i: "01", name: "Financial Losses", desc: "Competitors may use social engineering to steal sensitive data such as development plans and marketing strategies, causing direct financial loss." },
  { i: "02", name: "Harm to Goodwill", desc: "Goodwill is essential for attracting customers. Leaking sensitive organizational information damages it." },
  { i: "03", name: "Loss of Privacy", desc: "If an organization cannot protect the privacy of its stakeholders or customers, trust erodes and business relationships end." },
  { i: "04", name: "Dangers of Terrorism", desc: "Terrorists and anti-social elements may use social engineering to build blueprints of their targets — people and property." },
  { i: "05", name: "Lawsuits and Arbitration", desc: "Legal action results in negative publicity and affects business performance." },
  { i: "06", name: "Temporary or Permanent Closure", desc: "Loss of goodwill combined with lawsuits and arbitration may force an organization to close its business activities." },
];

/* ================= PART B · CYBERSTALKING ================= */

export const csIntro =
  "Cyberstalking is the repeated use of digital technology to harass, threaten or monitor someone without consent. It causes fear, distress and emotional harm, exploiting online anonymity and accessibility. Victims often feel constantly watched, which can disrupt daily life and personal safety.";

export const csBullets = [
  "Combines traditional stalking with digital tracking, making it harder to escape.",
  "Can cause severe psychological trauma, including anxiety, depression and physical risk.",
  "Targets all demographics, with women and public figures most at risk.",
  "Difficult for law enforcement due to cross-border jurisdiction and digital evidence collection.",
];

export const csLaw =
  "In the United States, cyberstalking is illegal under both federal and state laws. The primary federal law is 18 U.S.C. § 2261A (Federal Cyberstalking Law), which makes it a crime to use electronic communication such as email, social media or messaging platforms to harass, threaten or stalk someone online.";

export const csConsequences = [
  { i: "01", name: "Legal Consequences", desc: "Victims or authorities can pursue fines, restraining orders or imprisonment for perpetrators under applicable cybercrime laws." },
  { i: "02", name: "Mental Health Impact", desc: "Persistent harassment can cause anxiety, depression, fear and trauma, sometimes leading to extreme actions." },
  { i: "03", name: "Reputational Harm", desc: "Public harassment, false information or doxing can damage personal and professional reputations." },
  { i: "04", name: "Loss of Privacy", desc: "Victims may feel constantly monitored or exposed, impacting their sense of security." },
  { i: "05", name: "Financial Costs", desc: "Legal fees, enhanced security measures or losses from identity theft create significant burdens." },
  { i: "06", name: "Social Withdrawal", desc: "Fear of being targeted may cause victims to isolate themselves or avoid social interactions." },
  { i: "07", name: "Escalation to Physical Threats", desc: "In severe cases, cyberstalking can evolve into real-world harassment or physical harm." },
];

export const csStat = {
  n: "69%",
  text: "of stalking victims experience immense emotional distress. The fear that cyberstalking victims experience is often higher than it is for in-person stalking.",
};

export const csTechniquesLead =
  "Cyberstalkers use a variety of smart and deceptive tactics to monitor, harass and control their victims. These techniques often combine technology with psychological manipulation.";

export const csTechniques = [
  { i: "01", name: "Webcam Hijacking", desc: "Attackers trick users into installing malware that secretly gives access to their webcam. Victims remain unaware while stalkers monitor or record them.", meta: "Malware" },
  { i: "02", name: "Monitoring Social Media Check-ins", desc: "Stalkers track location updates, check-ins and posts shared on social media platforms.", meta: "OSINT" },
  { i: "03", name: "Catfishing (Fake Identity Creation)", desc: "Attackers create fake profiles by impersonating someone trustworthy or known to the victim.", meta: "Deception" },
  { i: "04", name: "Installing Stalkerware", desc: "Secretly installed on a victim's device to track location, messages and activities. It runs in the background without the user's knowledge, giving continuous access to private data.", meta: "Device" },
  { i: "05", name: "Tracking Through Geotags", desc: "Digital photos often contain location data (EXIF metadata) that reveals where the image was taken.", meta: "Metadata" },
];

export const csProtection = [
  { i: "01", name: "Log Out from Shared Devices", desc: "Always sign out after using public or shared computers to prevent unauthorized access to your accounts and personal data." },
  { i: "02", name: "Avoid Sharing Future Plans Online", desc: "Do not post travel plans, live locations or upcoming events publicly — stalkers can misuse this information to track you." },
  { i: "03", name: "Use Strong Passwords & Enable MFA", desc: "Create strong, unique passwords and enable Multi-Factor Authentication to improve account security." },
  { i: "04", name: "Be Careful with Public Wi-Fi", desc: "Avoid accessing banking, email or sensitive accounts on unsecured public Wi-Fi networks." },
  { i: "05", name: "Manage Social Media Privacy Settings", desc: "Limit who can view your posts and personal details by adjusting privacy settings." },
  { i: "06", name: "Monitor Your Online Presence", desc: "Regularly check what information about you is available online and remove unnecessary personal details." },
];

export const csReportingLead =
  "Cyberstalking is a punishable offence under various legal provisions depending on your country or region. Governments and law enforcement agencies provide multiple ways to report such incidents and seek help.";

export const csReporting = [
  { i: "01", name: "Know Your Legal Rights", desc: "Cyberstalking is a punishable cybercrime in many countries." },
  { i: "02", name: "Use Cybercrime Portals", desc: "Report incidents through official government cybercrime websites." },
  { i: "03", name: "Submit Evidence", desc: "Provide screenshots, emails, chat logs or social media messages as proof." },
  { i: "04", name: "Contact Local Police", desc: "Visit the nearest police station for serious threats or harassment." },
  { i: "05", name: "Track Your Complaint", desc: "Follow up regularly and share additional details if needed." },
  { i: "06", name: "Get Emergency Help", desc: "Contact emergency services immediately if you feel unsafe or threatened." },
];

/* --- Knowledge check (Part A: Q1–6 · Part B: Q7–11) ---------------- */
export type Q10 = { q: string; options: string[]; answer: number; why: string; part: "A" | "B" };

export const questions10: Q10[] = [
  {
    part: "A",
    q: "Which of the following best describes social engineering?",
    options: [
      "Exploiting software vulnerabilities using automated tools",
      "Manipulating people to gain confidential information",
      "Breaking encryption using brute force",
      "Scanning networks for open ports",
    ],
    answer: 1,
    why: "Social engineering targets human psychology — trust, fear, curiosity — rather than technical vulnerabilities.",
  },
  {
    part: "A",
    q: "An attacker sends a fake message saying \u201cYou won a free iPhone, click here to claim.\u201d What type of attack is this?",
    options: ["Phishing", "Baiting", "Tailgating", "Pretexting"],
    answer: 1,
    why: "A tempting reward offered to lure the victim into clicking or downloading is baiting — the lever is greed or curiosity.",
  },
  {
    part: "A",
    q: "Which of the following is NOT a common source of information gathering in social engineering?",
    options: ["Social media profiles", "Company websites", "Public records", "Encrypted databases without access"],
    answer: 3,
    why: "Research relies on publicly available sources. An encrypted database the attacker cannot access provides nothing to work with.",
  },
  {
    part: "A",
    q: "An attacker enters a secure office by following an employee who opened the door using an access card. What type of attack is this?",
    options: ["Baiting", "Tailgating", "Phishing", "Scareware"],
    answer: 1,
    why: "Following an authorized person through a controlled door without your own authorization is tailgating.",
  },
  {
    part: "A",
    q: "Which social engineering technique involves building trust using a fake identity or fabricated story?",
    options: ["Exploitation", "Research", "Pretexting", "Covering Tracks"],
    answer: 2,
    why: "Pretexting is the fabricated identity or situation — the story — used to earn the victim's trust.",
  },
  {
    part: "A",
    q: "Which of the following is the least effective way to prevent social engineering attacks?",
    options: [
      "Employee awareness training",
      "Multi-Factor Authentication (MFA)",
      "Ignoring software updates",
      "Verifying requests through official channels",
    ],
    answer: 2,
    why: "Ignoring updates is not a defence at all — it leaves known vulnerabilities open. The other three actively reduce risk.",
  },
  {
    part: "B",
    q: "Which of the following best defines cyberstalking?",
    options: [
      "Accessing a system without permission",
      "Repeated online harassment or monitoring of a person",
      "Sending a single spam email",
      "Posting general content on social media",
    ],
    answer: 1,
    why: "Cyberstalking is the repeated use of digital technology to harass, threaten or monitor someone without consent.",
  },
  {
    part: "B",
    q: "Which of the following actions is NOT typically associated with cyberstalking?",
    options: [
      "Creating fake profiles to interact with a victim",
      "Tracking someone's online activity",
      "Encrypting data to protect privacy",
      "Sending threatening messages",
    ],
    answer: 2,
    why: "Encrypting data to protect privacy is a defensive practice. Fake profiles, tracking and threats are all stalker behaviours.",
  },
  {
    part: "B",
    q: "An attacker creates a fake account pretending to be your friend and gains your trust to collect personal information. What technique is being used?",
    options: ["Brute force attack", "Catfishing", "SQL Injection", "Denial of Service"],
    answer: 1,
    why: "Impersonating someone trustworthy or known to the victim through a fake profile is catfishing.",
  },
  {
    part: "B",
    q: "A victim\u2019s photos uploaded online reveal hidden location data, which a stalker uses to track them. What is the primary vulnerability here?",
    options: ["Weak password", "Metadata leakage (EXIF data)", "Network sniffing", "Firewall misconfiguration"],
    answer: 1,
    why: "Digital photos embed EXIF metadata, including GPS coordinates. Uploading them without stripping that data leaks location.",
  },
  {
    part: "B",
    q: "A user reports being cyberstalked. The attacker uses multiple fake accounts, sends threats, and tracks activity but avoids direct identity exposure. What is the best first response?",
    options: [
      "Ignore the activity completely",
      "Immediately delete all social media accounts",
      "Collect evidence and report to cybercrime authorities",
      "Publicly confront the attacker online",
    ],
    answer: 2,
    why: "Preserve screenshots, messages and logs, then report through official cybercrime channels. Confronting or deleting destroys evidence and can escalate risk.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents10: { section: string; items: string[] }[] = [
  {
    section: "Social engineering",
    items: [
      "Title",
      "What social engineering is",
      "How it works · overview",
      "Research · Pretext · Engage",
      "Exploit · Monetize · Cover",
      "Five attack types",
      "Prevention",
      "Impact on organizations",
    ],
  },
  {
    section: "Cyberstalking",
    items: ["What cyberstalking is", "Consequences", "Stalker techniques", "Protecting yourself", "Reporting"],
  },
  {
    section: "Knowledge check",
    items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Q06", "Q07", "Q08", "Q09", "Q10", "Q11", "Score"],
  },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL10 = 27;
