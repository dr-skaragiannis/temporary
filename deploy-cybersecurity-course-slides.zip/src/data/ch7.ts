/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 07
   Threat Actor
------------------------------------------------------------------ */

export const CH7_TITLE = "Threat Actor";
export const ch7Stamp = "Last Updated : 12 Jun, 2026";

export const ch7Intro =
  "A threat actor is an individual, group or organization that deliberately conducts cyberattacks to exploit system vulnerabilities and achieve specific objectives. Identifying these actors helps organizations anticipate threats and strengthen their overall security posture.";

export const ch7Bullets = [
  "Enables development of targeted threat models based on attacker behavior.",
  "Improves incident investigation and attribution accuracy.",
  "Helps prioritize security tools, training and resources effectively.",
  "Encourages collaboration and intelligence sharing across organizations.",
  "Assists in meeting compliance and risk management requirements.",
];

export const actorsLead =
  "Threat actors exist in many forms. It is important to identify them because each type has different motives, methods and targets.";

/* --- The five threat actor types ------------------------------------ */
export type Actor = {
  i: string;
  key: string;
  name: string;
  short: string;
  motive: string;
  intro: string;
  bullets: string[];
  example: string;
  scale: string;
  tone: "amber" | "phos" | "sage";
};

export const actors: Actor[] = [
  {
    i: "01",
    key: "cybercriminal",
    name: "Cybercriminals",
    short: "Cybercriminal",
    motive: "Financial gain",
    intro:
      "Cybercriminals conduct attacks mainly for financial gain. They operate individually or in organized groups, often using tools and services that make cybercrime easier and more scalable.",
    bullets: [
      "Use ransomware, fraud and data theft to generate profit.",
      "Operate through underground markets to buy/sell stolen data.",
    ],
    example:
      "Ransomware groups like LockBit and Akira targeting organizations for large payments.",
    scale: "Individual → organized group",
    tone: "amber",
  },
  {
    i: "02",
    key: "nation",
    name: "Nation-State Hackers (State-Sponsored Threat Actors)",
    short: "Nation-State",
    motive: "Political · military · economic advantage",
    intro:
      "Nation-state hackers are backed by governments and conduct cyber operations for political, military or economic advantages. They are highly skilled and focus on long-term strategic goals.",
    bullets: [
      "Target critical sectors like energy, defense and telecom.",
      "Use advanced techniques like zero-day exploits and APTs.",
    ],
    example:
      "Groups like APT28 (Fancy Bear) involved in global cyber espionage activities.",
    scale: "Highly skilled · long-term",
    tone: "amber",
  },
  {
    i: "03",
    key: "insider",
    name: "Insider Threats (Individual)",
    short: "Insider",
    motive: "Reuse of trusted access",
    intro:
      "Insider threats come from individuals within an organization who misuse their authorized access. These threats can be intentional or accidental but often go unnoticed initially.",
    bullets: [
      "Use valid credentials to bypass security controls.",
      "Exploit internal systems, cloud services or personal devices.",
    ],
    example:
      "Employees leaking sensitive company data or mishandling confidential information.",
    scale: "Inside the perimeter",
    tone: "phos",
  },
  {
    i: "04",
    key: "hacktivist",
    name: "Hacktivists",
    short: "Hacktivist",
    motive: "Political · social cause",
    intro:
      "Hacktivists use hacking as a tool to promote political or social causes. Their goal is to create awareness, protest or disrupt targeted organizations.",
    bullets: [
      "Launch DDoS attacks or deface websites.",
      "Leak confidential data to expose organizations.",
    ],
    example:
      "Groups targeting government or corporate websites to protest policies.",
    scale: "Loose collectives",
    tone: "sage",
  },
  {
    i: "05",
    key: "terrorist",
    name: "Cyber Terrorists",
    short: "Cyber Terrorist",
    motive: "Fear · large-scale disruption",
    intro:
      "Cyber terrorists aim to create fear and large-scale disruption using cyberattacks. They often target critical infrastructure and essential services.",
    bullets: [
      "Attack systems controlling power, healthcare or transport.",
      "Use destructive malware to cause maximum damage.",
    ],
    example:
      "Attempts to disrupt energy grids or emergency systems to create panic.",
    scale: "Critical infrastructure",
    tone: "amber",
  },
];

/* --- Workflow / Cyber Kill Chain ------------------------------------- */
export const workflowLead =
  "Cyber attacks often follow a structured approach to successfully breach systems and achieve their objectives. One widely used model is the Lockheed Martin Cyber Kill Chain, which breaks down an attack into multiple stages, helping organizations understand and defend against each step.";

export const killChain = [
  {
    i: "01",
    name: "Reconnaissance",
    label: "RECON",
    desc: "Attackers gather information about the target using sources like social media, public records (OSINT) or network scanning tools. This helps identify vulnerabilities and entry points.",
    breaks: "Shrink your footprint — limit OSINT exposure, alert on scanning and enumeration.",
  },
  {
    i: "02",
    name: "Weaponization",
    label: "WEAPONIZE",
    desc: "The attacker creates a malicious payload by combining exploits with malware. This payload is designed to take advantage of identified weaknesses.",
    breaks: "Content disarm and reconstruction, sandboxing, exploit mitigations such as ASLR and DEP.",
  },
  {
    i: "03",
    name: "Delivery",
    label: "DELIVER",
    desc: "The payload is delivered to the target through methods such as phishing emails, malicious attachments, infected websites (drive-by downloads) or USB devices.",
    breaks: "Email and web filtering, attachment sandboxing, USB device control, user awareness.",
  },
  {
    i: "04",
    name: "Exploitation",
    label: "EXPLOIT",
    desc: "A vulnerability in the system is triggered to execute malicious code. This step allows attackers to gain initial access to the system.",
    breaks: "Patch promptly, validate input, disable macros — the countermeasures from Chapter 06.",
  },
  {
    i: "05",
    name: "Installation",
    label: "INSTALL",
    desc: "Malware or backdoors are installed to maintain persistent access. This ensures the attacker can return to the system even after initial entry.",
    breaks: "EDR, application allow-listing, disable unnecessary services and script hosts.",
  },
  {
    i: "06",
    name: "Command and Control (C2)",
    label: "C2",
    desc: "The compromised system establishes communication with the attacker's server. This allows remote control and further instructions to be executed.",
    breaks: "Egress filtering, DNS monitoring, allow-listed destinations — starve the channel.",
  },
  {
    i: "07",
    name: "Actions on Objectives",
    label: "OBJECTIVES",
    desc: "Attackers achieve their goal, such as stealing data, encrypting files (ransomware), disrupting services or maintaining long-term access.",
    breaks: "DLP, encryption, segmentation and tested backups — the difference between an incident and a disaster.",
  },
];

export const killChainNote =
  "Modern attackers often use legitimate system tools (living-off-the-land) to avoid detection. If blocked at any stage, attackers may restart or repeat earlier steps to find alternative entry points.";

/* --- Real-world cases -------------------------------------------------- */
export const cases = [
  {
    tag: "2025",
    title: "Commvault SaaS Platform Exploitation",
    actor: "Unknown · zero-day",
    points: [
      "Attackers exploited a zero-day vulnerability (CVE-2025-3928) in the Commvault Metallic SaaS backup platform.",
      "Gained access to client secrets used for Microsoft 365 backups.",
      "CISA issued advisories urging credential rotation and tighter access controls.",
    ],
    lesson:
      "A backup platform is a high-value pivot: whoever controls the backups controls the recovery.",
  },
  {
    tag: "2025",
    title: "Oracle Cloud Breach by Threat Actor “rose87168”",
    actor: "Named individual actor",
    points: [
      "Hacker claimed to breach Oracle Cloud infrastructure.",
      "Approximately 6 million records and 140,000 tenants affected.",
      "Exploited vulnerability CVE-2021-35587 in Oracle Access Manager.",
      "Oracle denied the breach, but cybersecurity firm CloudSEK validated the leaked data as plausible.",
    ],
    lesson:
      "Disputed incidents are still incidents — attribution takes time and evidence can be contested.",
  },
];

/* --- Detection ---------------------------------------------------------- */
export type Detect = {
  i: string;
  name: string;
  desc: string;
  tools: string[];
  example: string;
};

export const detection: Detect[] = [
  {
    i: "01",
    name: "Monitor Network Traffic",
    desc: "Large data transfers to unknown servers (especially at odd hours) indicate potential attacks.",
    tools: ["Wireshark", "Snort", "Suricata"],
    example:
      "A PC sending data to a foreign IP at 3 AM may signal malware activity.",
  },
  {
    i: "02",
    name: "Check Active Network Connections (netstat)",
    desc: "netstat shows who your computer is communicating with. Unusual or suspicious IP connections may indicate backdoors or malware.",
    tools: ["netstat", "ss", "lsof"],
    example:
      "An established connection to an IP you never visited, from a process you never launched.",
  },
  {
    i: "03",
    name: "Analyze Logs with SIEM Tools",
    desc: "Logs capture logins, errors and system changes. SIEM tools detect abnormal behaviour: multiple failed logins, unauthorized admin privilege changes, Word launching PowerShell (macro malware).",
    tools: ["Splunk", "ELK Stack"],
    example:
      "Five failed logins followed by a successful one from a new country, then a privilege change.",
  },
  {
    i: "04",
    name: "Use EDR (Endpoint Detection and Response)",
    desc: "EDR tools monitor program behaviour, detecting abnormal actions like scripts launching from Word, and identify Indicators of Compromise (IoCs) such as unusual processes or memory use.",
    tools: ["CrowdStrike", "SentinelOne"],
    example:
      "WinWord.exe spawning powershell.exe with an encoded command line.",
  },
  {
    i: "05",
    name: "Monitor User Behaviour",
    desc: "UEBA tools analyze how users typically behave and flag unusual actions — logins from unexpected countries, access to sensitive files never used before.",
    tools: ["UEBA", "Insider-risk analytics"],
    example:
      "A finance user pulling engineering source files they have never opened.",
  },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q7 = { q: string; options: string[]; answer: number; why: string };

export const questions7: Q7[] = [
  {
    q: "What is a threat actor in the context of cybersecurity?",
    options: [
      "A type of anti-virus software",
      "An individual or group that intentionally uses technology to cause harm or steal data",
      "A firewall rule",
      "A type of encryption algorithm",
    ],
    answer: 1,
    why: "A threat actor is an individual, group or organization that deliberately conducts cyberattacks to exploit vulnerabilities for a specific objective.",
  },
  {
    q: "What is the main motive behind most cybercriminal activity?",
    options: [
      "Personal curiosity",
      "Environmental activism",
      "Software updates",
      "Financial gain",
    ],
    answer: 3,
    why: "Cybercriminals attack mainly for financial gain — ransomware, fraud and data theft, often sold through underground markets.",
  },
  {
    q: "Which threat actor is most likely to work for a government and engage in espionage or sabotage?",
    options: [
      "Nation-State Hacker",
      "Script Kiddie",
      "Green Hat Hacker",
      "Red Hat Hacker",
    ],
    answer: 0,
    why: "Nation-state actors are government-backed, highly skilled and pursue long-term political, military or economic advantage.",
  },
  {
    q: "What best describes an insider threat?",
    options: [
      "Only external hackers with advanced skills",
      "Automated malware",
      "IoT devices on the network",
      "A person with trusted access who abuses their position to harm the organization",
    ],
    answer: 3,
    why: "Insider threats come from within — valid credentials are used to bypass controls, which is why they often go unnoticed initially.",
  },
  {
    q: "What tool can help detect if a threat actor has established unusual outbound connections from your computer?",
    options: ["netstat command", "ping command", "ipconfig command", "tasklist command"],
    answer: 0,
    why: "netstat lists active connections and the remote endpoints your machine is talking to — an unfamiliar IP is a red flag.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents7: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What a threat actor is", "Five actor types"],
  },
  {
    section: "Threat actors",
    items: [
      "Cybercriminals · Nation-State",
      "Insider · Hacktivist",
      "Cyber Terrorists",
      "Actor matrix",
    ],
  },
  {
    section: "Attack workflow",
    items: [
      "Workflow — the kill chain",
      "The seven stages",
      "Where to break the chain",
    ],
  },
  {
    section: "Field evidence",
    items: [
      "Real-world cases",
      "Detection methods 01–03",
      "Detection methods 04–05",
    ],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Score", "Takeaways"],
  },
];

export const TOTAL7 = 21;
