/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 13
   Malware and its Types
------------------------------------------------------------------ */

export const CH13_TITLE = "Malware & Its Types";
export const ch13Stamp = "Last Updated : 4 Jun, 2026";

export const ch13Intro =
  "Malware (short for malicious software) is any program designed to harm, exploit or gain unauthorized access to systems, networks or devices. It can disrupt normal operations, steal sensitive data or allow attackers to control systems remotely.";

export const ch13Bullets = [
  "Commonly used in attacks like ransomware, data breaches and system compromise.",
  "Continuously evolves with new variants, making detection challenging.",
  "Can spread across devices and networks, increasing its impact.",
  "Causes significant financial losses worldwide.",
  "Used in advanced attacks such as APTs and cyber espionage.",
];

/* --- Six types ------------------------------------------------------- */
export type MalType = {
  i: string;
  name: string;
  desc: string;
  goal: string;
  spread: string;
  userAction: "Required" | "Not required";
  tone: "phos" | "amber" | "sage";
};

export const malTypes: MalType[] = [
  {
    i: "01",
    name: "Botnets",
    desc: "A network of infected devices controlled by a hacker. The devices are used together to perform attacks like DDoS or sending spam without the owner's knowledge.",
    goal: "Borrowed compute",
    spread: "Via other malware",
    userAction: "Required",
    tone: "phos",
  },
  {
    i: "02",
    name: "Spyware",
    desc: "Malware that secretly monitors user activities. It collects sensitive information like passwords, browsing history and personal data.",
    goal: "Surveillance",
    spread: "Bundled · drive-by",
    userAction: "Required",
    tone: "amber",
  },
  {
    i: "03",
    name: "Adware",
    desc: "Software that shows unwanted advertisements on your system. It may also track your online behaviour to display targeted ads.",
    goal: "Ad revenue",
    spread: "Bundled installs",
    userAction: "Required",
    tone: "sage",
  },
  {
    i: "04",
    name: "Ransomware",
    desc: "Locks or encrypts your files and demands money to unlock them. One of the most dangerous types of malware for individuals and organizations.",
    goal: "Extortion",
    spread: "Phishing · exploits",
    userAction: "Required",
    tone: "amber",
  },
  {
    i: "05",
    name: "Trojan Horse",
    desc: "Malware that looks like legitimate software. Once installed, it allows attackers to access or control the system.",
    goal: "Backdoor access",
    spread: "Disguised download",
    userAction: "Required",
    tone: "amber",
  },
  {
    i: "06",
    name: "Worms",
    desc: "Self-replicating malware that spreads automatically across networks. Worms do not need user action and can slow down systems by consuming resources.",
    goal: "Propagation",
    spread: "Network · self-replicating",
    userAction: "Not required",
    tone: "phos",
  },
];

/* --- Signs of infection ------------------------------------------------ */
export const signs = [
  {
    i: "01",
    name: "Poor System Performance",
    desc: "The device becomes slow and unresponsive. Programs take longer to open, the system may freeze and performance drops because malware uses resources in the background.",
    hint: "Check CPU/memory with nothing open",
  },
  {
    i: "02",
    name: "Browser Redirects",
    desc: "Your browser automatically takes you to a different website than the one you intended. Usually caused by malicious scripts or adware trying to generate traffic or steal data.",
    hint: "Adware · hijacked DNS",
  },
  {
    i: "03",
    name: "Fake Infection Warnings",
    desc: "Pop-ups claim your system is infected and ask you to buy a security tool. These warnings are usually fake and designed to trick users into paying or installing more malware.",
    hint: "Scareware",
  },
  {
    i: "04",
    name: "Startup or Shutdown Problems",
    desc: "Malware interferes with normal operations, causing delays or errors when starting or shutting down. The system may restart automatically or fail to boot properly.",
    hint: "Persistence hooks",
  },
  {
    i: "05",
    name: "Persistent Pop-up Ads",
    desc: "Frequent, unwanted ads appear even when not browsing — a typical sign of adware. These ads can be intrusive and may lead to harmful websites.",
    hint: "Adware",
  },
];

/* --- Purposes ------------------------------------------------------------- */
export const purposes = [
  { i: "01", name: "Identity theft", desc: "Using deception to induce a victim to provide personal information." },
  { i: "02", name: "Financial theft", desc: "Theft of customer credit card information or other financial information." },
  { i: "03", name: "Denial-of-service", desc: "Taking over several computers and using them to launch DoS attacks against other networks." },
  { i: "04", name: "Cryptomining", desc: "Using infected computers to mine for cryptocurrencies like bitcoin." },
];

/* --- Real-world examples --------------------------------------------------- */
export const examples = [
  {
    type: "Ransomware",
    name: "WannaCry",
    year: "2017",
    desc: "A global ransomware attack that exploited a Windows vulnerability to spread rapidly. It encrypted files on hundreds of thousands of systems, severely disrupting hospitals and businesses.",
    tone: "amber" as const,
  },
  {
    type: "Worm",
    name: "Stuxnet",
    year: "2010",
    desc: "A sophisticated worm that targeted industrial control systems. It caused physical damage to nuclear centrifuges, demonstrating how malware can impact real-world infrastructure.",
    tone: "phos" as const,
  },
  {
    type: "Trojan",
    name: "Emotet",
    year: "2014→",
    desc: "Initially a banking Trojan, Emotet evolved into a malware distribution platform widely used to deliver ransomware and other malicious payloads.",
    tone: "amber" as const,
  },
  {
    type: "Spyware",
    name: "Pegasus",
    year: "2016→",
    desc: "Advanced spyware used to monitor targeted individuals such as journalists and officials. It infects mobile devices and extracts sensitive data like messages and calls.",
    tone: "sage" as const,
  },
];

/* --- Protection ------------------------------------------------------------- */
export const protection = [
  { i: "01", vector: "Phishing Emails", desc: "Always verify the sender before opening emails. Avoid clicking suspicious links or attachments. Do not respond to emails asking for personal information." },
  { i: "02", vector: "Malicious Websites", desc: "Browse safely and visit only trusted websites. Avoid unknown links from emails, social media or messages. Use safe search practices." },
  { i: "03", vector: "Unpatched Vulnerabilities", desc: "Keep your operating system and software updated. Install updates and security patches regularly to fix known vulnerabilities." },
  { i: "04", vector: "Infected Removable Media", desc: "Avoid unknown USB drives or external devices. Disable auto-run features and always scan removable media before use." },
  { i: "05", vector: "Use Security Software", desc: "Install and maintain reliable antivirus or anti-malware tools to detect and prevent threats." },
  { i: "06", vector: "Pop-up Safety", desc: "Do not click on pop-up ads or links. Close suspicious pop-ups using the \u201cX\u201d button." },
  { i: "07", vector: "App Installation", desc: "Avoid installing unnecessary applications. Download software only from trusted and official sources." },
];

/* --- Removal steps ------------------------------------------------------------ */
export const removal = [
  { i: "01", name: "Install an anti-malware tool", desc: "Download and install a trusted scanner such as Malwarebytes on your device (Windows, macOS, Android or iOS)." },
  { i: "02", name: "Update malware definitions", desc: "Open the application and update the malware database to ensure detection of the latest threats." },
  { i: "03", name: "Run a full system scan", desc: "Start a manual scan to check processes, files, registry entries and system storage." },
  { i: "04", name: "Review scan results", desc: "Examine the detected threats along with their names and locations." },
  { i: "05", name: "Quarantine threats", desc: "Move suspicious files to quarantine to isolate them and prevent further damage." },
  { i: "06", name: "Remove malware", desc: "Delete or clean quarantined items after confirming they are malicious." },
  { i: "07", name: "Restart the system", desc: "Reboot the device if required to complete the removal process." },
  { i: "08", name: "Verify system security", desc: "Perform another scan or check for unusual behaviour like slow performance or pop-ups." },
];

/* --- Tools ----------------------------------------------------------------------- */
export const tools = [
  { name: "Malwarebytes", platform: "Win · Mac · Android · iOS", desc: "Detects and removes malware, ransomware, spyware and adware. Fast scanning with real-time protection and minimal performance impact." },
  { name: "SUPERAntiSpyware", platform: "Windows", desc: "Focuses on spyware, adware, Trojans and tracking cookies. Especially useful for cleaning heavily infected systems." },
  { name: "Malicious Software Removal Tool (MSRT)", platform: "Windows", desc: "A Microsoft tool that removes common malware. Runs automatically through Windows Update and performs periodic scans." },
  { name: "Bitdefender Antivirus Free", platform: "Windows", desc: "Strong real-time protection against viruses and online threats. Lightweight, easy to use, detects malicious activity automatically." },
  { name: "Adaware Antivirus Free", platform: "Windows", desc: "Protects against malware, spyware and phishing. Real-time protection with a simple, user-friendly interface." },
  { name: "Avast Free Mac Security", platform: "macOS", desc: "Designed for Mac to detect malware and web-based threats. Real-time scanning with email and web protection." },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q13 = { q: string; options: string[]; answer: number; why: string };

export const questions13: Q13[] = [
  {
    q: "Which of the following is a type of malware that encrypts files and demands payment for decryption?",
    options: ["Spyware", "Ransomware", "Adware", "Worm"],
    answer: 1,
    why: "Ransomware locks or encrypts files and demands money to unlock them — WannaCry is the textbook case.",
  },
  {
    q: "What type of malware replicates itself and spreads through networks without needing a host program?",
    options: ["Virus", "Worm", "Trojan horse", "Logic bomb"],
    answer: 1,
    why: "Worms are self-replicating and spread automatically across networks with no user action or host program — unlike a virus, which needs a host file.",
  },
  {
    q: "Which type of malware disguises itself as a legitimate application or file?",
    options: ["Virus", "Trojan horse", "Ransomware", "Keylogger"],
    answer: 1,
    why: "A Trojan Horse looks like legitimate software; once installed it gives attackers access to or control of the system.",
  },
  {
    q: "What is a common sign that a device may be infected with malware?",
    options: ["Slow system performance", "Unexpected browser redirects", "Improved system updates", "Random application crashes"],
    answer: 0,
    why: "Poor system performance is the first and most common indicator — malware consumes resources in the background. Browser redirects are also a sign, but slowness is the primary one listed.",
  },
  {
    q: "Which of the following is a method to protect against malware?",
    options: ["Ignoring software updates", "Running reputable antivirus software", "Clicking on unknown links", "Disabling firewalls"],
    answer: 1,
    why: "Reliable antivirus / anti-malware software detects and prevents threats. The other three options are exactly the behaviours that invite infection.",
  },
  {
    q: "What is the purpose of a keylogger?",
    options: ["To enhance system performance", "To record user keystrokes", "To monitor internet speed", "To encrypt files"],
    answer: 1,
    why: "A keylogger is a form of spyware that records every keystroke — capturing passwords, messages and card numbers as they are typed.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents13: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What malware is", "Six types", "Type comparison"],
  },
  {
    section: "Recognise",
    items: ["Signs of infection", "Purpose of attacks", "Real-world examples"],
  },
  {
    section: "Defend & recover",
    items: ["Protection", "Removal steps", "Removal tools"],
  },
  {
    section: "Knowledge check",
    items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Q06", "Score"],
  },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL13 = 19;
