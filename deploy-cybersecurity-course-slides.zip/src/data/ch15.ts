/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 15
   Identity Theft in Cyber Crime
------------------------------------------------------------------ */

export const CH15_TITLE = "Identity Theft";
export const ch15Stamp = "Last Updated : 4 Jun, 2026";

export const ch15Intro =
  "Identity theft is a cybercrime where an attacker steals and misuses a person's personal, financial or identity information without permission. This data is often used for fraud, impersonation or other illegal activities. With growing digital dependence, such attacks are becoming more frequent and can result in financial loss, legal trouble and reputational damage.";

export const ch15Bullets = [
  "Targets sensitive data such as Aadhaar, PAN, bank accounts and login credentials.",
  "Common methods include phishing, malware and data breaches.",
  "Can lead to unauthorized transactions and misuse of identity.",
  "Early detection and prompt action can significantly reduce the impact.",
];

export const ch15Example =
  "Attackers may steal credit card data from a compromised database and use it to make unauthorized purchases or apply for loans in the victim's name. This can negatively impact the victim's financial standing and credit history.";

/* --- Eight types ------------------------------------------------------ */
export type IdType = {
  i: string;
  name: string;
  desc: string;
  points: string[];
  asset: string;
  discovered: string;
  tone: "phos" | "amber" | "sage";
};

export const idTypes: IdType[] = [
  {
    i: "01",
    name: "Criminal Identity Theft",
    desc: "Someone uses another person's identity to commit crimes.",
    points: ["Victim is held responsible for illegal activities.", "Criminal uses stolen ID or verification documents.", "May lead to serious legal consequences for the victim."],
    asset: "ID documents",
    discovered: "Police contact · court notice",
    tone: "amber",
  },
  {
    i: "02",
    name: "Senior Identity Theft",
    desc: "Attackers mainly target elderly people to steal their personal information.",
    points: ["Seniors are tricked through fake calls or messages.", "Personal and financial data is collected.", "Often results in fraud or financial loss."],
    asset: "Personal & financial data",
    discovered: "Family notices · bank alert",
    tone: "phos",
  },
  {
    i: "03",
    name: "Driver's License Identity Theft",
    desc: "Misuse of driving licence details for fraudulent purposes.",
    points: ["Includes name, address and licence number misuse.", "Used to apply for loans or open accounts.", "Purchases are made in the victim's name."],
    asset: "Licence number",
    discovered: "Unknown accounts · debt letters",
    tone: "phos",
  },
  {
    i: "04",
    name: "Medical Identity Theft",
    desc: "Someone uses another person's health information.",
    points: ["Health records and insurance details are stolen.", "Fake treatments and claims are created.", "Victim may receive false medical bills."],
    asset: "Health records · insurance",
    discovered: "Bills for treatment never received",
    tone: "sage",
  },
  {
    i: "05",
    name: "Tax Identity Theft",
    desc: "Personal information is used to commit tax-related fraud.",
    points: ["Fake tax returns are filed to claim refunds.", "Attacker uses sensitive financial details.", "Victim discovers the issue during tax filing."],
    asset: "Tax ID · financial details",
    discovered: "Return rejected as duplicate",
    tone: "sage",
  },
  {
    i: "06",
    name: "Social Security Identity Theft",
    desc: "Stealing a person's Social Security Number (SSN).",
    points: ["Used to access personal and financial records.", "Can lead to identity misuse and fraud.", "Creates long-term security risks."],
    asset: "SSN",
    discovered: "Credit report anomalies",
    tone: "amber",
  },
  {
    i: "07",
    name: "Synthetic Identity Theft",
    desc: "Real and fake information are combined into a new identity.",
    points: ["A new fake identity is created.", "Used for illegal financial activities.", "Difficult to detect in early stages."],
    asset: "Fragments of real data",
    discovered: "Often years later",
    tone: "amber",
  },
  {
    i: "08",
    name: "Financial Identity Theft",
    desc: "Stolen financial information is used for monetary gain.",
    points: ["Includes unauthorized transactions and purchases.", "Bank or card details are misused.", "Victim notices after checking account activity."],
    asset: "Bank · card details",
    discovered: "Statement review",
    tone: "phos",
  },
];

/* --- Techniques ------------------------------------------------------------ */
export const techniques = [
  {
    i: "01",
    name: "Pretext Calling",
    points: ["Attackers pretend to be bank or company officials and call victims to gain trust.", "They convince users to share personal or financial details using polite or urgent requests."],
    channel: "Phone",
    physical: false,
  },
  {
    i: "02",
    name: "Mail Theft",
    points: ["Credit card details and transaction records are stolen from mailboxes.", "Attackers target public or unsecured mail to collect important documents."],
    channel: "Physical",
    physical: true,
  },
  {
    i: "03",
    name: "Phishing",
    points: ["Fake emails are sent pretending to be from trusted organizations like banks.", "These emails contain malicious links or attachments to steal user information."],
    channel: "Email",
    physical: false,
  },
  {
    i: "04",
    name: "Internet-Based Theft",
    points: ["Attackers create fake or unsecured networks to trap users online.", "Users unknowingly install spyware or malware through downloads or websites."],
    channel: "Network · web",
    physical: false,
  },
  {
    i: "05",
    name: "Dumpster Diving",
    points: ["Attackers search garbage to find documents containing personal or financial data.", "Happens when important papers are not properly destroyed before disposal."],
    channel: "Physical",
    physical: true,
  },
  {
    i: "06",
    name: "CVV Code Requests",
    points: ["Attackers pretend to be bank officials and ask for CVV details.", "This information is used to perform unauthorized online transactions."],
    channel: "Phone · message",
    physical: false,
  },
];

export const techniquesLead =
  "Identity thieves usually hack into corporate databases for personal credentials, which requires effort — but with social-engineering techniques it becomes easy.";

/* --- Prevention ---------------------------------------------------------------- */
export const prevention = [
  { i: "01", name: "Use strong, unique passwords", desc: "Avoid simple passwords; use a mix of letters, numbers and symbols.", group: "Accounts" },
  { i: "02", name: "Enable two-factor authentication", desc: "Add an extra layer of security with OTPs or authentication apps.", group: "Accounts" },
  { i: "03", name: "Secure your devices", desc: "Use PINs, passwords or biometrics (fingerprint / face lock).", group: "Devices" },
  { i: "04", name: "Avoid untrusted software and websites", desc: "Don't download cracked apps or click on suspicious links.", group: "Devices" },
  { i: "05", name: "Limit sharing of personal information", desc: "Avoid sharing Aadhaar, PAN or bank info online, over calls/messages or with untrusted sources.", group: "Data" },
  { i: "06", name: "Verify website authenticity", desc: "Check for https:// and trusted sources before entering personal or payment details.", group: "Data" },
  { i: "07", name: "Handle documents carefully", desc: "Carry only necessary ID; share copies only when required and with trusted entities.", group: "Documents" },
  { i: "08", name: "Manage passwords regularly", desc: "Update passwords periodically and avoid reusing them.", group: "Accounts" },
  { i: "09", name: "Never share OTPs", desc: "Do not disclose OTPs, even to someone claiming to be from a bank or service provider.", group: "Behaviour" },
  { i: "10", name: "Watch for suspicious activity", desc: "Ignore unexpected OTPs, emails or messages asking for personal information.", group: "Behaviour" },
  { i: "11", name: "Avoid scams and fake offers", desc: "Stay away from deals or rewards that seem too good to be true.", group: "Behaviour" },
  { i: "12", name: "Maintain privacy on social media", desc: "Keep accounts private and limit publicly visible information.", group: "Data" },
  { i: "13", name: "Stay informed about cyber threats", desc: "Keep learning about scams like phishing to stay alert.", group: "Behaviour" },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q15 = { q: string; options: string[]; answer: number; why: string };

export const questions15: Q15[] = [
  {
    q: "Which of the following best describes identity theft?",
    options: ["Stealing only bank passwords", "Using someone's personal data without permission", "Hacking only government websites", "Sending spam emails"],
    answer: 1,
    why: "Identity theft is the theft and misuse of a person's personal, financial or identity information without permission — passwords are only one part of it.",
  },
  {
    q: "Which situation is an example of phishing?",
    options: ["A hacker steals data from garbage", "You receive an email asking to verify bank details via link", "Someone steals your wallet physically", "A website crashes due to traffic"],
    answer: 1,
    why: "A fake email from a 'trusted' organisation with a link to enter your details is textbook phishing. Garbage search is dumpster diving.",
  },
  {
    q: "You receive a call from someone claiming to be a bank official asking for OTP. What type of attack is this?",
    options: ["Phishing", "Smishing", "Dumpster Diving", "Vishing"],
    answer: 3,
    why: "Voice phishing — vishing — is phishing over a phone call. It is the same thing as pretext calling in this chapter's technique list.",
  },
  {
    q: "An attacker uses your driving license details to open a bank account. This is:",
    options: ["Financial Identity Theft", "Synthetic Identity Theft", "Driver's License Identity Theft", "Medical Identity Theft"],
    answer: 2,
    why: "The stolen asset defines the type: misuse of licence details to open accounts or apply for loans is Driver's License Identity Theft.",
  },
  {
    q: "A hacker combines real Aadhaar data with fake details to create a new identity and commits fraud. What type is this?",
    options: ["Criminal Identity Theft", "Social Security Identity Theft", "Tax Identity Theft", "Synthetic Identity Theft"],
    answer: 3,
    why: "Combining real and fabricated information into a brand-new identity is synthetic identity theft — hard to detect because the identity never belonged to anyone.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents15: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What identity theft is"] },
  { section: "Types", items: ["Eight types · overview", "Types 01–04", "Types 05–08", "Asset & discovery matrix"] },
  { section: "Methods & defence", items: ["Techniques", "Prevention"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL15 = 16;
