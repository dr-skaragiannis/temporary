/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 08
   Careers: Salary Trends, Market Overview & Roadmap
------------------------------------------------------------------ */

export const CH8_TITLE = "Careers & Roadmap";
export const ch8Stamp = "Last Updated : 13 Jun, 2026";

export const ch8Intro =
  "Cybersecurity has become one of the highest-paying and fastest-growing technology careers worldwide. As organizations continue adopting cloud computing, AI, remote work and digital infrastructure, the demand for skilled cybersecurity professionals keeps increasing rapidly.";

export const headline = [
  { k: "Average US salary", v: "$130–136k", sub: "per year" },
  { k: "Entry-level range", v: "$65–85k", sub: "annually" },
  { k: "Market size · 2025", v: "$301.9B", sub: "valued" },
  { k: "Market size · 2034", v: "$878.5B", sub: "projected · 12.6% CAGR" },
  { k: "Unfilled positions", v: "4.8M", sub: "globally" },
];

/* --- Salary factors ----------------------------------------------- */
export const factorsLead =
  "Several important factors directly affect cybersecurity salaries:";

export const factors = [
  {
    i: "01",
    name: "Experience",
    desc: "Experienced professionals earn higher salaries due to advanced technical expertise and incident-handling capabilities.",
    meta: "Seniority",
  },
  {
    i: "02",
    name: "Certifications",
    desc: "Certifications like CISSP, OSCP, CEH, CISM and Security+ significantly improve salary potential.",
    meta: "Credentials",
  },
  {
    i: "03",
    name: "Technical Skills",
    desc: "Cloud security, Kubernetes, AWS security, penetration testing and threat hunting currently command higher salaries.",
    meta: "In-demand stack",
  },
  {
    i: "04",
    name: "Industry",
    desc: "Finance, healthcare, defense and cloud computing sectors usually offer higher compensation packages.",
    meta: "Sector",
  },
  {
    i: "05",
    name: "Location",
    desc: "Major technology hubs and remote US-based roles often provide higher salary ranges.",
    meta: "Geography",
  },
];

/* --- Job roles ------------------------------------------------------ */
export type Role = { role: string; lo: number; hi: number; plus?: boolean };

export const roles: Role[] = [
  { role: "Cybersecurity Analyst", lo: 75, hi: 120 },
  { role: "Network Security Engineer", lo: 90, hi: 140 },
  { role: "Penetration Tester", lo: 100, hi: 160 },
  { role: "Cloud Security Engineer", lo: 120, hi: 190 },
  { role: "Security Architect", lo: 150, hi: 220 },
  { role: "Cybersecurity Manager", lo: 130, hi: 200 },
  { role: "CISO", lo: 220, hi: 420, plus: true },
];

/* --- Market outlook -------------------------------------------------- */
export const marketLead =
  "The cybersecurity industry is growing rapidly because organizations are continuously facing ransomware, phishing, AI-driven attacks and cloud security risks.";

export const marketBullets = [
  "The cybersecurity market was valued at approximately USD 301.9 billion in 2025.",
  "It is expected to grow to nearly USD 878.5 billion by 2034 with a CAGR of around 12.6%.",
  "Around 4.8 million cybersecurity positions remain unfilled globally, increasing salary demand for skilled professionals.",
];

export const driversLead =
  "Cybersecurity is no longer optional, it's a strategic priority. Organizations across all industries must invest continuously in security solutions, making the field one of the fastest-growing segments in global IT markets.";

export const drivers = [
  {
    i: "01",
    name: "Rising Cyber Threats",
    desc: "Ransomware, phishing attacks, credential theft and AI-powered malware continue to increase globally.",
  },
  {
    i: "02",
    name: "Cloud & Digital Transformation",
    desc: "Businesses are rapidly adopting cloud computing, IoT devices, remote work systems and AI infrastructure, creating larger attack surfaces.",
  },
  {
    i: "03",
    name: "Compliance & Data Protection",
    desc: "Organizations must comply with strict security standards and data privacy regulations, increasing cybersecurity investments.",
  },
];

/* --- Companies -------------------------------------------------------- */
export const companiesLead =
  "Major technology and consulting companies actively recruit cybersecurity professionals worldwide.";

export const companies: Role[] = [
  { role: "Microsoft", lo: 120, hi: 220 },
  { role: "Google", lo: 140, hi: 280 },
  { role: "Amazon", lo: 130, hi: 250 },
  { role: "IBM", lo: 90, hi: 150 },
  { role: "Deloitte", lo: 90, hi: 170 },
  { role: "Accenture", lo: 85, hi: 160 },
];

/* --- Skills ------------------------------------------------------------ */
export const skills = [
  {
    i: "01",
    name: "Network Security",
    desc: "Knowledge of firewalls, IDS/IPS, VPNs and network protocols for securing enterprise infrastructure.",
  },
  {
    i: "02",
    name: "Cloud Security",
    desc: "Understanding AWS, Azure, Kubernetes and cloud identity management systems.",
  },
  {
    i: "03",
    name: "Penetration Testing",
    desc: "Ability to identify vulnerabilities using tools like Metasploit, Burp Suite and Nmap.",
  },
  {
    i: "04",
    name: "Threat Detection & Incident Response",
    desc: "Skills in SIEM platforms, log analysis, malware analysis and threat intelligence.",
  },
  {
    i: "05",
    name: "Cryptography",
    desc: "Knowledge of encryption algorithms, PKI, SSL/TLS and secure communication techniques.",
  },
  {
    i: "06",
    name: "Scripting & Automation",
    desc: "Experience with Python, Bash and PowerShell for security automation and threat analysis.",
  },
  {
    i: "07",
    name: "Continuous Learning",
    desc: "Cybersecurity professionals must stay updated with emerging threats, attack techniques and new security technologies.",
  },
];

/* --- Roadmap ------------------------------------------------------------ */
export const roadmapLead =
  "Cyber Security is the practice of protecting computer systems, networks, applications and data from cyber threats and unauthorized access. The roadmap begins with computer and networking fundamentals, then moves toward security concepts, ethical hacking, system protection and real-world cybersecurity practices.";

export type Stage = {
  i: string;
  name: string;
  lead: string;
  groups: { h: string; items: string[] }[];
  tone: "phos" | "amber" | "sage";
};

export const roadmap: Stage[] = [
  {
    i: "01",
    name: "Foundations",
    lead: "Before learning advanced cybersecurity concepts, learners should first understand how computers, operating systems and networks work.",
    tone: "sage",
    groups: [
      {
        h: "Computer Fundamentals",
        items: [
          "Hardware Basics: CPU, RAM, storage, motherboard",
          "Operating Systems: Windows and Linux basics",
          "File Systems, Processes and Services",
        ],
      },
      {
        h: "Linux & Command Line",
        items: [
          "Linux Terminal Basics",
          "File and Directory Commands",
          "User Permissions & Access Control",
          "Process Management",
          "Basic Shell Scripting",
        ],
      },
    ],
  },
  {
    i: "02",
    name: "Networking Fundamentals",
    lead: "Networking knowledge is essential because cyberattacks usually target communication between systems.",
    tone: "sage",
    groups: [
      {
        h: "Core Concepts",
        items: [
          "IP Addressing and Subnetting",
          "DNS and DHCP",
          "TCP/IP Model",
          "Ports and Protocols",
          "Routing and Switching",
        ],
      },
      {
        h: "Network Security",
        items: ["Firewalls and VPNs", "Packet Analysis", "IDS and Secure Communication"],
      },
    ],
  },
  {
    i: "03",
    name: "Security Fundamentals",
    lead: "After learning system and networking basics, the next step is understanding core cybersecurity principles.",
    tone: "phos",
    groups: [
      {
        h: "Important Security Concepts",
        items: [
          "CIA Triad (Confidentiality, Integrity, Availability)",
          "Authentication and Authorization",
          "Multi-Factor Authentication (MFA)",
          "Risk Management",
          "Security Policies",
        ],
      },
      {
        h: "Cryptography Basics",
        items: [
          "Encryption and Decryption",
          "Hashing Algorithms",
          "Digital Signatures",
          "Public Key Infrastructure (PKI)",
        ],
      },
    ],
  },
  {
    i: "04",
    name: "Programming Basics",
    lead: "Basic programming knowledge helps cybersecurity professionals automate tasks and analyze vulnerabilities.",
    tone: "phos",
    groups: [
      {
        h: "Languages Commonly Used",
        items: ["Python", "Bash Scripting", "C/C++ and JavaScript Basics"],
      },
      {
        h: "Concepts",
        items: ["Variables, Loops, Functions", "File Handling", "Networking Scripts"],
      },
    ],
  },
  {
    i: "05",
    name: "Ethical Hacking",
    lead: "Ethical hacking focuses on identifying vulnerabilities before attackers exploit them.",
    tone: "amber",
    groups: [
      {
        h: "Techniques",
        items: [
          "Footprinting and Reconnaissance",
          "Vulnerability Scanning",
          "Web Application Testing",
          "Password Cracking",
          "Exploitation Basics",
        ],
      },
      {
        h: "Common Tools",
        items: ["Nmap", "Metasploit", "Burp Suite", "Wireshark", "John the Ripper"],
      },
    ],
  },
  {
    i: "06",
    name: "Web Security",
    lead: "Web applications are common targets for cyberattacks, making web security an important area.",
    tone: "amber",
    groups: [
      {
        h: "Vulnerability Classes",
        items: [
          "SQL Injection",
          "Cross-Site Scripting (XSS)",
          "Cross-Site Request Forgery (CSRF)",
          "Authentication Vulnerabilities",
          "Secure Coding Practices",
        ],
      },
    ],
  },
  {
    i: "07",
    name: "System Security",
    lead: "System security focuses on protecting operating systems and devices from threats.",
    tone: "amber",
    groups: [
      {
        h: "Focus Areas",
        items: [
          "Windows Security",
          "Linux Hardening",
          "Endpoint Protection",
          "Malware Analysis Basics",
          "Log Monitoring",
        ],
      },
    ],
  },
  {
    i: "08",
    name: "Cloud and Modern Security",
    lead: "Modern organizations heavily depend on cloud platforms and online infrastructure.",
    tone: "phos",
    groups: [
      {
        h: "Cloud Security",
        items: [
          "AWS Security Fundamentals",
          "Azure Security Basics",
          "Identity and Access Management (IAM)",
          "Secure Cloud Storage",
          "Cloud Monitoring",
        ],
      },
      {
        h: "Modern Concepts",
        items: ["Zero Trust Security", "DevSecOps Basics", "Container Security", "API Security"],
      },
    ],
  },
  {
    i: "09",
    name: "Security Operations & Incident Response",
    lead: "Cybersecurity professionals must know how to detect and respond to attacks.",
    tone: "phos",
    groups: [
      {
        h: "Capabilities",
        items: [
          "Threat Monitoring",
          "SIEM Tools",
          "Incident Response Process",
          "Digital Forensics Basics",
          "Threat Intelligence",
        ],
      },
    ],
  },
  {
    i: "10",
    name: "Version Control & Collaboration",
    lead: "Cybersecurity professionals often work in teams and manage scripts or security tools. Version control helps track code changes and collaborate efficiently.",
    tone: "sage",
    groups: [{ h: "Tools", items: ["Git", "GitHub", "GitLab"] }],
  },
];

/* --- Certifications ------------------------------------------------------ */
export const certsLead =
  "Certifications help validate cybersecurity knowledge and improve job opportunities.";

export const certs = [
  {
    level: "Beginner",
    tone: "sage" as const,
    items: [
      "CompTIA Security+",
      "Google Cybersecurity Certificate",
      "Cisco Certified CyberOps Associate",
    ],
  },
  {
    level: "Intermediate",
    tone: "phos" as const,
    items: ["CEH (Certified Ethical Hacker)", "CompTIA CySA+", "PNPT"],
  },
  {
    level: "Advanced",
    tone: "amber" as const,
    items: ["CISSP", "OSCP", "CISM"],
  },
];

/* --- Practice -------------------------------------------------------------- */
export const practiceLead =
  "Practical experience is one of the most important parts of learning cybersecurity.";

export const projects = [
  "Password Strength Checker",
  "Port Scanner",
  "Packet Sniffer",
  "Simple Keylogger Simulation",
  "Vulnerability Scanner",
];

export const platforms = ["TryHackMe", "Hack The Box", "OverTheWire", "PicoCTF"];

export const careerPaths = [
  "Security Analyst",
  "Ethical Hacker",
  "Penetration Tester",
  "SOC Analyst",
  "Security Engineer",
  "Cloud Security Engineer",
  "Digital Forensics Analyst",
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q8 = { q: string; options: string[]; answer: number; why: string };

export const questions8: Q8[] = [
  {
    q: "Approximately what is the average cybersecurity salary in the United States?",
    options: [
      "USD 65,000 – 85,000 per year",
      "USD 130,000 – 136,000 per year",
      "USD 220,000 – 420,000 per year",
      "USD 301,900 per year",
    ],
    answer: 1,
    why: "The average US cybersecurity salary is around USD 130,000–136,000. The USD 65–85k band is the entry-level range and USD 220–420k+ is the CISO band.",
  },
  {
    q: "The global cybersecurity market is projected to reach roughly what value by 2034?",
    options: ["USD 4.8 billion", "USD 301.9 billion", "USD 878.5 billion", "USD 12.6 trillion"],
    answer: 2,
    why: "From about USD 301.9 billion in 2025 the market is expected to grow to nearly USD 878.5 billion by 2034, a CAGR of around 12.6%.",
  },
  {
    q: "Which of the following job roles has the highest typical salary range?",
    options: [
      "Cybersecurity Analyst",
      "Penetration Tester",
      "Security Architect",
      "Chief Information Security Officer (CISO)",
    ],
    answer: 3,
    why: "CISO roles range from USD 220,000 to 420,000+, above Security Architect (150–220k), Penetration Tester (100–160k) and Analyst (75–120k).",
  },
  {
    q: "In the learning roadmap, which stage should come first?",
    options: [
      "Ethical hacking with Metasploit and Burp Suite",
      "Computer, Linux and networking fundamentals",
      "Cloud security and Zero Trust",
      "Digital forensics and threat intelligence",
    ],
    answer: 1,
    why: "The roadmap begins with computer and networking fundamentals before moving to security concepts, ethical hacking, system protection and real-world practice.",
  },
  {
    q: "Which certification group is classed as Advanced in the roadmap?",
    options: [
      "CompTIA Security+, Google Cybersecurity Certificate, Cisco CyberOps Associate",
      "CEH, CompTIA CySA+, PNPT",
      "CISSP, OSCP, CISM",
      "Git, GitHub, GitLab",
    ],
    answer: 2,
    why: "CISSP, OSCP and CISM are the advanced tier. Security+, Google and Cisco CyberOps are beginner; CEH, CySA+ and PNPT are intermediate. Git tools are version control, not certifications.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents8: { section: string; items: string[] }[] = [
  {
    section: "Market",
    items: ["Title", "Market at a glance", "Salary factors", "Job roles & pay"],
  },
  {
    section: "Outlook",
    items: ["Growth drivers", "Top employers", "Top skills"],
  },
  {
    section: "Roadmap",
    items: [
      "Roadmap overview",
      "Foundations · Networking",
      "Security · Programming",
      "Hacking · Web · System",
      "Cloud · SecOps · Git",
      "Certifications & practice",
    ],
  },
  {
    section: "Knowledge check",
    items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"],
  },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL8 = 21;
