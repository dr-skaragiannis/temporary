/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 05
   Hackers and Their Types
------------------------------------------------------------------ */

export const CH5_TITLE = "Hackers and Their Types";
export const ch5Stamp = "Last Updated : 12 Jun, 2026";

export const ch5Intro =
  "Hackers are individuals who exploit technical skills to access computer systems or networks, either to cause harm or to strengthen security. Recognizing different hacker types and their methods is key to safeguarding data and systems.";

export const ch5Bullets = [
  "Exploit vulnerabilities in devices, networks and online accounts.",
  "Can cause financial loss, data theft and privacy breaches.",
  "Include ethical hackers who help improve organizational security.",
  "Target weakly secured systems for unauthorized access.",
];

export const primaryLead =
  "Hackers can target systems for various reasons, such as stealing money, accessing confidential data, showcasing technical skills or collecting intelligence. They are commonly categorized into three main types.";

/* --- The three primary hats ---------------------------------------- */
export type Hat = {
  key: string;
  name: string;
  short: string;
  intro: string;
  bullets: string[];
  example: string;
  authorized: string;
  legal: string;
  intent: string;
  x: number;
  y: number;
  tone: "phos" | "amber" | "sage";
};

export const hats: Hat[] = [
  {
    key: "black",
    name: "Black Hat Hackers",
    short: "Black Hat",
    intro:
      "Black hat hackers are malicious individuals who break into systems to steal information, damage networks or gain financial benefits.",
    bullets: [
      "Carry out illegal hacking activities.",
      "Exploit vulnerabilities for personal profit or reputation.",
    ],
    example:
      "A hacker deploys ransomware to encrypt company servers and demand Bitcoin payment.",
    authorized: "No",
    legal: "No — criminal",
    intent: "Profit · damage · notoriety",
    x: 0.09,
    y: 0.13,
    tone: "amber",
  },
  {
    key: "white",
    name: "White Hat Hackers",
    short: "White Hat",
    intro:
      "White hat hackers, also known as ethical hackers, use their hacking skills to help organizations improve cybersecurity by identifying vulnerabilities before attackers can exploit them.",
    bullets: [
      "Work legally and ethically to improve security.",
      "Perform penetration testing and security assessments.",
    ],
    example:
      "An ethical hacker uses penetration testing tools like Metasploit to detect security flaws in a web application.",
    authorized: "Yes — in writing",
    legal: "Yes — protected",
    intent: "Find flaws before criminals do",
    x: 0.87,
    y: 0.88,
    tone: "phos",
  },
  {
    key: "gray",
    name: "Gray Hat Hackers",
    short: "Gray Hat",
    intro:
      "Gray hat hackers operate between ethical and malicious hacking. They may access systems without permission but usually do not intend to cause harm.",
    bullets: [
      "May break rules but usually report discovered vulnerabilities.",
      "Often reveal security flaws publicly to raise awareness.",
    ],
    example:
      "A hacker discovers an exposed database online and privately reports the vulnerability to the organization.",
    authorized: "No — but discloses",
    legal: "Ambiguous",
    intent: "Recognition · curiosity",
    x: 0.36,
    y: 0.57,
    tone: "sage",
  },
];

/* --- Spectrum plot (authorization × intent) ------------------------- */
export type Spot = {
  key: string;
  name: string;
  x: number;
  y: number;
  r: number;
  tone: "phos" | "amber" | "sage";
  note: string;
  primary?: boolean;
};

export const spectrum: Spot[] = [
  {
    key: "black",
    name: "Black Hat",
    x: 0.09,
    y: 0.13,
    r: 15,
    tone: "amber",
    primary: true,
    note: "Unauthorized and offensive — steals, encrypts and extorts for money or notoriety.",
  },
  {
    key: "white",
    name: "White Hat",
    x: 0.87,
    y: 0.88,
    r: 15,
    tone: "phos",
    primary: true,
    note: "Authorized and defensive — attacks the system on purpose, then reports what it found.",
  },
  {
    key: "gray",
    name: "Gray Hat",
    x: 0.36,
    y: 0.57,
    r: 14,
    tone: "sage",
    primary: true,
    note: "Unauthorized, but discloses — breaks the rule, then hands the flaw back.",
  },
  {
    key: "script",
    name: "Script Kiddie",
    x: 0.1,
    y: 0.3,
    r: 9,
    tone: "amber",
    note: "Runs pre-made tools without understanding them — curiosity and thrill, low skill.",
  },
  {
    key: "green",
    name: "Green Hat",
    x: 0.3,
    y: 0.66,
    r: 9,
    tone: "phos",
    note: "A beginner learning the craft — asks questions, seeks mentorship, not yet malicious.",
  },
  {
    key: "blue",
    name: "Blue Hat",
    x: 0.82,
    y: 0.76,
    r: 9,
    tone: "phos",
    note: "Invited external tester — brought in before a product or system launches.",
  },
  {
    key: "red",
    name: "Red Hat",
    x: 0.16,
    y: 0.42,
    r: 9,
    tone: "sage",
    note: "Vigilante — attacks the attackers, using aggressive methods against cybercriminals.",
  },
  {
    key: "state",
    name: "State-Sponsored",
    x: 0.93,
    y: 0.22,
    r: 11,
    tone: "amber",
    note: "Fully authorized by a government, and still offensive — espionage and cyber operations.",
  },
  {
    key: "hacktivist",
    name: "Hacktivist",
    x: 0.13,
    y: 0.5,
    r: 9,
    tone: "sage",
    note: "Unauthorized, cause-driven — disrupts or exposes to advance a political or social agenda.",
  },
  {
    key: "insider",
    name: "Malicious Insider",
    x: 0.66,
    y: 0.19,
    r: 11,
    tone: "amber",
    note: "Holds legitimate access already — the credential is valid, the intent is not.",
  },
];

/* --- Other types ---------------------------------------------------- */
export type Other = {
  i: string;
  name: string;
  desc: string;
  auth: string;
  motive: string;
};

export const otherHackers: Other[] = [
  {
    i: "01",
    name: "Script Kiddies",
    desc: "Inexperienced hackers who rely on pre-made tools or scripts to carry out attacks, often motivated by curiosity, thrill or recognition rather than expertise.",
    auth: "No",
    motive: "Thrill · recognition",
  },
  {
    i: "02",
    name: "Green Hat Hackers",
    desc: "Beginners eager to learn hacking and cybersecurity, frequently seeking mentorship from experienced hackers to develop their skills.",
    auth: "No",
    motive: "Learning",
  },
  {
    i: "03",
    name: "Blue Hat Hackers",
    desc: "External security testers brought in to identify vulnerabilities before software or systems are launched, helping prevent potential exploits.",
    auth: "Yes — invited",
    motive: "Pre-launch testing",
  },
  {
    i: "04",
    name: "Red Hat Hackers",
    desc: "Vigilante hackers who target malicious actors directly, using aggressive methods to disrupt or neutralize cybercriminal activities.",
    auth: "No",
    motive: "Vigilantism",
  },
  {
    i: "05",
    name: "State or Nation-Sponsored Hackers",
    desc: "Highly trained professionals employed by governments to conduct cyber operations for intelligence, espionage or national security purposes.",
    auth: "Yes — by a state",
    motive: "Espionage · security",
  },
  {
    i: "06",
    name: "Hacktivists",
    desc: "Individuals who leverage hacking to promote political, social or environmental causes, often by disrupting organizations or exposing sensitive information.",
    auth: "No",
    motive: "Political · social cause",
  },
  {
    i: "07",
    name: "Malicious Insiders or Whistleblowers",
    desc: "People within an organization who exploit legitimate access to internal systems, potentially leaking data for personal gain, protest or ethical reasons.",
    auth: "Yes — already inside",
    motive: "Profit · protest · ethics",
  },
];

/* --- Insider-threat extension --------------------------------------- */
export const insiderTypes = [
  ["Malicious insider", "Seeking money, revenge or personal advantage — deliberately exfiltrating data."],
  ["Negligent insider", "Cuts corners: shadow IT, shared credentials, unencrypted files. No bad intent, same outcome."],
  ["Compromised insider", "A legitimate employee whose account or device has been taken over by an outsider."],
];

export const insiderSignals = [
  "Unusual volume of downloads or exports",
  "Access outside normal hours or from new locations",
  "Reaching for privileges the role does not need",
  "Probing systems unrelated to the job",
  "Newly resigned staff copying repositories",
];

export const insiderControls = [
  "Least privilege · just-enough access",
  "Separation of duties",
  "User & entity behaviour analytics (UEBA)",
  "Data loss prevention (DLP) on egress",
  "Joiner–mover–leaver access reviews",
];

/* --- Vulnerable devices --------------------------------------------- */
export const devices = [
  {
    i: "01",
    name: "Smart Devices",
    desc: "Smartphones and IoT gadgets are easy targets due to constant connectivity and software variations.",
    why: "Always on, rarely patched",
  },
  {
    i: "02",
    name: "Webcams",
    desc: "Hackers use Remote Access Trojans (RATs) to spy, record and steal on-camera activity.",
    why: "RATs · physical privacy",
  },
  {
    i: "03",
    name: "Routers",
    desc: "Compromised routers allow attackers to control network traffic, launch DDoS attacks or steal data.",
    why: "Whole-network position",
  },
  {
    i: "04",
    name: "Jailbroken or Rooted Phones",
    desc: "Removing system restrictions exposes devices to apps and threats outside secure app stores.",
    why: "OS defences removed",
  },
];

export const devicesExtra = [
  "Devices still running end-of-life firmware",
  "Routers left on vendor default credentials",
  "Smart TVs, printers and cameras on the guest Wi-Fi",
  "Wearables and vehicle infotainment systems",
  "Public charging points and unknown USB sticks",
];

/* --- Prevention ------------------------------------------------------ */
export const prevention = [
  {
    i: "01",
    name: "Software Updates",
    desc: "Turn on automatic updates to fix vulnerabilities before hackers exploit them.",
    tip: "Settings → Update & security → Automatic updates",
    blocks: "Zero-day · malware",
  },
  {
    i: "02",
    name: "Use Different Passwords",
    desc: "Strong, unique passwords reduce the impact if one account is compromised.",
    tip: "A password manager makes this painless",
    blocks: "Credential stuffing",
  },
  {
    i: "03",
    name: "HTTPS Encryption",
    desc: 'Check for "https://" to ensure the website encrypts your data.',
    tip: "Padlock in the address bar — and read the domain, not the logo",
    blocks: "Eavesdropping · MITM",
  },
  {
    i: "04",
    name: "Avoid Strange Links",
    desc: "Do not click suspicious ads, email links or unknown attachments.",
    tip: "Hover first: does the URL match the sender?",
    blocks: "Phishing · ransomware",
  },
  {
    i: "05",
    name: "Change Default Passwords",
    desc: "Replace default device passwords to prevent attackers from easily breaking in.",
    tip: "admin/admin is public knowledge — it ships in every manual",
    blocks: "Router & IoT takeover",
  },
];

/* --- Extension: hardening checklist ---------------------------------- */
export const hardening = [
  ["MFA on everything", "An SMS or app code stops a stolen password from being enough."],
  ["Back up with 3-2-1", "Three copies, two media types, one offsite — the real ransomware cure."],
  ["VPN on public Wi-Fi", "Encrypts the tunnel so interception on shared networks yields only noise."],
  ["Install from official stores", "Sideloading APKs and cracked installers is the classic malware route."],
  ["Full-disk encryption", "BitLocker or LUKS turns a lost laptop into an unreadable brick."],
  ["Lock screen + auto-lock", "Physical access beats almost any software control."],
  ["Audit sessions & devices", "Sign out unknown sessions; review connected apps and API tokens."],
  ["Check the breach corpus", "Have I Been Pwned tells you which of your credentials are already public."],
];

/* --- Extension: the hacking methodology ------------------------------ */
export const methodology = [
  {
    i: "01",
    name: "Reconnaissance",
    desc: "Gather everything about the target — domains, employee names, technologies, exposed services.",
    tools: "OSINT · DNS records · public filings · social profiles",
    note: "Passive recon never touches the target; active recon does.",
  },
  {
    i: "02",
    name: "Scanning & enumeration",
    desc: "Find live hosts, open ports and running services, then match them against known vulnerabilities.",
    tools: "nmap · vulnerability scanners · directory brute-force",
    note: "This is where an exposed admin panel usually shows up.",
  },
  {
    i: "03",
    name: "Gaining access",
    desc: "Exploit the weakness found — injection, stolen credentials, a phishing lure or an unpatched flaw.",
    tools: "Metasploit · credential stuffing · phishing kits",
    note: "Human error remains the cheapest entry point.",
  },
  {
    i: "04",
    name: "Maintaining access",
    desc: "Persist across reboots and privilege boundaries so the session survives detection.",
    tools: "Backdoors · web shells · scheduled tasks · privilege escalation",
    note: "Dwell time is what turns an incident into a breach.",
  },
  {
    i: "05",
    name: "Covering tracks — or reporting",
    desc: "A criminal clears logs and timestamps. An ethical hacker writes them up, with proof and a fix.",
    tools: "Log tampering (malicious) · findings report (ethical)",
    note: "This last step is precisely what separates black from white.",
  },
];

/* --- Extension: teams & careers -------------------------------------- */
export const teams = [
  {
    name: "Red Team",
    role: "Offensive",
    desc: "Adversaries for hire inside the org — full-scope simulated attacks that test people and process, not just patches.",
    color: "amber",
  },
  {
    name: "Blue Team",
    role: "Defensive",
    desc: "Detects and responds: SOC analysts, threat hunters and incident responders working from logs, alerts and telemetry.",
    color: "phos",
  },
  {
    name: "Purple Team",
    role: "Collaborative",
    desc: "Red and blue in the same room — every attack technique is rehearsed live so detection rules improve immediately.",
    color: "sage",
  },
];

export const roles = [
  "Penetration tester",
  "SOC analyst",
  "Incident responder",
  "Threat hunter",
  "Security engineer",
  "GRC / compliance analyst",
  "Malware analyst",
  "CISO",
];

export const certs = [
  "CompTIA Security+",
  "CEH — Certified Ethical Hacker",
  "OSCP",
  "CISSP",
  "CISM",
];

/* --- Knowledge check -------------------------------------------------- */
export type Q5 = { q: string; options: string[]; answer: number; why: string };

export const questions5: Q5[] = [
  {
    q: "What is a hacker in the context of cybersecurity?",
    options: [
      "Any computer user with internet access",
      "Someone who breaks into systems or networks using technical skills",
      "Only government security employees",
      "A person who repairs computers",
    ],
    answer: 1,
    why: "A hacker is anyone who uses technical skill to gain access to systems or networks — the intent is what makes the label ethical or criminal.",
  },
  {
    q: "What distinguishes a white hat hacker from a black hat hacker?",
    options: [
      "White hats use only Linux",
      "Black hats follow legal rules",
      "White hats use viruses",
      "White hats are authorized to test and secure systems, while black hats exploit systems for malicious gain",
    ],
    answer: 3,
    why: "Authorization and intent, not skill or toolset: white hats are contracted to test, black hats exploit for profit or damage.",
  },
  {
    q: "Which type of hacker is most likely to use pre-made tools without understanding how they work?",
    options: ["Red Hat Hacker", "Script Kiddie", "State-Sponsored Hacker", "Blue Hat Hacker"],
    answer: 1,
    why: "Script kiddies run downloaded tools and scripts they do not fully understand, usually for thrill or recognition.",
  },
  {
    q: "Which prevention step best limits the damage if one of your online accounts is compromised?",
    options: [
      "Using the same password everywhere",
      "Turning off software updates",
      "Using strong, unique passwords for each account",
      "Ignoring HTTPS and padlock icons in the browser",
    ],
    answer: 2,
    why: "Unique passwords contain the blast radius — one leaked credential cannot unlock every other account.",
  },
  {
    q: "Which type of hacker is typically a beginner who wants to learn and asks experienced hackers questions?",
    options: ["Script Kiddie", "Green Hat Hacker", "Red Hat Hacker", "Hacktivist"],
    answer: 1,
    why: "Green hats are beginners eager to learn, actively seeking mentorship from more experienced hackers.",
  },
];

/* --- Contents ---------------------------------------------------------- */
export const contents5: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What a hacker is", "The hacker spectrum"],
  },
  {
    section: "Primary types",
    items: ["Black · White · Gray", "Hat comparison matrix"],
  },
  {
    section: "Other types",
    items: [
      "Seven more types",
      "Script Kiddies · Green · Blue",
      "Red Hat · State · Hacktivist",
      "Malicious insiders",
    ],
  },
  {
    section: "Devices & defence",
    items: ["Most vulnerable devices", "Prevention", "Extended hardening"],
  },
  {
    section: "Going deeper",
    items: ["The hacking methodology", "Teams & careers"],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Score", "Takeaways"],
  },
];

export const TOTAL5 = 22;
