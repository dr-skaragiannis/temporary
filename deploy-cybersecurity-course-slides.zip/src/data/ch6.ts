/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 06
   Vulnerabilities in Information Security
------------------------------------------------------------------ */

export const CH6_TITLE = "Vulnerabilities in Information Security";
export const ch6Stamp = "Last Updated : 8 Jun, 2026";

export const ch6Intro =
  "A vulnerability is a weakness in a system, application, network or process that can be exploited by a threat to compromise confidentiality, integrity or availability of assets. It may exist in software, hardware, configurations or human behavior and is a key focus in maintaining cybersecurity.";

export const ch6Bullets = [
  "Acts as an entry point for attackers to compromise systems",
  "Can exist in software, hardware, networks, processes or users",
  "Exploitation may lead to data breaches or service disruption",
  "Identified and reduced through regular security testing",
];

/* --- The five vulnerability types ----------------------------------- */
export type Example = { title: string; desc: string };
export type Vuln = {
  i: string;
  key: string;
  name: string;
  short: string;
  def: string;
  examples: Example[];
  causes: string[];
  prevents: Example[];
};

export const vulns: Vuln[] = [
  {
    i: "01",
    key: "hardware",
    name: "Hardware Vulnerability",
    short: "Hardware",
    def: "Weaknesses or flaws in physical devices (like computers or routers) that hackers can exploit to gain unauthorized access or cause damage.",
    examples: [
      {
        title: "Physical Attacks",
        desc: "Hardware devices like servers, laptops or smartphones are susceptible to physical attacks. Attackers may gain access to critical systems by stealing or tampering with hardware.",
      },
      {
        title: "Firmware Vulnerabilities",
        desc: "The software that runs on hardware, known as firmware, can have vulnerabilities. Flaws in firmware can lead to persistent attacks, as they are not always detected or patched as frequently as software.",
      },
    ],
    causes: [
      "Old version of systems or devices",
      "Unprotected storage",
      "Unencrypted devices, etc.",
    ],
    prevents: [
      {
        title: "Encrypt Sensitive Data",
        desc: "Ensure that all hardware, such as laptops and smartphones, is encrypted to protect data from unauthorized access in case of theft.",
      },
      {
        title: "Use Strong Authentication",
        desc: "Implement biometric or multi-factor authentication on devices to enhance security.",
      },
      {
        title: "Secure Devices Physically",
        desc: "Lock hardware devices in secure locations to prevent physical tampering or theft.",
      },
      {
        title: "Keep Hardware Up-to-Date",
        desc: "Regularly update hardware firmware to patch vulnerabilities and ensure the latest security measures are in place.",
      },
    ],
  },
  {
    i: "02",
    key: "software",
    name: "Software Vulnerability",
    short: "Software",
    def: "Flaws or bugs in software (such as apps or operating systems) that can be used by hackers to compromise the system, often due to coding mistakes or outdated software.",
    examples: [
      {
        title: "Unpatched Software",
        desc: "One of the most common vulnerabilities is the failure to install security updates or patches. Software vendors frequently release updates to address security flaws and neglecting to apply these patches can leave systems open to exploitation.",
      },
      {
        title: "Buffer Overflow",
        desc: "A buffer overflow occurs when data is written beyond the boundaries of a buffer, leading to unexpected behavior and allowing attackers to inject malicious code into the system.",
      },
      {
        title: "Insecure Code",
        desc: "Poorly written or insecure code can create vulnerabilities. Examples include improper input validation, which can lead to issues like SQL injection or flaws in error handling that could reveal sensitive data.",
      },
      {
        title: "Weak Authentication",
        desc: "Many systems rely on weak authentication methods such as simple passwords or unencrypted login forms, which can be exploited by attackers to gain unauthorized access.",
      },
    ],
    causes: [
      "Lack of input validation",
      "Unverified uploads",
      "Cross-site scripting",
      "Unencrypted data, etc.",
    ],
    prevents: [
      {
        title: "Regular Patching and Updates",
        desc: "Apply software patches and updates as soon as they are released. Many vulnerabilities arise due to outdated software.",
      },
      {
        title: "Secure Coding Practices",
        desc: "Developers should use secure coding practices to avoid common software vulnerabilities such as SQL injection and buffer overflows.",
      },
      {
        title: "Use Antivirus Software",
        desc: "Install and regularly update antivirus and anti-malware software to detect and remove malicious code.",
      },
      {
        title: "Apply Proper Input Validation",
        desc: "Ensure that input validation checks are in place to prevent attacks like cross-site scripting (XSS) and SQL injection.",
      },
    ],
  },
  {
    i: "03",
    key: "network",
    name: "Network Vulnerability",
    short: "Network",
    def: "A network vulnerability is a weakness or flaw in the design, implementation or configuration of a computer network that attackers can exploit to gain unauthorized access, steal data or disrupt services. These vulnerabilities can exist in hardware (routers, switches), software (servers, protocols) or network configurations.",
    examples: [
      {
        title: "Unsecured Wireless Networks",
        desc: "Wi-Fi networks that are not properly secured with strong passwords or encryption can be easily accessed by attackers. Once inside the network, an attacker can intercept communications, gain access to devices or launch attacks against connected systems.",
      },
      {
        title: "Open Ports",
        desc: "Unnecessary or open ports on a device can serve as gateways for attackers to exploit. Proper configuration of firewalls is essential to ensure only necessary ports are open and accessible.",
      },
      {
        title: "Man-in-the-Middle (MITM) Attacks",
        desc: "In MITM attacks, attackers intercept and alter the communication between two parties. If sensitive information such as login credentials or financial data is transmitted unencrypted, it can be captured and misused.",
      },
    ],
    causes: [
      "Unprotected communication",
      "Malware or malicious software (e.g. Viruses, Keyloggers, Worms, etc.)",
      "Social engineering attacks",
      "Misconfigured firewalls",
    ],
    prevents: [
      {
        title: "Use Strong Encryption",
        desc: "Ensure that sensitive data is encrypted during transmission over the network using protocols like SSL/TLS.",
      },
      {
        title: "Secure Wi-Fi Networks",
        desc: "Use strong passwords and encryption (WPA3) on wireless networks to prevent unauthorized access.",
      },
      {
        title: "Firewalls and IDS/IPS",
        desc: "Implement firewalls to block unauthorized network traffic and use Intrusion Detection Systems (IDS) or Intrusion Prevention Systems (IPS) to monitor and protect network traffic.",
      },
      {
        title: "Limit Open Ports",
        desc: "Close unnecessary open ports on devices to reduce attack surfaces. Regularly audit the network for exposed ports.",
      },
    ],
  },
  {
    i: "04",
    key: "procedural",
    name: "Procedural Vulnerability",
    short: "Procedural",
    def: "Weaknesses in the processes or rules organizations follow, like using default passwords or failing to monitor activities, which can allow attackers to bypass security.",
    examples: [
      {
        title: "Default Configurations",
        desc: "Many devices, applications and systems come with default settings that are not optimized for security. Leaving these defaults unchanged, such as using default administrator passwords, can provide attackers with an easy way into the system.",
      },
      {
        title: "Improper Access Controls",
        desc: "Misconfiguring access control settings, such as leaving sensitive data accessible to unauthorized users, can expose systems to exploitation. Role-based access control (RBAC) and least privilege access are essential to minimize this risk.",
      },
      {
        title: "Inadequate Logging and Monitoring",
        desc: "Failure to implement adequate logging and monitoring can prevent organizations from detecting unauthorized access or malicious activities in a timely manner. A lack of monitoring can allow an attacker to maintain persistent access without detection.",
      },
    ],
    causes: [],
    prevents: [
      {
        title: "Change Default Configurations",
        desc: "Always change default configurations on devices, software and network devices to ensure stronger security.",
      },
      {
        title: "Role-Based Access Control (RBAC)",
        desc: "Implement RBAC to ensure that employees have access only to the information they need for their job.",
      },
      {
        title: "Regular Monitoring and Logging",
        desc: "Establish robust logging and monitoring practices to detect and respond to unusual activity promptly.",
      },
      {
        title: "Use the Principle of Least Privilege (PoLP)",
        desc: "Only grant users the minimum level of access necessary for them to perform their duties.",
      },
    ],
  },
  {
    i: "05",
    key: "human",
    name: "Human Vulnerabilities",
    short: "Human",
    def: "Security risks caused by human behavior, such as falling for phishing attacks, using weak passwords or not being aware of security threats, making it easier for hackers to exploit the system.",
    examples: [
      {
        title: "Social Engineering",
        desc: "Human behavior is often the weakest link in cyber security. Attackers use social engineering tactics to manipulate individuals into disclosing confidential information or performing actions that compromise security. Phishing, baiting and pretexting are common social engineering methods.",
      },
      {
        title: "Negligence",
        desc: "Employees or users may inadvertently introduce vulnerabilities through negligence, such as using weak passwords, sharing login credentials or failing to lock their devices when not in use. This makes them easy targets for attackers.",
      },
      {
        title: "Lack of Security Awareness",
        desc: "A lack of training and awareness about cyber security best practices can leave individuals and organizations vulnerable to attacks. Users may fail to recognize phishing emails or may click on malicious links without thinking.",
      },
    ],
    causes: [],
    prevents: [
      {
        title: "Security Awareness Training",
        desc: "Conduct regular cyber security training for employees to help them identify phishing attacks, social engineering tactics and other malicious activities.",
      },
      {
        title: "Use Strong Passwords and Multi-Factor Authentication (MFA)",
        desc: "Encourage the use of complex passwords and MFA to secure user accounts.",
      },
      {
        title: "Regular Security Audits",
        desc: "Perform regular audits of employee behavior and access permissions to ensure compliance with security policies.",
      },
      {
        title: "Be Cautious of Suspicious Emails and Links",
        desc: "Train users to avoid clicking on unknown links, opening suspicious email attachments or entering sensitive information on untrusted websites.",
      },
    ],
  },
];

/* --- Extension: how vulnerabilities are found ------------------------ */
export const testingLifecycle = [
  {
    i: "01",
    name: "Threat modelling",
    desc: "Map the design before code exists — trust boundaries, entry points and what an attacker would want.",
    when: "Design",
  },
  {
    i: "02",
    name: "Static analysis (SAST)",
    desc: "Scan source or binary for insecure patterns without running the program: unvalidated input, hard-coded secrets.",
    when: "Build",
  },
  {
    i: "03",
    name: "Dynamic analysis (DAST)",
    desc: "Probe the running application from the outside — the way an attacker would — to catch what code review misses.",
    when: "Test",
  },
  {
    i: "04",
    name: "Penetration testing",
    desc: "A human tester chains findings together under a signed scope to prove real-world impact.",
    when: "Pre-release",
  },
  {
    i: "05",
    name: "Bug bounty & disclosure",
    desc: "External researchers report flaws continuously, in exchange for recognition or payment under a policy.",
    when: "Live",
  },
  {
    i: "06",
    name: "Remediate & retest",
    desc: "Patch, verify the fix, then confirm the original finding can no longer be reproduced.",
    when: "Always",
  },
];

/* --- Extension: CVE & CVSS ------------------------------------------ */
export const cvssBands = [
  ["None", "0.0", "#7E8F84"],
  ["Low", "0.1 – 3.9", "#3DF07A"],
  ["Medium", "4.0 – 6.9", "#C7D2C9"],
  ["High", "7.0 – 8.9", "#FFB020"],
  ["Critical", "9.0 – 10.0", "#FF6B3D"],
];

export const cveNotes = [
  [
    "CVE identifier",
    "A public, unique reference — CVE-2021-44228 for Log4Shell — so everyone means the same bug when they say the same name.",
  ],
  [
    "CVSS base score",
    "A 0.10 numeric score for exploitability and impact, which becomes the CVSS vector string published alongside it.",
  ],
  [
    "NVD",
    "The National Vulnerability Database enriches CVEs with references, affected products and suggested mitigations.",
  ],
  [
    "Remediation SLA",
    "Critical: days. High: weeks. Medium: the next patch cycle. Anything unowned is effectively unpatched.",
  ],
];

/* --- Knowledge check -------------------------------------------------- */
export type Q6 = { q: string; options: string[]; answer: number; why: string };

export const questions6: Q6[] = [
  {
    q: "An employee's laptop containing sensitive company data is stolen. The company ensures that the attacker cannot read any data from it. Based on the article, which preventive measure was most likely implemented?",
    options: [
      "Closing unused network ports",
      "Encrypting sensitive data on the device",
      "Using intrusion detection systems",
      "Applying role-based access control",
    ],
    answer: 1,
    why: "Hardware prevention: encrypt sensitive data on all devices so it cannot be read if the laptop is stolen.",
  },
  {
    q: "A system crashes when excessive data is input, allowing an attacker to execute malicious code. According to the article, what is the root cause?",
    options: [
      "Buffer overflow",
      "Lack of encryption",
      "Default configuration",
      "Open ports",
    ],
    answer: 0,
    why: "A buffer overflow writes data beyond the buffer boundary — that overrun is what lets an attacker inject code.",
  },
  {
    q: "A company fails to install updates released by a software vendor, and attackers exploit a known flaw. Which vulnerability cause from the article does this represent?",
    options: [
      "Improper access control",
      "Social engineering",
      "Unpatched software",
      "Unsecured wireless network",
    ],
    answer: 2,
    why: "Unpatched software is one of the most common vulnerabilities — vendors release fixes, and not applying them leaves the flaw open.",
  },
  {
    q: "An attacker gains access to a system through an unnecessarily open port. According to the article, what should have been done to prevent this?",
    options: [
      "Use biometric authentication",
      "Limit open ports",
      "Encrypt stored data",
      "Conduct employee training",
    ],
    answer: 1,
    why: "Limit open ports: close the unnecessary ones and audit the network regularly to reduce the attack surface.",
  },
  {
    q: "A company leaves default admin credentials unchanged on its systems. What type of vulnerability is this, based on the article?",
    options: [
      "Hardware vulnerability",
      "Network vulnerability",
      "Procedural vulnerability",
      "Human vulnerability",
    ],
    answer: 2,
    why: "Default configurations are a process failure — the article places them under procedural vulnerability.",
  },
];

/* --- Contents ---------------------------------------------------------- */
export const contents6: { section: string; items: string[] }[] = [
  {
    section: "Foundations",
    items: ["Title", "What a vulnerability is", "Five types — index"],
  },
  {
    section: "Hardware",
    items: ["Hardware · examples", "Hardware · causes & prevention"],
  },
  {
    section: "Software",
    items: ["Software · examples", "Software · causes & prevention"],
  },
  {
    section: "Network",
    items: ["Network · examples", "Network · causes & prevention"],
  },
  {
    section: "Procedural",
    items: ["Procedural · examples", "Procedural · prevention"],
  },
  {
    section: "Human",
    items: ["Human · examples", "Human · prevention"],
  },
  {
    section: "Going deeper",
    items: ["How vulnerabilities are found", "CVE & CVSS"],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Score", "Takeaways"],
  },
];

export const TOTAL6 = 23;
