/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 03
   Applications of Cybersecurity
------------------------------------------------------------------ */

export const CH3_TITLE = "Applications of Cybersecurity";

/* --- Applications -------------------------------------------------- */
export type App1 = {
  i: string;
  name: string;
  intro: string;
  uses: string[];
  example: string;
  tag: string;
};

export const applications: App1[] = [
  {
    i: "01",
    name: "Protecting Personal Information",
    intro:
      "Cybersecurity protects sensitive personal data such as identity credentials, financial records and confidential information from unauthorized access and cyber threats.",
    uses: [
      "Uses encryption and access control mechanisms.",
      "Ensures privacy across digital platforms and cloud services.",
    ],
    example: "Banking apps use AES encryption to secure customer account details.",
    tag: "IDENTITY",
  },
  {
    i: "02",
    name: "Securing Online Transactions",
    intro:
      "Cybersecurity secures online banking, e-commerce and digital payment systems against fraud and unauthorized transactions.",
    uses: [
      "Uses HTTPS, SSL/TLS encryption and secure payment gateways.",
      "Protects transaction data from interception attacks.",
    ],
    example:
      "Online payment gateways use SSL certificates to encrypt card transactions.",
    tag: "PAYMENTS",
  },
  {
    i: "03",
    name: "Safe Internet Browsing",
    intro:
      "Safe browsing technologies protect users from malicious websites, phishing attacks and malware infections.",
    uses: [
      "Uses firewalls, antivirus and web filtering tools.",
      "Prevents phishing, spyware and ransomware attacks.",
    ],
    example:
      "Modern browsers block phishing websites using real-time threat detection.",
    tag: "WEB",
  },
  {
    i: "04",
    name: "Protecting Devices and Smart Home Systems",
    intro:
      "Cybersecurity secures computers, smartphones and IoT-enabled smart devices from unauthorized access and exploitation.",
    uses: [
      "Implements strong authentication and device encryption.",
      "Requires regular firmware and security updates.",
      "Protects IoT networks from cyber intrusions.",
    ],
    example:
      "Smart CCTV cameras use encrypted connections to prevent unauthorized access.",
    tag: "IOT · ENDPOINT",
  },
  {
    i: "05",
    name: "Email Security",
    intro:
      "Email security protects communication systems from phishing, spam, malware and unauthorized access.",
    uses: [
      "Filters suspicious and malicious emails automatically.",
      "Uses email encryption and sender authentication protocols.",
    ],
    example:
      "SPF and DKIM protocols verify legitimate email senders to stop spoofing attacks.",
    tag: "MESSAGING",
  },
  {
    i: "06",
    name: "Social Media Safety",
    intro:
      "Cybersecurity safeguards social media accounts and personal data shared on digital platforms.",
    uses: [
      "Uses strong passwords and multi-factor authentication (MFA).",
      "Protects accounts from hacking and impersonation attacks.",
    ],
    example:
      "Two-factor authentication prevents unauthorized logins even if passwords are leaked.",
    tag: "ACCOUNTS",
  },
];

/* --- Key tools & technologies -------------------------------------- */
export const tools = [
  {
    i: "01",
    name: "DDoS Security",
    desc: "Protects servers from heavy malicious traffic and keeps websites available during attacks.",
    cat: "AVAILABILITY",
  },
  {
    i: "02",
    name: "Web Application Firewall",
    desc: "Filters web traffic and blocks harmful requests to protect applications.",
    cat: "APPLICATION",
  },
  {
    i: "03",
    name: "Bot Protection",
    desc: "Detects and blocks fake automated users to prevent system abuse.",
    cat: "IDENTITY",
  },
  {
    i: "04",
    name: "Antivirus & Antimalware",
    desc: "Scans and removes malware to keep systems secure from threats.",
    cat: "ENDPOINT",
  },
  {
    i: "05",
    name: "Threat Management Systems",
    desc: "Monitors networks and detects cyber threats for quick response.",
    cat: "DETECTION",
  },
  {
    i: "06",
    name: "Critical Systems Protection",
    desc: "Secures important servers and systems with advanced monitoring.",
    cat: "INFRASTRUCTURE",
  },
  {
    i: "07",
    name: "Rules & Regulations",
    desc: "Defines cybersecurity policies and ensures legal compliance.",
    cat: "GOVERNANCE",
  },
];

/* --- Understanding the CIA Triad ------------------------------------ */
export const ciaIntro =
  "The CIA Triad is a fundamental framework in information security used to protect data and maintain secure, reliable systems. It guides policies to ensure information remains confidential, accurate and accessible to authorized users.";

export const ciaBullets = [
  "Defines the core principles of Confidentiality, Integrity and Availability",
  "Provides a framework for protecting sensitive and important information",
  "Guides organizations in implementing effective cybersecurity strategies",
];

export const ciaStamp = "Last Updated : 24 Apr, 2026";

export const confidentiality = {
  def: "Confidentiality ensures that sensitive data is accessible only to authorized individuals or systems. Its purpose is to prevent unauthorized viewing, access or misuse of private information.",
  risks: [
    [
      "Unauthorized Access",
      "Attackers exploit vulnerabilities to access protected data.",
    ],
    [
      "Weak Encryption",
      "Outdated or weak encryption can be easily broken, exposing sensitive information.",
    ],
    [
      "Insider Threats",
      "Employees or trusted users may leak or accidentally expose confidential data.",
    ],
  ],
  fixes: [
    [
      "Encryption",
      "Use strong encryption methods like AES or RSA to protect data from unauthorized reading. Avoid outdated algorithms like DES.",
    ],
    [
      "VPN",
      "A Virtual Private Network creates an encrypted tunnel for internet communication, preventing interception.",
    ],
    [
      "Access Controls",
      "Implement strict authentication and authorization policies to limit data access to only authorized users.",
    ],
  ],
};

export const integrity = {
  def: "Integrity ensures that data remains accurate, authentic and unaltered during storage or transmission. Any unauthorized modification or corruption compromises the reliability of data.",
  risks: [
    [
      "Data Tampering",
      "Attackers may intentionally alter or corrupt data for malicious purposes.",
    ],
    [
      "Malware & Ransomware",
      "Malicious software can modify, encrypt or destroy data, leading to loss and system disruption.",
    ],
  ],
  fixes: [
    [
      "Hash Functions",
      "Detects modifications by generating unique hash values for data.",
    ],
  ],
  hashes: [
    ["MD5", "Produces a 128-bit hash value."],
    ["SHA Family", "Includes SHA-1, SHA-2, SHA-3 with varying bit lengths."],
  ],
  steps: [
    [
      "Host A creates a hash",
      "Host A sends data and creates a hash value (H1) using a hash function.",
    ],
    ["Attach hash", "H1 is sent along with the data."],
    ["Host B verifies", "Host B generates a new hash (H2) from the received data."],
    [
      "Compare",
      "If H1 = H2, the data is unchanged (integrity preserved). If H1 ≠ H2, the data was altered or corrupted.",
    ],
  ],
  note: "Even a small change in the input (like altering a single word or character) will completely change the resulting hash.",
};

export const availability = {
  def: "Availability ensures that systems, networks and data are accessible to authorized users whenever needed. Disruptions can halt operations and cause major losses.",
  risks: [
    [
      "DoS and DDoS Attacks",
      "Denial of Service (DoS) or Distributed Denial of Service (DDoS) attacks flood network resources with excessive traffic, making them unavailable to legitimate users.",
    ],
    [
      "Impact",
      "Such attacks can cause major service disruptions, downtime and financial losses for companies.",
    ],
  ],
  fixes: [
    [
      "Hardware Maintenance",
      "Regularly maintain and upgrade hardware to prevent failures and ensure smooth operations.",
    ],
    [
      "Regular Upgrades",
      "Keep systems and software updated to maintain performance and security.",
    ],
    [
      "Failover Plan",
      "Implement failover systems so that if one component fails, another can take over, minimizing downtime.",
    ],
    [
      "Preventing Bottlenecks",
      "Monitor and manage network traffic to avoid congestion or bottlenecks, ensuring consistent performance.",
    ],
  ],
};

/* --- Risk / control matrix ------------------------------------------ */
export const matrix = [
  {
    pillar: "C",
    name: "Confidentiality",
    risk: "Unauthorized access · weak encryption · insider threats",
    control: "AES / RSA encryption, VPN tunnels, strict access control",
  },
  {
    pillar: "I",
    name: "Integrity",
    risk: "Data tampering · malware & ransomware modification",
    control: "Hash functions (MD5, SHA family), verification of H1 vs H2",
  },
  {
    pillar: "A",
    name: "Availability",
    risk: "DoS / DDoS flooding · downtime · bottlenecks",
    control: "Maintenance, upgrades, failover planning, traffic management",
  },
];

/* --- Knowledge check ------------------------------------------------ */
export type Q3 = { q: string; options: string[]; answer: number; why: string };

export const questions3: Q3[] = [
  {
    q: 'What does the "CIA" in CIA Triad stand for?',
    options: [
      "Cyber, Internet, Access",
      "Central Intelligence Agency",
      "Confidentiality, Integrity, Availability",
      "Control, Isolation, Authentication",
    ],
    answer: 2,
    why: "CIA is an acronym for Confidentiality, Integrity and Availability — the three goals information security exists to protect.",
  },
  {
    q: "What is the CIA Triad in cybersecurity?",
    options: [
      "A type of computer virus",
      "A framework used to protect data and maintain secure systems",
      "A software used to speed up internet",
      "A tool for deleting files",
    ],
    answer: 1,
    why: "It is a framework — a set of principles that guides policies, not a product you install.",
  },
  {
    q: "What does Integrity in the CIA Triad ensure?",
    options: [
      "Data is always deleted",
      "Data remains accurate and unchanged",
      "Data is shared publicly",
      "Data is stored in multiple devices",
    ],
    answer: 1,
    why: "Integrity guarantees data stays accurate, authentic and unaltered during storage or transmission.",
  },
  {
    q: "Which of the following is a risk to Confidentiality?",
    options: ["Strong passwords", "Encryption", "Unauthorized access", "System backup"],
    answer: 2,
    why: "Unauthorized access is the risk itself; strong passwords, encryption and backups are the countermeasures.",
  },
  {
    q: "Which of the following best helps maintain data integrity during transmission?",
    options: [
      "Using only strong passwords",
      "Applying hash functions like MD5 or SHA to verify data has not changed",
      "Adding more RAM to the server",
      "Blocking all incoming traffic",
    ],
    answer: 1,
    why: "Both sides hash the payload and compare: H1 = H2 proves the data was not altered in transit.",
  },
  {
    q: "Which combination of measures best supports the Availability pillar?",
    options: [
      "Strong encryption and VPN only",
      "Hashing and digital signatures only",
      "Regular hardware maintenance, system upgrades, failover planning, and avoiding network bottlenecks",
      "Using a single powerful server with no backups",
    ],
    answer: 2,
    why: "Availability is operational: maintain the hardware, keep it patched, plan for failover and keep traffic flowing.",
  },
];

/* --- Contents -------------------------------------------------------- */
export const contents3: { section: string; items: string[] }[] = [
  {
    section: "Applications",
    items: [
      "Title",
      "Applications of cybersecurity",
      "Applications 01–03",
      "Applications 04–06",
    ],
  },
  {
    section: "Toolkit",
    items: ["Key tools & technologies"],
  },
  {
    section: "CIA — in depth",
    items: [
      "Understanding the CIA Triad",
      "Confidentiality",
      "Integrity",
      "Hash functions in action",
      "Availability",
      "Risk & control matrix",
    ],
  },
  {
    section: "Knowledge Check",
    items: ["Briefing", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Score", "Takeaways"],
  },
];

export const TOTAL3 = 20;
