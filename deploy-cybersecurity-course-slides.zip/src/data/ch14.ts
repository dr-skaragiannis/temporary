/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 14
   Phishing
------------------------------------------------------------------ */

export const CH14_TITLE = "Phishing";
export const ch14Stamp = "Last Updated : 24 Apr, 2026";

export const ch14Intro =
  "Phishing is a cyberattack where attackers use fake messages or websites to trick victims into giving away sensitive information. It works like \u201cfishing,\u201d using bait to lure targets into clicking harmful links or entering confidential data.";

export const ch14Bullets = [
  "Goal: steal sensitive info (passwords, credit card details, SSNs, DOB).",
  "Attackers impersonate trusted brands or services.",
  "Most phishing happens through emails that look genuine.",
  "Fake websites often mimic real ones but have suspicious URLs.",
];

/* --- Methods -------------------------------------------------------- */
export const methods = [
  {
    i: "01",
    name: "Clicking on an Unknown File or Attachment",
    desc: "Attackers send malicious files that trigger malware installation or ask for confidential information when opened.",
    points: ["Suspicious email attachments often contain malware.", "Files may prompt users to enter sensitive data.", "Common in spam or fake corporate emails."],
    channel: "Email",
  },
  {
    i: "02",
    name: "Using an Open or Free Wi-Fi Hotspot",
    desc: "Attackers lure users with free Wi-Fi and secretly monitor or steal their data.",
    points: ["Hackers can intercept browsing activity.", "Login credentials and personal data can be captured.", "Fake Wi-Fi hotspots mimic legitimate networks."],
    channel: "Network",
  },
  {
    i: "03",
    name: "Responding to Social Media Requests",
    desc: "Through social engineering, attackers trick users into accepting fake friend requests or revealing personal details.",
    points: ["Fake profiles are used to gain trust.", "Users may unknowingly share private information.", "Attackers gather data for further targeted attacks."],
    channel: "Social",
  },
  {
    i: "04",
    name: "Clicking on Unauthenticated Links or Ads",
    desc: "These links redirect users to fake websites that mimic real ones to steal confidential information.",
    points: ["Fake URLs closely resemble legitimate sites.", "Users are prompted to enter passwords or financial data.", "Often seen in emails, pop-ups or unsafe websites."],
    channel: "Web",
  },
];

/* --- Six types ---------------------------------------------------------- */
export type PhishType = {
  i: string;
  name: string;
  desc: string;
  points: string[];
  channel: string;
  targeting: "Mass" | "Targeted" | "Executive";
  tone: "phos" | "amber" | "sage";
};

export const phishTypes: PhishType[] = [
  {
    i: "01",
    name: "Email Phishing",
    desc: "Attackers send fake emails pretending to be trusted organizations to trick users into sharing sensitive data.",
    points: ["Sent to large groups.", "Aims to steal bank details, card numbers or login credentials.", "May contain malware-infected attachments or links."],
    channel: "Email",
    targeting: "Mass",
    tone: "sage",
  },
  {
    i: "02",
    name: "Spear Phishing",
    desc: "Targets a specific person or organization using personalized information.",
    points: ["Attackers research the victim beforehand.", "Emails appear more convincing and customized.", "Often used to steal confidential corporate data."],
    channel: "Email",
    targeting: "Targeted",
    tone: "phos",
  },
  {
    i: "03",
    name: "Whaling",
    desc: "A specialized spear-phishing attack targeting high-level executives.",
    points: ["Targets CEOs, CFOs, directors or senior managers.", "Uses urgent or high-pressure messages.", "Designed to steal sensitive business information or authorize fraudulent payments."],
    channel: "Email",
    targeting: "Executive",
    tone: "amber",
  },
  {
    i: "04",
    name: "Smishing",
    desc: "Phishing conducted through SMS messages.",
    points: ["Contains malicious links or fake warnings.", "May ask users to click a link or call a fraudulent number.", "Often disguised as bank alerts, delivery updates or OTP messages."],
    channel: "SMS",
    targeting: "Mass",
    tone: "sage",
  },
  {
    i: "05",
    name: "Vishing",
    desc: "Voice phishing carried out through phone calls.",
    points: ["Attackers use fake caller IDs or IVR systems.", "Pretend to be banks, tech support or government agencies.", "Trick victims into sharing OTPs, PINs or personal details."],
    channel: "Voice",
    targeting: "Targeted",
    tone: "phos",
  },
  {
    i: "06",
    name: "Clone Phishing",
    desc: "Attackers duplicate a legitimate email and replace its links or attachments with malicious ones.",
    points: ["Sent from a spoofed address resembling the original sender.", "Appears highly trustworthy as it copies a real email.", "May spread through the victim's contact list once compromised."],
    channel: "Email",
    targeting: "Targeted",
    tone: "amber",
  },
];

/* --- Signs ---------------------------------------------------------------- */
export const signs = [
  { i: "01", name: "Suspicious email addresses", desc: "Look for slight misspellings or altered domains." },
  { i: "02", name: "Urgent requests for personal information", desc: "Phishing emails often pressure victims." },
  { i: "03", name: "Poor grammar and spelling", desc: "A common indication of a fake message." },
  { i: "04", name: "Requests for sensitive information", desc: "Legitimate organizations rarely request such data via email." },
  { i: "05", name: "Unusual links or attachments", desc: "Avoid clicking links from unknown sources." },
  { i: "06", name: "Strange URLs", desc: "Fake websites often mimic real ones but with slight variations." },
];

/* --- Prevention -------------------------------------------------------------- */
export const prevention = [
  { i: "01", name: "Authorized Sources", desc: "Download software only from trusted platforms." },
  { i: "02", name: "Confidentiality", desc: "Never share private details with unknown links or websites." },
  { i: "03", name: "Check URLs", desc: "Verify website addresses to avoid fake sites." },
  { i: "04", name: "Don't reply to suspicious emails", desc: "Contact the sender through a fresh email if unsure." },
  { i: "05", name: "Use phishing detection tools", desc: "These help identify malicious websites." },
  { i: "06", name: "Avoid free Wi-Fi", desc: "Public hotspots may expose sensitive data." },
  { i: "07", name: "Keep your system updated", desc: "Updates patch vulnerabilities." },
  { i: "08", name: "Enable firewalls", desc: "Firewalls filter suspicious traffic." },
];

/* --- Fake vs real website ------------------------------------------------------- */
export const siteChecks = [
  {
    i: "01",
    name: "Check the URL",
    desc: "A legitimate website uses a secure medium. Look at the very beginning of the address.",
    points: [
      "https:// — the \u201cs\u201d means secure; data is encrypted in transit.",
      "http:// — not guaranteed to be safe; avoid entering data.",
    ],
    good: "https://www.example-bank.com",
    bad: "http://example-bank-login.info",
  },
  {
    i: "02",
    name: "Check the Domain Name",
    desc: "Attackers register addresses that mimic large brands. Read the spelling letter by letter.",
    points: [
      "One swapped or missing letter is enough — \u201camazon\u201d vs \u201camazom\u201d.",
      "The brand name may appear in the path instead of the domain.",
    ],
    good: "www.amazon.com/orders",
    bad: "www.amazom.com/order_id=23",
  },
  {
    i: "03",
    name: "Analyze the Site Design",
    desc: "Attackers imitate the original as closely as they can, but something is usually off.",
    points: [
      "Low-resolution logos, wrong fonts, broken layout.",
      "A brand page hosted on an unrelated domain is a clone.",
    ],
    good: "www.facebook.com",
    bad: "www.sugarcube.com/facebook",
  },
  {
    i: "04",
    name: "Check Available Web Pages",
    desc: "A fake site rarely reproduces the whole original — often only the page that captures your login.",
    points: [
      "Click the other links on the page.",
      "If everything leads back to a login form, it is fake.",
    ],
    good: "Home · Products · Support · Login",
    bad: "Login only — all links dead",
  },
];

/* --- Tools ------------------------------------------------------------------------ */
export const tools = [
  { name: "Anti-Phishing Domain Advisor (APDA)", desc: "Warns users about phishing websites with real-time alerts.", how: "Real-time alerts" },
  { name: "PhishTank", desc: "A community-driven database of reported phishing sites.", how: "Community database" },
  { name: "Webroot Anti-Phishing", desc: "Uses machine learning to detect suspicious websites.", how: "Machine learning" },
  { name: "Malwarebytes Anti-Phishing", desc: "Blocks malicious websites using real-time detection.", how: "Real-time blocking" },
  { name: "Kaspersky Anti-Phishing", desc: "Provides integrated protection using known phishing database lists.", how: "Known-site lists" },
];

export const toolsNote =
  "Anti-phishing tools add protection but are not a complete solution. Users must remain cautious and practice safe browsing habits.";

/* --- Knowledge check ---------------------------------------------------- */
export type Q14 = { q: string; options: string[]; answer: number; why: string };

export const questions14: Q14[] = [
  {
    q: "What is the main goal of a phishing attack?",
    options: ["Speed up your internet connection", "Steal sensitive information like passwords or credit card details", "Install software updates", "Test website performance"],
    answer: 1,
    why: "Phishing exists to harvest sensitive information — passwords, card details, SSNs — by tricking the victim into handing it over.",
  },
  {
    q: "Which of the following is a common sign that an email may be a phishing attempt?",
    options: ["It comes from your saved contacts", "It has a professional email signature", "It contains a company logo", "It uses urgent language demanding personal information"],
    answer: 3,
    why: "Urgency plus a demand for personal information is the classic phishing pattern. Logos and signatures are trivially copied.",
  },
  {
    q: "How does smishing differ from regular email phishing?",
    options: ["Smishing only targets companies", "Smishing uses SMS/text messages instead of email", "Smishing requires malware preinstalled on the phone", "Smishing never contains links"],
    answer: 1,
    why: "Smishing is phishing over SMS — fake bank alerts, delivery updates or OTP messages carrying malicious links or numbers.",
  },
  {
    q: "Which check helps you quickly spot a fake website pretending to be a real brand?",
    options: ["Checking if the URL uses \u201chttps://\u201d and verifying the domain spelling", "Only looking at the logo", "Making sure the page loads slowly", "Seeing if it has bright colors"],
    answer: 0,
    why: "The URL scheme and the exact domain spelling are the two fastest, most reliable checks. Logos and colours are easily cloned.",
  },
  {
    q: "What makes clone phishing especially dangerous compared to a normal fake email?",
    options: ["It never uses attachments", "It copies a legitimate email and only swaps links or files with malicious ones", "It can only be sent once", "It always arrives without a subject line"],
    answer: 1,
    why: "Clone phishing duplicates a real message the victim has already seen and trusts, replacing only the links or attachments — so every visual cue looks right.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents14: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What phishing is", "How it reaches you"] },
  { section: "Types", items: ["Six types", "Targeting spectrum"] },
  { section: "Recognise & prevent", items: ["Signs of phishing", "Preventive measures", "Fake vs real website", "Anti-phishing tools"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL14 = 17;
