/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 16
   History of Cyber Security
------------------------------------------------------------------ */

export const CH16_TITLE = "History of Cybersecurity";
export const ch16Stamp = "Last Updated : 18 Mar, 2026";

export const ch16Intro =
  "The history of cybersecurity explains how security measures have evolved alongside the growth of computers and the Internet to protect digital systems from emerging cyber threats.";

export const ch16Bullets = [
  "Cybersecurity developed as computer networks and the Internet expanded.",
  "Early efforts focused on preventing unauthorized access and data interception.",
  "The rise of personal computers introduced viruses and antivirus software.",
  "Widespread Internet use led to new and more complex cyber threats.",
  "Modern cybersecurity addresses advanced attacks targeting cloud systems, IoT and critical infrastructure.",
];

export const definition =
  "Cybersecurity is the practice of protecting computers, mobile devices, servers, electronic systems, networks and data from malicious attacks. It is also known as Information Security (INFOSEC), Information Assurance (IA) or System Security.";

export const definitionNote =
  "The earliest cyber malware was created unintentionally and caused no harm. Cybersecurity then evolved rapidly due to the sharp rise in cybercrime and the widespread use of the internet.";

/* --- Eras ------------------------------------------------------------ */
export type Era = {
  i: string;
  years: string;
  name: string;
  threat: string;
  response: string;
  lead: string;
  points: string[];
  tone: "phos" | "amber" | "sage";
};

export const eras: Era[] = [
  {
    i: "01",
    years: "1960s–1970s",
    name: "The First Security Concerns",
    threat: "Shared access · Creeper",
    response: "Periodic processing · Reaper",
    lead: "During the mid-to-late 1960s, time-sharing systems allowed multiple users to access computers simultaneously. As more jobs and users relied on networked systems, controlling access to data became a serious concern.",
    points: [
      "Periodic processing: system jobs ran at set intervals and were scanned for security risks before access to the next level was allowed.",
      "1970s: Bob Thomas created Creeper, a program that could move across the ARPANET network.",
      "Creeper was not malicious — it simply displayed “I AM THE CREEPER: CATCH ME IF YOU CAN.”",
      "Ray Tomlinson, inventor of email, wrote Reaper to chase and delete Creeper — the first antivirus and first self-replicating security program.",
      "In 1971 Creeper became widely recognised as the first computer worm and Trojan, though it caused no damage.",
    ],
    tone: "sage",
  },
  {
    i: "02",
    years: "1980s",
    name: "Birth of Commercial Antivirus",
    threat: "Floppy-disk viruses",
    response: "Commercial AV products",
    lead: "The year 1987 marked the beginning of commercial antivirus software. As personal computers became common, viruses spread through floppy disks, making antivirus software essential.",
    points: [
      "Andreas Lüning and Kai Figge released antivirus software for the Atari ST.",
      "Ultimate Virus Killer (UVK) was launched.",
      "NOD antivirus was developed in Czechoslovakia.",
      "John McAfee founded McAfee and released VirusScan in the U.S.",
    ],
    tone: "phos",
  },
  {
    i: "03",
    years: "2000s",
    name: "Threats Diversify and Multiply",
    threat: "Organised, funded crime",
    response: "Laws · penalties",
    lead: "In the early 2000s, cyberattacks became more organised and heavily funded by criminal groups. Governments began recognising hacking as a serious crime and introduced strict laws and penalties.",
    points: [
      "Internet usage expanded and viruses, worms and malware multiplied.",
      "Cybersecurity continued to advance — but attackers became more sophisticated at the same pace.",
    ],
    tone: "amber",
  },
  {
    i: "04",
    years: "2022 →",
    name: "Cybersecurity After 2022",
    threat: "Ransomware · AI-driven attacks",
    response: "Automation · threat intel",
    lead: "The cybersecurity industry continues to grow rapidly. According to Statista, the global cybersecurity market is expected to reach $345.4 billion by 2026. Ransomware remains one of the most common threats and continues to rise.",
    points: [
      "Cyberattacks follow a multi-step process: Surveillance → Exploitation → Access & Persistence.",
      "These steps can occur within seconds or span months.",
      "Cybercriminals now use emerging technologies such as AI, Machine Learning and Blockchain to launch stealthy, advanced attacks.",
    ],
    tone: "amber",
  },
];

/* --- Creeper / Reaper ---------------------------------------------------- */
export const creeperReaper = {
  creeper: {
    name: "Creeper",
    year: "1971",
    author: "Bob Thomas",
    role: "First worm & Trojan",
    desc: "Moved across ARPANET from machine to machine, printing a taunting message. Experimental, not malicious — no data was harmed.",
    message: "I AM THE CREEPER: CATCH ME IF YOU CAN.",
  },
  reaper: {
    name: "Reaper",
    year: "1972",
    author: "Ray Tomlinson",
    role: "First antivirus",
    desc: "Chased Creeper across the network and deleted it. Also the first self-replicating security program — it used the worm's own trick against it.",
    message: "// target: creeper · action: delete",
  },
};

/* --- Attack lifecycle ------------------------------------------------------ */
export const lifecycle = [
  { i: "01", name: "Surveillance", desc: "Collecting information using ping scans and port scans.", label: "RECON" },
  { i: "02", name: "Exploitation", desc: "Exploiting vulnerabilities in discovered services.", label: "EXPLOIT" },
  { i: "03", name: "Access and Persistence", desc: "Gaining and keeping control over systems.", label: "PERSIST" },
];

/* --- Laws (India) ----------------------------------------------------------- */
export const lawLead =
  "India amended the IT Act of 2000 (Sections 66–69) to address cybercrime. The amendments focus on:";

export const lawPoints = [
  "Collecting and analysing cybersecurity incident data.",
  "Issuing alerts and forecasts for cyber threats.",
  "Coordinating incident response activities.",
  "Publishing guidelines, advisories and vulnerability reports.",
];

/* --- Modern solutions --------------------------------------------------------- */
export const solutions = [
  { name: "Computer forensics", kind: "Investigate" },
  { name: "Multi-Factor Authentication (MFA)", kind: "Prevent" },
  { name: "Network Behavioural Analysis (NBA)", kind: "Detect" },
  { name: "Real-time system protection", kind: "Prevent" },
  { name: "Threat intelligence and automation", kind: "Detect" },
  { name: "Sandboxing", kind: "Contain" },
  { name: "Backups and mirroring", kind: "Recover" },
  { name: "Web application firewalls", kind: "Prevent" },
  { name: "Social engineering awareness", kind: "Prevent" },
];

export const solutionsNote =
  "Despite these controls, attackers have shown the ability to bypass traditional defences like 2FA, forcing organisations to rethink their security strategies.";

/* --- Future ------------------------------------------------------------------------ */
export const future = [
  { i: "01", name: "AI in the defence stack", desc: "AI is now integrated into antivirus and firewall solutions for smarter threat detection." },
  { i: "02", name: "Availability under attack", desc: "With automation, cloud computing, IoT and upcoming 5G networks, attackers increasingly target system availability and critical infrastructure." },
  { i: "03", name: "Continuous evolution", desc: "Cybersecurity will keep evolving to protect users, organisations and nations in an increasingly connected digital world." },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q16 = { q: string; options: string[]; answer: number; why: string };

export const questions16: Q16[] = [
  {
    q: "What was the primary goal of early cybersecurity efforts (1970s)?",
    options: ["Prevent ransomware attacks", "Protect cloud infrastructure", "Prevent unauthorized access and data misuse", "Develop AI-based security systems"],
    answer: 2,
    why: "Time-sharing systems put many users on one machine — controlling who could reach which data was the first security problem.",
  },
  {
    q: "Which program is considered the first antivirus software?",
    options: ["Creeper", "Reaper", "McAfee VirusScan", "NOD Antivirus"],
    answer: 1,
    why: "Reaper, written by Ray Tomlinson to hunt and delete Creeper, is regarded as the first antivirus. Creeper was the worm it chased.",
  },
  {
    q: "Why did cybersecurity become more important in the 1980s?",
    options: ["Introduction of blockchain technology", "Increase in cloud computing usage", "Spread of viruses through personal computers and floppy disks", "Development of AI-based attacks"],
    answer: 2,
    why: "Personal computers became common and viruses travelled on floppy disks, which is what made commercial antivirus essential from 1987 onward.",
  },
  {
    q: "Which of the following BEST represents the attack lifecycle mentioned in modern cybersecurity?",
    options: ["Attack → Delete → Exit", "Scan → Install → Shutdown", "Surveillance → Exploitation → Access & Persistence", "Login → Upload → Logout"],
    answer: 2,
    why: "Reconnaissance (ping and port scans), then exploiting a discovered vulnerability, then gaining and keeping control — seconds or months apart.",
  },
  {
    q: "An organization uses AI-based tools to detect threats, but attackers still bypass defenses. What does this indicate?",
    options: ["AI completely prevents cyberattacks", "Traditional and modern defenses alone are sufficient", "Attackers are evolving faster than static security systems", "Cybersecurity is no longer required"],
    answer: 2,
    why: "The whole history is an arms race: every control, from Reaper to 2FA to AI, has eventually been bypassed. Defences must keep adapting.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents16: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why", "Timeline"] },
  { section: "Eras", items: ["1970s · first concerns", "Creeper vs Reaper", "1980s · commercial AV", "2000s & after 2022"] },
  { section: "Today & tomorrow", items: ["Attack lifecycle", "Law & modern solutions", "The future"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL16 = 18;
