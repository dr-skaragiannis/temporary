import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch16Bullets,
  ch16Intro,
  ch16Stamp,
  contents16,
  creeperReaper,
  definition,
  definitionNote,
  eras,
  future,
  lawLead,
  lawPoints,
  lifecycle,
  questions16,
  solutions,
  solutionsNote,
  TOTAL16,
  type Era,
} from "./data/ch16";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "timeline with era ticks" backdrop
================================================================== */
function TimelineBackdrop() {
  const ticks = [
    { x: 700, label: "1971", c: "#C7D2C9" },
    { x: 820, label: "1987", c: "#3DF07A" },
    { x: 960, label: "2000s", c: "#FFB020" },
    { x: 1110, label: "2022→", c: "#FFB020" },
  ];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="tlFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="tlGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* rising threat curve */}
      <path d="M640 520 C 760 500, 860 440, 960 330 S 1120 130, 1200 60" fill="none" stroke="#FFB020" strokeOpacity="0.45" strokeWidth="2" strokeDasharray="6 6" />
      {/* main timeline */}
      <line x1="640" y1="360" x2="1200" y2="360" stroke="#3DF07A" strokeOpacity="0.55" strokeWidth="2" />
      {ticks.map((t) => (
        <g key={t.x}>
          <line x1={t.x} y1="340" x2={t.x} y2="380" stroke={t.c} strokeOpacity="0.8" strokeWidth="2" />
          <g filter="url(#tlGlow)"><circle cx={t.x} cy="360" r="6" fill={t.c} /></g>
          <text x={t.x} y="410" textAnchor="middle" fill={t.c} fillOpacity="0.85" fontFamily="IBM Plex Mono, monospace" fontSize="12" letterSpacing="2">{t.label}</text>
        </g>
      ))}
      {/* terminal window fragment */}
      <g transform="translate(680 180)" fontFamily="IBM Plex Mono, monospace" fontSize="11">
        <rect width="300" height="90" fill="#0B0F0D" stroke="#C7D2C9" strokeOpacity="0.3" />
        <text x="12" y="28" fill="#C7D2C9" fillOpacity="0.55">$ creeper --arpanet</text>
        <text x="12" y="50" fill="#3DF07A" fillOpacity="0.85">I AM THE CREEPER:</text>
        <text x="12" y="70" fill="#3DF07A" fillOpacity="0.85">CATCH ME IF YOU CAN.</text>
      </g>
      <rect width="1200" height="700" fill="url(#tlFade)" />
    </svg>
  );
}

export function TitleSlide16({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <TimelineBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Historical briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 16 of 16</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.16&nbsp;//&nbsp;HISTORY</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL16}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 16</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">History of</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Cybersecurity</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch16Intro} From a harmless worm on ARPANET to AI-driven
              ransomware — four eras, one arms race, and where it goes next.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(4)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to Creeper vs Reaper</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Eras", "Four"], ["First worm", "1971"], ["Market by 2026", "$345.4B"], ["Doc revision", ch16Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide16() {
  return (
    <Slide tag="SEC // CH.16 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why history matters</span></>} lede={ch16Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch16Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Cybersecurity, defined</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{definition}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["INFOSEC", "Information Assurance", "System Security"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
            <p className="mt-4 border-t border-sage/10 pt-3 text-[12.5px] font-light leading-[1.55] text-muted">{definitionNote}</p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · TIMELINE
================================================================== */
export function TimelineSlide16() {
  return (
    <Slide tag="SEC // CH.16 // TIMELINE" num="03" title={<>Four <span className="text-phos">eras</span></>} lede="Each era pairs a new class of threat with the defence invented to meet it. The pattern never changes — only the scale." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {eras.map((e, n) => (
            <motion.div key={e.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.07 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 items-center justify-center border bg-ink px-3 font-mono text-[11px]" style={{ borderColor: TONE[e.tone], color: TONE[e.tone], borderRadius: 2 }}>{e.years}</span>
              </div>
              <h3 className="mt-3 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{e.name}</h3>
              <div className="mt-3 grid gap-px bg-sage/15">
                <div className="bg-ink p-3">
                  <div className="font-mono text-[9px] tracked text-amber">Threat</div>
                  <div className="mt-1 text-[12px] text-sage/90">{e.threat}</div>
                </div>
                <div className="bg-ink p-3">
                  <div className="font-mono text-[9px] tracked text-phos">Response</div>
                  <div className="mt-1 text-[12px] text-sage/90">{e.response}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared era-detail slide
================================================================== */
function EraDetail({ e, num, side }: { e: Era; num: string; side?: React.ReactNode }) {
  return (
    <Slide tag={`SEC // CH.16 // ERA ${e.i} // ${e.years}`} num={num} title={<>{e.years} — <span className="text-phos">{e.name}</span></>} lede={e.lead} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className={side ? "lg:col-span-7" : "lg:col-span-12"}>
          {e.points.map((p, n) => (
            <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.04} />
          ))}
        </div>
        {side && <motion.div variants={rise} className="lg:col-span-5">{side}</motion.div>}
      </div>
    </Slide>
  );
}

export const Era1970s16 = () => (
  <EraDetail
    e={eras[0]}
    num="04"
    side={
      <Panel className="p-5">
        <div className="font-mono text-[9.5px] tracked text-amber">Why time-sharing changed everything</div>
        <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">
          A single-user machine has no access-control problem. The moment several
          people share one computer, "who may read this?" becomes a question the
          system has to answer — and that question is the origin of the whole
          field.
        </p>
      </Panel>
    }
  />
);

/* ==================================================================
   05 · CREEPER VS REAPER
================================================================== */
export function CreeperReaperSlide16() {
  const pair = [
    { ...creeperReaper.creeper, tone: "amber" as const, side: "Offence" },
    { ...creeperReaper.reaper, tone: "phos" as const, side: "Defence" },
  ];
  return (
    <Slide tag="SEC // CH.16 // 1971–72" num="05" title={<>Creeper <span className="text-muted">vs</span> <span className="text-phos">Reaper</span></>} lede="The first worm and the first antivirus, one year apart — and the first demonstration that defence borrows the attacker's techniques." dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {pair.map((p, n) => (
          <motion.div key={p.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[p.tone] }}>
            <div className="p-5">
              <div className="flex items-center justify-between">
                <Tag tone={p.tone}>{p.side}</Tag>
                <span className="font-mono text-[10px] text-muted">{p.year}</span>
              </div>
              <h3 className="mt-3 font-display text-[2rem] uppercase leading-none tracking-tight" style={{ color: TONE[p.tone] }}>{p.name}</h3>
              <div className="mt-1 font-mono text-[10px] tracked text-sage/70">{p.role} · {p.author}</div>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
            </div>
            <div className="mt-auto border-t border-sage/15 bg-ink p-4 font-mono text-[12px] leading-[1.6]" style={{ color: TONE[p.tone] }}>
              <span className="text-muted">$ </span>{p.message}
            </div>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-5 grid gap-px bg-sage/15 sm:grid-cols-3 font-mono text-[9.5px] tracked">
        <div className="bg-panel/70 p-3 text-sage/80">Creeper moved itself between hosts → worm</div>
        <div className="bg-panel/70 p-3 text-sage/80">It looked like a normal program → Trojan</div>
        <div className="bg-panel/70 p-3 text-phos">Reaper copied itself to hunt it → first self-replicating defence</div>
      </motion.div>
    </Slide>
  );
}

export const Era1980s16 = () => (
  <EraDetail
    e={eras[1]}
    num="06"
    side={
      <Panel className="p-5">
        <div className="font-mono text-[9.5px] tracked text-phos">1987 · four products, one year</div>
        <div className="mt-3 grid grid-cols-2 gap-px bg-sage/15">
          {[["Atari ST AV", "Lüning & Figge"], ["UVK", "Ultimate Virus Killer"], ["NOD", "Czechoslovakia"], ["VirusScan", "McAfee · U.S."]].map(([a, b]) => (
            <div key={a} className="bg-ink p-3">
              <div className="font-mono text-[12px] text-sage">{a}</div>
              <div className="mt-0.5 text-[11px] font-light text-muted">{b}</div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">The delivery medium was the floppy disk — malware went wherever the disk went, so protection had to live on every PC.</p>
      </Panel>
    }
  />
);

/* ==================================================================
   07 · 2000s & AFTER 2022
================================================================== */
export function ModernErasSlide16() {
  const two = [eras[2], eras[3]];
  return (
    <Slide tag="SEC // CH.16 // ERAS 03–04" num="07" title={<>2000s &amp; <span className="text-phos">after 2022</span></>} lede="Crime becomes organised, then industrialised. The threat curve steepens and the market grows to match it." dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {two.map((e, n) => (
          <motion.div key={e.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[e.tone] }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[e.tone] }}>Era {e.i} · {e.years}</span>
              <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{e.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{e.lead}</p>
            </div>
            <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
              {e.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[e.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-5 flex flex-wrap items-center gap-6 border-t border-sage/15 pt-4">
        <div>
          <div className="font-mono text-[9.5px] tracked text-muted">Global market · 2026 (Statista)</div>
          <div className="mt-1 font-display text-[1.8rem] leading-none text-phos glow">$345.4B</div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-muted">Most common threat</div>
          <div className="mt-1 font-display text-[1.8rem] leading-none text-amber">Ransomware</div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-muted">Attacker toolkit</div>
          <div className="mt-1 flex gap-2">{["AI", "ML", "Blockchain"].map((t) => <Tag key={t} tone="amber">{t}</Tag>)}</div>
        </div>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   08 · ATTACK LIFECYCLE
================================================================== */
export function LifecycleSlide16() {
  return (
    <Slide tag="SEC // CH.16 // LIFECYCLE" num="08" title={<>The modern <span className="text-phos">attack lifecycle</span></>} lede="Cyberattacks generally follow a multi-step process. These steps can occur within seconds or span months." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[26px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-4 lg:grid-cols-3">
          {lifecycle.map((s, n) => (
            <motion.div key={s.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="relative">
              <div className="relative z-10 flex h-[52px] items-center">
                <span className="flex h-11 w-11 items-center justify-center border bg-ink font-mono text-[14px]" style={{ borderColor: n === 2 ? TONE.amber : TONE.phos, color: n === 2 ? TONE.amber : TONE.phos, borderRadius: 2 }}>{s.i}</span>
              </div>
              <div className="font-mono text-[9.5px] tracked text-muted">{s.label}</div>
              <h3 className="mt-1 font-display text-[1.3rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <motion.div variants={rise} className="mt-8 grid gap-px bg-sage/15 sm:grid-cols-2">
        <div className="bg-panel/70 p-4">
          <div className="font-mono text-[9.5px] tracked text-phos">Seconds</div>
          <p className="mt-1.5 text-[12.5px] font-light leading-[1.55] text-muted">Automated scanners find an exposed service, fire a known exploit and drop a payload before anyone is watching.</p>
        </div>
        <div className="bg-panel/70 p-4">
          <div className="font-mono text-[9.5px] tracked text-amber">Months</div>
          <p className="mt-1.5 text-[12.5px] font-light leading-[1.55] text-muted">A patient actor maps the network quietly, waits for the right vulnerability and stays resident long after the first foothold.</p>
        </div>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   09 · LAW & MODERN SOLUTIONS
================================================================== */
export function LawSolutionsSlide16() {
  const kinds = ["Prevent", "Detect", "Contain", "Recover", "Investigate"];
  const kindTone: Record<string, string> = { Prevent: TONE.phos, Detect: TONE.phos, Contain: TONE.amber, Recover: TONE.amber, Investigate: TONE.sage };
  return (
    <Slide tag="SEC // CH.16 // RESPONSE" num="09" title={<>Law &amp; <span className="text-phos">modern solutions</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Government response · India</div>
            <div className="mt-2 font-display text-[1.2rem] uppercase leading-tight text-sage">IT Act 2000 · §66–69</div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{lawLead}</p>
            <ul className="mt-3 border-t border-sage/10 pt-2">
              {lawPoints.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-amber" />{p}
                </li>
              ))}
            </ul>
          </Panel>
        </div>
        <div className="lg:col-span-7">
          <div className="font-mono text-[9.5px] tracked text-phos">Modern cybersecurity solutions</div>
          <div className="mt-2 grid gap-px bg-sage/15 sm:grid-cols-3">
            {solutions.map((s, n) => (
              <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.04 } } }} className="bg-ink p-3">
                <div className="font-mono text-[9px] tracked" style={{ color: kindTone[s.kind] }}>{s.kind}</div>
                <div className="mt-1 text-[12.5px] font-medium leading-tight text-sage">{s.name}</div>
              </motion.div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[9px] tracked text-muted">
            {kinds.map((k) => (
              <span key={k} className="flex items-center gap-1.5"><span className="inline-block h-2 w-3" style={{ background: kindTone[k] }} />{k}</span>
            ))}
          </div>
          <motion.div variants={rise} className="mt-4 border-l-2 border-amber bg-amber/[0.07] p-4">
            <div className="font-mono text-[9.5px] tracked text-amber">Caveat</div>
            <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{solutionsNote}</p>
          </motion.div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · FUTURE
================================================================== */
export function FutureSlide16() {
  return (
    <Slide tag="SEC // CH.16 // FUTURE" num="10" title={<>The future of <span className="text-phos">cybersecurity</span></>} lede="The future depends on leveraging emerging technologies to reduce attack frequency and impact." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {future.map((f, n) => (
          <motion.div key={f.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 1 ? TONE.amber : TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n === 1 ? TONE.amber : TONE.phos }}>Trend {f.i}</span>
            <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{f.name}</h3>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{f.desc}</p>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-6 border-t border-sage/15 pt-4">
        <div className="font-mono text-[9.5px] tracked text-muted">Expanding attack surface</div>
        <div className="mt-2 flex flex-wrap gap-2">
          {["Automation", "Cloud computing", "IoT", "5G networks", "Critical infrastructure"].map((t) => <Tag key={t} tone="amber">{t}</Tag>)}
        </div>
        <p className="mt-3 max-w-[70ch] text-[12.5px] font-light leading-[1.55] text-muted">
          Reaper caught Creeper in 1972. Every defence since has eventually been
          outrun. The lesson of the history is not that the arms race can be won —
          it is that it must be continuously run.
        </p>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   11 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide16({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.16 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Catch me
          <br />
          <span className="text-phos glow">if you can.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the first security goal, the first antivirus,
          the 1980s turning point, the attack lifecycle and what it means when
          AI defences are bypassed. Select an answer to reveal it instantly —
          the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(11)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   12–16 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide16({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions16[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.16 // CHECK // Q0${n + 1}`} num={String(12 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "History"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   17 · SCORE
================================================================== */
export function ScoreSlide16({ answers }: { answers: (number | null)[] }) {
  const score = questions16.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions16.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — you caught the Creeper." : pct >= 60 ? "Solid. Re-read the timeline and match each era to its threat." : "Revisit the four eras and the attack lifecycle, then retake.";
  return (
    <Slide tag="SEC // CH.16 // CHECK // RESULT" num="17" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions16.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions16.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions16.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   18 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide16() {
  const items = [
    ["01", "Sharing created security", "The moment two users shared one machine, access control became necessary. Everything since follows."],
    ["02", "The first worm was harmless", "Creeper taunted; Reaper hunted it. Offence and defence were born a year apart."],
    ["03", "Medium shapes the threat", "Floppy disks made viruses portable and antivirus commercial. The Internet did the same at scale."],
    ["04", "Crime professionalised in the 2000s", "Funded, organised attackers forced governments to write laws and set penalties."],
    ["05", "Recon → exploit → persist", "Seconds or months, the lifecycle is the same. Break it early and the rest never happens."],
    ["06", "No control is final", "2FA has been bypassed; AI defences will be too. Security is a process, not a product."],
  ];
  return (
    <Slide tag="SEC // CH.16 // CLOSE" num="18" title={<>Chapter 16 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 16 · History of Cybersecurity</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents16.length} sections · {TOTAL16} slides</span>
      </div>
    </Slide>
  );
}
