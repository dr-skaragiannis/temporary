/* Hand-drawn vector marks — the deck's identity. */

/** Rail / favicon mark: shield containing the triad triangle. */
export function Mark({ size = 26 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden
      className="glow"
    >
      <path
        d="M16 2.2 28.6 6.9v9.6c0 6.9-5.2 11.7-12.6 13.7C8.6 28.2 3.4 23.4 3.4 16.5V6.9L16 2.2Z"
        stroke="#3DF07A"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M16 9.4 23 21.6H9L16 9.4Z"
        stroke="#3DF07A"
        strokeWidth="1.3"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="9.4" r="2.1" fill="#3DF07A" />
      <circle cx="23" cy="21.6" r="2.1" fill="#3DF07A" />
      <circle cx="9" cy="21.6" r="2.1" fill="#3DF07A" />
    </svg>
  );
}

/** Larger seal used on the title slide. */
export function TriadSeal({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 260 240" fill="none" className={className} aria-hidden>
      <circle
        cx="130"
        cy="126"
        r="112"
        stroke="#3DF07A"
        strokeOpacity="0.25"
        strokeWidth="1"
        strokeDasharray="3 7"
      />
      <circle
        cx="130"
        cy="126"
        r="96"
        stroke="#3DF07A"
        strokeOpacity="0.45"
        strokeWidth="1"
      />
      <path
        d="M130 50 205 182H55L130 50Z"
        stroke="#3DF07A"
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
      <path
        d="M130 78 181 166H79L130 78Z"
        stroke="#3DF07A"
        strokeOpacity="0.35"
        strokeWidth="1"
        strokeLinejoin="round"
      />
      {[
        [130, 50],
        [205, 182],
        [55, 182],
      ].map(([x, y]) => (
        <g key={`${x}-${y}`}>
          <circle cx={x} cy={y} r="17" fill="#0B0F0D" stroke="#3DF07A" strokeWidth="1.5" />
          <circle cx={x} cy={y} r="5" fill="#3DF07A" />
        </g>
      ))}
      <path
        d="M118 120h24v22a12 12 0 0 1-24 0v-22Z"
        stroke="#3DF07A"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path
        d="M122 120v-7a8 8 0 0 1 16 0v7"
        stroke="#3DF07A"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}
