import { motion, type Variants } from "framer-motion";
import type { ReactNode } from "react";
import { TOTAL } from "../data/content";

/* ------------------------------------------------------------------
   Motion language: machined, short, staggered. No bounce.
------------------------------------------------------------------ */
export const group: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.045, delayChildren: 0.05 } },
};

export const rise: Variants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { duration: 0.38, ease: "easeOut" } },
};

export const drawX: Variants = {
  hidden: { scaleX: 0 },
  show: { scaleX: 1, transition: { duration: 0.55, ease: "easeOut" } },
};

export const wipe: Variants = {
  hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
  show: {
    opacity: 1,
    clipPath: "inset(0 0% 0 0)",
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

/* ------------------------------------------------------------------ */

export function Tag({
  children,
  tone = "phos",
}: {
  children: ReactNode;
  tone?: "phos" | "amber" | "muted";
}) {
  const c =
    tone === "amber"
      ? "text-amber border-amber/40"
      : tone === "muted"
        ? "text-muted border-sage/20"
        : "text-phos border-phos/40";
  return (
    <span
      className={`inline-block border ${c} px-2 py-[3px] font-mono text-[9.5px] leading-none tracked`}
    >
      {children}
    </span>
  );
}

export function Rule({ tone = "phos" }: { tone?: "phos" | "faint" }) {
  return (
    <motion.div
      variants={drawX}
      className={`h-px w-full origin-left ${
        tone === "phos" ? "bg-phos/50" : "bg-sage/20"
      }`}
    />
  );
}

/** Huge outlined section numeral bleeding off the left edge. */
export function BleedNum({ n }: { n: string }) {
  return (
    <span
      aria-hidden
      className="outline-num pointer-events-none absolute left-[-0.06em] top-1/2 hidden -translate-y-1/2 select-none font-display text-[26vw] leading-none lg:block"
    >
      {n}
    </span>
  );
}

export function Slide({
  tag,
  num,
  title,
  lede,
  children,
  dense = false,
}: {
  tag: string;
  num: string;
  title: ReactNode;
  lede?: ReactNode;
  children?: ReactNode;
  dense?: boolean;
}) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto px-5 pb-28 pt-7 sm:px-8 md:px-12 md:pb-24 md:pt-9 lg:px-16"
    >
      <BleedNum n={num} />
      <div className="relative mx-auto w-full max-w-[1360px] lg:pl-[9vw]">
        <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-2">
          <motion.div variants={rise}>
            <Tag>{tag}</Tag>
          </motion.div>
          <motion.span
            variants={rise}
            className="font-mono text-[10px] tracked text-muted"
          >
            {num} / {String(TOTAL)}
          </motion.span>
        </div>

        <motion.h2
          variants={wipe}
          className="mt-4 font-display text-[clamp(1.9rem,4.4vw,3.6rem)] uppercase leading-[0.94] tracking-[-0.015em] text-sage"
        >
          {title}
        </motion.h2>

        {lede && (
          <motion.p
            variants={rise}
            className="mt-4 max-w-[68ch] text-[15px] font-light leading-[1.6] text-muted md:text-base"
          >
            {lede}
          </motion.p>
        )}

        <div className="mt-5">
          <Rule />
        </div>

        <div className={dense ? "mt-6" : "mt-8"}>{children}</div>
      </div>
    </motion.section>
  );
}

/* ------------------------------------------------------------------
   The Apollo-checklist row: index · item · status
------------------------------------------------------------------ */
export function Row({
  i,
  label,
  desc,
  meta,
  delay = 0,
}: {
  i: string;
  label: ReactNode;
  desc?: ReactNode;
  meta?: string;
  delay?: number;
}) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 8 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.36, ease: "easeOut", delay },
        },
      }}
      className="group grid grid-cols-[2.1rem_minmax(0,1fr)] items-start gap-x-4 border-t border-sage/15 py-3.5 transition-colors duration-200 hover:bg-phos/[0.045] sm:grid-cols-[2.6rem_minmax(0,1fr)_auto] sm:gap-x-6"
    >
      <span className="pt-[3px] font-mono text-[11px] tabular-nums text-phos/70 transition-colors group-hover:text-phos sm:text-xs">
        {i}
      </span>
      <div className="min-w-0">
        <div className="font-mono text-[12.5px] font-medium tracked-sm text-sage sm:text-[13.5px]">
          {label}
        </div>
        {desc && (
          <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-muted sm:text-sm">
            {desc}
          </p>
        )}
      </div>
      {meta && (
        <span className="hidden self-start pt-1 text-right font-mono text-[9.5px] tracked text-phos/55 sm:block">
          {meta}
        </span>
      )}
    </motion.div>
  );
}

/** Panel with a hard hairline — no rounded cards. */
export function Panel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`border border-sage/15 bg-panel/70 ${className}`}
      style={{ borderRadius: 2 }}
    >
      {children}
    </div>
  );
}
