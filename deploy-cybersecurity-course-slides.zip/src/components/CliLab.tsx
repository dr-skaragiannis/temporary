import { useEffect, useMemo, useRef, useState } from "react";

/* ==================================================================
   A small, faithful Linux permission lab: virtual filesystem,
   real chmod/chown parsing, identity-aware access checks.
================================================================== */

type Kind = "in" | "out" | "err" | "ok" | "note";
type Entry = { kind: Kind; text: string };
type Klass = "owner" | "group" | "other";

type VFile = {
  name: string;
  type: "file" | "dir";
  owner: string;
  group: string;
  perms: number; // 0o7777
  size: number;
  mtime: string;
  content?: string;
};

type Ident = {
  key: string;
  name: string;
  uid: number;
  groups: string[];
  label: string;
  blurb: string;
};

const IDENTITIES: Ident[] = [
  {
    key: "owner",
    name: "narx",
    uid: 1000,
    groups: ["users", "devs"],
    label: "Owner",
    blurb: "narx — created these files",
  },
  {
    key: "group",
    name: "carol",
    uid: 1001,
    groups: ["users", "devs"],
    label: "Group member",
    blurb: "carol — in groups users & devs",
  },
  {
    key: "other",
    name: "dave",
    uid: 1002,
    groups: ["dave"],
    label: "Other",
    blurb: "dave — no matching group",
  },
];

const BITS: Record<Klass, Record<string, number>> = {
  owner: { r: 0o400, w: 0o200, x: 0o100, s: 0o4000 },
  group: { r: 0o040, w: 0o020, x: 0o010, s: 0o2000 },
  other: { r: 0o004, w: 0o002, x: 0o001, t: 0o1000 },
};

const initialFs = (): VFile[] => [
  {
    name: "NarX.txt",
    type: "file",
    owner: "narx",
    group: "users",
    perms: 0o644,
    size: 46,
    mtime: "Apr 14 16:37",
    content: "Linux permissions define who can read, write and execute.",
  },
  {
    name: "run.sh",
    type: "file",
    owner: "narx",
    group: "users",
    perms: 0o644,
    size: 812,
    mtime: "Apr 14 16:40",
    content: "#!/bin/sh\necho \"lab ready\"",
  },
  {
    name: "notes.md",
    type: "file",
    owner: "narx",
    group: "devs",
    perms: 0o640,
    size: 214,
    mtime: "Apr 14 16:41",
    content: "# lab notes\nr = 4   w = 2   x = 1",
  },
  {
    name: "project",
    type: "dir",
    owner: "narx",
    group: "users",
    perms: 0o755,
    size: 4096,
    mtime: "Apr 14 16:42",
  },
  {
    name: "secret.key",
    type: "file",
    owner: "root",
    group: "root",
    perms: 0o600,
    size: 2210,
    mtime: "Apr 14 16:44",
    content: "-----BEGIN PRIVATE KEY-----",
  },
];

/* ---------- helpers ------------------------------------------------ */
const PERMS3 = ["r", "w", "x"];

function modeStr(p: number, type: "file" | "dir") {
  let s = type === "dir" ? "d" : "-";
  for (let i = 8; i >= 0; i--) {
    const on = (p & (1 << i)) !== 0;
    s += on ? PERMS3[(8 - i) % 3] : "-";
  }
  if (p & 0o4000) s = s.slice(0, 3) + ((p & 0o100) ? "s" : "S") + s.slice(4);
  if (p & 0o2000)
    s = s.slice(0, 6) + ((p & 0o010) ? "s" : "S") + s.slice(7);
  if (p & 0o1000)
    s = s.slice(0, 9) + ((p & 0o001) ? "t" : "T") + s.slice(10);
  return s;
}

const octal3 = (p: number) =>
  `${(p >> 6) & 7}${(p >> 3) & 7}${p & 7}`;

const octal4 = (p: number) => {
  const lead = (p >> 9) & 7;
  return lead ? `${lead}${octal3(p)}` : octal3(p);
};

function klassOf(f: VFile, me: Ident): Klass {
  if (f.owner === me.name) return "owner";
  if (me.groups.includes(f.group)) return "group";
  return "other";
}

const can = (p: number, k: Klass, a: "r" | "w" | "x") =>
  (p & BITS[k][a]) !== 0;

function applySymbolic(
  p: number,
  spec: string,
): { ok: true; perms: number } | { ok: false; msg: string } {
  let out = p;
  const parts = spec.split(",").filter(Boolean);
  if (!parts.length) return { ok: false, msg: `invalid mode: '${spec}'` };
  for (const raw of parts) {
    const m = /^([ugoa]*)([+-=])([rwxst]+)$/.exec(raw.trim());
    if (!m) return { ok: false, msg: `invalid mode: '${spec}'` };
    const who = m[1];
    const op = m[2];
    const syms = m[3];
    let classes: Klass[];
    if (!who || who.includes("a")) classes = ["owner", "group", "other"];
    else {
      classes = [];
      if (who.includes("u")) classes.push("owner");
      if (who.includes("g")) classes.push("group");
      if (who.includes("o")) classes.push("other");
    }
    for (const c of classes) {
      let mask = 0;
      for (const s of syms) mask |= BITS[c][s] ?? 0;
      if (op === "+") out |= mask;
      else if (op === "-") out &= ~mask;
      else {
        out &= ~(BITS[c].r | BITS[c].w | BITS[c].x | (BITS[c].s ?? 0));
        out |= mask;
      }
    }
  }
  return { ok: true, perms: out & 0o7777 };
}

const EXERCISES = [
  {
    n: "01",
    task: "Make run.sh executable by everyone.",
    hint: "chmod o+x run.sh   ·   or   chmod 755 run.sh",
    check: (fs: VFile[]) => {
      const f = fs.find((x) => x.name === "run.sh");
      return !!f && (f.perms & 0o001) !== 0;
    },
  },
  {
    n: "02",
    task: "Give the group write access to notes.md.",
    hint: "chmod g+w notes.md   ·   or   chmod 660 notes.md",
    check: (fs: VFile[]) => {
      const f = fs.find((x) => x.name === "notes.md");
      return !!f && (f.perms & 0o020) !== 0;
    },
  },
  {
    n: "03",
    task: "Lock project/ so only its owner can create files inside.",
    hint: "chmod u=rwx,go-w project   ·   or   chmod 700 project",
    check: (fs: VFile[]) => {
      const f = fs.find((x) => x.name === "project");
      return !!f && (f.perms & 0o077) === 0;
    },
  },
];

const HELP = [
  "ls [-l] [name]      list directory contents",
  "cat name            print a file — access is checked",
  "chmod MODE name     change a mode: u+x  |  g+w,o-r  |  755",
  "chown [user:]group  change ownership (owner or root only)",
  "stat name           inode, device, blocks, timestamps",
  "namei -l path       walk every component of a path",
  "id · whoami · pwd   show the current identity",
  "help · clear · reset",
];

/* ================================================================== */

export function CliLab() {
  const [fs, setFs] = useState<VFile[]>(initialFs);
  const [meKey, setMeKey] = useState("owner");
  const [lines, setLines] = useState<Entry[]>([
    { kind: "note", text: "Debian GNU/Linux 12 · bash 5.2 · permission lab" },
    { kind: "out", text: "Type `help` for commands, `ls -l` to begin." },
  ]);
  const [input, setInput] = useState("");
  const [hist, setHist] = useState<string[]>([]);
  const [hIdx, setHIdx] = useState(-1);
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const me = useMemo(
    () => IDENTITIES.find((i) => i.key === meKey) ?? IDENTITIES[0],
    [meKey],
  );

  useEffect(() => {
    if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight;
  }, [lines]);

  const find = (n: string) => fs.find((f) => f.name === n);

  function lsLine(f: VFile) {
    return `${modeStr(f.perms, f.type)} 1 ${f.owner.padEnd(5)} ${f.group.padEnd(
      5,
    )} ${String(f.size).padStart(5)} ${f.mtime} ${f.name}${
      f.type === "dir" ? "/" : ""
    }`;
  }

  function execute(raw: string): Entry[] {
    const line = raw.trim();
    if (!line) return [];
    const [cmd, ...args] = line.split(/\s+/);
    const out: Entry[] = [];
    const p = (t: string, k: Kind = "out") => out.push({ kind: k, text: t });

    switch (cmd) {
      case "help":
        HELP.forEach((h) => p(h));
        break;

      case "clear":
        setLines([]);
        return [];

      case "reset":
        setFs(initialFs());
        p("lab reset — all modes restored.", "ok");
        break;

      case "pwd":
        p("/home/narx");
        break;

      case "whoami":
        p(me.name);
        break;

      case "id":
        p(
          `uid=${me.uid}(${me.name}) gid=1000(${me.groups[0] ?? "users"}) groups=${me.groups
            .map((g, i) => `${1000 + i}(${g})`)
            .join(",")}`,
        );
        break;

      case "ls": {
        const flags = args.filter((a) => a.startsWith("-")).join("");
        const name = args.find((a) => !a.startsWith("-"));
        if (name) {
          const f = find(name);
          if (!f) p(`ls: cannot access '${name}': No such file or directory`, "err");
          else if (flags.includes("l")) p(lsLine(f));
          else p(f.type === "dir" ? `${f.name}/` : f.name);
        } else if (flags.includes("l")) {
          p("total " + fs.length * 4);
          fs.forEach((f) => p(lsLine(f)));
        } else {
          p(fs.map((f) => (f.type === "dir" ? f.name + "/" : f.name)).join("  "));
        }
        break;
      }

      case "cat": {
        const name = args[0];
        if (!name) {
          p("cat: missing operand", "err");
          break;
        }
        const f = find(name);
        if (!f) {
          p(`cat: ${name}: No such file or directory`, "err");
          break;
        }
        if (f.type === "dir") {
          p(`cat: ${name}: Is a directory`, "err");
          break;
        }
        if (!can(f.perms, klassOf(f, me), "r")) {
          p(`cat: ${name}: Permission denied`, "err");
          break;
        }
        (f.content ?? "").split("\n").forEach((l) => p(l));
        break;
      }

      case "chmod": {
        const [mode, target] = args;
        if (!mode || !target) {
          p("chmod: missing operand", "err");
          break;
        }
        const f = find(target);
        if (!f) {
          p(`chmod: cannot access '${target}': No such file or directory`, "err");
          break;
        }
        if (klassOf(f, me) !== "owner") {
          p(
            `chmod: changing permissions of '${target}': Operation not permitted`,
            "err",
          );
          break;
        }
        let perms: number;
        if (/^[0-7]{3,4}$/.test(mode)) {
          perms = parseInt(mode, 10) & 0o7777;
        } else {
          const r = applySymbolic(f.perms, mode);
          if (!r.ok) {
            p(`chmod: invalid mode: '${mode}'`, "err");
            break;
          }
          perms = r.perms;
        }
        if (perms === f.perms) break;
        setFs((prev) =>
          prev.map((x) => (x.name === f.name ? { ...x, perms } : x)),
        );
        p(
          `mode of '${f.name}' from ${modeStr(f.perms, f.type)} (${octal4(
            f.perms,
          )}) changed to ${modeStr(perms, f.type)} (${octal4(perms)})`,
          "ok",
        );
        break;
      }

      case "chown": {
        const spec = args[0];
        const target = args[1];
        if (!spec || !target) {
          p("chown: missing operand", "err");
          break;
        }
        const f = find(target);
        if (!f) {
          p(`chown: cannot access '${target}': No such file or directory`, "err");
          break;
        }
        if (f.owner !== me.name) {
          p(`chown: changing ownership of '${target}': Operation not permitted`, "err");
          break;
        }
        const [nu, ng] = spec.includes(":")
          ? (spec.split(":") as [string, string])
          : [spec, ""];
        if (nu && nu !== me.name) {
          p(`chown: changing ownership of '${target}': Operation not permitted`, "err");
          break;
        }
        if (ng && !me.groups.includes(ng)) {
          p(`chown: changing group of '${target}': Operation not permitted`, "err");
          break;
        }
        setFs((prev) =>
          prev.map((x) =>
            x.name === f.name
              ? { ...x, owner: nu || x.owner, group: ng || x.group }
              : x,
          ),
        );
        p(`ownership of '${f.name}' retained by ${nu || f.owner}:${ng || f.group}`, "ok");
        break;
      }

      case "stat": {
        const name = args[0];
        if (!name) {
          p("stat: missing operand", "err");
          break;
        }
        const f = find(name);
        if (!f) {
          p(`stat: cannot stat '${name}': No such file or directory`, "err");
          break;
        }
        p(`  File: ${f.name}`);
        p(
          `  Size: ${String(f.size).padEnd(14)}Blocks: 8          IO Block: 4096  ${
            f.type === "dir" ? "directory" : "regular file"
          }`,
        );
        p(`Device: 802h/2050d    Inode: 1288496     Links: 1`);
        p(
          `Access: (${octal4(f.perms)}/${modeStr(
            f.perms,
            f.type,
          )})  Uid: ( ${f.owner.padEnd(6)})   Gid: ( ${f.group.padEnd(6)})`,
        );
        p("Modify: 2024-11-18 10:50:56.000000000 +0000");
        p("Change: 2024-11-18 10:50:56.000000000 +0000");
        p(" Birth: -");
        break;
      }

      case "namei": {
        const path = args.find((a) => !a.startsWith("-"));
        if (!path) {
          p("namei: missing operand", "err");
          break;
        }
        p(`f: ${path}`);
        const parts = path.split("/").filter(Boolean);
        if (parts[0] !== "home" || parts[1] !== "narx") {
          p(`drwxr-xr-x root  root  /`);
          parts.forEach((seg) => p(`Missing: ${seg}`, "err"));
          break;
        }
        p(`drwxr-xr-x root  root  /`);
        p(`drwxr-xr-x root  root  home`);
        p(`drwxr-xr-x narx  users narx`);
        parts.slice(2).forEach((seg) => {
          const f = find(seg);
          if (f)
            p(
              `${modeStr(f.perms, f.type)} ${f.owner.padEnd(5)} ${f.group.padEnd(
                5,
              )} ${seg}`,
            );
          else p(`Missing: ${seg}`, "err");
        });
        break;
      }

      default:
        p(`bash: ${cmd}: command not found`, "err");
    }
    return out;
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const raw = input;
    setInput("");
    setHIdx(-1);
    if (!raw.trim()) return;
    setHist((h) => [raw, ...h].slice(0, 40));
    if (raw.trim().toLowerCase() === "clear") {
      setLines([]);
      return;
    }
    const entry: Entry = { kind: "in", text: raw.trim() };
    const res = execute(raw);
    setLines((l) => [...l, entry, ...res]);
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "ArrowUp") {
      e.preventDefault();
      const n = Math.min(hIdx + 1, hist.length - 1);
      if (n >= 0) {
        setHIdx(n);
        setInput(hist[n]);
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const n = hIdx - 1;
      setHIdx(n);
      setInput(n >= 0 ? hist[n] : "");
    }
  }

  const promptUser = me.name;
  const done = EXERCISES.filter((x) => x.check(fs)).length;

  const color: Record<Kind, string> = {
    in: "text-sage",
    out: "text-muted",
    err: "text-amber",
    ok: "text-phos",
    note: "text-phos/60",
  };

  return (
    <div className="grid gap-5 lg:grid-cols-12">
      {/* ---------------- terminal ---------------- */}
      <div className="lg:col-span-8">
        <div
          className="flex h-[430px] flex-col border border-phos/40 bg-[#060A08] md:h-[520px]"
          style={{ borderRadius: 2 }}
          onClick={() => inputRef.current?.focus()}
        >
          <div className="flex items-center justify-between border-b border-phos/25 bg-panel px-3 py-2">
            <span className="font-mono text-[10px] tracked text-phos">
              {promptUser}@lab:~ — /home/narx
            </span>
            <span className="font-mono text-[9.5px] tracked text-muted">
              bash 5.2 · simulated
            </span>
          </div>

          <div
            ref={boxRef}
            className="flex-1 overflow-y-auto px-3 py-3 font-mono text-[12.5px] leading-[1.6]"
          >
            {lines.map((l, i) =>
              l.kind === "in" ? (
                <div key={i} className="whitespace-pre-wrap break-words">
                  <span className="text-phos">{promptUser}</span>
                  <span className="text-muted">@lab:~$ </span>
                  <span className="text-sage">{l.text}</span>
                </div>
              ) : (
                <div
                  key={i}
                  className={`whitespace-pre-wrap break-words ${color[l.kind]}`}
                >
                  {l.text || "\u00A0"}
                </div>
              ),
            )}
          </div>

          <form
            onSubmit={submit}
            className="flex items-center gap-2 border-t border-phos/25 bg-panel/60 px-3 py-2.5"
          >
            <span className="shrink-0 font-mono text-[12.5px]">
              <span className="text-phos">{promptUser}</span>
              <span className="text-muted">@lab:~$</span>
            </span>
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              spellCheck={false}
              autoComplete="off"
              aria-label="Terminal input"
              className="min-w-0 flex-1 bg-transparent font-mono text-[12.5px] text-sage caret-phos outline-none placeholder:text-muted/50"
              placeholder="chmod o+x run.sh"
            />
            <button
              type="submit"
              className="shrink-0 border border-phos/50 px-2 py-1 font-mono text-[9.5px] tracked text-phos transition-colors hover:bg-phos hover:text-ink"
              style={{ borderRadius: 2 }}
            >
              Run
            </button>
          </form>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          {[
            "help",
            "ls -l",
            "cat NarX.txt",
            "stat run.sh",
            "namei -l /home/narx/notes.md",
            "id",
            "reset",
          ].map((c) => (
            <button
              key={c}
              onClick={() => {
                const res = execute(c);
                setLines((l) => [...l, { kind: "in", text: c }, ...res]);
                inputRef.current?.focus();
              }}
              className="border border-sage/25 px-2.5 py-1.5 font-mono text-[10px] text-sage/85 transition-colors hover:border-phos hover:text-phos"
              style={{ borderRadius: 2 }}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* ---------------- side panel ---------------- */}
      <div className="lg:col-span-4">
        <div className="border border-sage/20 bg-panel/60 p-4" style={{ borderRadius: 2 }}>
          <div className="font-mono text-[9.5px] tracked text-phos">
            Run the shell as
          </div>
          <div className="mt-2.5 grid grid-cols-3 gap-1.5">
            {IDENTITIES.map((id) => (
              <button
                key={id.key}
                onClick={() => setMeKey(id.key)}
                className={`border px-1.5 py-2 text-center transition-colors ${
                  meKey === id.key
                    ? "border-phos bg-deep text-phos"
                    : "border-sage/25 text-sage/70 hover:border-phos/60"
                }`}
                style={{ borderRadius: 2 }}
              >
                <span className="block font-mono text-[11px]">{id.name}</span>
                <span className="mt-0.5 block font-mono text-[8.5px] tracked">
                  {id.label}
                </span>
              </button>
            ))}
          </div>
          <p className="mt-2.5 font-mono text-[10px] leading-relaxed text-muted">
            {me.blurb}
          </p>
        </div>

        <div className="mt-4 border border-sage/20 bg-panel/60 p-4" style={{ borderRadius: 2 }}>
          <div className="flex items-baseline justify-between">
            <span className="font-mono text-[9.5px] tracked text-phos">
              Exercises
            </span>
            <span className="font-mono text-[10px] text-sage tabular-nums">
              {done}/{EXERCISES.length}
            </span>
          </div>
          <div className="mt-3 space-y-3">
            {EXERCISES.map((x) => {
              const ok = x.check(fs);
              return (
                <div
                  key={x.n}
                  className={`border-l-2 pl-3 transition-colors ${
                    ok ? "border-phos" : "border-sage/30"
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <span
                      className={`font-mono text-[10px] ${ok ? "text-phos" : "text-muted"}`}
                    >
                      {ok ? "✓" : x.n}
                    </span>
                    <span
                      className={`text-[12.5px] font-light leading-snug ${
                        ok ? "text-phos" : "text-sage/85"
                      }`}
                    >
                      {x.task}
                    </span>
                  </div>
                  {!ok && (
                    <div className="mt-1 break-words font-mono text-[10px] text-muted">
                      {x.hint}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {done === EXERCISES.length && (
            <div className="mt-3 border-t border-phos/40 pt-3 font-mono text-[10px] tracked text-phos">
              Lab complete · all three cleared
            </div>
          )}
        </div>

        <div className="mt-4 border border-sage/20 bg-panel/60 p-4" style={{ borderRadius: 2 }}>
          <div className="font-mono text-[9.5px] tracked text-phos">Cheat sheet</div>
          <div className="mt-2.5 space-y-1.5">
            {[
              ["chmod u+x file", "add execute to owner"],
              ["chmod g+w,o-r f", "two classes, one line"],
              ["chmod 755 file", "rwxr-xr-x"],
              ["chown narx:devs f", "owner + group"],
              ["cat file", "access is checked"],
            ].map(([a, b]) => (
              <div key={a} className="flex items-baseline justify-between gap-3">
                <code className="font-mono text-[10.5px] text-sage/90">{a}</code>
                <span className="text-right font-mono text-[9px] text-muted">{b}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
