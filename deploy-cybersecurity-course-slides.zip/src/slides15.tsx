import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch15Bullets,
  ch15Example,
  ch15Intro,
  ch15Stamp,
  contents15,
  idTypes,
  prevention,
  questions15,
  techniques,
  techniquesLead,
  TOTAL15,
} from "./data/ch15";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "fragmented ID card" backdrop
================================================================== */
function IdBackdrop() {
  const shards = [
    { x: 760, y: 200, w: 120, h: 70, r: -8, c: "#3DF07A" },
    { x: 900, y: 170, w: 140, h: 80, r: 6, c: "#C7D2C9" },
    { x: 1060, y: 230, w: 100, h: 60, r: -14, c: "#FFB020" },
    { x: 800, y: 330, w: 150, h: 90, r: 4, c: "#C7D2C9" },
    { x: 980, y: 340, w: 130, h: 80, r: -5, c: "#3DF07A" },
    { x: 850, y: 470, w: 110, h: 70, r: 10, c: "#FFB020" },
    { x: 1000, y: 460, w: 140, h: 85, r: -3, c: "#C7D2C9" },
  ];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="idFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {shards.map((s, n) => (
        <g key={n} transform={`translate(${s.x} ${s.y}) rotate(${s.r})`}>
          <rect width={s.w} height={s.h} fill="#0B0F0D" stroke={s.c} strokeOpacity="0.6" strokeWidth="1.5" />
          <rect x="8" y="8" width={s.h * 0.45} height={s.h * 0.55} fill={s.c} fillOpacity="0.18" stroke={s.c} strokeOpacity="0.4" />
          {[0, 1, 2].map((k) => (
            <rect key={k} x={s.h * 0.45 + 16} y={12 + k * 12} width={Math.max(20, s.w - s.h * 0.45 - 30) * (k === 0 ? 1 : 0.7)} height="4" fill={s.c} fillOpacity={0.35 - k * 0.08} />
          ))}
        </g>
      ))}
      <g fontFamily="IBM Plex Mono, monospace" fontSize="11" fill="#C7D2C9" fillOpacity="0.22">
        <text x="700" y="140">XXXX-XXXX-4821</text>
        <text x="1010" y="620">SSN ***-**-1093</text>
        <text x="720" y="600">DOB 07/14/19▮▮</text>
      </g>
      <rect width="1200" height="700" fill="url(#idFade)" />
    </svg>
  );
}

export function TitleSlide15({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <IdBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Personal data briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 15 of 16</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.15&nbsp;//&nbsp;IDENTITY-THEFT</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL15}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 15</span>
              <span className="mt-1 block text-[clamp(2.2rem,6.8vw,5.8rem)] text-phos glow">Identity Theft</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch15Intro} Eight types, six techniques and thirteen habits that
              keep your identity your own.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(7)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to prevention</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Theft types", "Eight"], ["Techniques", "Six"], ["Prevention steps", "Thirteen"], ["Doc revision", ch15Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT IDENTITY THEFT IS
================================================================== */
export function IntroSlide15() {
  return (
    <Slide tag="SEC // CH.15 // DEFINITION" num="02" title={<>What <span className="text-phos">identity theft</span> is</>} lede={ch15Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch15Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Example</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{ch15Example}</p>
            <div className="mt-4 grid grid-cols-3 gap-px bg-sage/15">
              {[["Steal", "Breach a database"], ["Use", "Buy · borrow"], ["Damage", "Credit history"]].map(([h, d]) => (
                <div key={h} className="bg-ink p-3">
                  <div className="font-display text-[0.9rem] uppercase text-phos">{h}</div>
                  <p className="mt-1 text-[11px] font-light text-muted">{d}</p>
                </div>
              ))}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · EIGHT TYPES — OVERVIEW
================================================================== */
export function TypesIndexSlide15() {
  return (
    <Slide tag="SEC // CH.15 // TYPES" num="03" title={<>Eight <span className="text-phos">types of identity theft</span></>} lede="Each type is named for the asset stolen or the victim targeted. Amber marks the forms with the longest-lasting or hardest-to-undo consequences." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {idTypes.map((t, n) => (
          <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.05 } } }} className="bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px]" style={{ color: TONE[t.tone] }}>{t.i}</span>
              <span className="h-1.5 w-6" style={{ background: TONE[t.tone] }} />
            </div>
            <h3 className="mt-3 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared type-detail slide (4 per slide)
================================================================== */
function TypeDetail({ from, to, num, head }: { from: number; to: number; num: string; head: string }) {
  const slice = idTypes.slice(from, to);
  return (
    <Slide tag={`SEC // CH.15 // TYPES ${slice[0].i}–${slice[slice.length - 1].i}`} num={num} title={<>Types — <span className="text-phos">{head}</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {slice.map((t, n) => (
          <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[t.tone] }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[t.tone] }}>Type {t.i}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
            </div>
            <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[t.tone] }} />{p}
                </li>
              ))}
            </ul>
            <div className="grid grid-cols-2 gap-px border-t border-sage/15 bg-sage/10">
              <div className="bg-ink p-3">
                <div className="font-mono text-[9px] tracked text-muted">Asset</div>
                <div className="mt-1 text-[11.5px] text-sage/90">{t.asset}</div>
              </div>
              <div className="bg-ink p-3">
                <div className="font-mono text-[9px] tracked text-muted">Discovered via</div>
                <div className="mt-1 text-[11.5px] text-sage/90">{t.discovered}</div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

export const TypesA15 = () => <TypeDetail from={0} to={4} num="04" head="criminal, senior, licence, medical" />;
export const TypesB15 = () => <TypeDetail from={4} to={8} num="05" head="tax, SSN, synthetic, financial" />;

/* ==================================================================
   06 · ASSET & DISCOVERY MATRIX
================================================================== */
export function MatrixSlide15() {
  const speed: Record<string, number> = { "01": 2, "02": 2, "03": 2, "04": 1, "05": 2, "06": 1, "07": 0, "08": 3 };
  const labels = ["Very slow", "Slow", "Moderate", "Fast"];
  return (
    <Slide tag="SEC // CH.15 // MATRIX" num="06" title={<>Asset &amp; <span className="text-phos">discovery</span> matrix</>} lede="What each type steals, how the victim usually finds out, and how quickly. The slower the discovery, the more damage accumulates — synthetic identity theft is the worst case." dense>
      <div className="overflow-x-auto">
        <div className="min-w-[720px]">
          <div className="grid grid-cols-[minmax(0,1fr)_11rem_13rem_9rem] gap-x-4 border-b border-sage/20 pb-2 font-mono text-[9.5px] tracked text-muted">
            <span>Type</span><span>Asset stolen</span><span>Discovered via</span><span className="text-center">Detection speed</span>
          </div>
          {idTypes.map((t, n) => (
            <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.04 } } }} className="grid grid-cols-[minmax(0,1fr)_11rem_13rem_9rem] items-center gap-x-4 border-t border-sage/10 py-2.5 hover:bg-phos/[0.04]">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[11px]" style={{ color: TONE[t.tone] }}>{t.i}</span>
                <span className="font-mono text-[12px] text-sage">{t.name}</span>
              </div>
              <span className="text-[12.5px] font-light text-sage/85">{t.asset}</span>
              <span className="text-[12.5px] font-light text-sage/85">{t.discovered}</span>
              <div className="flex flex-col items-center gap-1">
                <span className="flex gap-1">
                  {[0, 1, 2, 3].map((k) => (
                    <span key={k} className="inline-block h-2.5 w-4" style={{ background: k <= speed[t.i] ? (speed[t.i] === 0 ? TONE.amber : TONE.phos) : "transparent", border: k <= speed[t.i] ? "none" : "1px solid rgba(199,210,201,0.15)" }} />
                  ))}
                </span>
                <span className="font-mono text-[9px] tracked" style={{ color: speed[t.i] === 0 ? TONE.amber : "rgba(126,143,132,1)" }}>{labels[speed[t.i]]}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · TECHNIQUES
================================================================== */
export function TechniquesSlide15() {
  return (
    <Slide tag="SEC // CH.15 // TECHNIQUES" num="07" title={<>Techniques of <span className="text-phos">identity theft</span></>} lede={techniquesLead} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {techniques.map((t, n) => (
          <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="flex flex-col bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px]" style={{ color: t.physical ? TONE.amber : TONE.phos }}>{t.i}</span>
              <Tag tone={t.physical ? "amber" : "phos"}>{t.channel}</Tag>
            </div>
            <h3 className="mt-3 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <ul className="mt-3 flex-1 border-t border-sage/10 pt-2">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: t.physical ? TONE.amber : TONE.phos }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-5 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[9.5px] tracked text-muted">
        <span className="flex items-center gap-2"><span className="inline-block h-2 w-5 bg-phos" /> Digital or voice — defeated by scepticism and verification</span>
        <span className="flex items-center gap-2"><span className="inline-block h-2 w-5 bg-amber" /> Physical — defeated by a shredder and a locked mailbox</span>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   08 · PREVENTION
================================================================== */
export function PreventionSlide15() {
  const groups = ["Accounts", "Devices", "Data", "Documents", "Behaviour"];
  return (
    <Slide tag="SEC // CH.15 // PREVENTION" num="08" title={<>Prevention from <span className="text-phos">identity theft</span></>} lede="Thirteen habits grouped by what they protect. The behaviour column matters most — every technique on the previous slide depends on the victim cooperating." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {groups.map((g, gi) => {
          const items = prevention.filter((p) => p.group === g);
          const hot = g === "Behaviour";
          return (
            <motion.div key={g} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: gi * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: hot ? TONE.amber : TONE.phos }}>
              <div className="flex items-center justify-between p-4 pb-2">
                <h3 className="font-display text-[1rem] uppercase tracking-tight text-sage">{g}</h3>
                <span className="font-mono text-[10px]" style={{ color: hot ? TONE.amber : TONE.phos }}>{items.length}</span>
              </div>
              <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
                {items.map((p) => (
                  <li key={p.i} className="border-t border-sage/10 py-2 first:border-t-0 first:pt-0">
                    <div className="flex items-start gap-2">
                      <span className="font-mono text-[10px] text-muted">{p.i}</span>
                      <div>
                        <div className="text-[12.5px] font-medium text-sage">{p.name}</div>
                        <p className="mt-0.5 text-[11.5px] font-light leading-[1.45] text-muted">{p.desc}</p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </motion.div>
          );
        })}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide15({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.15 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Whose identity?
          <br />
          <span className="text-phos glow">Which type?</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the definition, a phishing scenario, an OTP
          call, a driving-licence case and a synthetic identity. Select an
          answer to reveal it instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(9)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   10–14 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide15({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions15[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.15 // CHECK // Q0${n + 1}`} num={String(10 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Identity theft"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · SCORE
================================================================== */
export function ScoreSlide15({ answers }: { answers: (number | null)[] }) {
  const score = questions15.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions15.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every type identified." : pct >= 60 ? "Solid. Re-read the eight types and match each to its stolen asset." : "Revisit the types overview and the techniques slide, then retake.";
  return (
    <Slide tag="SEC // CH.15 // CHECK // RESULT" num="15" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions15.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions15.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions15.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide15() {
  const items = [
    ["01", "Identity is a bundle of numbers", "Aadhaar, PAN, SSN, licence, card — steal one and the rest often follow."],
    ["02", "Type follows the asset", "Name the stolen thing and you have named the theft: licence, medical, tax, financial."],
    ["03", "Synthetic is the slow burn", "Real fragments plus fabrication build an identity nobody is watching — detection takes years."],
    ["04", "Most techniques need your help", "Pretext calls, phishing and CVV requests only work if the victim answers. Silence is a control."],
    ["05", "Paper still leaks", "Mail theft and dumpster diving are low-tech and effective — shred, and lock the mailbox."],
    ["06", "Never share an OTP", "No bank, no support desk, no official will ever legitimately ask for one."],
  ];
  return (
    <Slide tag="SEC // CH.15 // CLOSE" num="16" title={<>Chapter 15 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 15 · Identity Theft</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents15.length} sections · {TOTAL15} slides</span>
      </div>
    </Slide>
  );
}
