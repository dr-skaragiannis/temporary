import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch11Bullets,
  ch11Intro,
  ch11Stamp,
  commonVectors,
  contents11,
  defences,
  incidents,
  questions11,
  TOTAL11,
  vectors,
} from "./data/ch11";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "radar sweep with incoming vectors" backdrop
================================================================== */
function VectorBackdrop() {
  const arrows = [
    { a: -20, len: 260, warm: true },
    { a: 15, len: 300, warm: false },
    { a: 48, len: 240, warm: true },
    { a: 95, len: 280, warm: false },
    { a: 140, len: 250, warm: false },
    { a: 200, len: 290, warm: true },
    { a: 250, len: 230, warm: false },
    { a: 300, len: 270, warm: true },
  ];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="vbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <linearGradient id="vbSweep" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#3DF07A" stopOpacity="0" />
          <stop offset="100%" stopColor="#3DF07A" stopOpacity="0.28" />
        </linearGradient>
        <filter id="vbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => (
          <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />
        ))}
        {Array.from({ length: 15 }).map((_, n) => (
          <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />
        ))}
      </g>
      <g transform="translate(930 350)">
        {[80, 160, 240].map((r) => (
          <circle key={r} r={r} fill="none" stroke="#3DF07A" strokeOpacity="0.18" strokeDasharray={r === 160 ? "6 8" : undefined} />
        ))}
        <path d="M0 0 L240 0 A240 240 0 0 0 170 -170 Z" fill="url(#vbSweep)" />
        <line x1="-260" y1="0" x2="260" y2="0" stroke="#3DF07A" strokeOpacity="0.25" />
        <line x1="0" y1="-260" x2="0" y2="260" stroke="#3DF07A" strokeOpacity="0.25" />
        {arrows.map(({ a, len, warm }) => {
          const r = (a * Math.PI) / 180;
          const x1 = Math.cos(r) * len;
          const y1 = Math.sin(r) * len;
          const x2 = Math.cos(r) * (len - 110);
          const y2 = Math.sin(r) * (len - 110);
          const c = warm ? "#FFB020" : "#3DF07A";
          const tip = 9;
          const px = x2 + Math.cos(r + 2.7) * tip;
          const py = y2 + Math.sin(r + 2.7) * tip;
          const qx = x2 + Math.cos(r - 2.7) * tip;
          const qy = y2 + Math.sin(r - 2.7) * tip;
          return (
            <g key={a}>
              <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeOpacity="0.55" strokeWidth="1.5" strokeDasharray="7 5" />
              <polygon points={`${x2},${y2} ${px},${py} ${qx},${qy}`} fill={c} fillOpacity="0.85" />
              <g filter="url(#vbGlow)">
                <circle cx={x1} cy={y1} r="4" fill={c} />
              </g>
            </g>
          );
        })}
        <g filter="url(#vbGlow)">
          <circle r="7" fill="#C7D2C9" />
        </g>
      </g>
      <rect width="1200" height="700" fill="url(#vbFade)" />
    </svg>
  );
}

export function TitleSlide11({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <VectorBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Threat landscape briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 11 of 16</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.11&nbsp;//&nbsp;ATTACK-VECTORS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL11}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 11</span>
              <span className="mt-1 block text-[clamp(2rem,6.2vw,5.4rem)] text-phos glow">Emerging Attack Vectors</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch11Intro} Six emerging vectors, the seven established ones they
              build on, four recent incidents and the four controls that
              protect an organization against them.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(7)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to recent incidents</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Emerging vectors", "Six"], ["Common vectors", "Seven"], ["Defences", "Four"], ["Doc revision", ch11Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT AN ATTACK VECTOR IS
================================================================== */
export function IntroSlide11() {
  return (
    <Slide tag="SEC // CH.11 // DEFINITION" num="02" title={<>What an <span className="text-phos">attack vector</span> is</>} lede={ch11Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch11Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Vector vs. vulnerability</div>
            <div className="mt-3 grid grid-cols-2 gap-px bg-sage/15">
              <div className="bg-ink p-3">
                <div className="font-display text-[0.95rem] uppercase text-sage">Vulnerability</div>
                <p className="mt-1 text-[12px] font-light text-muted">The weakness — an unpatched flaw, a misconfiguration, a trusting employee.</p>
              </div>
              <div className="bg-ink p-3">
                <div className="font-display text-[0.95rem] uppercase text-phos">Vector</div>
                <p className="mt-1 text-[12px] font-light text-muted">The path the attacker takes to reach and exploit that weakness.</p>
              </div>
            </div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">
              "Emerging" means the path is new — because the technology it
              travels through is new, or because the technique keeps changing
              faster than signatures can follow.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · SIX EMERGING VECTORS — INDEX
================================================================== */
export function VectorIndexSlide11() {
  return (
    <Slide tag="SEC // CH.11 // INDEX" num="03" title={<>Six <span className="text-phos">emerging vectors</span></>} lede="Each one rides a modern technology or a new technique. Colour marks the primary surface: people and third parties in amber, systems in green." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {vectors.map((v, n) => (
          <motion.div key={v.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px]" style={{ color: TONE[v.tone] }}>{v.i}</span>
              <span className="font-mono text-[9.5px] tracked text-muted">{v.surface}</span>
            </div>
            <h3 className="mt-3 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{v.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{v.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared vector-detail slide (3 per slide)
================================================================== */
function VectorDetail({ from, to, num, head }: { from: number; to: number; num: string; head: string }) {
  const slice = vectors.slice(from, to);
  return (
    <Slide tag={`SEC // CH.11 // VECTORS ${slice[0].i}–${slice[slice.length - 1].i}`} num={num} title={<>Vectors — <span className="text-phos">{head}</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {slice.map((v, n) => (
          <motion.div
            key={v.i}
            variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }}
            className="flex flex-col border border-sage/15 bg-panel/60"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[v.tone] }}
          >
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[v.tone] }}>Vector {v.i} · {v.surface}</span>
              <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{v.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{v.desc}</p>
            </div>
            <div className="grid flex-1 grid-cols-1 gap-px border-t border-sage/15 bg-sage/10">
              <div className="bg-ink p-4">
                <div className="font-mono text-[9.5px] tracked text-phos">Example</div>
                <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{v.example}</p>
              </div>
              <div className="bg-ink p-4">
                <div className="font-mono text-[9.5px] tracked text-amber">Impact</div>
                <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{v.impact}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

export const VectorsA11 = () => <VectorDetail from={0} to={3} num="04" head="AI, IoT & cloud" />;
export const VectorsB11 = () => <VectorDetail from={3} to={6} num="05" head="deepfake, supply chain & fileless" />;

/* ==================================================================
   06 · VECTOR MATRIX
================================================================== */
export function MatrixSlide11() {
  const cols = ["Detection difficulty", "Scale", "Human element", "Third-party"];
  const map: Record<string, number[]> = {
    "01": [3, 2, 3, 1],
    "02": [2, 3, 1, 2],
    "03": [2, 3, 2, 2],
    "04": [3, 1, 3, 1],
    "05": [3, 3, 1, 3],
    "06": [3, 1, 1, 1],
  };
  return (
    <Slide tag="SEC // CH.11 // MATRIX" num="06" title={<>Vector <span className="text-phos">matrix</span></>} lede="A rough profile of each emerging vector across four dimensions. Three filled blocks means high; one means low." dense>
      <div className="overflow-x-auto">
        <div className="min-w-[680px]">
          <div className="grid grid-cols-[minmax(0,1fr)_repeat(4,8.5rem)] gap-x-3 border-b border-sage/20 pb-2 font-mono text-[9.5px] tracked text-muted">
            <span>Vector</span>
            {cols.map((c) => (<span key={c} className="text-center">{c}</span>))}
          </div>
          {vectors.map((v, n) => (
            <motion.div key={v.i} variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="grid grid-cols-[minmax(0,1fr)_repeat(4,8.5rem)] items-center gap-x-3 border-t border-sage/10 py-3 hover:bg-phos/[0.04]">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[11px]" style={{ color: TONE[v.tone] }}>{v.i}</span>
                <span className="font-mono text-[12px] text-sage">{v.name}</span>
              </div>
              {map[v.i].map((lvl, c) => (
                <span key={c} className="flex justify-center gap-1">
                  {[1, 2, 3].map((k) => (
                    <span key={k} className="inline-block h-3 w-5" style={{ background: k <= lvl ? (lvl === 3 ? TONE.amber : TONE.phos) : "transparent", border: k <= lvl ? "none" : "1px solid rgba(199,210,201,0.15)" }} />
                  ))}
                </span>
              ))}
            </motion.div>
          ))}
        </div>
      </div>
      <motion.p variants={rise} className="mt-5 font-mono text-[10px] tracked text-muted">
        Every emerging vector scores high on at least one dimension where traditional controls are weakest.
      </motion.p>
    </Slide>
  );
}

/* ==================================================================
   07 · COMMON VECTORS
================================================================== */
export function CommonSlide11() {
  return (
    <Slide tag="SEC // CH.11 // COMMON" num="07" title={<>The <span className="text-phos">established</span> vectors</>} lede="The emerging vectors are built on top of these. AI phishing is still phishing; an IoT botnet still delivers DoS; fileless malware is still malware." dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {commonVectors.map((c, n) => (
            <Row key={c.i} i={c.i} label={c.name} desc={c.desc} meta={c.meta} delay={n * 0.035} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Old → new</div>
            <ul className="mt-3">
              {[["Phishing", "AI-generated phishing · deepfakes"], ["DoS", "IoT botnets"], ["Malware", "Fileless · in-memory"], ["Insider", "Compromised vendor (supply chain)"], ["Data theft", "Open cloud buckets"]].map(([a, b]) => (
                <li key={a} className="grid grid-cols-[6rem_1fr] gap-2 border-t border-sage/10 py-2 text-[12px]">
                  <span className="font-mono text-sage/70">{a}</span>
                  <span className="font-light text-sage/90">→ {b}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · RECENT INCIDENTS
================================================================== */
export function IncidentsSlide11() {
  return (
    <Slide tag="SEC // CH.11 // INCIDENTS" num="08" title={<>Recent <span className="text-phos">cyber security attacks</span></>} lede="Four incidents from 2023–2024 — two data breaches and two ransomware operations against very large organizations." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {incidents.map((x, n) => (
          <motion.div
            key={x.org}
            variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }}
            className="flex flex-col border border-sage/15 bg-panel/60"
            style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[x.tone] }}
          >
            <div className="p-5">
              <div className="flex items-center justify-between">
                <span className="font-display text-[1.6rem] leading-none" style={{ color: TONE[x.tone] }}>{x.year}</span>
                <Tag tone={x.tone === "amber" ? "amber" : "phos"}>{x.kind}</Tag>
              </div>
              <h3 className="mt-3 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{x.org}</h3>
            </div>
            <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
              {x.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[x.tone] }} />
                  {p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · DEFENCES
================================================================== */
export function DefencesSlide11() {
  return (
    <Slide tag="SEC // CH.11 // DEFENCE" num="09" title={<>Protect your <span className="text-phos">organization</span></>} lede="Four foundational controls. None is sufficient alone — together they contain, detect, block and neutralize." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {defences.map((d, n) => (
          <motion.div key={d.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="flex flex-col bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{d.i}</span>
              <span className="border border-phos/50 px-1.5 py-[2px] font-mono text-[9px] tracked text-phos" style={{ borderRadius: 2 }}>✓</span>
            </div>
            <h3 className="mt-3 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{d.name}</h3>
            <p className="mt-2.5 flex-1 text-[13px] font-light leading-[1.6] text-muted">{d.desc}</p>
            <div className="mt-3 border-t border-sage/10 pt-2 font-mono text-[9.5px] leading-[1.5] tracked text-amber/80">Counters: {d.counters}</div>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-6 grid grid-cols-4 gap-px bg-sage/15 font-mono text-[9.5px] tracked">
        {["Contain", "Detect & block", "Clean", "Protect data"].map((w, n) => (
          <div key={w} className="bg-panel/70 p-2.5 text-center text-sage/80">{String(n + 1).padStart(2, "0")} · {w}</div>
        ))}
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   10 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide11({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.11 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Name the vector.
          <br />
          <span className="text-phos glow">Choose the control.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the definition of an attack vector, what makes one
          "emerging", a MITM scenario, the goal of ransomware and the right
          real-time defence. Select an answer to reveal it instantly — the
          rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(10)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   11–15 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide11({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions11[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.11 // CHECK // Q0${n + 1}`} num={String(11 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Attack vectors"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · SCORE
================================================================== */
export function ScoreSlide11({ answers }: { answers: (number | null)[] }) {
  const score = questions11.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions11.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every vector named, every control chosen." : pct >= 60 ? "Solid. Re-read the vector you missed and the control that counters it." : "Revisit the six vectors and the defences slide, then retake.";
  return (
    <Slide tag="SEC // CH.11 // CHECK // RESULT" num="16" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions11.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions11.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions11.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   17 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide11() {
  const items = [
    ["01", "New technology, new path", "Cloud, AI and IoT each open an attack surface that did not exist a few years ago."],
    ["02", "Emerging is built on established", "AI phishing is still phishing; an IoT botnet still delivers DoS. Master the basics first."],
    ["03", "Detection is the hard part", "Fileless malware, deepfakes and realistic AI lures defeat signature-based tools."],
    ["04", "Trust is a vector", "Supply-chain and deepfake attacks exploit relationships — vendors, updates, executives."],
    ["05", "Nobody is too big", "Boeing, Hyundai, a national medical council — scale is not protection."],
    ["06", "Layer the four controls", "Segment to contain, IDPS to detect and block, anti-malware to clean, encryption to protect what leaks."],
  ];
  return (
    <Slide tag="SEC // CH.11 // CLOSE" num="17" title={<>Chapter 11 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 11 · Emerging Attack Vectors</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents11.length} sections · {TOTAL11} slides</span>
      </div>
    </Slide>
  );
}
