import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch14Bullets,
  ch14Intro,
  ch14Stamp,
  contents14,
  methods,
  phishTypes,
  prevention,
  questions14,
  signs,
  siteChecks,
  tools,
  toolsNote,
  TOTAL14,
} from "./data/ch14";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "hook and lure" backdrop
================================================================== */
function HookBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="hkFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="hkGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="6" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* line from top */}
      <line x1="940" y1="0" x2="940" y2="300" stroke="#C7D2C9" strokeOpacity="0.35" strokeDasharray="3 6" />
      {/* hook */}
      <path d="M940 300 v90 a55 55 0 1 0 110 0 v-30" fill="none" stroke="#FFB020" strokeOpacity="0.85" strokeWidth="4" strokeLinecap="round" filter="url(#hkGlow)" />
      <path d="M1050 360 l-14 -22 M1050 360 l18 -16" stroke="#FFB020" strokeOpacity="0.85" strokeWidth="4" strokeLinecap="round" />
      {/* bait: envelope */}
      <g transform="translate(905 395)" filter="url(#hkGlow)">
        <rect width="70" height="46" fill="#0B0F0D" stroke="#3DF07A" strokeWidth="2" />
        <path d="M0 0 L35 26 L70 0" fill="none" stroke="#3DF07A" strokeWidth="2" />
      </g>
      {/* ripples */}
      <g transform="translate(940 560)">
        {[60, 130, 210].map((r, n) => (
          <ellipse key={r} rx={r} ry={r * 0.28} fill="none" stroke="#3DF07A" strokeOpacity={0.35 - n * 0.1} />
        ))}
      </g>
      {/* decoy URLs drifting */}
      <g fontFamily="IBM Plex Mono, monospace" fontSize="11" fill="#C7D2C9" fillOpacity="0.25">
        <text x="700" y="150">http://amazom.com/order_id=23</text>
        <text x="760" y="640">www.sugarcube.com/facebook</text>
        <text x="1000" y="220">paypa1-secure.net</text>
      </g>
      <rect width="1200" height="700" fill="url(#hkFade)" />
    </svg>
  );
}

export function TitleSlide14({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <HookBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Deception briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 14 of 16</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.14&nbsp;//&nbsp;PHISHING</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL14}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 14</span>
              <span className="mt-1 block text-[clamp(3rem,9vw,7.5rem)] text-phos glow">Phishing</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch14Intro} Four delivery methods, six attack types, six warning
              signs, a four-step test for fake websites, and the tools that
              help — with the reminder that none of them replace attention.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(7)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to fake vs real</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Delivery methods", "Four"], ["Attack types", "Six"], ["Website checks", "Four"], ["Doc revision", ch14Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT PHISHING IS
================================================================== */
export function IntroSlide14() {
  return (
    <Slide tag="SEC // CH.14 // DEFINITION" num="02" title={<>What <span className="text-phos">phishing</span> is</>} lede={ch14Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch14Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">The fishing metaphor</div>
            <div className="mt-3 grid grid-cols-3 gap-px bg-sage/15">
              {[["Bait", "A message that looks trusted"], ["Hook", "A link, file or form"], ["Catch", "Your credentials"]].map(([h, d]) => (
                <div key={h} className="bg-ink p-3">
                  <div className="font-display text-[0.95rem] uppercase text-phos">{h}</div>
                  <p className="mt-1 text-[11.5px] font-light leading-[1.45] text-muted">{d}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">
              Phishing is the delivery mechanism for much of what earlier
              chapters covered: it is how malware arrives, how botnets recruit
              and how social engineers make first contact.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · METHODS
================================================================== */
export function MethodsSlide14() {
  return (
    <Slide tag="SEC // CH.14 // METHODS" num="03" title={<>How it <span className="text-phos">reaches you</span></>} lede="Phishing can occur in several ways. Any of the methods below can lead a user into a phishing attack." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {methods.map((m, n) => (
          <motion.div key={m.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <div className="p-5">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[9.5px] tracked text-phos">Method {m.i}</span>
                <Tag tone="muted">{m.channel}</Tag>
              </div>
              <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{m.name}</h3>
              <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{m.desc}</p>
            </div>
            <ul className="flex-1 border-t border-sage/15 bg-ink p-4">
              {m.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-phos" />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · SIX TYPES
================================================================== */
export function TypesSlide14() {
  return (
    <Slide tag="SEC // CH.14 // TYPES" num="04" title={<>Six <span className="text-phos">types of phishing</span></>} lede="Classified by channel and by how carefully the victim is chosen. Amber marks the highest-stakes, most-targeted forms." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {phishTypes.map((t, n) => (
          <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="flex flex-col bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px]" style={{ color: TONE[t.tone] }}>{t.i}</span>
              <div className="flex gap-1.5">
                <Tag tone="muted">{t.channel}</Tag>
                <Tag tone={t.tone === "amber" ? "amber" : t.tone === "phos" ? "phos" : "muted"}>{t.targeting}</Tag>
              </div>
            </div>
            <h3 className="mt-3 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
            <ul className="mt-3 flex-1 border-t border-sage/10 pt-2">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1 text-[12px] font-light leading-[1.45] text-sage/85">
                  <span className="mt-[6px] h-1 w-1 shrink-0" style={{ background: TONE[t.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · TARGETING SPECTRUM
================================================================== */
export function SpectrumSlide14() {
  const cols = ["Mass", "Targeted", "Executive"] as const;
  const rows = ["Email", "SMS", "Voice"];
  return (
    <Slide tag="SEC // CH.14 // SPECTRUM" num="05" title={<>Targeting <span className="text-phos">spectrum</span></>} lede="The same six attacks arranged by channel and precision. Moving right means more research per victim, fewer victims, and far higher payoff per success." dense>
      <div className="overflow-x-auto">
        <div className="min-w-[640px]">
          <div className="grid grid-cols-[6rem_repeat(3,1fr)] gap-px bg-sage/15">
            <div className="bg-ink p-3 font-mono text-[9.5px] tracked text-muted">Channel ↓ / Precision →</div>
            {cols.map((c, n) => (
              <div key={c} className="bg-ink p-3 text-center font-display text-[0.95rem] uppercase" style={{ color: n === 2 ? TONE.amber : n === 1 ? TONE.phos : TONE.sage }}>{c}</div>
            ))}
            {rows.map((r) => (
              <>
                <div key={`${r}-h`} className="bg-ink p-3 font-mono text-[11px] text-sage">{r}</div>
                {cols.map((c) => {
                  const hits = phishTypes.filter((t) => t.channel === r && t.targeting === c);
                  return (
                    <motion.div key={`${r}-${c}`} variants={rise} className="min-h-[72px] bg-ink p-3">
                      {hits.length === 0 ? (
                        <span className="font-mono text-[10px] text-sage/25">—</span>
                      ) : (
                        hits.map((h) => (
                          <div key={h.i} className="mb-1.5 border-l-2 pl-2" style={{ borderColor: TONE[h.tone] }}>
                            <div className="font-mono text-[12px] text-sage">{h.name}</div>
                            <div className="text-[11px] font-light text-muted">{h.points[0]}</div>
                          </div>
                        ))
                      )}
                    </motion.div>
                  );
                })}
              </>
            ))}
          </div>
        </div>
      </div>
      <motion.div variants={rise} className="mt-5 grid gap-px bg-sage/15 sm:grid-cols-3 font-mono text-[9.5px] tracked">
        <div className="bg-panel/70 p-3 text-sage/80">Mass → volume; generic bait; easy to spot</div>
        <div className="bg-panel/70 p-3 text-phos">Targeted → research; personalised; convincing</div>
        <div className="bg-panel/70 p-3 text-amber">Executive → whaling; payment authority; urgent</div>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   06 · SIGNS
================================================================== */
export function SignsSlide14() {
  return (
    <Slide tag="SEC // CH.14 // SIGNS" num="06" title={<>Signs of <span className="text-phos">phishing</span></>} lede="Identifying the signs of phishing helps users avoid falling victim." dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {signs.map((s, n) => (
            <Row key={s.i} i={s.i} label={s.name} desc={s.desc} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-0">
            <div className="border-b border-sage/15 p-4 font-mono text-[9.5px] tracked text-amber">Specimen · annotated</div>
            <div className="p-4 font-mono text-[11.5px] leading-[1.7]">
              <div><span className="text-muted">From:</span> <span className="text-sage">security@</span><span className="text-amber underline decoration-dotted">paypa1-secure.net</span> <span className="text-[9.5px] text-amber">← 01 · 06</span></div>
              <div><span className="text-muted">Subject:</span> <span className="text-sage">URGENT: Acount suspended</span> <span className="text-[9.5px] text-amber">← 02 · 03</span></div>
              <div className="mt-2 border-t border-sage/10 pt-2 text-sage/85">
                Dear Costumer, <span className="text-[9.5px] text-amber">← 03</span><br />
                We detected unusual activty. Confirm your password and card number within 24 hours <span className="text-[9.5px] text-amber">← 02 · 04</span> or your account will be closed.<br />
                <span className="text-phos underline">http://paypa1-secure.net/verify</span> <span className="text-[9.5px] text-amber">← 05 · 06</span>
              </div>
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · PREVENTION
================================================================== */
export function PreventionSlide14() {
  return (
    <Slide tag="SEC // CH.14 // PREVENTION" num="07" title={<>Preventive <span className="text-phos">measures</span></>} lede="Users can avoid phishing by following these precautions." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {prevention.map((p, n) => (
          <motion.div key={p.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] text-phos/70">{p.i}</span>
              <span className="border border-phos/50 px-1.5 py-[2px] font-mono text-[9px] tracked text-phos" style={{ borderRadius: 2 }}>✓</span>
            </div>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{p.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · FAKE VS REAL WEBSITE
================================================================== */
export function FakeRealSlide14() {
  return (
    <Slide tag="SEC // CH.14 // FAKE VS REAL" num="08" title={<>Fake website or <span className="text-phos">real website?</span></>} lede="Four checks, in the order you should run them — the first two take seconds and catch most clones." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {siteChecks.map((c, n) => (
          <motion.div key={c.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked text-phos">Check {c.i}</span>
              <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
              <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{c.desc}</p>
              <ul className="mt-3 border-t border-sage/10 pt-2">
                {c.points.map((p) => (
                  <li key={p} className="flex gap-2.5 py-1 text-[12px] font-light leading-[1.45] text-sage/85">
                    <span className="mt-[6px] h-1 w-1 shrink-0 bg-phos" />{p}
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-auto grid gap-px border-t border-sage/15 bg-sage/10">
              <div className="bg-ink p-3">
                <div className="font-mono text-[9px] tracked text-phos">✓ Real</div>
                <div className="mt-1 break-all font-mono text-[11px] text-sage/90">{c.good}</div>
              </div>
              <div className="bg-ink p-3">
                <div className="font-mono text-[9px] tracked text-amber">✕ Fake</div>
                <div className="mt-1 break-all font-mono text-[11px] text-amber/90">{c.bad}</div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · TOOLS
================================================================== */
export function ToolsSlide14() {
  return (
    <Slide tag="SEC // CH.14 // TOOLS" num="09" title={<>Anti-phishing <span className="text-phos">tools</span></>} lede="These tools help detect phishing attacks." dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-8">
          {tools.map((t, n) => (
            <Row key={t.name} i={String(n + 1).padStart(2, "0")} label={t.name} desc={t.desc} meta={t.how} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-4">
          <div className="border-l-2 border-amber bg-amber/[0.07] p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Note</div>
            <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{toolsNote}</p>
          </div>
          <Panel className="mt-4 p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">Three detection approaches</div>
            <ul className="mt-3 space-y-2 text-[12.5px] font-light leading-[1.5] text-sage/85">
              <li><span className="font-mono text-sage">Lists</span> — known bad sites (PhishTank, Kaspersky). Fast, but blind to brand-new domains.</li>
              <li><span className="font-mono text-sage">Real-time</span> — check on visit (APDA, Malwarebytes). Catches newer sites.</li>
              <li><span className="font-mono text-sage">ML</span> — judge by features (Webroot). Best for never-seen-before pages.</li>
            </ul>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide14({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.14 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Don't take the bait.
          <br />
          <span className="text-phos glow">Name the hook.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the goal of phishing, the tell-tale sign,
          smishing, spotting a fake website and why clone phishing is so
          effective. Select an answer to reveal it instantly — the rationale
          appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(10)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   11–15 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide14({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions14[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.14 // CHECK // Q0${n + 1}`} num={String(11 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Phishing"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · SCORE
================================================================== */
export function ScoreSlide14({ answers }: { answers: (number | null)[] }) {
  const score = questions14.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions14.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — nothing on the hook." : pct >= 60 ? "Solid. Re-read the six types and the website checks." : "Revisit the signs of phishing and the fake-vs-real slide, then retake.";
  return (
    <Slide tag="SEC // CH.14 // CHECK // RESULT" num="16" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions14.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions14.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions14.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   17 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide14() {
  const items = [
    ["01", "Phishing is the front door", "It is how malware lands, how botnets recruit and how social engineers open a conversation."],
    ["02", "Channel × precision", "Email, SMS, voice — mass, targeted or executive. Six types, one idea: impersonate trust."],
    ["03", "Urgency is the tell", "Pressure plus a request for personal data is the pattern. Logos and signatures prove nothing."],
    ["04", "Read the address bar", "https:// and the exact domain spelling catch most clones in under five seconds."],
    ["05", "Clones copy what you already trust", "A duplicated real email with swapped links defeats every visual check — verify out-of-band."],
    ["06", "Tools assist, habits protect", "Lists, real-time checks and ML help. None replace a cautious user."],
  ];
  return (
    <Slide tag="SEC // CH.14 // CLOSE" num="17" title={<>Chapter 14 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 14 · Phishing</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents14.length} sections · {TOTAL14} slides</span>
      </div>
    </Slide>
  );
}
