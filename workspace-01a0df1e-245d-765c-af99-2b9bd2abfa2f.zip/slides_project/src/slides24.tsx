import { motion } from "framer-motion";
import { Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  advantages24,
  ch24Intro,
  ch24IntroPoints,
  ch24Stamp,
  contents24,
  disadvantages24,
  questions24,
  ssoConfigsA,
  ssoConfigsB,
  ssoTokenIntro,
  ssoTokenPoints,
  TOTAL24,
  working24,
} from "./data/ch24";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "single key, many doors" backdrop
================================================================== */
function SingleKeyBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="skFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="skGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* single key */}
      <g transform="translate(790 300)" filter="url(#skGlow)">
        <circle cx="0" cy="0" r="26" fill="none" stroke="#3DF07A" strokeWidth="2.4" />
        <circle cx="0" cy="0" r="10" fill="none" stroke="#3DF07A" strokeWidth="2.4" />
        <line x1="18" y1="18" x2="86" y2="86" stroke="#3DF07A" strokeWidth="2.4" strokeLinecap="round" />
        <line x1="70" y1="70" x2="70" y2="90" stroke="#3DF07A" strokeWidth="2.4" strokeLinecap="round" />
        <line x1="78" y1="78" x2="78" y2="98" stroke="#3DF07A" strokeWidth="2.4" strokeLinecap="round" />
      </g>
      {/* three doors it opens */}
      {[[960, 150], [1040, 260], [980, 400]].map(([x, y], n) => (
        <g key={n} transform={`translate(${x} ${y})`}>
          <rect width="70" height="94" fill="#0B0F0D" stroke="#C7D2C9" strokeOpacity="0.4" strokeWidth="1.3" />
          <circle cx="55" cy="47" r="3" fill="#FFB020" />
          <line x1="0" y1="0" x2="-72" y2="48" stroke="#3DF07A" strokeOpacity="0.35" strokeDasharray="3 4" />
        </g>
      ))}
      <rect width="1200" height="700" fill="url(#skFade)" />
    </svg>
  );
}

export function TitleSlide24({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <SingleKeyBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Identity briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 24 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.24&nbsp;//&nbsp;SSO</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL24}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 24</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Single Sign On</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">(SSO)</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch24Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(3)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to SSO configurations</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Working steps", "Eight"], ["Configuration types", "Five"], ["Advantages", "Five"], ["Doc revision", ch24Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide24() {
  return (
    <Slide tag="SEC // CH.24 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch24Intro} dense>
      <div>
        {ch24IntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · WORKING
================================================================== */
export function WorkingSlide24() {
  return (
    <Slide tag="SEC // CH.24 // MECHANISM" num="03" title={<>Working of <span className="text-phos">Single Sign On</span></>} lede="There are the following steps in the working of SSO:" dense>
      <div>
        {working24.map((w, n) => (
          <Row key={w} i={String(n + 1).padStart(2, "0")} label={w} delay={n * 0.035} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · SSO CONFIGURATIONS I — Kerberos · SAML · Smart card
================================================================== */
export function ConfigsASlide24() {
  return (
    <Slide tag="SEC // CH.24 // CONFIGURATIONS" num="04" title={<>Types of <span className="text-phos">SSO configurations</span></>} lede="Kerberos, SAML and smart card-based configurations." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {ssoConfigsA.map((c, n) => (
          <motion.div key={c.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[c.tone] }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[c.tone] }}>{c.i}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
              <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{c.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {c.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[c.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · SSO CONFIGURATIONS II — Social media · Enterprise-level
================================================================== */
export function ConfigsBSlide24() {
  return (
    <Slide tag="SEC // CH.24 // CONFIGURATIONS" num="05" title={<>More <span className="text-phos">SSO configurations</span></>} lede="Social media-based and enterprise-level configurations." dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {ssoConfigsB.map((c, n) => (
          <motion.div key={c.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[c.tone] }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[c.tone] }}>{c.i} · Configuration</span>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
              <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{c.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {c.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[c.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · SSO TOKEN
================================================================== */
export function TokenSlide24() {
  return (
    <Slide tag="SEC // CH.24 // TOKEN" num="06" title={<>The <span className="text-phos">SSO token</span></>} lede={ssoTokenIntro} dense>
      <div>
        {ssoTokenPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · ADVANTAGES
================================================================== */
export function AdvantagesSlide24() {
  return (
    <Slide tag="SEC // CH.24 // TRADE-OFFS" num="07" title={<>Advantages of <span className="text-phos">SSO</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {advantages24.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.05 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · DISADVANTAGES
================================================================== */
export function DisadvantagesSlide24() {
  return (
    <Slide tag="SEC // CH.24 // TRADE-OFFS" num="08" title={<>Disadvantages of <span className="text-phos">SSO</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {disadvantages24.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide24({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.24 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          One login,
          <br />
          <span className="text-phos glow">many doors.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the purpose of SSO, where credentials are
          verified, what an SSO token does, which configuration uses XML and
          a major disadvantage of the model. Select an answer to reveal it
          instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(9)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   10–14 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide24({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions24[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.24 // CHECK // Q0${n + 1}`} num={String(10 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "SSO"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · SCORE
================================================================== */
export function ScoreSlide24({ answers }: { answers: (number | null)[] }) {
  const score = questions24.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions24.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every door opens with the one key." : pct >= 60 ? "Solid. Re-read the configuration types and the SSO token section." : "Revisit the working mechanism and configuration types, then retake.";
  return (
    <Slide tag="SEC // CH.24 // CHECK // RESULT" num="15" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions24.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions24.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions24.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide24() {
  const items = [
    ["01", "SSO trades many logins for one", "A single set of credentials, verified once, unlocks every connected application in the session."],
    ["02", "The Identity Provider does the verifying", "The SSO server never trusts a login on its own — it always checks back with an IdP like Active Directory."],
    ["03", "Five configuration models, one goal", "Kerberos, SAML, smart card, social media and enterprise-level setups all deliver the same single-login experience differently."],
    ["04", "Tokens carry the proof", "After the first login, a time-limited SSO token — not the password — travels between applications."],
    ["05", "Convenience and risk are linked", "Fewer passwords to manage is also fewer points to protect — the token becomes the new high-value target."],
    ["06", "Pair SSO with MFA", "Combining SSO with multi-factor authentication offsets its single point of failure with a second layer of proof."],
  ];
  return (
    <Slide tag="SEC // CH.24 // CLOSE" num="16" title={<>Chapter 24 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 24 · Single Sign On (SSO)</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents24.length} sections · {TOTAL24} slides</span>
      </div>
    </Slide>
  );
}
