import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch18Bullets,
  ch18Intro,
  ch18Stamp,
  components,
  contents18,
  cyberTools,
  features,
  importance,
  physicalTools,
  questions18,
  riskTools,
  TOTAL18,
  trainingStat,
  type Component,
  type Feature,
} from "./data/ch18";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "layered shield" backdrop
================================================================== */
function LayersBackdrop() {
  const rings = [
    { r: 150, o: 0.5, dash: "0" },
    { r: 120, o: 0.4, dash: "3 7" },
    { r: 92, o: 0.55, dash: "0" },
  ];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="lyFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="lyGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      <g transform="translate(920 320)">
        {rings.map((r, n) => (
          <circle key={n} r={r.r} fill="none" stroke={n === 1 ? "#FFB020" : "#3DF07A"} strokeOpacity={r.o} strokeWidth="1.5" strokeDasharray={r.dash} />
        ))}
        <g filter="url(#lyGlow)">
          <path d="M0 -46 30 -30v34c0 22 -13 36 -30 44 -17 -8 -30 -22 -30 -44v-34Z" fill="#0B0F0D" stroke="#3DF07A" strokeWidth="2" />
          <path d="M-9 -1 -3 6 11 -12" fill="none" stroke="#3DF07A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        {[[-95, 50], [95, 50], [0, 108]].map(([x, y], n) => (
          <g key={n} transform={`translate(${x} ${y})`}>
            <rect x="-24" y="-16" width="48" height="32" fill="#0B0F0D" stroke="#C7D2C9" strokeOpacity="0.35" />
          </g>
        ))}
      </g>
      <rect width="1200" height="700" fill="url(#lyFade)" />
    </svg>
  );
}

export function TitleSlide18({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <LayersBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Governance briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 18 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.18&nbsp;//&nbsp;SMS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL18}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 18</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Security Management</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">System</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch18Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(2)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to key components</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Core components", "Four"], ["Key features", "Three"], ["Human factor", "88% of incidents"], ["Doc revision", ch18Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide18() {
  return (
    <Slide tag="SEC // CH.18 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch18Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch18Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Also known as</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              An Information Security Management System (ISMS) — a structured,
              organization-wide approach that pairs technology with policy and
              people, rather than treating security as a single tool.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Data", "Assets", "People", "Infrastructure"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · KEY COMPONENTS — OVERVIEW
================================================================== */
export function ComponentsIndexSlide18() {
  return (
    <Slide tag="SEC // CH.18 // COMPONENTS" num="03" title={<>Key components of an <span className="text-phos">SMS</span></>} lede="A strong Security Management System consists of multiple layers working together." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {components.map((c, n) => (
            <motion.div key={c.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.07 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 items-center justify-center border bg-ink px-3 font-mono text-[11px]" style={{ borderColor: TONE[c.tone], color: TONE[c.tone], borderRadius: 2 }}>{c.i}</span>
              </div>
              <h3 className="mt-3 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
              <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{c.lead}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared component-pair detail slide
================================================================== */
function ComponentPairDetail({ pair, num, tagSuffix }: { pair: Component[]; num: string; tagSuffix: string }) {
  return (
    <Slide tag={`SEC // CH.18 // ${tagSuffix}`} num={num} title={<>{pair[0].name} &amp; <span className="text-phos">{pair[1].name}</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {pair.map((c, n) => (
          <motion.div key={c.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[c.tone] }}>
            <div className="p-5">
              <div className="flex items-center justify-between">
                <Tag tone={c.tone === "sage" ? "muted" : c.tone}>{c.i}</Tag>
                <span className="font-mono text-[10px] text-muted">Component</span>
              </div>
              <h3 className="mt-3 font-display text-[1.4rem] uppercase leading-tight tracking-tight" style={{ color: TONE[c.tone] }}>{c.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{c.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {c.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[c.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

export const ComponentsDetailA18 = () => (
  <ComponentPairDetail pair={[components[0], components[1]]} num="04" tagSuffix="CYBER & PHYSICAL" />
);

export const ComponentsDetailB18 = () => (
  <ComponentPairDetail pair={[components[2], components[3]]} num="05" tagSuffix="POLICIES & TRAINING" />
);

/* ==================================================================
   06 · FEATURES — OVERVIEW
================================================================== */
export function FeaturesIndexSlide18() {
  return (
    <Slide tag="SEC // CH.18 // FEATURES" num="06" title={<>Features of a <span className="text-phos">Security Management System</span></>} lede="These features work together to detect risk, safeguard assets and respond to threats — keeping the organization beyond the reach of hackers, thieves and disasters." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {features.map((f, n) => (
          <motion.div key={f.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 1 ? TONE.amber : TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n === 1 ? TONE.amber : TONE.phos }}>Feature {f.i}</span>
            <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{f.name}</h3>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{f.lead}</p>
            <div className="mt-3 flex flex-wrap gap-1.5 border-t border-sage/15 pt-3">
              {f.items.map((it) => <Tag key={it.label} tone="muted">{it.label}</Tag>)}
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared single-feature detail slide
================================================================== */
function FeatureDetail({ f, num, tagSuffix }: { f: Feature; num: string; tagSuffix: string }) {
  return (
    <Slide tag={`SEC // CH.18 // FEATURE ${f.i} // ${tagSuffix}`} num={num} title={<>{f.name.split(" ")[0]} <span className="text-phos">{f.name.split(" ").slice(1).join(" ")}</span></>} lede={f.lead} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className={f.caseStudy ? "lg:col-span-7" : "lg:col-span-12"}>
          {f.items.map((it, n) => (
            <Row key={it.label} i={String(n + 1).padStart(2, "0")} label={it.label} desc={it.desc} delay={n * 0.05} />
          ))}
        </div>
        {f.caseStudy && (
          <motion.div variants={rise} className="lg:col-span-5">
            <Panel className="p-5">
              <div className="font-mono text-[9.5px] tracked text-amber">{f.caseStudy.label}</div>
              <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{f.caseStudy.text}</p>
            </Panel>
          </motion.div>
        )}
      </div>
    </Slide>
  );
}

export const PhysicalSafetySlide18 = () => (
  <FeatureDetail f={features[0]} num="07" tagSuffix="PHYSICAL SAFETY" />
);
export const AssetIdentificationSlide18 = () => (
  <FeatureDetail f={features[1]} num="08" tagSuffix="ASSET IDENTIFICATION" />
);
export const SecurityProceduresSlide18 = () => (
  <FeatureDetail f={features[2]} num="09" tagSuffix="SECURITY PROCEDURES" />
);

/* ==================================================================
   10 · IMPORTANCE OF SMS
================================================================== */
export function ImportanceSlide18() {
  return (
    <Slide tag="SEC // CH.18 // IMPORTANCE" num="10" title={<>Importance of a <span className="text-phos">Security Management System</span></>} lede="A Security Management System is essential for protecting critical organizational assets." dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {importance.map((it, n) => (
          <motion.div key={it.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">{it.i}</span>
            <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{it.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{it.lead}</p>
            <ul className="mt-3 border-t border-sage/15 pt-2.5">
              {it.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-phos" />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · TOOLS & CONTROLS (cyber + physical)
================================================================== */
export function ToolsSlide18() {
  const groups = [
    { g: cyberTools, tone: "phos" as const },
    { g: physicalTools, tone: "amber" as const },
  ];
  return (
    <Slide tag="SEC // CH.18 // TOOLS" num="11" title={<>Components &amp; operations — <span className="text-phos">tools &amp; controls</span></>} lede="SMS isn't only high-tech software — it's a security culture that keeps hackers out, prevents accidents and achieves compliance." dense>
      {groups.map(({ g, tone }) => (
        <div key={g.i} className="mb-6 last:mb-0">
          <div className="font-mono text-[9.5px] tracked" style={{ color: TONE[tone] }}>{g.i} · {g.name}</div>
          <div className="mt-2 grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
            {g.tools.map((t, n) => (
              <motion.div key={t.label} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="bg-ink p-3.5">
                <div className="text-[12.5px] font-medium leading-tight text-sage">{t.label}</div>
                <div className="mt-1.5 text-[11.5px] font-light leading-[1.45] text-muted">{t.desc}</div>
              </motion.div>
            ))}
          </div>
        </div>
      ))}
    </Slide>
  );
}

/* ==================================================================
   12 · TRAINING & RISK ASSESSMENTS
================================================================== */
export function TrainingRiskSlide18() {
  return (
    <Slide tag="SEC // CH.18 // TRAINING & RISK" num="12" title={<>Employee training &amp; <span className="text-phos">risk assessments</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Panel className="p-6">
            <div className="font-mono text-[9.5px] tracked text-amber">{trainingStat.source}</div>
            <div className="mt-3 font-display text-[3rem] leading-none text-phos glow">{trainingStat.pct}</div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.6] text-sage/85">{trainingStat.text}</p>
          </Panel>
        </div>
        <div className="lg:col-span-7">
          <div className="font-mono text-[9.5px] tracked text-phos">Risk assessments</div>
          <div className="mt-2">
            {riskTools.map((r, n) => (
              <Row key={r.label} i={String(n + 1).padStart(2, "0")} label={r.label} desc={r.desc} delay={n * 0.05} />
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide18({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 4 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.18 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Layer it
          <br />
          <span className="text-phos glow">up.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Four items covering the components, asset identification, security
          policies and why the human layer matters most. Select an answer to
          reveal it instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(13)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   14–17 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide18({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions18[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.18 // CHECK // Q0${n + 1}`} num={String(14 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 04</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "SMS"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   18 · SCORE
================================================================== */
export function ScoreSlide18({ answers }: { answers: (number | null)[] }) {
  const score = questions18.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions18.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — the layers hold." : pct >= 60 ? "Solid. Re-read the four components and the features section." : "Revisit the components, features and importance sections, then retake.";
  return (
    <Slide tag="SEC // CH.18 // CHECK // RESULT" num="18" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions18.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions18.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions18.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide18() {
  const items = [
    ["01", "SMS is layered, not singular", "Cybersecurity, physical security, policies and training all have to work together — no single tool is an SMS."],
    ["02", "Assets must be found before they're protected", "You can't secure what you haven't mapped — inventory tools and data classification come first."],
    ["03", "Procedures turn risk into a plan", "Risk assessment, threat analysis and incident response convert 'something might happen' into 'here's what we do.'"],
    ["04", "The stakes are IP, integrity and PII", "Trade secrets, trustworthy data and personal information are what an SMS is ultimately protecting."],
    ["05", "Interconnected systems share risk", "A weakness in one connected system can compromise every system it touches."],
    ["06", "People are the largest attack surface", "88% of incidents trace back to human mistake — training is not optional, it's the control with the biggest return."],
  ];
  return (
    <Slide tag="SEC // CH.18 // CLOSE" num="19" title={<>Chapter 18 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 18 · Security Management System</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents18.length} sections · {TOTAL18} slides</span>
      </div>
    </Slide>
  );
}
