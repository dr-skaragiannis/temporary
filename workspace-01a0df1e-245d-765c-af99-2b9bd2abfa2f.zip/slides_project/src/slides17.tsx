import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch17Bullets,
  ch17Intro,
  ch17Stamp,
  challenges,
  characteristics,
  contents17,
  goodBadNote,
  goodBadPairs,
  goodQualities,
  metricTypes,
  questions17,
  someMetricsA,
  someMetricsB,
  TOTAL17,
  uses,
  type MetricType,
} from "./data/ch17";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "instrument dashboard" backdrop
================================================================== */
function DashboardBackdrop() {
  const bars = [38, 62, 48, 80, 55, 70, 42, 90, 60, 74, 50, 66];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="dbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="dbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* KPI bar chart */}
      <g transform="translate(660 420)">
        <line x1="0" y1="0" x2="480" y2="0" stroke="#C7D2C9" strokeOpacity="0.25" />
        {bars.map((h, n) => (
          <rect key={n} x={n * 40} y={-h * 1.7} width="22" height={h * 1.7} fill={n % 3 === 0 ? "#FFB020" : "#3DF07A"} fillOpacity="0.55" />
        ))}
      </g>
      {/* rising trend line */}
      <path d="M660 300 C 780 270, 860 230, 960 150 S 1120 60, 1180 40" fill="none" stroke="#3DF07A" strokeOpacity="0.55" strokeWidth="2" strokeDasharray="6 6" />
      {/* gauge */}
      <g transform="translate(760 170)" filter="url(#dbGlow)">
        <circle r="52" fill="none" stroke="#C7D2C9" strokeOpacity="0.2" strokeWidth="8" />
        <path d="M -37 26 A 52 52 0 1 1 37 26" fill="none" stroke="#3DF07A" strokeOpacity="0.8" strokeWidth="8" strokeLinecap="round" />
        <text x="0" y="8" textAnchor="middle" fill="#3DF07A" fontFamily="IBM Plex Mono, monospace" fontSize="18">92%</text>
      </g>
      <rect width="1200" height="700" fill="url(#dbFade)" />
    </svg>
  );
}

export function TitleSlide17({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <DashboardBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Measurement briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 17 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.17&nbsp;//&nbsp;METRICS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL17}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 17</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Cyber Security</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Metrics</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch17Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(3)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to types of metrics</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Metric types", "Four"], ["Good qualities", "Five"], ["Uses", "Eight"], ["Doc revision", ch17Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide17() {
  return (
    <Slide tag="SEC // CH.17 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch17Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch17Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">In one line</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              A cybersecurity metric turns a security activity into a number
              you can track, compare and act on — incident counts, response
              time, cost of attacks.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Visibility", "Performance", "Maturity", "Decision-making"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · KEY CHARACTERISTICS OF GOOD METRICS
================================================================== */
export function CharacteristicsSlide17() {
  return (
    <Slide tag="SEC // CH.17 // QUALITY BAR" num="03" title={<>Key characteristics of <span className="text-phos">good metrics</span></>} lede="Effective cybersecurity metrics should have the following qualities." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {characteristics.map((c, n) => (
          <motion.div key={c.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
            <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{c.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · TYPES OVERVIEW
================================================================== */
export function TypesIndexSlide17() {
  return (
    <Slide tag="SEC // CH.17 // TYPES" num="04" title={<>Four <span className="text-phos">types</span> of metric</>} lede="Each type answers a different question — how exposed are we, how fast do we react, how risky is the business, are we compliant." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {metricTypes.map((t, n) => (
            <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.07 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 items-center justify-center border bg-ink px-3 font-mono text-[11px]" style={{ borderColor: TONE[t.tone], color: TONE[t.tone], borderRadius: 2 }}>{t.i}</span>
              </div>
              <h3 className="mt-3 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              <p className="mt-2 text-[12.5px] font-light leading-[1.55] text-muted">{t.lead}</p>
              <div className="mt-3 border-t border-sage/15 pt-2">
                <div className="font-mono text-[9px] tracked text-amber">Example</div>
                <div className="mt-1 text-[12px] text-sage/90">{t.example}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared type-pair detail slide
================================================================== */
function TypePairDetail({ pair, num, tagSuffix }: { pair: MetricType[]; num: string; tagSuffix: string }) {
  return (
    <Slide tag={`SEC // CH.17 // ${tagSuffix}`} num={num} title={<>{pair[0].name} &amp; <span className="text-phos">{pair[1].name}</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {pair.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[t.tone] }}>
            <div className="p-5">
              <div className="flex items-center justify-between">
                <Tag tone={t.tone === "sage" ? "muted" : t.tone}>{t.i}</Tag>
                <span className="font-mono text-[10px] text-muted">Metric type</span>
              </div>
              <h3 className="mt-3 font-display text-[1.5rem] uppercase leading-tight tracking-tight" style={{ color: TONE[t.tone] }}>{t.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{t.lead}</p>
            </div>
            <div className="mt-auto border-t border-sage/15 bg-ink p-4">
              <div className="font-mono text-[9.5px] tracked" style={{ color: TONE[t.tone] }}>Example</div>
              <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{t.example}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

export const TypesDetailA17 = () => (
  <TypePairDetail pair={[metricTypes[0], metricTypes[1]]} num="05" tagSuffix="TECHNICAL & OPERATIONAL" />
);

export const TypesDetailB17 = () => (
  <TypePairDetail pair={[metricTypes[2], metricTypes[3]]} num="06" tagSuffix="STRATEGIC & COMPLIANCE" />
);

/* ==================================================================
   07 · USES OF CYBERSECURITY METRICS
================================================================== */
export function UsesSlide17() {
  return (
    <Slide tag="SEC // CH.17 // USES" num="07" title={<>Uses of <span className="text-phos">cybersecurity metrics</span></>} lede="Metrics help organizations strengthen their security posture by providing accurate, measurable and actionable insights." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {uses.map((u, n) => (
          <motion.div key={u.i} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.04 } } }} className="bg-ink p-4">
            <span className="font-mono text-[10px] text-phos/70">{u.i}</span>
            <h3 className="mt-1.5 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{u.name}</h3>
            <ul className="mt-2.5 space-y-1.5">
              {u.points.map((p) => (
                <li key={p} className="flex gap-2 text-[11.5px] font-light leading-[1.45] text-muted">
                  <span className="mt-[6px] h-1 w-1 shrink-0 bg-phos/70" />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08–09 · SOME CYBERSECURITY METRICS (A / B)
================================================================== */
function SomeMetricsSlide({ list, num, part }: { list: { name: string; desc: string }[]; num: string; part: string }) {
  return (
    <Slide tag={`SEC // CH.17 // IN PRACTICE ${part}`} num={num} title={<>Some cybersecurity <span className="text-phos">metrics {part}</span></>} lede="A list of important cybersecurity metrics that portray the current threat scenario really well." dense>
      <div>
        {list.map((m, n) => (
          <Row key={m.name} i={String(n + 1).padStart(2, "0")} label={m.name} desc={m.desc} delay={n * 0.04} />
        ))}
      </div>
    </Slide>
  );
}

export const MetricsExamplesA17 = () => <SomeMetricsSlide list={someMetricsA} num="08" part="I" />;
export const MetricsExamplesB17 = () => <SomeMetricsSlide list={someMetricsB} num="09" part="II" />;

/* ==================================================================
   10 · GOOD VS BAD METRIC
================================================================== */
export function GoodBadSlide17() {
  return (
    <Slide tag="SEC // CH.17 // GOOD OR BAD" num="10" title={<>Metric: <span className="text-phos">good or bad</span></>} lede="A good metric is definable, comprehensive and has room for comparison." dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">A good metric is</div>
            <div className="mt-3 flex flex-col gap-2">
              {goodQualities.map((q) => <Tag key={q}>{q}</Tag>)}
            </div>
            <p className="mt-4 border-t border-sage/10 pt-3 text-[12.5px] font-light leading-[1.55] text-muted">{goodBadNote}</p>
          </Panel>
        </div>
        <div className="lg:col-span-8">
          <div className="grid grid-cols-2 gap-px bg-sage/15 font-mono text-[9.5px] tracked">
            <div className="bg-panel/80 p-3 text-phos">Good metric</div>
            <div className="bg-panel/80 p-3 text-amber">Bad metric</div>
          </div>
          <div className="mt-px grid grid-cols-2 gap-px bg-sage/15">
            {goodBadPairs.map((p, n) => (
              <div key={n} className="contents">
                <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="bg-ink p-3.5 text-[13px] font-light text-sage/90">{p.good}</motion.div>
                <motion.div variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 + 0.02 } } }} className="bg-ink p-3.5 text-[13px] font-light text-muted">{p.bad}</motion.div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · CHALLENGES
================================================================== */
export function ChallengesSlide17() {
  return (
    <Slide tag="SEC // CH.17 // LIMITS" num="11" title={<>Challenges with a <span className="text-phos">cybersecurity metric</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {challenges.map((c, n) => (
          <motion.div key={c} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked text-amber">Limit {String(n + 1).padStart(2, "0")}</span>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">{c}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide17({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 6 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.17 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Measure
          <br />
          <span className="text-phos glow">what matters.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Six items covering what counts as a metric, the four metric types,
          good vs bad metrics and what an unaddressed vulnerability really
          means. Select an answer to reveal it instantly — the rationale
          appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(12)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   13–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide17({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions17[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.17 // CHECK // Q0${n + 1}`} num={String(13 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 06</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Metrics"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide17({ answers }: { answers: (number | null)[] }) {
  const score = questions17.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions17.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — you can build the dashboard." : pct >= 60 ? "Solid. Re-read the four metric types and the good-vs-bad table." : "Revisit the metric types, uses and the good-vs-bad examples, then retake.";
  return (
    <Slide tag="SEC // CH.17 // CHECK // RESULT" num="19" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions17.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions17.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions17.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide17() {
  const items = [
    ["01", "Metrics turn activity into evidence", "Incident counts, response time and cost of attacks are numbers you can track, compare and act on."],
    ["02", "Good metrics share five qualities", "Measurable, relevant, actionable, timely and consistent — miss one and the number stops being useful."],
    ["03", "Four types, four audiences", "Technical, operational, strategic and compliance metrics each answer a different stakeholder's question."],
    ["04", "Uses go beyond dashboards", "Metrics support accountability, decision-making, risk unification, audits and continuous learning."],
    ["05", "Definable, comprehensive, comparable", "That's what separates a good metric from a bad one — not how sophisticated it sounds."],
    ["06", "Activity ≠ outcome", "High vulnerabilities with no incidents yet is still risk. Metrics describe the picture; people still have to act on it."],
  ];
  return (
    <Slide tag="SEC // CH.17 // CLOSE" num="20" title={<>Chapter 17 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 17 · Cyber Security Metrics</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents17.length} sections · {TOTAL17} slides</span>
      </div>
    </Slide>
  );
}
