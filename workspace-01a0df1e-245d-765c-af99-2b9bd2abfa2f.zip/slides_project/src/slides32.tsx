import { motion } from "framer-motion";
import { Row, Slide, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch32Intro,
  ch32IntroPoints,
  ch32Stamp,
  contents32,
  detectionMethods32,
  evasionTechniques,
  idsBenefits,
  idsClasses,
  idsImportance,
  idsLimitations,
  idsPlacement,
  intrusionMethods,
  questions32,
  TOTAL32,
  vsFirewallIntro,
  vsFirewallItems,
  workingIntro32,
  workingSteps32,
} from "./data/ch32";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "watchdog sensor grid" backdrop
================================================================== */
function WatchdogBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="wdbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="wdbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* sensor nodes across a network line */}
      <g transform="translate(740 220)" opacity="0.85">
        <line x1="0" y1="40" x2="340" y2="40" stroke="#3DF07A" strokeWidth="2" strokeOpacity="0.4" />
        {[0, 85, 170, 255, 340].map((x, n) => (
          <g key={n} transform={`translate(${x} 40)`}>
            <circle r="6" fill="#0B0F0D" stroke={n === 2 ? "#FFB020" : "#3DF07A"} strokeWidth="2.5" />
          </g>
        ))}
      </g>
      {/* watchdog eye — alert pulse on the flagged node */}
      <g transform="translate(910 260)" filter="url(#wdbGlow)">
        <circle cx="0" cy="0" r="34" fill="none" stroke="#FFB020" strokeWidth="2.5" />
        <circle cx="0" cy="0" r="10" fill="#FFB020" opacity="0.9" />
        <path d="M-46 0 A46 46 0 0 1 46 0" fill="none" stroke="#FFB020" strokeWidth="2" strokeDasharray="4 4" opacity="0.6" />
      </g>
      <rect width="1200" height="700" fill="url(#wdbFade)" />
    </svg>
  );
}

export function TitleSlide32({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <WatchdogBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 32 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.32&nbsp;//&nbsp;IDS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL32}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 32</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">Intrusion Detection</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">System (IDS)</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch32Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(8)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to IDS vs Firewall</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["IDS types", "Five"], ["Evasion techniques", "Four"], ["Detection methods", "Two"], ["Doc revision", ch32Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide32() {
  return (
    <Slide tag="SEC // CH.32 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch32Intro} dense>
      <div>
        {ch32IntroPoints.map((p, n) => (
          <Row key={p.name} i={String(n + 1).padStart(2, "0")} label={p.name} desc={p.desc} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · COMMON METHODS OF INTRUSION
================================================================== */
export function IntrusionMethodsSlide32() {
  return (
    <Slide tag="SEC // CH.32 // THREAT MODEL" num="03" title={<>Common methods of <span className="text-phos">intrusion</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {intrusionMethods.map((m, n) => (
          <motion.div key={m.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n % 2 === 0 ? TONE.phos : TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n % 2 === 0 ? TONE.phos : TONE.amber }}>0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{m.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{m.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · WORKING OF IDS
================================================================== */
export function WorkingSlide32() {
  return (
    <Slide tag="SEC // CH.32 // PROCESS" num="04" title={<>Working of <span className="text-phos">IDS</span></>} lede={workingIntro32} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {workingSteps32.map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">{s.n}</span>
            <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · CLASSIFICATION I (NIDS, HIDS, Hybrid)
================================================================== */
function ClassCard({ c, tone, delay }: { c: (typeof idsClasses)[number]; tone: string; delay: number }) {
  return (
    <motion.div variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: tone }}>
      <div className="p-4">
        <span className="font-mono text-[9.5px] tracked" style={{ color: tone }}>{c.n} · {c.short}</span>
        <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
        <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted"><span className="text-sage/70">Function — </span>{c.func}</p>
        <p className="mt-2 text-[12px] font-light leading-[1.5] text-muted"><span className="text-sage/70">Usage — </span>{c.usage}</p>
      </div>
      <div className="mt-auto border-t border-sage/15 bg-ink p-4">
        <span className="font-mono text-[9px] tracked text-muted">EXAMPLE</span>
        <p className="mt-1.5 text-[12px] font-light italic leading-[1.5] text-sage/85">{c.example}</p>
      </div>
    </motion.div>
  );
}

export function ClassificationASlide32() {
  return (
    <Slide tag="SEC // CH.32 // CLASSIFICATION I" num="05" title={<>Classification of <span className="text-phos">IDS</span> — I</>} lede="Several types of IDS exist, categorized by where they operate or how they detect intrusions." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {idsClasses.slice(0, 3).map((c, n) => (
          <ClassCard key={c.name} c={c} tone={n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage} delay={n * 0.08} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · CLASSIFICATION II (APIDS, PIDS)
================================================================== */
export function ClassificationBSlide32() {
  return (
    <Slide tag="SEC // CH.32 // CLASSIFICATION II" num="06" title={<>Classification of <span className="text-phos">IDS</span> — II</>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {idsClasses.slice(3, 5).map((c, n) => (
          <ClassCard key={c.name} c={c} tone={n === 0 ? TONE.phos : TONE.amber} delay={n * 0.1} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · IDS EVASION TECHNIQUES
================================================================== */
export function EvasionSlide32() {
  return (
    <Slide tag="SEC // CH.32 // ADVERSARY" num="07" title={<>IDS <span className="text-phos">evasion techniques</span></>} lede="Attackers often use methods to evade detection by IDS systems. Some of the most common evasion techniques include:" dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {evasionTechniques.map((e, n) => (
          <motion.div key={e.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1} · {e.name}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{e.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · DETECTION METHODS
================================================================== */
export function DetectionMethodsSlide32() {
  return (
    <Slide tag="SEC // CH.32 // METHOD" num="08" title={<>Detection <span className="text-phos">methods</span> of IDS</>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {detectionMethods32.map((d, n) => (
          <motion.div key={d.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>0{n + 1}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{d.name}</h3>
              <p className="mt-2.5 text-[12.5px] font-light leading-[1.5] text-muted">{d.desc}</p>
            </div>
            <ul className="border-t border-sage/15 px-5 pt-4">
              {d.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
            <div className="mt-auto border-t border-sage/15 bg-ink p-4">
              <span className="font-mono text-[9px] tracked text-muted">EXAMPLE</span>
              <p className="mt-1.5 text-[12px] font-light italic leading-[1.5] text-sage/85">{d.example}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · IDS vs FIREWALL
================================================================== */
export function VsFirewallSlide32() {
  return (
    <Slide tag="SEC // CH.32 // COMPARISON" num="09" title={<>IDS <span className="text-phos">vs</span> Firewall</>} lede={vsFirewallIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {vsFirewallItems.map((v, n) => (
          <motion.div key={v.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.amber : TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.amber : TONE.phos }}>{v.name}</span>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-sage/85">{v.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · IMPORTANCE OF IDS
================================================================== */
export function ImportanceSlide32() {
  return (
    <Slide tag="SEC // CH.32 // VALUE" num="10" title={<>Importance of <span className="text-phos">IDS</span></>} dense>
      <div>
        {idsImportance.map((p, n) => (
          <Row key={p.name} i={String(n + 1).padStart(2, "0")} label={p.name} desc={p.desc} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · PLACEMENT OF IDS
================================================================== */
export function PlacementSlide32() {
  return (
    <Slide tag="SEC // CH.32 // ARCHITECTURE" num="11" title={<>Placement of <span className="text-phos">IDS</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-3">
        {idsPlacement.map((p, n) => (
          <motion.div key={p.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }}>0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{p.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · BENEFITS
================================================================== */
export function BenefitsSlide32() {
  return (
    <Slide tag="SEC // CH.32 // TRADE-OFFS" num="12" title={<>Benefits of <span className="text-phos">IDS</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {idsBenefits.map((b, n) => (
          <motion.div key={b.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1} · {b.name}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{b.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · LIMITATIONS
================================================================== */
export function LimitationsSlide32() {
  return (
    <Slide tag="SEC // CH.32 // TRADE-OFFS" num="13" title={<>Limitations of <span className="text-phos">IDS</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {idsLimitations.map((l, n) => (
          <motion.div key={l.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1} · {l.name}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{l.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide32({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.32 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><span className="inline-block border border-amber/40 px-2 py-[3px] font-mono text-[9.5px] leading-none tracked text-amber">Knowledge check</span></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Watch closely,
          <br />
          <span className="text-phos glow">alert instantly.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the primary purpose of IDS, why it's passive
          compared to an IPS, signature-based detection, how HIDS works,
          and which IDS type watches an entire network. Select an answer
          to reveal it instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(14)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   15–19 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide32({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions32[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.32 // CHECK // Q0${n + 1}`} num={String(15 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Intrusion Detection"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · SCORE
================================================================== */
export function ScoreSlide32({ answers }: { answers: (number | null)[] }) {
  const score = questions32.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions32.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — the watchdog never blinked." : pct >= 60 ? "Solid. Re-read the classification and detection method sections." : "Revisit the classification and IDS-vs-firewall sections, then retake.";
  return (
    <Slide tag="SEC // CH.32 // CHECK // RESULT" num="20" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions32.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions32.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions32.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   21 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide32() {
  const items = [
    ["01", "IDS is a watchdog, not a wall", "It monitors traffic and system activity, alerting administrators to suspicious behavior — it does not block anything itself."],
    ["02", "Attackers evade before they intrude", "Address spoofing, fragmentation, pattern evasion and coordinated attacks all try to slip past detection before an alert ever fires."],
    ["03", "Five classifications, five vantage points", "NIDS, HIDS, Hybrid, APIDS and PIDS each watch a different layer — network, host, combined, application protocol, or transport protocol."],
    ["04", "Two detection philosophies", "Signature-based detection catches known threats cheaply; anomaly-based detection catches the unknown at the cost of more false positives."],
    ["05", "IDS and firewalls are partners, not rivals", "A firewall blocks based on rules; an IDS detects and alerts after the fact — together they cover prevention and visibility."],
    ["06", "Placement and trade-offs matter", "Behind the firewall, inside the network, or fused with it — each position changes what an IDS sees, while false positives and resource cost remain constant limitations."],
  ];
  return (
    <Slide tag="SEC // CH.32 // CLOSE" num="21" title={<>Chapter 32 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 32 · Intrusion Detection System (IDS)</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents32.length} sections · {TOTAL32} slides</span>
      </div>
    </Slide>
  );
}
