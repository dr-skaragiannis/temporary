import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  backupAdvantages26,
  backupDisadvantages26,
  backupExample,
  backupIntro,
  backupPoints,
  backupTypes26,
  ch26Intro,
  ch26IntroPoints,
  ch26Module,
  ch26Stamp,
  compareRows26,
  contents26,
  disasterRecoveryIntro,
  disasterRecoveryPoints,
  questions26,
  recoveryAdvantages26,
  recoveryDisadvantages26,
  recoveryExample,
  recoveryIntro,
  scenarios26,
  TOTAL26,
} from "./data/ch26";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "restore point" backdrop
================================================================== */
function RestorePointBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="rpFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="rpGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* cyclic restore arrow with data nodes */}
      <g transform="translate(920 340)" filter="url(#rpGlow)">
        <path d="M -120 0 A 120 120 0 1 1 -80 96" fill="none" stroke="#3DF07A" strokeWidth="2.4" strokeLinecap="round" />
        <path d="M -100 78 L -80 96 L -58 74" fill="none" stroke="#3DF07A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        {[[-120, 0], [-60, -104], [60, -104], [120, 0], [60, 104]].map(([x, y], n) => (
          <circle key={n} cx={x} cy={y} r={n === 0 ? 9 : 6} fill="#0B0F0D" stroke={n === 0 ? "#3DF07A" : "#C7D2C9"} strokeOpacity={n === 0 ? 1 : 0.55} strokeWidth="1.8" />
        ))}
      </g>
      <rect width="1200" height="700" fill="url(#rpFade)" />
    </svg>
  );
}

export function TitleSlide26({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <RestorePointBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 26 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.26&nbsp;//&nbsp;BACKUP&nbsp;&amp;&nbsp;RECOVERY</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL26}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 26</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Backup vs</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Recovery</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch26Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(10)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to comparison</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Backup types covered", "Four+"], ["Comparison rows", "Ten"], ["Real-world scenarios", "Three"], ["Doc revision", ch26Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide26() {
  return (
    <Slide tag="SEC // CH.26 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch26Intro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch26IntroPoints.map((p, n) => (
            <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Module context</div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">{ch26Module}</p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · WHAT IS BACKUP
================================================================== */
export function BackupIntroSlide26() {
  return (
    <Slide tag="SEC // CH.26 // BACKUP" num="03" title={<>What is <span className="text-phos">Backup</span></>} lede={backupIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {backupPoints.map((p, n) => (
            <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Example</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{backupExample}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Google Drive", "Microsoft OneDrive", "AWS Backup"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · BACKUP TYPES — Differential · Cloud
================================================================== */
export function BackupTypesSlide26() {
  return (
    <Slide tag="SEC // CH.26 // BACKUP" num="04" title={<>Backup <span className="text-phos">types in focus</span></>} lede="Full, incremental, local and mirror copies are the base types — differential and cloud backup extend the model further." dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {backupTypes26.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>0{n + 1} · Type</span>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · BACKUP ADVANTAGES
================================================================== */
export function BackupAdvantagesSlide26() {
  return (
    <Slide tag="SEC // CH.26 // BACKUP // TRADE-OFFS" num="05" title={<>Advantages of <span className="text-phos">Backup</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {backupAdvantages26.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · BACKUP DISADVANTAGES
================================================================== */
export function BackupDisadvantagesSlide26() {
  return (
    <Slide tag="SEC // CH.26 // BACKUP // TRADE-OFFS" num="06" title={<>Disadvantages of <span className="text-phos">Backup</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {backupDisadvantages26.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · WHAT IS RECOVERY
================================================================== */
export function RecoveryIntroSlide26() {
  return (
    <Slide tag="SEC // CH.26 // RECOVERY" num="07" title={<>What is <span className="text-phos">Recovery</span></>} lede={recoveryIntro} dense>
      <motion.div variants={rise}>
        <Panel className="p-5">
          <div className="font-mono text-[9.5px] tracked text-amber">Example</div>
          <p className="mt-3 max-w-[70ch] text-[13.5px] font-light leading-[1.6] text-sage/85">{recoveryExample}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Tag tone="muted">Recuva</Tag>
            <Tag tone="muted">Database recovery techniques</Tag>
          </div>
        </Panel>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   08 · DISASTER RECOVERY PLANNING
================================================================== */
export function DisasterRecoverySlide26() {
  return (
    <Slide tag="SEC // CH.26 // RECOVERY" num="08" title={<>Disaster <span className="text-phos">recovery planning</span></>} lede={disasterRecoveryIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {disasterRecoveryPoints.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2.5 text-[13px] font-light leading-[1.5] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · RECOVERY ADVANTAGES
================================================================== */
export function RecoveryAdvantagesSlide26() {
  return (
    <Slide tag="SEC // CH.26 // RECOVERY // TRADE-OFFS" num="09" title={<>Advantages of <span className="text-phos">Recovery</span></>} dense>
      <div>
        {recoveryAdvantages26.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · RECOVERY DISADVANTAGES
================================================================== */
export function RecoveryDisadvantagesSlide26() {
  return (
    <Slide tag="SEC // CH.26 // RECOVERY // TRADE-OFFS" num="10" title={<>Disadvantages of <span className="text-phos">Recovery</span></>} dense>
      <div>
        {recoveryDisadvantages26.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Comparison table shared component
================================================================== */
function CompareTable({ rows, startIdx }: { rows: typeof compareRows26; startIdx: number }) {
  return (
    <div className="border border-sage/15" style={{ borderRadius: 2 }}>
      <div className="grid grid-cols-2 border-b border-sage/20 bg-panel/70">
        <div className="border-r border-sage/15 px-4 py-2.5 font-mono text-[10px] tracked text-phos">BACKUP</div>
        <div className="px-4 py-2.5 font-mono text-[10px] tracked text-amber">RECOVERY</div>
      </div>
      {rows.map((r, n) => (
        <motion.div key={r.backup} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.05 } } }} className="grid grid-cols-2 border-b border-sage/10 last:border-b-0 odd:bg-panel/25">
          <div className="border-r border-sage/10 px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">
            <span className="mr-2 font-mono text-[9.5px] text-phos/60">{String(startIdx + n).padStart(2, "0")}</span>{r.backup}
          </div>
          <div className="px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.recovery}</div>
        </motion.div>
      ))}
    </div>
  );
}

/* ==================================================================
   11 · BACKUP VS RECOVERY I
================================================================== */
export function ComparisonASlide26() {
  return (
    <Slide tag="SEC // CH.26 // COMPARISON I" num="11" title={<>Backup <span className="text-phos">vs</span> Recovery</>} dense>
      <CompareTable rows={compareRows26.slice(0, 5)} startIdx={1} />
    </Slide>
  );
}

/* ==================================================================
   12 · BACKUP VS RECOVERY II
================================================================== */
export function ComparisonBSlide26() {
  return (
    <Slide tag="SEC // CH.26 // COMPARISON II" num="12" title={<>Backup <span className="text-phos">vs</span> Recovery <span className="text-muted">(cont.)</span></>} dense>
      <CompareTable rows={compareRows26.slice(5, 10)} startIdx={6} />
    </Slide>
  );
}

/* ==================================================================
   13 · REAL-WORLD SCENARIOS
================================================================== */
export function ScenariosSlide26() {
  return (
    <Slide tag="SEC // CH.26 // PRACTICE" num="13" title={<>Real-world <span className="text-phos">scenarios</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {scenarios26.map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.sage }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked text-sage">0{n + 1}</span>
              <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{s.desc}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              <li className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.phos }} />{s.backupRole}
              </li>
              <li className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.amber }} />{s.recoveryRole}
              </li>
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide26({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 4 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.26 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Copy it,
          <br />
          <span className="text-phos glow">restore it.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Four items covering the definition of Backup, a real Recovery
          example, Backup's primary goal and a disadvantage of Recovery.
          Select an answer to reveal it instantly — the rationale appears
          underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(14)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   15–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide26({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions26[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.26 // CHECK // Q0${n + 1}`} num={String(15 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 04</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Backup & Recovery"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide26({ answers }: { answers: (number | null)[] }) {
  const score = questions26.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions26.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — the restore point holds." : pct >= 50 ? "Solid. Re-read the Backup vs Recovery comparison table." : "Revisit the Backup and Recovery definitions, then retake.";
  return (
    <Slide tag="SEC // CH.26 // CHECK // RESULT" num="19" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions26.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions26.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions26.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide26() {
  const items = [
    ["01", "Backup is prevention, Recovery is response", "One creates a safety copy before anything goes wrong; the other restores usability after it does."],
    ["02", "There's more than one backup type", "Full, incremental, differential, local, mirror and cloud copies each trade off storage cost against recovery speed."],
    ["03", "Recovery isn't guaranteed", "Severe corruption or an overwrite can defeat even a good recovery tool — which is why backups exist in the first place."],
    ["04", "Disaster recovery planning ties it together", "RTOs, backup strategy and recovery strategy combine to minimize downtime and financial loss after a major failure."],
    ["05", "The comparison table is the exam-ready summary", "Ten side-by-side contrasts capture nearly every distinction between the two concepts."],
    ["06", "Real incidents need both", "Ransomware, accidental deletion and hardware failure all resolve the same way: backup supplies the clean copy, recovery brings it back online."],
  ];
  return (
    <Slide tag="SEC // CH.26 // CLOSE" num="20" title={<>Chapter 26 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 26 · Backup vs Recovery</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents26.length} sections · {TOTAL26} slides</span>
      </div>
    </Slide>
  );
}
