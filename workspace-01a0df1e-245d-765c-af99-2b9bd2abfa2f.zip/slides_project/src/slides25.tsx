import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  adDsServices,
  adDsServicesIntro,
  adObjects25,
  advantages25,
  benefits25,
  ch25Intro,
  ch25Stamp,
  contents25,
  directoryServiceIntro,
  directoryServicePoints,
  disadvantages25,
  domainControllerIntro,
  domainControllerServices,
  questions25,
  terms25,
  TOTAL25,
} from "./data/ch25";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "directory tree" backdrop
================================================================== */
function DirectoryTreeBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="dtFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="dtGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* root node */}
      <g transform="translate(880 160)" filter="url(#dtGlow)">
        <rect x="-46" y="-18" width="92" height="36" fill="#0B0F0D" stroke="#3DF07A" strokeWidth="2" />
        <text x="0" y="5" textAnchor="middle" fill="#3DF07A" fontFamily="IBM Plex Mono, monospace" fontSize="11">FOREST</text>
      </g>
      {/* branches to domains */}
      {[[760, 280], [880, 300], [1010, 280]].map(([x, y], n) => (
        <g key={n}>
          <line x1="880" y1="178" x2={x} y2={y - 18} stroke="#3DF07A" strokeOpacity="0.4" strokeWidth="1.4" />
          <rect x={x - 40} y={y - 18} width="80" height="32" fill="#0B0F0D" stroke="#C7D2C9" strokeOpacity="0.5" strokeWidth="1.3" />
          <text x={x} y={y + 3} textAnchor="middle" fill="#C7D2C9" fontFamily="IBM Plex Mono, monospace" fontSize="9.5">DOMAIN</text>
        </g>
      ))}
      {/* leaves under middle domain */}
      {[[820, 400], [880, 420], [940, 400]].map(([x, y], n) => (
        <g key={n}>
          <line x1="880" y1="314" x2={x} y2={y - 14} stroke="#FFB020" strokeOpacity="0.4" strokeWidth="1.2" />
          <circle cx={x} cy={y} r="14" fill="none" stroke="#FFB020" strokeWidth="1.6" />
        </g>
      ))}
      <rect width="1200" height="700" fill="url(#dtFade)" />
    </svg>
  );
}

export function TitleSlide25({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <DirectoryTreeBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Directory services briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 25 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.25&nbsp;//&nbsp;AD&nbsp;DS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL25}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 25</span>
              <span className="mt-1 block text-[clamp(1.8rem,5.4vw,4.7rem)] text-phos glow">Active Directory</span>
              <span className="mt-1 block text-[clamp(1.8rem,5.4vw,4.7rem)] text-phos glow">Domain Services</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch25Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(4)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to AD DS services</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Benefits", "Nine"], ["AD DS services", "Five"], ["Glossary terms", "Twelve"], ["Doc revision", ch25Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide25() {
  return (
    <Slide tag="SEC // CH.25 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch25Intro} dense>
      <motion.div variants={rise}>
        <Panel className="p-5">
          <div className="font-mono text-[9.5px] tracked text-amber">In one line</div>
          <p className="mt-3 max-w-[70ch] text-[13.5px] font-light leading-[1.6] text-sage/85">
            A directory is any structured, searchable listing of objects — a
            phone book is the everyday example. Active Directory is
            Microsoft's directory technology for managing computers, users
            and devices across a Windows Server network.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Directory", "Windows Server", "Network objects", "Centralized management"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
          </div>
        </Panel>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   03 · BENEFITS
================================================================== */
export function BenefitsSlide25() {
  return (
    <Slide tag="SEC // CH.25 // BENEFITS" num="03" title={<>Benefits of <span className="text-phos">Active Directory</span></>} dense>
      <div>
        {benefits25.map((b, n) => (
          <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.03} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · DIRECTORY SERVICE
================================================================== */
export function DirectoryServiceSlide25() {
  return (
    <Slide tag="SEC // CH.25 // DIRECTORY SERVICE" num="04" title={<>What is a <span className="text-phos">directory service</span></>} lede={directoryServiceIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {directoryServicePoints.map((p, n) => (
            <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Up next</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{adDsServicesIntro}</p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · AD DS SERVICES
================================================================== */
export function AdDsServicesSlide25() {
  return (
    <Slide tag="SEC // CH.25 // AD DS SERVICES" num="05" title={<>The five <span className="text-phos">AD DS services</span></>} dense>
      <div>
        {adDsServices.map((s, n) => (
          <Row key={s.name} i={String(n + 1).padStart(2, "0")} label={s.name} desc={s.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · DOMAIN CONTROLLERS
================================================================== */
export function DomainControllersSlide25() {
  return (
    <Slide tag="SEC // CH.25 // DOMAIN CONTROLLERS" num="06" title={<><span className="text-phos">Domain controllers</span></>} lede={domainControllerIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {domainControllerServices.map((s, n) => (
          <motion.div key={s} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2.5 text-[13px] font-light leading-[1.5] text-sage/85">{s}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · ACTIVE DIRECTORY OBJECTS
================================================================== */
export function AdObjectsSlide25() {
  return (
    <Slide tag="SEC // CH.25 // OBJECTS" num="07" title={<>Active Directory <span className="text-phos">objects</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {adObjects25.map((o, n) => (
          <motion.div key={o.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>0{n + 1}</span>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{o.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{o.desc}</p>
            </div>
            <ul className="mt-auto flex flex-wrap gap-2 border-t border-sage/15 bg-ink p-4">
              {o.examples.map((e) => <Tag key={e} tone="muted">{e}</Tag>)}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · TERMINOLOGY I
================================================================== */
export function TerminologyASlide25() {
  const half = terms25.slice(0, 6);
  return (
    <Slide tag="SEC // CH.25 // GLOSSARY I" num="08" title={<>Common terminology &amp; <span className="text-phos">AD concepts</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {half.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.92rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · TERMINOLOGY II
================================================================== */
export function TerminologyBSlide25() {
  const half = terms25.slice(6, 12);
  return (
    <Slide tag="SEC // CH.25 // GLOSSARY II" num="09" title={<>More terminology &amp; <span className="text-phos">AD concepts</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {half.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 7}</span>
            <h3 className="mt-2 font-display text-[0.92rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · ADVANTAGES
================================================================== */
export function AdvantagesSlide25() {
  return (
    <Slide tag="SEC // CH.25 // TRADE-OFFS" num="10" title={<>Advantages of <span className="text-phos">AD DS</span></>} dense>
      <div>
        {advantages25.map((a, n) => (
          <Row key={a.name} i={String(n + 1).padStart(2, "0")} label={a.name} desc={a.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · DISADVANTAGES
================================================================== */
export function DisadvantagesSlide25() {
  return (
    <Slide tag="SEC // CH.25 // TRADE-OFFS" num="11" title={<>Disadvantages of <span className="text-phos">AD DS</span></>} dense>
      <div>
        {disadvantages25.map((a, n) => (
          <Row key={a.name} i={String(n + 1).padStart(2, "0")} label={a.name} desc={a.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide25({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 1 item</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.25 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          One question,
          <br />
          <span className="text-phos glow">one controller.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          A single item on the core role of a domain controller inside
          Active Directory. Select an answer to reveal it instantly — the
          rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(12)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   13 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide25({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions25[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.25 // CHECK // Q0${n + 1}`} num={String(13 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 01</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Active Directory"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · SCORE
================================================================== */
export function ScoreSlide25({ answers }: { answers: (number | null)[] }) {
  const score = questions25.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions25.length) * 100);
  const verdict = pct === 100 ? "Correct — the domain controller's role is clear." : "Re-read the Domain Controllers section, then retake.";
  return (
    <Slide tag="SEC // CH.25 // CHECK // RESULT" num="14" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions25.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions25.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions25.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide25() {
  const items = [
    ["01", "A directory is just a structured listing", "Active Directory applies that idea to every computer, user and device on a Windows Server network."],
    ["02", "AD DS is five services in one", "Domain Services, Certificate Services, Lightweight Directory Services, Federation Services and Rights Management each solve a different piece of identity and access."],
    ["03", "Domain controllers do the heavy lifting", "They host the directory database and run Kerberos KDC, NetLogon, Windows Time and Intersite Messaging."],
    ["04", "Two object types cover everything", "Containers (forests, trees, domains, OUs) hold things; leaves (users, computers, printers) are the things being held."],
    ["05", "The glossary is the real foundation", "Schema, LDAP, replication, trust relationships and Group Policy are the vocabulary every AD conversation depends on."],
    ["06", "Centralization is a trade-off", "AD DS buys huge administrative leverage at the cost of complexity, licensing cost and a bigger attack surface to defend."],
  ];
  return (
    <Slide tag="SEC // CH.25 // CLOSE" num="15" title={<>Chapter 25 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 25 · Active Directory Domain Services</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents25.length} sections · {TOTAL25} slides</span>
      </div>
    </Slide>
  );
}
