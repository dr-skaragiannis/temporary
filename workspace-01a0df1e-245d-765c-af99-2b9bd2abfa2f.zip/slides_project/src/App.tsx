import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { Mark } from "./components/mark";
import { contents, TOTAL, questions } from "./data/content";
import { contents2, TOTAL2, questions2 } from "./data/ch2";
import { contents3, TOTAL3, questions3 } from "./data/ch3";
import { contents4, TOTAL4, questions4 } from "./data/ch4";
import { contents5, TOTAL5, questions5 } from "./data/ch5";
import { contents6, TOTAL6, questions6 } from "./data/ch6";
import { contents7, TOTAL7, questions7 } from "./data/ch7";
import { contents8, TOTAL8, questions8 } from "./data/ch8";
import { contents9, TOTAL9, questions9 } from "./data/ch9";
import { contents10, TOTAL10, questions10 } from "./data/ch10";
import { contents11, TOTAL11, questions11 } from "./data/ch11";
import { contents12, TOTAL12, questions12 } from "./data/ch12";
import { contents13, TOTAL13, questions13 } from "./data/ch13";
import { contents14, TOTAL14, questions14 } from "./data/ch14";
import { contents15, TOTAL15, questions15 } from "./data/ch15";
import { contents16, TOTAL16, questions16 } from "./data/ch16";
import { contents17, TOTAL17, questions17 } from "./data/ch17";
import { contents18, TOTAL18, questions18 } from "./data/ch18";
import { contents19, TOTAL19, questions19 } from "./data/ch19";
import { contents20, TOTAL20, questions20 } from "./data/ch20";
import { contents21, TOTAL21, questions21 } from "./data/ch21";
import { contents22, TOTAL22, questions22 } from "./data/ch22";
import { contents23, TOTAL23, questions23 } from "./data/ch23";
import { contents24, TOTAL24, questions24 } from "./data/ch24";
import { contents25, TOTAL25, questions25 } from "./data/ch25";
import { contents26, TOTAL26, questions26 } from "./data/ch26";
import { contents27, TOTAL27, questions27 } from "./data/ch27";
import { contents28, TOTAL28 } from "./data/ch28";
import { contents29, TOTAL29 } from "./data/ch29";
import { contents30, questions30, TOTAL30 } from "./data/ch30";
import { contents31, questions31, TOTAL31 } from "./data/ch31";
import { contents32, questions32, TOTAL32 } from "./data/ch32";
import { contents33, questions33, TOTAL33 } from "./data/ch33";
import * as S1 from "./slides";
import * as S2 from "./slides2";
import * as S3 from "./slides3";
import * as S4 from "./slides4";
import * as S5 from "./slides5";
import * as S6 from "./slides6";
import * as S7 from "./slides7";
import * as S8 from "./slides8";
import * as S9 from "./slides9";
import * as S10 from "./slides10";
import * as S11 from "./slides11";
import * as S12 from "./slides12";
import * as S13 from "./slides13";
import * as S14 from "./slides14";
import * as S15 from "./slides15";
import * as S16 from "./slides16";
import * as S17 from "./slides17";
import * as S18 from "./slides18";
import * as S19 from "./slides19";
import * as S20 from "./slides20";
import * as S21 from "./slides21";
import * as S22 from "./slides22";
import * as S23 from "./slides23";
import * as S24 from "./slides24";
import * as S25 from "./slides25";
import * as S26 from "./slides26";
import * as S27 from "./slides27";
import * as S28 from "./slides28";
import * as S29 from "./slides29";
import * as S30 from "./slides30";
import * as S31 from "./slides31";
import * as S32 from "./slides32";
import * as S33 from "./slides33";

/* ------------------------------------------------------------------ */
type Item = { label: string; idx: number; section: string };

const buildFlat = (c: { section: string; items: string[] }[]): Item[] => {
  const out: Item[] = [];
  c.forEach((g) =>
    g.items.forEach((it) =>
      out.push({ label: it, idx: out.length, section: g.section }),
    ),
  );
  return out;
};

const CHAPTERS = [
  {
    n: 1,
    code: "CH.01",
    short: "01",
    name: "Introduction to Cybersecurity",
    rail: "Intro to Cybersecurity · Ch.01",
    flat: buildFlat(contents),
    total: TOTAL,
    quiz: { start: 18, first: 19, count: 5, score: 24 },
  },
  {
    n: 2,
    code: "CH.02",
    short: "02",
    name: "Linux Permissions",
    rail: "Linux Permissions · Ch.02",
    flat: buildFlat(contents2),
    total: TOTAL2,
    quiz: { start: 16, first: 17, count: 5, score: 22 },
  },
  {
    n: 3,
    code: "CH.03",
    short: "03",
    name: "Applications of Cybersecurity",
    rail: "Applications · Ch.03",
    flat: buildFlat(contents3),
    total: TOTAL3,
    quiz: { start: 11, first: 12, count: 6, score: 18 },
  },
  {
    n: 4,
    code: "CH.04",
    short: "04",
    name: "Types of Cyber Attacks",
    rail: "Cyber Attacks · Ch.04",
    flat: buildFlat(contents4),
    total: TOTAL4,
    quiz: { start: 12, first: 13, count: 5, score: 18 },
  },
  {
    n: 5,
    code: "CH.05",
    short: "05",
    name: "Hackers and Their Types",
    rail: "Hackers · Ch.05",
    flat: buildFlat(contents5),
    total: TOTAL5,
    quiz: { start: 14, first: 15, count: 5, score: 20 },
  },
  {
    n: 6,
    code: "CH.06",
    short: "06",
    name: "Vulnerabilities in Information Security",
    rail: "Vulnerabilities · Ch.06",
    flat: buildFlat(contents6),
    total: TOTAL6,
    quiz: { start: 15, first: 16, count: 5, score: 21 },
  },
  {
    n: 7,
    code: "CH.07",
    short: "07",
    name: "Threat Actor",
    rail: "Threat Actor · Ch.07",
    flat: buildFlat(contents7),
    total: TOTAL7,
    quiz: { start: 13, first: 14, count: 5, score: 19 },
  },
  {
    n: 8,
    code: "CH.08",
    short: "08",
    name: "Careers & Roadmap",
    rail: "Careers · Ch.08",
    flat: buildFlat(contents8),
    total: TOTAL8,
    quiz: { start: 13, first: 14, count: 5, score: 19 },
  },
  {
    n: 9,
    code: "CH.09",
    short: "09",
    name: "Types of Cyber Crime",
    rail: "Cyber Crime · Ch.09",
    flat: buildFlat(contents9),
    total: TOTAL9,
    quiz: { start: 9, first: 10, count: 5, score: 15 },
  },
  {
    n: 10,
    code: "CH.10",
    short: "10",
    name: "Social Engineering & Cyberstalking",
    rail: "Social Eng. · Ch.10",
    flat: buildFlat(contents10),
    total: TOTAL10,
    quiz: { start: 13, first: 14, count: 11, score: 25 },
  },
  {
    n: 11,
    code: "CH.11",
    short: "11",
    name: "Emerging Attack Vectors",
    rail: "Attack Vectors · Ch.11",
    flat: buildFlat(contents11),
    total: TOTAL11,
    quiz: { start: 9, first: 10, count: 5, score: 15 },
  },
  {
    n: 12,
    code: "CH.12",
    short: "12",
    name: "Botnets",
    rail: "Botnets · Ch.12",
    flat: buildFlat(contents12),
    total: TOTAL12,
    quiz: { start: 9, first: 10, count: 4, score: 14 },
  },
  {
    n: 13,
    code: "CH.13",
    short: "13",
    name: "Malware & Its Types",
    rail: "Malware · Ch.13",
    flat: buildFlat(contents13),
    total: TOTAL13,
    quiz: { start: 10, first: 11, count: 6, score: 17 },
  },
  {
    n: 14,
    code: "CH.14",
    short: "14",
    name: "Phishing",
    rail: "Phishing · Ch.14",
    flat: buildFlat(contents14),
    total: TOTAL14,
    quiz: { start: 9, first: 10, count: 5, score: 15 },
  },
  {
    n: 15,
    code: "CH.15",
    short: "15",
    name: "Identity Theft",
    rail: "Identity Theft · Ch.15",
    flat: buildFlat(contents15),
    total: TOTAL15,
    quiz: { start: 8, first: 9, count: 5, score: 14 },
  },
  {
    n: 16,
    code: "CH.16",
    short: "16",
    name: "History of Cybersecurity",
    rail: "History · Ch.16",
    flat: buildFlat(contents16),
    total: TOTAL16,
    quiz: { start: 10, first: 11, count: 5, score: 16 },
  },
  {
    n: 17,
    code: "CH.17",
    short: "17",
    name: "Cyber Security Metrics",
    rail: "Security Metrics · Ch.17",
    flat: buildFlat(contents17),
    total: TOTAL17,
    quiz: { start: 11, first: 12, count: 6, score: 18 },
  },
  {
    n: 18,
    code: "CH.18",
    short: "18",
    name: "Security Management System",
    rail: "Security Mgmt. System · Ch.18",
    flat: buildFlat(contents18),
    total: TOTAL18,
    quiz: { start: 12, first: 13, count: 4, score: 17 },
  },
  {
    n: 19,
    code: "CH.19",
    short: "19",
    name: "Cybersecurity Framework",
    rail: "Cybersecurity Framework · Ch.19",
    flat: buildFlat(contents19),
    total: TOTAL19,
    quiz: { start: 12, first: 13, count: 5, score: 18 },
  },
  {
    n: 20,
    code: "CH.20",
    short: "20",
    name: "Cyber Security in Critical Infrastructure",
    rail: "Critical Infrastructure · Ch.20",
    flat: buildFlat(contents20),
    total: TOTAL20,
    quiz: { start: 9, first: 10, count: 5, score: 15 },
  },
  {
    n: 21,
    code: "CH.21",
    short: "21",
    name: "Authentication Applications",
    rail: "Auth. Applications · Ch.21",
    flat: buildFlat(contents21),
    total: TOTAL21,
    quiz: { start: 21, first: 22, count: 5, score: 27 },
  },
  {
    n: 22,
    code: "CH.22",
    short: "22",
    name: "X.509 Authentication Service",
    rail: "X.509 Auth. Service · Ch.22",
    flat: buildFlat(contents22),
    total: TOTAL22,
    quiz: { start: 6, first: 7, count: 5, score: 12 },
  },
  {
    n: 23,
    code: "CH.23",
    short: "23",
    name: "Multi-Factor Authentication (MFA)",
    rail: "Multi-Factor Auth. · Ch.23",
    flat: buildFlat(contents23),
    total: TOTAL23,
    quiz: { start: 11, first: 12, count: 5, score: 17 },
  },
  {
    n: 24,
    code: "CH.24",
    short: "24",
    name: "Single Sign On (SSO)",
    rail: "Single Sign On (SSO) · Ch.24",
    flat: buildFlat(contents24),
    total: TOTAL24,
    quiz: { start: 8, first: 9, count: 5, score: 14 },
  },
  {
    n: 25,
    code: "CH.25",
    short: "25",
    name: "Active Directory Domain Services",
    rail: "Active Directory Domain Svcs · Ch.25",
    flat: buildFlat(contents25),
    total: TOTAL25,
    quiz: { start: 11, first: 12, count: 1, score: 13 },
  },
  {
    n: 26,
    code: "CH.26",
    short: "26",
    name: "Backup vs Recovery",
    rail: "Backup vs Recovery · Ch.26",
    flat: buildFlat(contents26),
    total: TOTAL26,
    quiz: { start: 13, first: 14, count: 4, score: 18 },
  },
  {
    n: 27,
    code: "CH.27",
    short: "27",
    name: "Secure Coding",
    rail: "Secure Coding · Ch.27",
    flat: buildFlat(contents27),
    total: TOTAL27,
    quiz: { start: 19, first: 20, count: 5, score: 25 },
  },
  {
    n: 28,
    code: "CH.28",
    short: "28",
    name: "Static Application Security Testing (SAST)",
    rail: "Static App. Security Testing · Ch.28",
    flat: buildFlat(contents28),
    total: TOTAL28,
    // No knowledge check was supplied for this chapter — quiz range is
    // pushed out of bounds so no question/score slide is ever matched.
    quiz: { start: 9999, first: 9999, count: 0, score: 9999 },
  },
  {
    n: 29,
    code: "CH.29",
    short: "29",
    name: "DAST & Vulnerability Assessment",
    rail: "DAST & Vuln. Assessment · Ch.29",
    flat: buildFlat(contents29),
    total: TOTAL29,
    // No knowledge check was supplied for this chapter either.
    quiz: { start: 9999, first: 9999, count: 0, score: 9999 },
  },
  {
    n: 30,
    code: "CH.30",
    short: "30",
    name: "Vulnerability Assessment: Types, Comparisons & Process",
    rail: "Vulnerability Assessment · Ch.30",
    flat: buildFlat(contents30),
    total: TOTAL30,
    quiz: { start: 12, first: 13, count: 4, score: 17 },
  },
  {
    n: 31,
    code: "CH.31",
    short: "31",
    name: "Penetration Testing — Software Engineering",
    rail: "Penetration Testing · Ch.31",
    flat: buildFlat(contents31),
    total: TOTAL31,
    quiz: { start: 12, first: 13, count: 5, score: 18 },
  },
  {
    n: 32,
    code: "CH.32",
    short: "32",
    name: "Intrusion Detection System (IDS)",
    rail: "Intrusion Detection · Ch.32",
    flat: buildFlat(contents32),
    total: TOTAL32,
    quiz: { start: 13, first: 14, count: 5, score: 19 },
  },
  {
    n: 33,
    code: "CH.33",
    short: "33",
    name: "Intrusion Prevention System (IPS)",
    rail: "Intrusion Prevention · Ch.33",
    flat: buildFlat(contents33),
    total: TOTAL33,
    quiz: { start: 12, first: 13, count: 5, score: 18 },
  },
];

const CONTENTS_BY_CHAPTER: Record<number, { section: string; items: string[] }[]> = {
  1: contents,
  2: contents2,
  3: contents3,
  4: contents4,
  5: contents5,
  6: contents6,
  7: contents7,
  8: contents8,
  9: contents9,
  10: contents10,
  11: contents11,
  12: contents12,
  13: contents13,
  14: contents14,
  15: contents15,
  16: contents16,
  17: contents17,
  18: contents18,
  19: contents19,
  20: contents20,
  21: contents21,
  22: contents22,
  23: contents23,
  24: contents24,
  25: contents25,
  26: contents26,
  27: contents27,
  28: contents28,
  29: contents29,
  30: contents30,
  31: contents31,
  32: contents32,
  33: contents33,
};

const QUESTION_SETS: Record<number, { q: { answer: number }[] }> = {
  1: { q: questions },
  2: { q: questions2 },
  3: { q: questions3 },
  4: { q: questions4 },
  5: { q: questions5 },
  6: { q: questions6 },
  7: { q: questions7 },
  8: { q: questions8 },
  9: { q: questions9 },
  10: { q: questions10 },
  11: { q: questions11 },
  12: { q: questions12 },
  13: { q: questions13 },
  14: { q: questions14 },
  15: { q: questions15 },
  16: { q: questions16 },
  17: { q: questions17 },
  18: { q: questions18 },
  19: { q: questions19 },
  20: { q: questions20 },
  21: { q: questions21 },
  22: { q: questions22 },
  23: { q: questions23 },
  24: { q: questions24 },
  25: { q: questions25 },
  26: { q: questions26 },
  27: { q: questions27 },
  28: { q: [] },
  29: { q: [] },
  30: { q: questions30 },
  31: { q: questions31 },
  32: { q: questions32 },
  33: { q: questions33 },
};

const INITIAL_ANSWERS = (n: number) =>
  Array.from({ length: n }, () => null as number | null);

export default function App() {
  const [ch, setCh] = useState(1);
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Record<number, (number | null)[]>>(() => ({
    1: INITIAL_ANSWERS(questions.length),
    2: INITIAL_ANSWERS(questions2.length),
    3: INITIAL_ANSWERS(questions3.length),
    4: INITIAL_ANSWERS(questions4.length),
  }));
  const [open, setOpen] = useState(false);
  const [railOpen, setRailOpen] = useState(false);

  const meta = CHAPTERS[ch - 1];
  const flat = meta.flat;
  const total = meta.total;
  const quiz = meta.quiz;

  const go = useCallback(
    (n: number) => {
      setI(Math.max(0, Math.min(total - 1, n)));
      setOpen(false);
    },
    [total],
  );
  const next = useCallback(() => go(i + 1), [go, i]);
  const prev = useCallback(() => go(i - 1), [go, i]);

  const jumpChapter = (n: number) => {
    setCh(n);
    setI(0);
    setOpen(false);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      const t = e.target as HTMLElement | null;
      const tag = t?.tagName ?? "";
      /* never steal keys from a text field, and let a focused
         control handle its own Space / Enter activation */
      if (
        tag === "INPUT" ||
        tag === "TEXTAREA" ||
        tag === "SELECT" ||
        t?.isContentEditable
      )
        return;
      if ((tag === "BUTTON" || tag === "A") && (k === " " || k === "Enter"))
        return;
      if (k === "ArrowRight" || k === "PageDown" || k === " ") {
        e.preventDefault();
        next();
      } else if (k === "ArrowLeft" || k === "PageUp") {
        e.preventDefault();
        prev();
      } else if (k === "Home") {
        go(0);
      } else if (k === "End") {
        go(total - 1);
      } else if (k === "i" || k === "I") {
        setOpen((o) => !o);
      } else if (k === "m" || k === "M") {
        setRailOpen((o) => !o);
      } else if (k === "Escape") {
        setOpen(false);
        setRailOpen(false);
      } else if (["1", "2", "3", "4", "5", "6", "7", "8", "9"].includes(k)) {
        jumpChapter(Number(k));
      } else if (k === "0") {
        jumpChapter(10);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  /* ---- quiz ---- */
  const chapterAnswers = answers[ch] ?? [];
  const qStart = quiz.first;
  const qEnd = quiz.first + quiz.count - 1;
  const activeQuestions = QUESTION_SETS[ch].q as {
    q: string;
    options: string[];
    answer: number;
    why: string;
  }[];

  const setAnswer = (n: number, c: number) =>
    setAnswers((prevA) => {
      const arr = [...(prevA[ch] ?? [])];
      arr[n] = c;
      return { ...prevA, [ch]: arr };
    });

  const score = useMemo(
    () =>
      activeQuestions.reduce(
        (a, q, n) => a + (chapterAnswers[n] === q.answer ? 1 : 0),
        0,
      ),
    [activeQuestions, chapterAnswers],
  );

  /* ---- slide router ---- */
  const slide = useMemo(() => {
    if (i >= qStart && i <= qEnd) {
      const n = i - qStart;
      const sel = chapterAnswers[n];
      const onAnswer = (c: number) => setAnswer(n, c);
      if (ch === 1)
        return <S1.QuestionSlide n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 2)
        return <S2.QuestionSlide2 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 4)
        return <S4.QuestionSlide4 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 5)
        return <S5.QuestionSlide5 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 6)
        return <S6.QuestionSlide6 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 7)
        return <S7.QuestionSlide7 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 8)
        return <S8.QuestionSlide8 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 9)
        return <S9.QuestionSlide9 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 10)
        return <S10.QuestionSlide10 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 11)
        return <S11.QuestionSlide11 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 12)
        return <S12.QuestionSlide12 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 13)
        return <S13.QuestionSlide13 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 14)
        return <S14.QuestionSlide14 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 15)
        return <S15.QuestionSlide15 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 16)
        return <S16.QuestionSlide16 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 17)
        return <S17.QuestionSlide17 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 18)
        return <S18.QuestionSlide18 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 19)
        return <S19.QuestionSlide19 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 20)
        return <S20.QuestionSlide20 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 21)
        return <S21.QuestionSlide21 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 22)
        return <S22.QuestionSlide22 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 23)
        return <S23.QuestionSlide23 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 24)
        return <S24.QuestionSlide24 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 25)
        return <S25.QuestionSlide25 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 26)
        return <S26.QuestionSlide26 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 27)
        return <S27.QuestionSlide27 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 30)
        return <S30.QuestionSlide30 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 31)
        return <S31.QuestionSlide31 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 32)
        return <S32.QuestionSlide32 n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 33)
        return <S33.QuestionSlide33 n={n} selected={sel} onAnswer={onAnswer} />;
      return <S3.QuestionSlide3 n={n} selected={sel} onAnswer={onAnswer} />;
    }
    if (i === quiz.score) {
      if (ch === 1) return <S1.ScoreSlide answers={chapterAnswers} />;
      if (ch === 2) return <S2.ScoreSlide2 answers={chapterAnswers} />;
      if (ch === 4) return <S4.ScoreSlide4 answers={chapterAnswers} />;
      if (ch === 5) return <S5.ScoreSlide5 answers={chapterAnswers} />;
      if (ch === 6) return <S6.ScoreSlide6 answers={chapterAnswers} />;
      if (ch === 7) return <S7.ScoreSlide7 answers={chapterAnswers} />;
      if (ch === 8) return <S8.ScoreSlide8 answers={chapterAnswers} />;
      if (ch === 9) return <S9.ScoreSlide9 answers={chapterAnswers} />;
      if (ch === 10) return <S10.ScoreSlide10 answers={chapterAnswers} />;
      if (ch === 11) return <S11.ScoreSlide11 answers={chapterAnswers} />;
      if (ch === 12) return <S12.ScoreSlide12 answers={chapterAnswers} />;
      if (ch === 13) return <S13.ScoreSlide13 answers={chapterAnswers} />;
      if (ch === 14) return <S14.ScoreSlide14 answers={chapterAnswers} />;
      if (ch === 15) return <S15.ScoreSlide15 answers={chapterAnswers} />;
      if (ch === 16) return <S16.ScoreSlide16 answers={chapterAnswers} />;
      if (ch === 17) return <S17.ScoreSlide17 answers={chapterAnswers} />;
      if (ch === 18) return <S18.ScoreSlide18 answers={chapterAnswers} />;
      if (ch === 19) return <S19.ScoreSlide19 answers={chapterAnswers} />;
      if (ch === 20) return <S20.ScoreSlide20 answers={chapterAnswers} />;
      if (ch === 21) return <S21.ScoreSlide21 answers={chapterAnswers} />;
      if (ch === 22) return <S22.ScoreSlide22 answers={chapterAnswers} />;
      if (ch === 23) return <S23.ScoreSlide23 answers={chapterAnswers} />;
      if (ch === 24) return <S24.ScoreSlide24 answers={chapterAnswers} />;
      if (ch === 25) return <S25.ScoreSlide25 answers={chapterAnswers} />;
      if (ch === 26) return <S26.ScoreSlide26 answers={chapterAnswers} />;
      if (ch === 27) return <S27.ScoreSlide27 answers={chapterAnswers} />;
      if (ch === 30) return <S30.ScoreSlide30 answers={chapterAnswers} />;
      if (ch === 31) return <S31.ScoreSlide31 answers={chapterAnswers} />;
      if (ch === 32) return <S32.ScoreSlide32 answers={chapterAnswers} />;
      if (ch === 33) return <S33.ScoreSlide33 answers={chapterAnswers} />;
      return <S3.ScoreSlide3 answers={chapterAnswers} />;
    }

    if (ch === 1) {
      switch (i) {
        case 0:
          return <S1.TitleSlide go={go} />;
        case 1:
          return <S1.DefinitionSlide />;
        case 2:
          return <S1.PracticeSlide />;
        case 3:
          return <S1.ObjectivesSlide />;
        case 4:
          return <S1.StandardsSlide />;
        case 5:
          return <S1.AtStakeSlide />;
        case 6:
          return <S1.TriadSlide />;
        case 7:
          return <S1.TriadDetailSlide />;
        case 8:
          return <S1.DomainsIndexSlide />;
        case 9:
          return <S1.DomainsDetailA />;
        case 10:
          return <S1.DomainsDetailB />;
        case 11:
          return <S1.AttackTableSlide />;
        case 12:
          return <S1.ThreatWheelSlide />;
        case 13:
          return <S1.ThreatsSlide />;
        case 14:
          return <S1.NumbersSlide />;
        case 15:
          return <S1.ForensicsSlide />;
        case 16:
          return <S1.TrendsSlide />;
        case 17:
          return <S1.ChallengesSlide />;
        case 18:
          return <S1.QuizIntroSlide go={go} />;
        default:
          return <S1.TakeawaysSlide />;
      }
    }

    if (ch === 2) {
      switch (i) {
        case 0:
          return <S2.TitleSlide2 go={go} />;
        case 1:
          return <S2.WhySlide />;
        case 2:
          return <S2.ThreePermsSlide />;
        case 3:
          return <S2.OwnershipSlide />;
        case 4:
          return <S2.OperatorsSlide />;
        case 5:
          return <S2.NineCharsSlide />;
        case 6:
          return <S2.ClassRefSlide />;
        case 7:
          return <S2.LsSlide />;
        case 8:
          return <S2.NameiStatSlide />;
        case 9:
          return <S2.ChmodSymbolicSlide />;
        case 10:
          return <S2.SymbolicExamplesSlide />;
        case 11:
          return <S2.OctalSlide />;
        case 12:
          return <S2.ModeReadingSlide />;
        case 13:
          return <S2.SpecialPermsSlide />;
        case 14:
          return <S2.ChownSlide />;
        case 15:
          return <S2.SimulatorSlide />;
        case 16:
          return <S2.QuizIntroSlide2 go={go} />;
        default:
          return <S2.TakeawaysSlide2 />;
      }
    }

    if (ch === 22) {
      switch (i) {
        case 0:
          return <S22.TitleSlide22 go={go} />;
        case 1:
          return <S22.IntroSlide22 />;
        case 2:
          return <S22.WorkingSlide22 />;
        case 3:
          return <S22.FormatSlide22 />;
        case 4:
          return <S22.CharacteristicsSlide22 />;
        case 5:
          return <S22.ApplicationsSlide22 />;
        case 6:
          return <S22.QuizIntroSlide22 go={go} />;
        default:
          return <S22.TakeawaysSlide22 />;
      }
    }

    if (ch === 23) {
      switch (i) {
        case 0:
          return <S23.TitleSlide23 go={go} />;
        case 1:
          return <S23.IntroSlide23 />;
        case 2:
          return <S23.ComponentsSlide23 />;
        case 3:
          return <S23.ImportanceSlide23 />;
        case 4:
          return <S23.SelectingSlide23 />;
        case 5:
          return <S23.PrimaryMethodsSlide23 />;
        case 6:
          return <S23.AdvancedMethodsSlide23 />;
        case 7:
          return <S23.TokenMethodsSlide23 />;
        case 8:
          return <S23.StrengthSlide23 />;
        case 9:
          return <S23.AdvantagesSlide23 />;
        case 10:
          return <S23.DisadvantagesSlide23 />;
        case 11:
          return <S23.QuizIntroSlide23 go={go} />;
        default:
          return <S23.TakeawaysSlide23 />;
      }
    }

    if (ch === 24) {
      switch (i) {
        case 0:
          return <S24.TitleSlide24 go={go} />;
        case 1:
          return <S24.IntroSlide24 />;
        case 2:
          return <S24.WorkingSlide24 />;
        case 3:
          return <S24.ConfigsASlide24 />;
        case 4:
          return <S24.ConfigsBSlide24 />;
        case 5:
          return <S24.TokenSlide24 />;
        case 6:
          return <S24.AdvantagesSlide24 />;
        case 7:
          return <S24.DisadvantagesSlide24 />;
        case 8:
          return <S24.QuizIntroSlide24 go={go} />;
        default:
          return <S24.TakeawaysSlide24 />;
      }
    }

    if (ch === 25) {
      switch (i) {
        case 0:
          return <S25.TitleSlide25 go={go} />;
        case 1:
          return <S25.IntroSlide25 />;
        case 2:
          return <S25.BenefitsSlide25 />;
        case 3:
          return <S25.DirectoryServiceSlide25 />;
        case 4:
          return <S25.AdDsServicesSlide25 />;
        case 5:
          return <S25.DomainControllersSlide25 />;
        case 6:
          return <S25.AdObjectsSlide25 />;
        case 7:
          return <S25.TerminologyASlide25 />;
        case 8:
          return <S25.TerminologyBSlide25 />;
        case 9:
          return <S25.AdvantagesSlide25 />;
        case 10:
          return <S25.DisadvantagesSlide25 />;
        case 11:
          return <S25.QuizIntroSlide25 go={go} />;
        default:
          return <S25.TakeawaysSlide25 />;
      }
    }

    if (ch === 26) {
      switch (i) {
        case 0:
          return <S26.TitleSlide26 go={go} />;
        case 1:
          return <S26.IntroSlide26 />;
        case 2:
          return <S26.BackupIntroSlide26 />;
        case 3:
          return <S26.BackupTypesSlide26 />;
        case 4:
          return <S26.BackupAdvantagesSlide26 />;
        case 5:
          return <S26.BackupDisadvantagesSlide26 />;
        case 6:
          return <S26.RecoveryIntroSlide26 />;
        case 7:
          return <S26.DisasterRecoverySlide26 />;
        case 8:
          return <S26.RecoveryAdvantagesSlide26 />;
        case 9:
          return <S26.RecoveryDisadvantagesSlide26 />;
        case 10:
          return <S26.ComparisonASlide26 />;
        case 11:
          return <S26.ComparisonBSlide26 />;
        case 12:
          return <S26.ScenariosSlide26 />;
        case 13:
          return <S26.QuizIntroSlide26 go={go} />;
        default:
          return <S26.TakeawaysSlide26 />;
      }
    }

    if (ch === 27) {
      switch (i) {
        case 0:
          return <S27.TitleSlide27 go={go} />;
        case 1:
          return <S27.IntroSlide27 />;
        case 2:
          return <S27.ImportanceSlide27 />;
        case 3:
          return <S27.CodeCompareSlide27 />;
        case 4:
          return <S27.PrinciplesASlide27 />;
        case 5:
          return <S27.PrinciplesBSlide27 />;
        case 6:
          return <S27.WebAppIntroSlide27 />;
        case 7:
          return <S27.XssIntroSlide27 />;
        case 8:
          return <S27.XssDjangoSlide27 />;
        case 9:
          return <S27.FrontendCspSlide27 />;
        case 10:
          return <S27.SqlInjectionSlide27 />;
        case 11:
          return <S27.NosqlCommandSlide27 />;
        case 12:
          return <S27.DeserializationSlide27 />;
        case 13:
          return <S27.AuthSessionSlide27 />;
        case 14:
          return <S27.JwtAuthzSlide27 />;
        case 15:
          return <S27.CsrfCorsCachingSlide27 />;
        case 16:
          return <S27.ExpressOverviewSlide27 />;
        case 17:
          return <S27.ExpressCodeASlide27 />;
        case 18:
          return <S27.ExpressCodeBSlide27 />;
        case 19:
          return <S27.QuizIntroSlide27 go={go} />;
        default:
          return <S27.TakeawaysSlide27 />;
      }
    }

    if (ch === 28) {
      switch (i) {
        case 0:
          return <S28.TitleSlide28 go={go} />;
        case 1:
          return <S28.IntroSlide28 />;
        case 2:
          return <S28.StepsASlide28 />;
        case 3:
          return <S28.StepsBSlide28 />;
        case 4:
          return <S28.VulnerabilitiesSlide28 />;
        case 5:
          return <S28.ToolsSlide28 />;
        case 6:
          return <S28.CicdSlide28 />;
        case 7:
          return <S28.EmergingASlide28 />;
        case 8:
          return <S28.EmergingBSlide28 />;
        case 9:
          return <S28.SastVsDastSlide28 />;
        case 10:
          return <S28.LimitationsSlide28 />;
        default:
          return <S28.TakeawaysSlide28 />;
      }
    }

    if (ch === 29) {
      switch (i) {
        case 0:
          return <S29.TitleSlide29 go={go} />;
        case 1:
          return <S29.DastIntroSlide29 />;
        case 2:
          return <S29.DastStepsASlide29 />;
        case 3:
          return <S29.DastStepsBSlide29 />;
        case 4:
          return <S29.DastToolsSlide29 />;
        case 5:
          return <S29.DastAdvantagesSlide29 />;
        case 6:
          return <S29.DastVsSastSlide29 />;
        case 7:
          return <S29.VaIntroSlide29 />;
        case 8:
          return <S29.VaImportanceSlide29 />;
        default:
          return <S29.TakeawaysSlide29 />;
      }
    }

    if (ch === 30) {
      switch (i) {
        case 0:
          return <S30.TitleSlide30 go={go} />;
        case 1:
          return <S30.TypesSlide30 />;
        case 2:
          return <S30.GlanceSlide30 />;
        case 3:
          return <S30.DetailsASlide30 />;
        case 4:
          return <S30.DetailsBSlide30 />;
        case 5:
          return <S30.WorkingASlide30 />;
        case 6:
          return <S30.WorkingBSlide30 />;
        case 7:
          return <S30.ProcessSlide30 />;
        case 8:
          return <S30.UncoveredSlide30 />;
        case 9:
          return <S30.ToolsSlide30 />;
        case 10:
          return <S30.AdvantagesSlide30 />;
        case 11:
          return <S30.DisadvantagesSlide30 />;
        case 12:
          return <S30.QuizIntroSlide30 go={go} />;
        default:
          return <S30.TakeawaysSlide30 />;
      }
    }

    if (ch === 31) {
      switch (i) {
        case 0:
          return <S31.TitleSlide31 go={go} />;
        case 1:
          return <S31.IntroSlide31 />;
        case 2:
          return <S31.StagesSlide31 />;
        case 3:
          return <S31.MethodsASlide31 />;
        case 4:
          return <S31.MethodsBSlide31 />;
        case 5:
          return <S31.TypesSlide31 />;
        case 6:
          return <S31.RulesSlide31 />;
        case 7:
          return <S31.ToolsSlide31 />;
        case 8:
          return <S31.CaseStudySlide31 />;
        case 9:
          return <S31.TipsSlide31 />;
        case 10:
          return <S31.AdvantagesSlide31 />;
        case 11:
          return <S31.ApplicationsSlide31 />;
        case 12:
          return <S31.QuizIntroSlide31 go={go} />;
        default:
          return <S31.TakeawaysSlide31 />;
      }
    }

    if (ch === 32) {
      switch (i) {
        case 0:
          return <S32.TitleSlide32 go={go} />;
        case 1:
          return <S32.IntroSlide32 />;
        case 2:
          return <S32.IntrusionMethodsSlide32 />;
        case 3:
          return <S32.WorkingSlide32 />;
        case 4:
          return <S32.ClassificationASlide32 />;
        case 5:
          return <S32.ClassificationBSlide32 />;
        case 6:
          return <S32.EvasionSlide32 />;
        case 7:
          return <S32.DetectionMethodsSlide32 />;
        case 8:
          return <S32.VsFirewallSlide32 />;
        case 9:
          return <S32.ImportanceSlide32 />;
        case 10:
          return <S32.PlacementSlide32 />;
        case 11:
          return <S32.BenefitsSlide32 />;
        case 12:
          return <S32.LimitationsSlide32 />;
        case 13:
          return <S32.QuizIntroSlide32 go={go} />;
        default:
          return <S32.TakeawaysSlide32 />;
      }
    }

    if (ch === 33) {
      switch (i) {
        case 0:
          return <S33.TitleSlide33 go={go} />;
        case 1:
          return <S33.IntroSlide33 />;
        case 2:
          return <S33.InlineDeploymentSlide33 />;
        case 3:
          return <S33.PreprocessingSlide33 />;
        case 4:
          return <S33.LayeredInspectionSlide33 />;
        case 5:
          return <S33.DetectionMechanismsSlide33 />;
        case 6:
          return <S33.ResponseActionsSlide33 />;
        case 7:
          return <S33.TuningSlide33 />;
        case 8:
          return <S33.TypesSlide33 />;
        case 9:
          return <S33.ImportanceSlide33 />;
        case 10:
          return <S33.TechComparisonSlide33 />;
        case 11:
          return <S33.VsIdsSlide33 />;
        case 12:
          return <S33.QuizIntroSlide33 go={go} />;
        default:
          return <S33.TakeawaysSlide33 />;
      }
    }

    if (ch === 21) {
      switch (i) {
        case 0:
          return <S21.TitleSlide21 go={go} />;
        case 1:
          return <S21.IamIntroSlide21 />;
        case 2:
          return <S21.IamBenefitsSlide21 />;
        case 3:
          return <S21.IamImplementationSlide21 />;
        case 4:
          return <S21.IamRiseSlide21 />;
        case 5:
          return <S21.IamProtocolsSlide21 />;
        case 6:
          return <S21.IamPoliciesSlide21 />;
        case 7:
          return <S21.IamProsConsSlide21 />;
        case 8:
          return <S21.WinIntroSlide21 />;
        case 9:
          return <S21.WinAccountTypesSlide21 />;
        case 10:
          return <S21.WinCreateAccountSlide21 />;
        case 11:
          return <S21.WinResetPasswordASlide21 />;
        case 12:
          return <S21.WinResetPasswordBSlide21 />;
        case 13:
          return <S21.WinToolsASlide21 />;
        case 14:
          return <S21.WinToolsBSlide21 />;
        case 15:
          return <S21.KerbIntroSlide21 />;
        case 16:
          return <S21.KerbComponentsSlide21 />;
        case 17:
          return <S21.KerbWorkingSlide21 />;
        case 18:
          return <S21.KerbSecuritySlide21 />;
        case 19:
          return <S21.KerbApplicationsSlide21 />;
        case 20:
          return <S21.KerbLimitationsSlide21 />;
        case 21:
          return <S21.QuizIntroSlide21 go={go} />;
        default:
          return <S21.TakeawaysSlide21 />;
      }
    }

    if (ch === 20) {
      switch (i) {
        case 0:
          return <S20.TitleSlide20 go={go} />;
        case 1:
          return <S20.IntroSlide20 />;
        case 2:
          return <S20.ThreatLandscapeSlide20 />;
        case 3:
          return <S20.ChallengesSlide20 />;
        case 4:
          return <S20.PracticesSlide20 />;
        case 5:
          return <S20.SectorsIndexSlide20 />;
        case 6:
          return <S20.SectorsDetailA20 />;
        case 7:
          return <S20.SectorsDetailB20 />;
        case 8:
          return <S20.SectorsDetailC20 />;
        case 9:
          return <S20.QuizIntroSlide20 go={go} />;
        default:
          return <S20.TakeawaysSlide20 />;
      }
    }

    if (ch === 19) {
      switch (i) {
        case 0:
          return <S19.TitleSlide19 go={go} />;
        case 1:
          return <S19.IntroSlide19 />;
        case 2:
          return <S19.ProcessSlide19 />;
        case 3:
          return <S19.ComponentsSlide19 />;
        case 4:
          return <S19.FunctionsSlide19 />;
        case 5:
          return <S19.NeedSlide19 />;
        case 6:
          return <S19.CommonFrameworksSlide19 />;
        case 7:
          return <S19.TypesIndexSlide19 />;
        case 8:
          return <S19.TypesDetailA19 />;
        case 9:
          return <S19.TypesDetailB19 />;
        case 10:
          return <S19.TypesDetailC19 />;
        case 11:
          return <S19.BenefitsSlide19 />;
        case 12:
          return <S19.QuizIntroSlide19 go={go} />;
        default:
          return <S19.TakeawaysSlide19 />;
      }
    }

    if (ch === 18) {
      switch (i) {
        case 0:
          return <S18.TitleSlide18 go={go} />;
        case 1:
          return <S18.IntroSlide18 />;
        case 2:
          return <S18.ComponentsIndexSlide18 />;
        case 3:
          return <S18.ComponentsDetailA18 />;
        case 4:
          return <S18.ComponentsDetailB18 />;
        case 5:
          return <S18.FeaturesIndexSlide18 />;
        case 6:
          return <S18.PhysicalSafetySlide18 />;
        case 7:
          return <S18.AssetIdentificationSlide18 />;
        case 8:
          return <S18.SecurityProceduresSlide18 />;
        case 9:
          return <S18.ImportanceSlide18 />;
        case 10:
          return <S18.ToolsSlide18 />;
        case 11:
          return <S18.TrainingRiskSlide18 />;
        case 12:
          return <S18.QuizIntroSlide18 go={go} />;
        default:
          return <S18.TakeawaysSlide18 />;
      }
    }

    if (ch === 17) {
      switch (i) {
        case 0:
          return <S17.TitleSlide17 go={go} />;
        case 1:
          return <S17.IntroSlide17 />;
        case 2:
          return <S17.CharacteristicsSlide17 />;
        case 3:
          return <S17.TypesIndexSlide17 />;
        case 4:
          return <S17.TypesDetailA17 />;
        case 5:
          return <S17.TypesDetailB17 />;
        case 6:
          return <S17.UsesSlide17 />;
        case 7:
          return <S17.MetricsExamplesA17 />;
        case 8:
          return <S17.MetricsExamplesB17 />;
        case 9:
          return <S17.GoodBadSlide17 />;
        case 10:
          return <S17.ChallengesSlide17 />;
        case 11:
          return <S17.QuizIntroSlide17 go={go} />;
        default:
          return <S17.TakeawaysSlide17 />;
      }
    }

    if (ch === 16) {
      switch (i) {
        case 0:
          return <S16.TitleSlide16 go={go} />;
        case 1:
          return <S16.IntroSlide16 />;
        case 2:
          return <S16.TimelineSlide16 />;
        case 3:
          return <S16.Era1970s16 />;
        case 4:
          return <S16.CreeperReaperSlide16 />;
        case 5:
          return <S16.Era1980s16 />;
        case 6:
          return <S16.ModernErasSlide16 />;
        case 7:
          return <S16.LifecycleSlide16 />;
        case 8:
          return <S16.LawSolutionsSlide16 />;
        case 9:
          return <S16.FutureSlide16 />;
        case 10:
          return <S16.QuizIntroSlide16 go={go} />;
        default:
          return <S16.TakeawaysSlide16 />;
      }
    }

    if (ch === 15) {
      switch (i) {
        case 0:
          return <S15.TitleSlide15 go={go} />;
        case 1:
          return <S15.IntroSlide15 />;
        case 2:
          return <S15.TypesIndexSlide15 />;
        case 3:
          return <S15.TypesA15 />;
        case 4:
          return <S15.TypesB15 />;
        case 5:
          return <S15.MatrixSlide15 />;
        case 6:
          return <S15.TechniquesSlide15 />;
        case 7:
          return <S15.PreventionSlide15 />;
        case 8:
          return <S15.QuizIntroSlide15 go={go} />;
        default:
          return <S15.TakeawaysSlide15 />;
      }
    }

    if (ch === 14) {
      switch (i) {
        case 0:
          return <S14.TitleSlide14 go={go} />;
        case 1:
          return <S14.IntroSlide14 />;
        case 2:
          return <S14.MethodsSlide14 />;
        case 3:
          return <S14.TypesSlide14 />;
        case 4:
          return <S14.SpectrumSlide14 />;
        case 5:
          return <S14.SignsSlide14 />;
        case 6:
          return <S14.PreventionSlide14 />;
        case 7:
          return <S14.FakeRealSlide14 />;
        case 8:
          return <S14.ToolsSlide14 />;
        case 9:
          return <S14.QuizIntroSlide14 go={go} />;
        default:
          return <S14.TakeawaysSlide14 />;
      }
    }

    if (ch === 13) {
      switch (i) {
        case 0:
          return <S13.TitleSlide13 go={go} />;
        case 1:
          return <S13.IntroSlide13 />;
        case 2:
          return <S13.TypesSlide13 />;
        case 3:
          return <S13.CompareSlide13 />;
        case 4:
          return <S13.SignsSlide13 />;
        case 5:
          return <S13.PurposeSlide13 />;
        case 6:
          return <S13.ExamplesSlide13 />;
        case 7:
          return <S13.ProtectionSlide13 />;
        case 8:
          return <S13.RemovalSlide13 />;
        case 9:
          return <S13.ToolsSlide13 />;
        case 10:
          return <S13.QuizIntroSlide13 go={go} />;
        default:
          return <S13.TakeawaysSlide13 />;
      }
    }

    if (ch === 12) {
      switch (i) {
        case 0:
          return <S12.TitleSlide12 go={go} />;
        case 1:
          return <S12.IntroSlide12 />;
        case 2:
          return <S12.LifecycleSlide12 />;
        case 3:
          return <S12.StepsA12 />;
        case 4:
          return <S12.StepsB12 />;
        case 5:
          return <S12.TypesSlide12 />;
        case 6:
          return <S12.CompareSlide12 />;
        case 7:
          return <S12.AttacksSlide12 />;
        case 8:
          return <S12.PreventionSlide12 />;
        case 9:
          return <S12.QuizIntroSlide12 go={go} />;
        default:
          return <S12.TakeawaysSlide12 />;
      }
    }

    if (ch === 11) {
      switch (i) {
        case 0:
          return <S11.TitleSlide11 go={go} />;
        case 1:
          return <S11.IntroSlide11 />;
        case 2:
          return <S11.VectorIndexSlide11 />;
        case 3:
          return <S11.VectorsA11 />;
        case 4:
          return <S11.VectorsB11 />;
        case 5:
          return <S11.MatrixSlide11 />;
        case 6:
          return <S11.CommonSlide11 />;
        case 7:
          return <S11.IncidentsSlide11 />;
        case 8:
          return <S11.DefencesSlide11 />;
        case 9:
          return <S11.QuizIntroSlide11 go={go} />;
        default:
          return <S11.TakeawaysSlide11 />;
      }
    }

    if (ch === 10) {
      switch (i) {
        case 0:
          return <S10.TitleSlide10 go={go} />;
        case 1:
          return <S10.SEIntroSlide10 />;
        case 2:
          return <S10.SEWorkflowSlide10 />;
        case 3:
          return <S10.PhasesA10 />;
        case 4:
          return <S10.PhasesB10 />;
        case 5:
          return <S10.SETypesSlide10 />;
        case 6:
          return <S10.SEPreventionSlide10 />;
        case 7:
          return <S10.SEImpactSlide10 />;
        case 8:
          return <S10.CSIntroSlide10 />;
        case 9:
          return <S10.CSConsequencesSlide10 />;
        case 10:
          return <S10.CSTechniquesSlide10 />;
        case 11:
          return <S10.CSProtectionSlide10 />;
        case 12:
          return <S10.CSReportingSlide10 />;
        case 13:
          return <S10.QuizIntroSlide10 go={go} />;
        default:
          return <S10.TakeawaysSlide10 />;
      }
    }

    if (ch === 9) {
      switch (i) {
        case 0:
          return <S9.TitleSlide9 go={go} />;
        case 1:
          return <S9.IntroSlide9 />;
        case 2:
          return <S9.CategoriesSlide9 />;
        case 3:
          return <S9.CategoryASlide9 />;
        case 4:
          return <S9.CategoryBSlide9 />;
        case 5:
          return <S9.MatrixSlide9 />;
        case 6:
          return <S9.ChallengesSlide9 />;
        case 7:
          return <S9.ProtectSlide9 />;
        case 8:
          return <S9.ReportingSlide9 />;
        case 9:
          return <S9.QuizIntroSlide9 go={go} />;
        default:
          return <S9.TakeawaysSlide9 />;
      }
    }

    if (ch === 8) {
      switch (i) {
        case 0:
          return <S8.TitleSlide8 go={go} />;
        case 1:
          return <S8.GlanceSlide8 />;
        case 2:
          return <S8.FactorsSlide8 />;
        case 3:
          return <S8.RolesSlide8 />;
        case 4:
          return <S8.OutlookSlide8 />;
        case 5:
          return <S8.CompaniesSlide8 />;
        case 6:
          return <S8.SkillsSlide8 />;
        case 7:
          return <S8.RoadmapIndexSlide8 />;
        case 8:
          return <S8.RoadmapA8 />;
        case 9:
          return <S8.RoadmapB8 />;
        case 10:
          return <S8.RoadmapC8 />;
        case 11:
          return <S8.RoadmapD8 />;
        case 12:
          return <S8.CertsPracticeSlide8 />;
        case 13:
          return <S8.QuizIntroSlide8 go={go} />;
        default:
          return <S8.TakeawaysSlide8 />;
      }
    }

    if (ch === 7) {
      switch (i) {
        case 0:
          return <S7.TitleSlide7 go={go} />;
        case 1:
          return <S7.IntroSlide7 />;
        case 2:
          return <S7.ActorIndexSlide />;
        case 3:
          return <S7.ActorPair1 />;
        case 4:
          return <S7.ActorPair2 />;
        case 5:
          return <S7.ActorSoloSlide />;
        case 6:
          return <S7.ActorMatrixSlide />;
        case 7:
          return <S7.WorkflowSlide />;
        case 8:
          return <S7.KillChainSlide />;
        case 9:
          return <S7.BreakChainSlide />;
        case 10:
          return <S7.CasesSlide />;
        case 11:
          return <S7.DetectionA />;
        case 12:
          return <S7.DetectionB />;
        case 13:
          return <S7.QuizIntroSlide7 go={go} />;
        default:
          return <S7.TakeawaysSlide7 />;
      }
    }

    if (ch === 6) {
      switch (i) {
        case 0:
          return <S6.TitleSlide6 go={go} />;
        case 1:
          return <S6.IntroSlide6 />;
        case 2:
          return <S6.VulnIndexSlide />;
        case 3:
          return <S6.HardwareExamples />;
        case 4:
          return <S6.HardwareDefence />;
        case 5:
          return <S6.SoftwareExamples />;
        case 6:
          return <S6.SoftwareDefence />;
        case 7:
          return <S6.NetworkExamples />;
        case 8:
          return <S6.NetworkDefence />;
        case 9:
          return <S6.ProceduralExamples />;
        case 10:
          return <S6.ProceduralDefence />;
        case 11:
          return <S6.HumanExamples />;
        case 12:
          return <S6.HumanDefence />;
        case 13:
          return <S6.TestingSlide />;
        case 14:
          return <S6.CveSlide />;
        case 15:
          return <S6.QuizIntroSlide6 go={go} />;
        default:
          return <S6.TakeawaysSlide6 />;
      }
    }

    if (ch === 5) {
      switch (i) {
        case 0:
          return <S5.TitleSlide5 go={go} />;
        case 1:
          return <S5.IntroSlide5 />;
        case 2:
          return <S5.SpectrumSlide />;
        case 3:
          return <S5.PrimaryTypesSlide />;
        case 4:
          return <S5.HatMatrixSlide />;
        case 5:
          return <S5.OtherIndexSlide />;
        case 6:
          return <S5.OtherDetailA />;
        case 7:
          return <S5.OtherDetailB />;
        case 8:
          return <S5.InsiderSlide />;
        case 9:
          return <S5.DevicesSlide />;
        case 10:
          return <S5.PreventionSlide />;
        case 11:
          return <S5.HardeningSlide />;
        case 12:
          return <S5.MethodologySlide />;
        case 13:
          return <S5.TeamsSlide />;
        case 14:
          return <S5.QuizIntroSlide5 go={go} />;
        default:
          return <S5.TakeawaysSlide5 />;
      }
    }

    if (ch === 4) {
      switch (i) {
        case 0:
          return <S4.TitleSlide4 go={go} />;
        case 1:
          return <S4.IntroSlide4 />;
        case 2:
          return <S4.AttackIndexSlide />;
        case 3:
          return <S4.AttackPair1 />;
        case 4:
          return <S4.AttackPair2 />;
        case 5:
          return <S4.AttackPair3 />;
        case 6:
          return <S4.AttackPair4 />;
        case 7:
          return <S4.AttackMatrixSlide />;
        case 8:
          return <S4.StrategiesIndexSlide />;
        case 9:
          return <S4.StrategiesDetailA />;
        case 10:
          return <S4.StrategiesDetailB />;
        case 11:
          return <S4.DefenceMatrixSlide />;
        case 12:
          return <S4.QuizIntroSlide4 go={go} />;
        default:
          return <S4.TakeawaysSlide4 />;
      }
    }

    switch (i) {
      case 0:
        return <S3.TitleSlide3 go={go} />;
      case 1:
        return <S3.ApplicationsIndexSlide />;
      case 2:
        return <S3.ApplicationsDetailA />;
      case 3:
        return <S3.ApplicationsDetailB />;
      case 4:
        return <S3.ToolsSlide />;
      case 5:
        return <S3.CiaIntroSlide />;
      case 6:
        return <S3.ConfidentialitySlide />;
      case 7:
        return <S3.IntegritySlide />;
      case 8:
        return <S3.HashSlide />;
      case 9:
        return <S3.AvailabilitySlide />;
      case 10:
        return <S3.MatrixSlide />;
      case 11:
        return <S3.QuizIntroSlide3 go={go} />;
      default:
        return <S3.TakeawaysSlide3 />;
    }
  }, [ch, i, answers, go, qStart, qEnd, quiz.score, chapterAnswers]);

  const pct = ((i + 1) / total) * 100;
  const inQuiz = i >= quiz.start && i <= quiz.score;
  const section = flat[i]?.section ?? "";

  const chapterTabs = (compact = false) => (
    <div className="flex items-center gap-1.5">
      {CHAPTERS.map((c) => (
        <button
          key={c.n}
          onClick={() => jumpChapter(c.n)}
          title={c.name}
          className={`border px-2 py-1.5 font-mono text-[9.5px] tracked transition-colors ${
            ch === c.n
              ? "border-phos bg-phos text-ink"
              : "border-sage/25 text-sage/70 hover:border-phos hover:text-phos"
          }`}
          style={{ borderRadius: 2 }}
        >
          <span className="sm:hidden">{c.n}</span>
          <span className="hidden sm:inline">
            {compact ? c.short : c.code}
          </span>
        </button>
      ))}
    </div>
  );

  return (
    <MotionConfig reducedMotion="user">
      <div className="relative h-dvh w-full overflow-hidden bg-ink">
        {/* ============ LEFT RAIL / CHAPTER MENU SLIDER ============ */}
        <aside
          className={`absolute inset-y-0 left-0 z-30 hidden flex-col border-r border-sage/15 bg-panel/70 backdrop-blur-sm py-4 transition-[width] duration-300 ease-out md:flex ${
            railOpen ? "w-72" : "w-16 items-center"
          }`}
        >
          {/* ---- header row: logo + open/collapse toggle ---- */}
          <div
            className={`flex w-full items-center ${railOpen ? "justify-between px-4" : "flex-col gap-3 px-0"}`}
          >
            <button
              onClick={() => go(0)}
              aria-label="Back to this chapter's title slide"
              className="shrink-0 transition-opacity duration-200 hover:opacity-70"
            >
              <Mark size={railOpen ? 20 : 24} />
            </button>
            <button
              onClick={() => setRailOpen((o) => !o)}
              aria-label={railOpen ? "Minimize chapter menu" : "Open chapter menu"}
              title={railOpen ? "Minimize menu (M)" : "Open chapter menu (M)"}
              className="flex h-7 w-7 shrink-0 items-center justify-center border border-sage/25 font-mono text-[11px] text-sage/80 transition-colors duration-200 hover:border-phos hover:text-phos"
              style={{ borderRadius: 2 }}
            >
              {railOpen ? "⟨" : "☰"}
            </button>
          </div>

          {!railOpen && (
            <>
              <span
                className="mt-5 font-mono text-[9.5px] tracked text-muted"
                style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
              >
                {meta.rail}
              </span>

              <div className="relative mx-auto mt-5 w-px flex-1 bg-sage/20">
                <motion.div
                  className="absolute left-0 top-0 w-px bg-phos"
                  animate={{ height: `${pct}%` }}
                  transition={{ duration: 0.35, ease: "easeOut" }}
                  style={{ boxShadow: "0 0 6px rgba(61,240,122,.8)" }}
                />
              </div>

              <div className="mt-5 flex flex-col items-center leading-none">
                <span className="font-mono text-[8.5px] tracked text-phos/70">
                  CH{meta.short}
                </span>
                <span className="mt-1.5 font-display text-[15px] text-phos tabular-nums">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="mt-1 font-mono text-[9px] text-muted">/{total}</span>
              </div>
            </>
          )}

          {railOpen && (
            <>
              <div className="mt-4 flex items-center justify-between px-4">
                <span className="font-mono text-[9px] tracked text-muted">
                  Chapters · {CHAPTERS.length}
                </span>
                <span className="font-mono text-[9px] tracked text-phos/70">M</span>
              </div>

              {/* scrollable chapter list — vertical scroll for the full run of chapters */}
              <div className="mt-3 min-h-0 flex-1 overflow-y-auto overflow-x-hidden px-3 pb-2">
                <div className="space-y-1.5">
                  {CHAPTERS.map((c) => (
                    <button
                      key={c.n}
                      onClick={() => jumpChapter(c.n)}
                      title={c.name}
                      className={`flex w-full items-center gap-2.5 border px-2.5 py-2 text-left transition-colors duration-150 ${
                        ch === c.n
                          ? "border-phos bg-deep/60"
                          : "border-transparent hover:border-sage/25 hover:bg-phos/[0.05]"
                      }`}
                      style={{ borderRadius: 2 }}
                    >
                      <span
                        className={`shrink-0 font-mono text-[9.5px] tabular-nums ${
                          ch === c.n ? "text-phos" : "text-muted"
                        }`}
                      >
                        {c.short}
                      </span>
                      <span
                        className={`min-w-0 flex-1 truncate text-[12px] font-light leading-snug ${
                          ch === c.n ? "text-phos" : "text-sage/80"
                        }`}
                      >
                        {c.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-2 border-t border-sage/15 px-4 pt-3">
                <div className="flex items-baseline justify-between">
                  <span className="font-mono text-[9px] tracked text-muted">{meta.code}</span>
                  <span className="font-mono text-[10px] tracked text-sage tabular-nums">
                    {String(i + 1).padStart(2, "0")}
                    <span className="text-muted">/{total}</span>
                  </span>
                </div>
                <div className="relative mt-2 h-px w-full bg-sage/20">
                  <motion.div
                    className="absolute left-0 top-0 h-px bg-phos"
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.35, ease: "easeOut" }}
                    style={{ boxShadow: "0 0 6px rgba(61,240,122,.8)" }}
                  />
                </div>
              </div>
            </>
          )}
        </aside>

        {/* ============ MOBILE HEADER ============ */}
        <header className="absolute inset-x-0 top-0 z-30 flex h-11 items-center justify-between border-b border-sage/15 bg-panel/80 px-4 md:hidden">
          <button onClick={() => go(0)} className="flex items-center gap-2.5">
            <Mark size={17} />
            <span className="truncate max-w-[45vw] font-mono text-[9.5px] tracked text-muted">
              {meta.name}
            </span>
          </button>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[9.5px] tracked text-phos tabular-nums">
              {String(i + 1).padStart(2, "0")}/{total}
            </span>
            <button
              onClick={() => setOpen(true)}
              aria-label="Open contents"
              className="flex h-6 w-6 shrink-0 flex-col items-center justify-center gap-[3px] border border-sage/30"
            >
              <span className="h-px w-3 bg-sage" />
              <span className="h-px w-3 bg-sage" />
              <span className="h-px w-3 bg-sage" />
            </button>
          </div>
        </header>

        {/* ============ STAGE ============ */}
        <main
          className={`absolute bottom-0 left-0 right-0 top-11 overflow-hidden transition-[left] duration-300 ease-out md:top-0 ${
            railOpen ? "md:left-72" : "md:left-16"
          }`}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={`${ch}-${i}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16, ease: "easeOut" }}
              className="h-full w-full"
            >
              {slide}
            </motion.div>
          </AnimatePresence>

          <motion.div
            key={`sweep-${ch}-${i}`}
            aria-hidden
            initial={{ x: "-30%", opacity: 0.85 }}
            animate={{ x: "135%", opacity: 0 }}
            transition={{ duration: 0.65, ease: "easeOut" }}
            className="pointer-events-none absolute inset-y-0 left-0 z-20 w-[24%] bg-gradient-to-r from-transparent via-phos/[0.14] to-transparent"
          />
          <div
            aria-hidden
            className="scanlines pointer-events-none absolute inset-0 z-10 opacity-[0.22]"
          />
        </main>

        {/* ============ BOTTOM BAR ============ */}
        <nav
          className={`absolute bottom-0 left-0 right-0 z-30 flex h-14 items-center justify-between gap-3 border-t border-sage/20 bg-ink/92 px-3 backdrop-blur-sm transition-[left] duration-300 ease-out md:px-6 ${
            railOpen ? "md:left-72" : "md:left-16"
          }`}
        >
          <div className="flex items-center gap-2">
            {chapterTabs(true)}
            <span className="mx-1 hidden h-5 w-px bg-sage/20 sm:block" />
            <button
              onClick={prev}
              disabled={i === 0}
              className="border border-sage/25 px-2.5 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos disabled:opacity-25 sm:px-3"
              style={{ borderRadius: 2 }}
            >
              ←<span className="hidden sm:inline"> Prev</span>
            </button>
            <button
              onClick={next}
              disabled={i === total - 1}
              className="border border-phos/70 px-2.5 py-2 font-mono text-[10px] tracked text-phos transition-colors duration-200 hover:bg-phos hover:text-ink disabled:opacity-25 sm:px-3"
              style={{ borderRadius: 2 }}
            >
              <span className="hidden sm:inline">Next </span>→
            </button>
          </div>

          <div className="hidden items-end gap-[5px] sm:flex">
            {Array.from({ length: total }).map((_, n) => (
              <button
                key={n}
                onClick={() => go(n)}
                title={`${String(n + 1).padStart(2, "0")} · ${flat[n]?.label ?? ""}`}
                aria-label={`Go to slide ${n + 1}`}
                className="group relative flex h-6 items-end"
              >
                <span
                  className={`block w-[3px] transition-all duration-200 ${
                    n === i
                      ? "h-5 bg-phos"
                      : n < i
                        ? "h-3 bg-phos/45 group-hover:bg-phos"
                        : "h-2 bg-sage/30 group-hover:bg-sage/70"
                  }`}
                />
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 md:gap-4">
            {inQuiz && (
              <span className="hidden font-mono text-[10px] tracked text-muted sm:block">
                Score{" "}
                <span className="text-phos">
                  {score}/{activeQuestions.length}
                </span>
              </span>
            )}
            <span className="hidden font-mono text-[9.5px] tracked text-muted lg:block">
              {section}
            </span>
            <span className="font-mono text-[10px] tracked text-sage tabular-nums">
              {String(i + 1).padStart(2, "0")}
              <span className="text-muted">/{total}</span>
            </span>
            <button
              onClick={() => setRailOpen((o) => !o)}
              className="hidden border border-sage/25 px-3 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos md:block"
              style={{ borderRadius: 2 }}
            >
              Menu · M
            </button>
            <button
              onClick={() => setOpen(true)}
              className="hidden border border-sage/25 px-3 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos lg:block"
              style={{ borderRadius: 2 }}
            >
              Index · I
            </button>
          </div>
        </nav>

        {/* ============ CONTENTS DRAWER ============ */}
        <AnimatePresence>
          {open && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                onClick={() => setOpen(false)}
                className="absolute inset-0 z-40 bg-ink/70 backdrop-blur-[2px]"
              />
              <motion.aside
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ duration: 0.32, ease: "easeOut" }}
                className="absolute inset-y-0 right-0 z-50 flex w-[min(380px,88vw)] flex-col border-l border-phos/35 bg-panel"
              >
                <div className="flex items-center justify-between border-b border-sage/20 px-5 py-4">
                  <span className="font-mono text-[10px] tracked text-phos">
                    Contents
                  </span>
                  <button
                    onClick={() => setOpen(false)}
                    aria-label="Close contents"
                    className="font-mono text-[13px] text-muted transition-colors hover:text-amber"
                  >
                    ✕
                  </button>
                </div>

                <div className="border-b border-sage/20 px-5 py-3.5">
                  <div className="mb-2.5 font-mono text-[9px] tracked text-muted">
                    Chapter
                  </div>
                  <div className="space-y-2">
                    {CHAPTERS.map((c) => (
                      <button
                        key={c.n}
                        onClick={() => jumpChapter(c.n)}
                        className={`flex w-full items-center gap-3 border px-3 py-2.5 text-left transition-colors ${
                          ch === c.n
                            ? "border-phos bg-deep/60"
                            : "border-sage/25 hover:border-phos/60"
                        }`}
                        style={{ borderRadius: 2 }}
                      >
                        <span
                          className={`font-mono text-[11px] ${
                            ch === c.n ? "text-phos" : "text-muted"
                          }`}
                        >
                          {c.code}
                        </span>
                        <span
                          className={`min-w-0 flex-1 truncate text-[13px] font-light ${
                            ch === c.n ? "text-phos" : "text-sage/85"
                          }`}
                        >
                          {c.name}
                        </span>
                        <span className="shrink-0 font-mono text-[9.5px] text-muted">
                          {c.total}p
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto px-5 py-4">
                  {(CONTENTS_BY_CHAPTER[ch] ?? contents).map(
                    (g) => (
                      <div key={g.section} className="mb-5">
                        <div className="font-mono text-[9.5px] tracked text-amber">
                          {g.section}
                        </div>
                        <div className="mt-2 border-b border-sage/15">
                          {flat
                            .filter((f) => f.section === g.section)
                            .map((f) => (
                              <button
                                key={f.idx}
                                onClick={() => go(f.idx)}
                                className={`flex w-full items-baseline gap-3 border-t border-sage/15 py-2.5 text-left transition-colors duration-150 hover:bg-phos/[0.06] ${
                                  f.idx === i ? "bg-phos/[0.09]" : ""
                                }`}
                              >
                                <span
                                  className={`font-mono text-[10.5px] tabular-nums ${
                                    f.idx === i ? "text-phos" : "text-muted"
                                  }`}
                                >
                                  {String(f.idx + 1).padStart(2, "0")}
                                </span>
                                <span
                                  className={`text-[13px] font-light ${
                                    f.idx === i ? "text-phos" : "text-sage/85"
                                  }`}
                                >
                                  {f.label}
                                </span>
                              </button>
                            ))}
                        </div>
                      </div>
                    ),
                  )}
                </div>

                <div className="border-t border-sage/20 px-5 py-3 font-mono text-[9px] tracked text-muted">
                  ← → navigate · 1 2 3 chapter · I index · M menu · Esc close
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
