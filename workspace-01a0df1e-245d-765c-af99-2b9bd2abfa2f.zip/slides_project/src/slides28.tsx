import { motion } from "framer-motion";
import { Row, Slide, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch28Intro,
  ch28Stamp,
  cicdIntro,
  cicdRows,
  compareRows28,
  contents28,
  emerging28,
  emergingIntro,
  limitations28,
  sastSteps,
  sastTools,
  sastVsDastIntro,
  sastVulnerabilities,
  TOTAL28,
  whySast,
} from "./data/ch28";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   Shared two-column compare table
================================================================== */
function TwoColTable({
  headL,
  headR,
  rows,
}: {
  headL: string;
  headR: string;
  rows: { l: string; r: string }[];
}) {
  return (
    <div className="border border-sage/15" style={{ borderRadius: 2 }}>
      <div className="grid grid-cols-2 border-b border-sage/20 bg-panel/70">
        <div className="border-r border-sage/15 px-4 py-2.5 font-mono text-[10px] tracked text-phos">{headL}</div>
        <div className="px-4 py-2.5 font-mono text-[10px] tracked text-amber">{headR}</div>
      </div>
      {rows.map((r, n) => (
        <motion.div key={r.l} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.06 } } }} className="grid grid-cols-2 border-b border-sage/10 last:border-b-0 odd:bg-panel/25">
          <div className="border-r border-sage/10 px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.l}</div>
          <div className="px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.r}</div>
        </motion.div>
      ))}
    </div>
  );
}

/* ==================================================================
   01 · TITLE — vector "magnifier over code" backdrop
================================================================== */
function CodeScanBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="csnFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="csnGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* code lines */}
      <g transform="translate(780 190)" opacity="0.55">
        {[0, 1, 2, 3, 4, 5, 6].map((n) => (
          <rect key={n} x="0" y={n * 26} width={140 + (n % 3) * 60} height="8" fill="#C7D2C9" opacity="0.3" />
        ))}
      </g>
      {/* magnifying glass */}
      <g transform="translate(900 330)" filter="url(#csnGlow)">
        <circle cx="0" cy="0" r="58" fill="none" stroke="#3DF07A" strokeWidth="3" />
        <line x1="41" y1="41" x2="92" y2="92" stroke="#3DF07A" strokeWidth="7" strokeLinecap="round" />
        <rect x="-26" y="-14" width="52" height="8" fill="#FFB020" opacity="0.8" />
        <rect x="-26" y="2" width="34" height="8" fill="#FFB020" opacity="0.6" />
      </g>
      <rect width="1200" height="700" fill="url(#csnFade)" />
    </svg>
  );
}

export function TitleSlide28({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <CodeScanBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 28 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.28&nbsp;//&nbsp;SAST</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL28}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 28</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">Static Application</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">Security Testing</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch28Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(9)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to SAST vs DAST</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Working steps", "Seven"], ["Vulnerabilities covered", "Six"], ["Tools surveyed", "Five"], ["Doc revision", ch28Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide28() {
  return (
    <Slide tag="SEC // CH.28 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch28Intro} dense>
      <div>
        {whySast.map((w, n) => (
          <Row key={w.name} i={String(n + 1).padStart(2, "0")} label={w.name} desc={w.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · STEPS I (1–4)
================================================================== */
export function StepsASlide28() {
  return (
    <Slide tag="SEC // CH.28 // PROCESS I" num="03" title={<>Steps of <span className="text-phos">Static Application Security Testing</span></>} lede="The SAST working process:" dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {sastSteps.slice(0, 4).map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <div className="p-4">
              <span className="font-mono text-[9.5px] tracked text-phos">{s.n}</span>
              <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{s.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {s.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[11.5px] font-light leading-[1.45] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.phos }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · STEPS II (5–7)
================================================================== */
export function StepsBSlide28() {
  return (
    <Slide tag="SEC // CH.28 // PROCESS II" num="04" title={<>More SAST <span className="text-phos">working steps</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {sastSteps.slice(4, 7).map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <div className="p-4">
              <span className="font-mono text-[9.5px] tracked text-amber">{s.n}</span>
              <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{s.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {s.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[11.5px] font-light leading-[1.45] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · VULNERABILITIES DETECTED
================================================================== */
export function VulnerabilitiesSlide28() {
  return (
    <Slide tag="SEC // CH.28 // FINDINGS" num="05" title={<>Common vulnerabilities <span className="text-phos">detected by SAST</span></>} dense>
      <div>
        {sastVulnerabilities.map((v, n) => (
          <Row key={v.name} i={String(n + 1).padStart(2, "0")} label={v.name} desc={v.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · COMMON TOOLS
================================================================== */
export function ToolsSlide28() {
  return (
    <Slide tag="SEC // CH.28 // FINDINGS" num="06" title={<>Common tools for <span className="text-phos">SAST</span></>} lede="There are numerous SAST tools, both open-source and commercial. The choice depends on considerations like language support, DevOps integration and reporting." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {sastTools.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: t.kind === "Open-Source" ? TONE.phos : TONE.amber }}>
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9.5px] tracked" style={{ color: t.kind === "Open-Source" ? TONE.phos : TONE.amber }}>{t.kind}</span>
            </div>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · CI/CD INTEGRATION
================================================================== */
export function CicdSlide28() {
  return (
    <Slide tag="SEC // CH.28 // PIPELINE" num="07" title={<>Integrating SAST in <span className="text-phos">CI/CD pipelines</span></>} lede={cicdIntro} dense>
      <TwoColTable headL="CI/CD STAGE" headR="SAST INTEGRATION" rows={cicdRows.map((r) => ({ l: r.stage, r: r.integration }))} />
    </Slide>
  );
}

/* ==================================================================
   08 · EMERGING SAST I
================================================================== */
export function EmergingASlide28() {
  return (
    <Slide tag="SEC // CH.28 // FUTURE" num="08" title={<>Emerging <span className="text-phos">Static Application Security Testing</span></>} lede={emergingIntro} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {emerging28.slice(0, 2).map((e, n) => (
          <motion.div key={e.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>{e.n}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{e.name}</h3>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {e.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · EMERGING SAST II
================================================================== */
export function EmergingBSlide28() {
  return (
    <Slide tag="SEC // CH.28 // FUTURE" num="09" title={<>More emerging <span className="text-phos">SAST trends</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {emerging28.slice(2, 4).map((e, n) => (
          <motion.div key={e.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>{e.n}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{e.name}</h3>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {e.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · SAST vs DAST
================================================================== */
export function SastVsDastSlide28() {
  return (
    <Slide tag="SEC // CH.28 // COMPARISON" num="10" title={<>SAST <span className="text-phos">vs</span> DAST</>} lede={sastVsDastIntro} dense>
      <TwoColTable headL="SAST (STATIC)" headR="DAST (DYNAMIC)" rows={compareRows28.map((r) => ({ l: r.sast, r: r.dast }))} />
    </Slide>
  );
}

/* ==================================================================
   11 · LIMITATIONS
================================================================== */
export function LimitationsSlide28() {
  return (
    <Slide tag="SEC // CH.28 // TRADE-OFFS" num="11" title={<>Limitations of <span className="text-phos">SAST</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {limitations28.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide28() {
  const items = [
    ["01", "SAST reads code, it doesn't run it", "As a white-box, no-execution approach, it inspects source, binaries or bytecode directly for flaws."],
    ["02", "Seven steps, one pipeline", "Source collection, parsing, rule matching, data-flow and control-flow analysis, detection and reporting form the full working process."],
    ["03", "It catches code-level flaws early", "SQL injection, XSS, command injection, weak auth, buffer overflows and insecure dependencies are all visible before deployment."],
    ["04", "Tool choice depends on context", "SonarQube and Semgrep lead the open-source side; Checkmarx, Veracode and Fortify serve enterprise DevSecOps needs."],
    ["05", "SAST and DAST are complements, not rivals", "Static analysis finds code-level issues early; dynamic testing finds runtime and business-logic issues later — a mature pipeline uses both."],
    ["06", "AI is reshaping the field", "Machine learning is cutting false positives, catching zero-days earlier, and moving toward auto-remediation and real-time monitoring."],
  ];
  return (
    <Slide tag="SEC // CH.28 // CLOSE" num="12" title={<>Chapter 28 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 28 · Static Application Security Testing (SAST)</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents28.length} sections · {TOTAL28} slides</span>
      </div>
    </Slide>
  );
}
