/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 32
   Intrusion Detection System (IDS)
   Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH32_TITLE = "Intrusion Detection System (IDS)";
export const ch32Stamp = "Last Updated : 11 Apr, 2026";

export const ch32Intro =
  "An Intrusion Detection System (IDS) is a security tool that monitors network traffic or system activities to detect unauthorized access or suspicious behavior. Think of it as a \u201cwatchdog\u201d that looks for signs of cyber attacks or security breaches, helping administrators respond quickly before damage occurs.";

export type IntroPoint32 = { name: string; desc: string };

export const ch32IntroPoints: IntroPoint32[] = [
  { name: "Intrusion", desc: "Unauthorized access to a system, often by cybercriminals using advanced techniques." },
  { name: "IDS Functions", desc: "Monitors traffic for unusual activities and alerts administrators when potential attacks are detected." },
  { name: "Detection Focus", desc: "IDS looks for abnormal behavior that could harm data integrity, confidentiality or availability." },
];

/* --- Common Methods of Intrusion --------------------------------------- */
export type IntrusionMethod = { name: string; desc: string };

export const intrusionMethods: IntrusionMethod[] = [
  { name: "Address Spoofing", desc: "Hiding the source of an attack by using fake or unsecured proxy servers, making it hard to identify the attacker." },
  { name: "Fragmentation", desc: "Sending data in small pieces to slip past detection systems." },
  { name: "Pattern Evasion", desc: "Changing attack methods to avoid detection by IDS systems that look for specific patterns." },
  { name: "Coordinated Attack", desc: "Using multiple attackers or ports to scan a network, confusing the IDS and making it hard to see what is happening." },
];

/* --- Working of IDS ------------------------------------------------------ */
export type WorkingStep32 = { n: string; name: string; desc: string };

export const workingSteps32: WorkingStep32[] = [
  { n: "01", name: "Traffic Monitoring", desc: "The IDS captures and monitors data flowing through the network." },
  { n: "02", name: "Pattern Matching", desc: "It compares the incoming data against a set of predefined rules or patterns that could indicate potential attacks or intrusions." },
  { n: "03", name: "Alerting", desc: "If the system detects an activity that matches any of these patterns, it triggers an alert to notify the system administrator." },
  { n: "04", name: "Administrator Action", desc: "Upon receiving the alert, the administrator can investigate the source of the potential attack and take necessary actions to mitigate the risk." },
];

export const workingIntro32 =
  "An IDS operates by monitoring network traffic or system activities to detect suspicious or malicious actions. Here's how it works:";

/* --- Classification of IDS ------------------------------------------------ */
export type IdsClass = { n: string; name: string; short: string; func: string; usage: string; example: string };

export const idsClasses: IdsClass[] = [
  {
    n: "01",
    name: "Network Intrusion Detection System (NIDS)",
    short: "NIDS",
    func: "NIDS is deployed at strategic points within the network to monitor traffic from all devices.",
    usage: "It examines passing traffic across subnets and compares it against known attack signatures. When an attack is detected, it alerts the administrator.",
    example: "A NIDS could be placed in front of firewalls to monitor any attempts to crack the firewall.",
  },
  {
    n: "02",
    name: "Host Intrusion Detection System (HIDS)",
    short: "HIDS",
    func: "HIDS operates on individual devices (hosts) within the network.",
    usage: "It monitors traffic and file integrity on that specific host, comparing current system files with previous snapshots to detect unauthorized changes.",
    example: "A HIDS is often used on critical systems that should not be modified, like servers or sensitive machines.",
  },
  {
    n: "03",
    name: "Hybrid Intrusion Detection System",
    short: "Hybrid IDS",
    func: "A hybrid IDS combines multiple IDS types to provide more comprehensive protection.",
    usage: "It integrates host-based and network-based monitoring to give a complete view of network and system activity.",
    example: "Prelude is a hybrid IDS that combines NIDS and HIDS approaches.",
  },
  {
    n: "04",
    name: "Application Protocol-Based IDS (APIDS)",
    short: "APIDS",
    func: "APIDS monitors and analyzes application-specific protocols to detect potential attacks targeting specific applications.",
    usage: "It tracks communication protocols like SQL to detect malicious activity during database interactions.",
    example: "Monitoring SQL queries in a web server environment.",
  },
  {
    n: "05",
    name: "Protocol-Based IDS (PIDS)",
    short: "PIDS",
    func: "PIDS monitors communication protocols between devices (like HTTPS or HTTP) to detect abnormal activity.",
    usage: "It ensures that the communication follows expected patterns, identifying deviations that may signal an attack.",
    example: "Monitoring the HTTPS traffic entering a server.",
  },
];

/* --- IDS Evasion Techniques ------------------------------------------------ */
export type EvasionTech = { name: string; desc: string };

export const evasionTechniques: EvasionTech[] = [
  { name: "Fragmentation", desc: "An attacker breaks down malicious packets into smaller fragments. Since IDS systems may only scan the full packet, these fragments can bypass detection." },
  { name: "Packet Encoding", desc: "Attackers encode malicious packets using techniques like Base64 or hexadecimal encoding to hide malicious content from signature-based IDS systems." },
  { name: "Traffic Obfuscation", desc: "Obfuscating the content of packets by altering the structure or encoding makes it difficult for the IDS to interpret and detect the attack." },
  { name: "Encryption", desc: "Attackers may use encryption to hide malicious payloads, making it harder for an IDS to detect attacks hidden within encrypted traffic." },
];

/* --- Detection Methods ------------------------------------------------ */
export type DetectionMethod32 = { name: string; desc: string; points: string[]; example: string };

export const detectionMethods32: DetectionMethod32[] = [
  {
    name: "Signature-Based Detection",
    desc: "This method relies on predefined patterns (signatures) of known attacks. It compares incoming data to a database of attack signatures.",
    points: [
      "Easy to implement and effective for detecting known threats.",
      "Cannot detect new or unknown attacks unless their signature is added to the database.",
    ],
    example: "Detecting a specific virus or malware pattern.",
  },
  {
    name: "Anomaly-Based Detection",
    desc: "Anomaly-based IDS uses machine learning or statistical models to define what normal behavior looks like. Any activity that deviates from this norm is flagged as suspicious.",
    points: [
      "Can detect unknown attacks or behaviors.",
      "High rate of false positives if the model is not fine-tuned.",
    ],
    example: "Detecting abnormal traffic volume or unusual access patterns on a server.",
  },
];

/* --- Comparison of IDS with Firewalls -------------------------------------- */
export const vsFirewallIntro =
  "While both IDS and firewalls play important roles in network security, they serve different purposes:";

export type VsFirewallItem = { name: string; desc: string };

export const vsFirewallItems: VsFirewallItem[] = [
  { name: "Firewall", desc: "A firewall works to prevent unauthorized access by restricting traffic between networks based on predefined rules. It blocks suspicious inbound or outbound traffic, but it doesn't alert you when an attack happens inside the network." },
  { name: "IDS", desc: "An IDS, on the other hand, works by detecting and alerting on suspicious activity after an attack has occurred. It doesn't block traffic but instead alerts administrators so they can respond to potential threats." },
];

/* --- Importance of IDS ------------------------------------------------ */
export type Importance32 = { name: string; desc: string };

export const idsImportance: Importance32[] = [
  { name: "Complementary Security Layer", desc: "IDS works alongside firewalls and other security measures to provide comprehensive protection." },
  { name: "Early Detection", desc: "IDS can detect intrusions that bypass primary defenses like firewalls or VPNs." },
  { name: "Rapid Response", desc: "Alerts from IDS help administrators respond quickly to attacks, potentially reducing damage." },
];

/* --- Placement of IDS ------------------------------------------------ */
export type Placement32 = { name: string; desc: string };

export const idsPlacement: Placement32[] = [
  { name: "Behind the Firewall", desc: "Placing an IDS behind the firewall allows it to monitor incoming traffic without receiving internal traffic. This position provides visibility of external threats but avoids false alarms generated by internal traffic." },
  { name: "Within the Network", desc: "An IDS placed inside the network monitors internal traffic, helping to detect intrusions after the firewall has been bypassed." },
  { name: "Advanced IDS", desc: "In more sophisticated setups, an IDS may be integrated with the firewall, allowing for better response and detection of complex attacks entering the network." },
];

/* --- Benefits / Limitations -------------------------------------------- */
export type Benefit32 = { name: string; desc: string };

export const idsBenefits: Benefit32[] = [
  { name: "Detects Malicious Activity", desc: "IDS can detect any suspicious activities and alert the system administrator before any significant damage is done." },
  { name: "Improves Network Performance", desc: "IDS can identify any performance issues on the network, which can be addressed to improve network performance." },
  { name: "Compliance Requirements", desc: "IDS can help in meeting compliance requirements by monitoring network activity and generating reports." },
  { name: "Provides Insights", desc: "IDS generates valuable insights into network traffic, which can be used to identify any weaknesses and improve network security." },
];

export type Limitation32 = { name: string; desc: string };

export const idsLimitations: Limitation32[] = [
  { name: "False Alarms", desc: "IDS can generate false positives, alerting on harmless activities and causing unnecessary concern." },
  { name: "Resource Intensive", desc: "It can use a lot of system resources, potentially slowing down network performance." },
  { name: "Requires Maintenance", desc: "Regular updates and tuning are needed to keep the IDS effective, which can be time-consuming." },
  { name: "Doesn't Prevent Attacks", desc: "IDS detects and alerts but doesn't stop attacks, so additional measures are still needed." },
  { name: "Complex to Manage", desc: "Setting up and managing an IDS can be complex and may require specialized knowledge." },
];

/* --- Knowledge check --------------------------------------------------- */
export type Q32 = { q: string; options: string[]; answer: number; why: string };

export const questions32: Q32[] = [
  {
    q: "What is the primary purpose of an Intrusion Detection System (IDS)?",
    options: [
      "To prevent attacks from occurring",
      "To block malicious traffic",
      "To monitor network traffic and detect suspicious activity",
      "To encrypt communication between devices",
    ],
    answer: 2,
    why: "An IDS is a watchdog: it monitors network traffic or system activity and alerts administrators to suspicious behavior — it does not block traffic (that's a firewall/IPS job) or encrypt communications.",
  },
  {
    q: "Why is an IDS usually considered a passive security system compared to an Intrusion Prevention System (IPS)?",
    options: [
      "It cannot analyze network packets",
      "It works only on wireless networks",
      "It replaces firewalls in the network",
      "It only detects threats and sends alerts without blocking them",
    ],
    answer: 3,
    why: "An IDS detects and alerts on suspicious activity after it happens but does not block traffic itself — that passive, alert-only behavior is exactly what distinguishes it from an active IPS.",
  },
  {
    q: "What technique does an IDS use when it identifies attacks by comparing network traffic with known patterns of previous attacks?",
    options: [
      "Behavioral analysis",
      "Encryption-based detection",
      "Topology-based detection",
      "Signature-based detection",
    ],
    answer: 3,
    why: "Signature-based detection compares incoming data against a database of known attack signatures — effective for known threats, but blind to new ones until their signature is added.",
  },
  {
    q: "How does a Host Intrusion Detection System (HIDS) detect potential security breaches on a device?",
    options: [
      "By analyzing wireless signals in the network",
      "By forwarding suspicious packets to the router",
      "By blocking traffic using firewall rules",
      "By monitoring file system changes and system activities on the host",
    ],
    answer: 3,
    why: "HIDS runs on an individual host and monitors traffic and file integrity there, comparing current system files against previous snapshots to catch unauthorized changes.",
  },
  {
    q: "Which type of Intrusion Detection System monitors and analyzes traffic across an entire network or subnet?",
    options: [
      "Host Intrusion Detection System (HIDS)",
      "Application Protocol Intrusion Detection System (APIDS)",
      "Network Intrusion Detection System (NIDS)",
      "Hybrid Intrusion Detection System",
    ],
    answer: 2,
    why: "NIDS is deployed at strategic points within the network to examine traffic across subnets from all devices, comparing it against known attack signatures — HIDS instead watches a single host.",
  },
];

/* --- Table of contents ------------------------------------------------- */
export const contents32: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Attack surface", items: ["Common intrusion methods", "Working of IDS"] },
  { section: "Classification", items: ["Types I", "Types II"] },
  { section: "Evasion & detection", items: ["Evasion techniques", "Detection methods"] },
  { section: "Context", items: ["IDS vs Firewall", "Importance", "Placement"] },
  { section: "Trade-offs", items: ["Benefits", "Limitations"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL32 = 21;
