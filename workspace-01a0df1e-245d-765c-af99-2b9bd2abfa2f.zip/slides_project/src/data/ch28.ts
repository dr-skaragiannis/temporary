/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 28
   Static Application Security Testing (SAST)
   Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH28_TITLE = "Static Application Security Testing (SAST)";
export const ch28Stamp = "Last Updated : 18 May, 2026";

export const ch28Intro =
  "Static Application Security Testing (SAST) is an application security (AppSec) practice that analyzes source code, binaries or bytecode to identify vulnerabilities without executing the application. As a white-box testing approach, SAST provides full visibility into the internal structure of the application, enabling developers to detect and fix security flaws early.";

/* --- Why SAST matters ------------------------------------------------------- */
export type WhySast = { name: string; desc: string };

export const whySast: WhySast[] = [
  { name: "Early Security Integration", desc: "Embed SAST into the SDLC and CI/CD pipelines for continuous security checks." },
  { name: "Shift-Left Security Approach", desc: "Address security flaws at the earliest stages of development." },
  { name: "Reduced Risk and Cost", desc: "Fix vulnerabilities early to avoid expensive post-deployment remediation." },
  { name: "No Runtime Execution", desc: "Analyzes code without running the application, enabling faster and safer vulnerability detection." },
  { name: "Compliance Alignment", desc: "Helps meet security standards like OWASP Top 10 and other regulatory requirements." },
];

/* --- Steps of SAST -------------------------------------------------------------- */
export type SastStep = { n: string; name: string; lead: string; points: string[] };

export const sastSteps: SastStep[] = [
  {
    n: "01",
    name: "Source Code Collection",
    lead: "The SAST process begins by gathering the complete application codebase for security inspection. It includes source files, libraries, dependencies and configuration data required for accurate analysis.",
    points: [
      "Collects source code and project components from the application environment.",
      "Supports different programming languages and development frameworks.",
      "Prepares the application for automated static security scanning.",
    ],
  },
  {
    n: "02",
    name: "Code Parsing and Analysis",
    lead: "After collecting the code, the tool breaks the application into structured representations for deeper understanding. This step helps identify how the software is logically designed and connected internally.",
    points: [
      "Converts code into analyzable structures like syntax and flow trees.",
      "Examines functions, variables and execution relationships.",
      "Detects abnormal or insecure programming constructs.",
    ],
  },
  {
    n: "03",
    name: "Rule Matching",
    lead: "The analysis engine compares the application code with predefined security patterns and coding standards. It searches for known vulnerability signatures commonly exploited by attackers.",
    points: [
      "Matches code behavior against security rule databases.",
      "Identifies insecure coding implementations and weak practices.",
      "Detects threats such as injection flaws and unsafe APIs.",
    ],
  },
  {
    n: "04",
    name: "Data Flow Analysis",
    lead: "This stage tracks how data moves through the application from input to output. It helps determine whether untrusted information can reach sensitive operations without protection.",
    points: [
      "Monitors the path of user-controlled data across the system.",
      "Detects missing input validation and sanitization processes.",
      "Identifies risky interactions with databases or system commands.",
    ],
  },
  {
    n: "05",
    name: "Control Flow Analysis",
    lead: "Control flow analysis studies the sequence of operations performed by the application. It evaluates how different execution paths may introduce security weaknesses.",
    points: [
      "Analyzes conditions, loops and decision-making structures.",
      "Detects insecure authentication and authorization logic.",
      "Reviews execution paths that could bypass security checks.",
    ],
  },
  {
    n: "06",
    name: "Vulnerability Detection",
    lead: "Once the analysis is completed, the tool identifies and categorizes discovered security flaws. Each issue is prioritized according to its severity and possible impact on the application.",
    points: [
      "Generates vulnerability findings with severity classifications.",
      "Pinpoints affected files and exact code locations.",
      "Highlights potential risks and exploitation possibilities.",
    ],
  },
  {
    n: "07",
    name: "Reporting and Remediation",
    lead: "The final phase provides detailed reports that help developers resolve identified vulnerabilities. It also supports continuous security improvement through repeated scanning and verification.",
    points: [
      "Produces actionable remediation guidance for developers.",
      "Suggests secure coding improvements and best practices.",
      "Verifies fixes through rescanning and updated reports.",
    ],
  },
];

/* --- Common vulnerabilities detected by SAST ------------------------------------------ */
export type SastVuln = { name: string; desc: string };

export const sastVulnerabilities: SastVuln[] = [
  { name: "SQL Injection (A03 - Injection)", desc: "Malicious queries manipulate databases to access or alter data." },
  { name: "Cross-Site Scripting (XSS) (A07)", desc: "Attackers inject scripts to steal user data or hijack sessions." },
  { name: "Command Injection", desc: "Unauthorized system commands executed via unsanitized input." },
  { name: "Insecure Authentication (A07)", desc: "Weak login mechanisms or poor session handling." },
  { name: "Buffer Overflows", desc: "Memory corruption due to excess data input." },
  { name: "Insecure Dependencies (A06)", desc: "Use of outdated or vulnerable third-party libraries." },
];

/* --- Common tools for SAST ---------------------------------------------------------------- */
export type SastTool = { name: string; kind: string; desc: string };

export const sastTools: SastTool[] = [
  { name: "SonarQube", kind: "Open-Source", desc: "Supports multiple programming languages including Java, Python, C, C++ and JavaScript for comprehensive static code analysis." },
  { name: "Checkmarx", kind: "Commercial", desc: "Provides deep vulnerability scanning with seamless CI/CD pipeline integration for secure DevSecOps workflows." },
  { name: "Veracode", kind: "Commercial", desc: "Offers scalable cloud-based SAST solutions designed for enterprise-level application security testing." },
  { name: "Fortify", kind: "Commercial", desc: "Delivers detailed vulnerability reports along with strong compliance and risk management features." },
  { name: "Semgrep", kind: "Open-Source", desc: "Lightweight and fast static analysis tool ideal for quick code scanning and custom security rules." },
];

/* --- Integrating SAST in CI/CD pipelines ------------------------------------------------------ */
export const cicdIntro =
  "To ensure security in DevSecOps, SAST tools should be integrated with Continuous Integration/Continuous Deployment (CI/CD) pipelines.";

export type CicdRow = { stage: string; integration: string };

export const cicdRows: CicdRow[] = [
  { stage: "Code Commit", integration: "Automatically scan code on commit or pull request" },
  { stage: "Build Process", integration: "Identify security issues before deployment" },
  { stage: "Testing", integration: "Combine with Dynamic Application Security Testing (DAST)" },
  { stage: "Deployment", integration: "Final security checks before going live" },
];

/* --- Emerging SAST ------------------------------------------------------------------------------- */
export const emergingIntro = "SAST is rapidly evolving with emerging technologies:";

export type Emerging28 = { n: string; name: string; points: string[] };

export const emerging28: Emerging28[] = [
  {
    n: "01",
    name: "AI-Powered Security Testing",
    points: [
      "Uses artificial intelligence and machine learning to improve vulnerability detection accuracy.",
      "Reduces false positives, helping developers focus on real security risks.",
      "Enhances the efficiency and precision of modern SAST tools.",
      "Speeds up secure software development by automating repetitive analysis tasks.",
    ],
  },
  {
    n: "02",
    name: "Machine Learning-Driven Vulnerability Detection",
    points: [
      "Detects hidden security flaws using advanced machine learning pattern analysis.",
      "Identifies zero-day vulnerabilities earlier than traditional scanning methods.",
      "Learns from previous attack patterns to improve future threat detection.",
      "Helps organizations proactively strengthen application security.",
    ],
  },
  {
    n: "03",
    name: "Auto-Remediation Features",
    points: [
      "AI-powered auto-remediation suggests or applies security fixes in real time.",
      "Reduces the workload on developers by automating patch recommendations.",
      "Helps minimize remediation time and improve productivity.",
      "Ensures faster response to newly discovered vulnerabilities.",
    ],
  },
  {
    n: "04",
    name: "Real-Time Security Monitoring",
    points: [
      "Continuously scans applications to identify emerging threats instantly.",
      "Improves vulnerability management with ongoing security assessments.",
      "Enables rapid detection of newly introduced code weaknesses.",
      "Strengthens overall application security posture through proactive monitoring.",
    ],
  },
];

/* --- SAST vs DAST ------------------------------------------------------------------------------------ */
export const sastVsDastIntro =
  "Both Static Application Security Testing (SAST) and Dynamic Application Security Testing (DAST) are essential for security, but they serve different purposes.";

export type CompareRow28 = { sast: string; dast: string };

export const compareRows28: CompareRow28[] = [
  { sast: "Analyzes source code, binaries or bytecode", dast: "Tests running applications" },
  { sast: "No execution required", dast: "Requires a running application" },
  { sast: "Finds code-level vulnerabilities", dast: "Identifies runtime vulnerabilities" },
  { sast: "SQL injection, XSS, insecure dependencies", dast: "Business logic flaws, authentication bypass" },
  { sast: "Early in SDLC", dast: "Post-deployment or pre-production testing" },
];

/* --- Limitations ----------------------------------------------------------------------------------------- */
export const limitations28 = [
  "May generate false positives",
  "Cannot detect runtime vulnerabilities",
  "Requires source code access",
  "Complex applications may produce large reports",
];

/* --- Contents ----------------------------------------------------------------------------------------------- */
export const contents28: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Process", items: ["Steps I", "Steps II"] },
  { section: "Findings", items: ["Vulnerabilities detected", "Common tools"] },
  { section: "Pipeline", items: ["CI/CD integration"] },
  { section: "Future", items: ["Emerging trends I", "Emerging trends II"] },
  { section: "Comparison", items: ["SAST vs DAST"] },
  { section: "Trade-offs", items: ["Limitations"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL28 = 12;
