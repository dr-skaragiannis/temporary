/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 23
   Multi-Factor Authentication (MFA)
------------------------------------------------------------------ */

export const CH23_TITLE = "Multi-Factor Authentication (MFA)";
export const ch23Stamp = "Last Updated : 29 Apr, 2026";

export const ch23Intro =
  "Multi-factor authentication (MFA) is a security method that verifies a user's identity using two or more different types of credentials before granting access. It strengthens security by combining multiple proof factors to reduce the risk of unauthorized access.";

export const ch23IntroPoints = [
  "Uses different factor types like password, device or biometric data",
  "Makes it harder for attackers even if one credential is stolen",
  "Adds extra verification steps such as OTPs or authenticator apps",
  "Commonly used in banking, email and enterprise systems",
];

/* --- Components of MFA -------------------------------------------------- */
export type Component23 = { name: string; desc: string };

export const components23: Component23[] = [
  { name: "Knowledge factor", desc: "Information known to the user, such as a password or answers to security questions." },
  { name: "Possession factor", desc: "Items owned by the user, such as a smartphone, OTP app or hardware token." },
  { name: "Inherent factor", desc: "Biometric traits of the user, such as fingerprint, face recognition or iris scan." },
];

/* --- Importance of MFA --------------------------------------------------- */
export const importance23 = [
  "Reduces risk of credential exposure and improves identity security.",
  "Requires multiple verification factors such as a password, device or biometrics.",
  "Prevents unauthorized access even if one credential is compromised.",
  "Makes attacks difficult as additional factors are required for authentication.",
  "Provides strong layered protection against identity theft and misuse.",
];

/* --- Selecting authentication methods ------------------------------------ */
export const selectingIntro =
  "When enabling multi-factor authentication, multiple authentication methods should be configured to ensure reliability and flexibility in case one method becomes unavailable. Supporting diverse options improves both security and user experience. Commonly used authentication methods include:";

/* --- Primary Authentication and Verification Methods ---------------------- */
export type Method23 = { name: string; desc: string };

export const primaryMethods23: Method23[] = [
  { name: "Password", desc: "Default authentication method and cannot be disabled, forming base layer of security." },
  { name: "Mobile App Verification Code", desc: "One-time code generated via authenticator apps (e.g., Microsoft Authenticator), refreshed every 30 seconds and usable without internet." },
  { name: "Phone Call Verification", desc: "Automated call to registered number where user confirms authentication via keypad input." },
  { name: "SMS Verification", desc: "One-time code sent via text message, entered on sign-in screen within limited time." },
];

/* --- Advanced Authentication Methods --------------------------------------- */
export const advancedMethods23: Method23[] = [
  { name: "Security Questions", desc: "Predefined questions answered during registration, used as additional identity verification." },
  { name: "Windows Hello for Business", desc: "Biometric authentication using fingerprint or facial recognition for secure login." },
  { name: "FIDO2 Security Keys", desc: "Hardware-based password-less authentication using USB, Bluetooth or NFC devices." },
  { name: "Authenticator App Notifications", desc: "Push notifications sent to user devices for approval or denial of login attempts." },
];

/* --- Token-Based Authentication --------------------------------------------- */
export const tokenMethods23: Method23[] = [
  { name: "Hardware OATH Tokens", desc: "Physical devices generating one-time passwords based on open authentication standards." },
  { name: "Software OATH Tokens", desc: "Applications that generate OTPs using secret keys provided during setup." },
];

/* --- Strength and Security of Authentication Methods ------------------------ */
export const strength23 = [
  "Authentication methods should be evaluated based on security, usability and availability.",
  "Selection of appropriate methods strengthens overall system protection.",
  "Preference should be given to highly secure options such as biometrics, hardware tokens and authenticator apps.",
  "Supporting multiple methods ensures flexibility if one method fails.",
  "Strong authentication choices reduce risk of unauthorized access and improve security posture.",
];

/* --- Advantages -------------------------------------------------------------- */
export const advantages23 = [
  "Provides backup options when primary authentication method fails.",
  "Enhances security through multiple layers of verification.",
  "Reduces reliance on a single authentication factor.",
  "Protects against unauthorized access and credential compromise.",
  "Minimizes risk of identity theft even if credentials are exposed.",
  "Improves overall trust and security in systems and applications.",
];

/* --- Disadvantages ------------------------------------------------------------ */
export const disadvantages23 = [
  "Increases authentication time due to multiple verification steps.",
  "Setup and configuration can be complex and time-consuming.",
  "May require dependency on third-party services.",
  "User experience may be affected due to additional steps.",
  "Loss of authentication device can create access issues.",
];

/* --- Knowledge check ----------------------------------------------------------- */
export type Q23 = { q: string; options: string[]; answer: number; why: string };

export const questions23: Q23[] = [
  {
    q: "What is Multi-Factor Authentication (MFA)?",
    options: [
      "Using only a password for login",
      "Using two or more authentication factors to verify identity",
      "Encrypting user data",
      "Blocking unauthorized IP addresses",
    ],
    answer: 1,
    why: "MFA verifies identity by combining two or more different credential types — such as a password, a device and biometrics — rather than relying on a password alone, encryption, or IP blocking.",
  },
  {
    q: "Which of the following is an example of \"something you have\" in MFA?",
    options: ["Password", "Security question", "Smartphone receiving OTP", "Fingerprint"],
    answer: 2,
    why: "A smartphone receiving an OTP is a possession factor — something the user owns. Passwords and security questions are knowledge factors; a fingerprint is an inherent (biometric) factor.",
  },
  {
    q: "Why is MFA more secure than single-factor authentication?",
    options: [
      "It reduces login time",
      "It uses only biometric data",
      "It adds multiple layers of security",
      "It removes the need for passwords",
    ],
    answer: 2,
    why: "MFA layers multiple independent verification factors together, so even if one credential (like a password) is stolen, an attacker still cannot pass the remaining factors.",
  },
  {
    q: "Which of the following is a biometric authentication method?",
    options: ["PIN", "OTP", "Fingerprint scan", "Security token"],
    answer: 2,
    why: "A fingerprint scan reads a physical biometric trait of the user (an inherent factor). A PIN is knowledge-based, and an OTP or security token are possession-based.",
  },
  {
    q: "What is a common disadvantage of MFA?",
    options: ["Weak encryption", "Slower login process", "No need for devices", "Less security"],
    answer: 1,
    why: "Because MFA requires extra verification steps (such as entering an OTP or approving a push notification), it increases authentication time compared with a single password entry.",
  },
];

/* --- Contents -------------------------------------------------------------------- */
export const contents23: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Building blocks", items: ["Components of MFA", "Why it matters"] },
  { section: "Methods", items: ["Selecting methods", "Primary methods", "Advanced methods", "Token-based", "Strength & security"] },
  { section: "Trade-offs", items: ["Advantages", "Disadvantages"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL23 = 19;
