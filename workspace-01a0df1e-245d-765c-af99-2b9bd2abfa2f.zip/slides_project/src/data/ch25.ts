/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 25
   Active Directory Domain Services (AD DS)
------------------------------------------------------------------ */

export const CH25_TITLE = "Active Directory Domain Services";
export const ch25Stamp = "Last Updated : 4 May, 2023";

export const ch25Intro =
  "A directory is a hierarchical structure that stores information about objects on the network. A directory, in the most generic sense, is a comprehensive listing of objects. A phone book is a type of directory that stores information about people, businesses, and government organizations — phone books typically record names, addresses, and phone numbers. Active Directory (AD) is a Microsoft technology used to manage computers and other devices on a network. It is a primary feature of Windows Server, an operating system that runs both local and Internet-based servers.";

/* --- Benefits of Active Directory ------------------------------------------ */
export const benefits25 = [
  "Hierarchical organizational structure.",
  "Multimaster Authentication & Multimaster replication — the ability to access and modify AD DS from multiple points of administration.",
  "A single point of access to network resources.",
  "Ability to create trust relationships with external networks running previous versions of Active Directory and even Unix.",
  "Provides a centralized location for managing user and computer accounts, which can save time and increase efficiency for IT administrators. This also allows for consistent application of security policies and permissions.",
  "Provides a range of security features, including password policies, group policies, and access controls, which can help to protect the network from unauthorized access and malicious activity.",
  "Designed to support large networks with many users and devices, and can easily scale to meet the needs of growing organizations. This includes the ability to add additional domain controllers and servers as needed.",
  "Makes it easy to share resources such as files and printers across the network, and to manage access to these resources through permissions and security settings.",
  "Comprehensive auditing and reporting capabilities, which can help organizations to track changes and activity on the network, and to identify potential security issues.",
];

/* --- Directory Service ------------------------------------------------------- */
export const directoryServiceIntro =
  "A directory service is a hierarchical arrangement of objects which are structured in a way that makes access easy. However, functioning as a locator service is not AD's exclusive purpose. It also helps organizations have a central administration over all the activities carried out in their networks. Essentially a Network Directory Service:";

export const directoryServicePoints = [
  "Provides information about the user objects, computers and services in the network.",
  "Stores this information in a secure database and provides tools to manage and search the directory.",
  "Allows to manage the user accounts and resources, apply policies consistently as needed by an organization.",
];

export const adDsServicesIntro =
  'Active Directory provides several different services, which fall under the umbrella of "Active Directory Domain Services," or AD DS. These services include:';

/* --- AD DS services ------------------------------------------------------------- */
export type AdService = { name: string; desc: string };

export const adDsServices: AdService[] = [
  { name: "Domain Services", desc: "Stores centralized data and manages communication between users and domains; includes login authentication and search functionality." },
  { name: "Certificate Services", desc: "It generates, manages and shares certificates. A certificate uses encryption to enable a user to exchange information over the internet securely with a public key." },
  { name: "Lightweight Directory Services", desc: "Supports directory-enabled applications using the open (LDAP) protocol." },
  { name: "Directory Federation Services", desc: "Provides single-sign-on (SSO) to authenticate a user in multiple web applications in a single session." },
  { name: "Rights Management", desc: "It controls information rights and management. AD RMS encrypts content, such as email or Word documents, on a server to limit access." },
];

/* --- Domain Controllers ------------------------------------------------------------ */
export const domainControllerIntro =
  "A server that is running AD DS is called a domain controller. Domain controllers host and replicate the directory service database inside the forest. The directory service also provides services for managing and authenticating resources in the forest. These servers host essential services in AD DS, including the following:";

export const domainControllerServices = [
  "Kerberos Key Distribution Center (KDC)",
  "NetLogon (Netlogon)",
  "Windows Time (W32time)",
  "Intersite Messaging (IsmServ)",
];

/* --- Active Directory Objects ------------------------------------------------------- */
export type AdObjectType = { name: string; desc: string; examples: string[] };

export const adObjects25: AdObjectType[] = [
  { name: "Container Objects", desc: "These objects can contain other objects inside them, and we can make collections from them.", examples: ["Forest", "Tree", "Domains", "Organisational Units"] },
  { name: "Leaf Objects", desc: "These objects can not contain other objects inside them.", examples: ["Users", "Computers", "Printers"] },
];

/* --- Common terminologies & AD concepts ------------------------------------------------ */
export type Term25 = { name: string; desc: string };

export const terms25: Term25[] = [
  { name: "Schema", desc: "A set of rules, the schema, that defines the classes of objects and attributes contained in the directory, the constraints and limits on instances of these objects, and the format of their names." },
  { name: "Global Catalog", desc: "A global catalog that contains information about every object in the directory. This allows users and administrators to find directory information regardless of which domain in the directory actually contains the data." },
  { name: "Forest Root Domain", desc: "The first domain that is installed in an Active Directory Forest is referred to as the root domain." },
  { name: "Sites", desc: "Sites in AD DS represent the physical structure, or topology, of your network. AD DS uses network topology information, stored as site, subnet, and site link objects, to build the most efficient replication topology." },
  { name: "Lightweight Directory Access Protocol", desc: "AD is based on the Lightweight Directory Access Protocol (LDAP). This protocol provides a common language for clients and servers to speak to one another." },
  { name: "Domain Controller", desc: "A domain controller (DC) is a server that contains a writable copy of the Active Directory database and is responsible for authenticating users and computers, as well as enforcing security policies." },
  { name: "Organizational Unit", desc: "An organizational unit (OU) is a container object in Active Directory that can hold other objects, such as users, groups, and computers. OUs help organize objects within a domain and apply group policies to specific sets of objects." },
  { name: "Group Policy", desc: "Group Policy is a feature in Active Directory that allows administrators to define and enforce policies on groups of computers or users, including security settings, software deployment, and other system configurations." },
  { name: "Trust Relationship", desc: "A trust relationship is an association between two domains that enables users in one domain to access resources in the other domain. Trust relationships can be one-way or two-way, and can be transitive or non-transitive." },
  { name: "Replication", desc: "Replication is the process by which changes made to the Active Directory database on one domain controller are synchronized with the database on other domain controllers, maintaining consistency across the directory." },
  { name: "Kerberos", desc: "Kerberos is a network authentication protocol used by Active Directory to provide secure authentication for users and computers, using encryption to prevent unauthorized access to network resources." },
  { name: "Group", desc: "A group is a collection of user accounts or computer accounts that can be used to assign permissions or apply policies to multiple objects at once, simplifying administration and improving security." },
];

/* --- Advantages -------------------------------------------------------------------------- */
export type Adv25 = { name: string; desc: string };

export const advantages25: Adv25[] = [
  { name: "Centralized management", desc: "AD DS provides centralized management of users, computers, and other network resources, which makes it easier to manage and secure large-scale networks." },
  { name: "Scalability", desc: "AD DS can support large-scale networks with tens of thousands of users and devices, making it suitable for enterprise-level organizations." },
  { name: "Group policy management", desc: "AD DS provides group policy management, which allows administrators to manage and configure settings for groups of users and computers." },
  { name: "Authentication and authorization", desc: "AD DS provides authentication and authorization services, which allows administrators to control access to network resources based on user roles and permissions." },
  { name: "Single sign-on", desc: "AD DS supports single sign-on (SSO), which allows users to log in once and access multiple network resources without having to provide credentials multiple times." },
];

/* --- Disadvantages -------------------------------------------------------------------------- */
export const disadvantages25: Adv25[] = [
  { name: "Complexity", desc: "AD DS can be complex to set up and manage, requiring specialized knowledge and expertise." },
  { name: "Cost", desc: "AD DS requires licensing fees and may require additional hardware resources, which can increase the cost of network infrastructure." },
  { name: "Vulnerability", desc: "AD DS can be vulnerable to security threats, such as password attacks and denial-of-service (DoS) attacks, which can compromise network security." },
  { name: "Compatibility", desc: "AD DS is designed for Windows networks and may not be compatible with other operating systems or network environments." },
  { name: "Maintenance", desc: "AD DS requires regular maintenance, including software updates and security patches, to ensure optimal performance and security." },
];

/* --- Knowledge check ---------------------------------------------------------------------------- */
export type Q25 = { q: string; options: string[]; answer: number; why: string };

export const questions25: Q25[] = [
  {
    q: "What is the primary purpose of a Domain Controller in Active Directory?",
    options: ["File sharing", "User and group authentication, and centralized management", "Antivirus scanning", "Serving web pages"],
    answer: 1,
    why: "A domain controller holds a writable copy of the Active Directory database and is responsible for authenticating users and computers, enforcing security policies, and providing centralized management — not file sharing, antivirus scanning, or serving web pages.",
  },
];

/* --- Contents ---------------------------------------------------------------------------------------- */
export const contents25: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Structure & services", items: ["Benefits", "Directory service", "AD DS services", "Domain controllers", "AD objects"] },
  { section: "Glossary", items: ["Terminology I", "Terminology II"] },
  { section: "Trade-offs", items: ["Advantages", "Disadvantages"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL25 = 15;
