/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 17
   Cyber Security Metrics
------------------------------------------------------------------ */

export const CH17_TITLE = "Cyber Security Metrics";
export const ch17Stamp = "Last Updated : 24 Apr, 2026";

export const ch17Intro =
  "Cybersecurity metrics are measurable indicators used to evaluate the effectiveness, performance and maturity of an organization's cybersecurity posture. They provide meaningful data such as incident counts, response time and cost of attacks, helping organizations monitor threats and improve security decision-making.";

export const ch17Bullets = [
  "Cybersecurity metrics convert security activities into measurable values",
  "They provide visibility into threats, vulnerabilities and risks",
  "Help organizations track security performance over time",
  "Support planning, auditing and compliance requirements",
];

/* --- Key characteristics -------------------------------------------- */
export type Characteristic = { name: string; desc: string };

export const characteristics: Characteristic[] = [
  { name: "Measurable", desc: "Based on clear and numerical data" },
  { name: "Relevant", desc: "Aligned with organizational security goals" },
  { name: "Actionable", desc: "Helps in making improvements" },
  { name: "Timely", desc: "Updated regularly for accurate analysis" },
  { name: "Consistent", desc: "Can be tracked over time" },
];

/* --- Types of metrics -------------------------------------------------- */
export type MetricType = {
  i: string;
  name: string;
  lead: string;
  example: string;
  tone: "phos" | "amber" | "sage";
};

export const metricTypes: MetricType[] = [
  {
    i: "01",
    name: "Technical Metrics",
    lead: "Measure the technical security of systems and networks. They focus on identifying vulnerabilities, patch updates and system weaknesses.",
    example: "Number of detected malware attacks shows how exposed the system is.",
    tone: "phos",
  },
  {
    i: "02",
    name: "Operational Metrics",
    lead: "Track the day-to-day security activities and performance of security teams. They help evaluate how quickly and effectively incidents are handled.",
    example: "Incident response time shows how fast threats are managed.",
    tone: "amber",
  },
  {
    i: "03",
    name: "Strategic Metrics",
    lead: "Linked to business goals and overall risk management. They help top management understand the organization's security posture.",
    example: "Overall risk score indicates the level of risk to the business.",
    tone: "sage",
  },
  {
    i: "04",
    name: "Compliance Metrics",
    lead: "Ensure the organization is following legal, regulatory and industry standards. They are important for audits and certifications.",
    example: "Audit pass rate shows compliance with required standards.",
    tone: "phos",
  },
];

/* --- Uses of cybersecurity metrics --------------------------------------- */
export type Use = { i: string; name: string; points: string[] };

export const uses: Use[] = [
  {
    i: "01",
    name: "Performance & Accountability",
    points: [
      "Evaluate the effectiveness of security controls, tools and team performance.",
      "Ensure accountability by clearly tracking responsibilities across teams and departments.",
    ],
  },
  {
    i: "02",
    name: "Quantifiable Security Measurement",
    points: [
      "Define clear and measurable security goals using objective data.",
      "Enable data-driven decision-making instead of relying on assumptions.",
    ],
  },
  {
    i: "03",
    name: "Better Decision Making",
    points: [
      "Provide insights from past data to evaluate previous actions and outcomes.",
      "Support informed and accurate decisions for handling current and future risks.",
    ],
  },
  {
    i: "04",
    name: "Efficient Identification & Correction",
    points: [
      "Identify vulnerabilities and security gaps at an early stage.",
      "Allow quick remediation before threats can exploit weaknesses.",
    ],
  },
  {
    i: "05",
    name: "Unified Risk Assessment",
    points: [
      "Combine technical, financial and compliance risks into a single view.",
      "Help organizations prioritize risks based on impact and severity.",
    ],
  },
  {
    i: "06",
    name: "Historical Tracking & Learning",
    points: [
      "Maintain records of past security incidents and performance trends.",
      "Improve understanding of risks and support continuous learning.",
    ],
  },
  {
    i: "07",
    name: "Planning & Implementation",
    points: [
      "Assist in identifying system weaknesses and planning corrective actions.",
      "Enable effective implementation of security measures using past data and assessments.",
    ],
  },
  {
    i: "08",
    name: "Audit & Compliance Support",
    points: [
      "Provide documented evidence for audits and regulatory requirements.",
      "Help ensure that security practices meet required standards.",
    ],
  },
];

/* --- Some cybersecurity metrics ------------------------------------------------ */
export type SomeMetric = { name: string; desc: string };

export const someMetricsA: SomeMetric[] = [
  { name: "Systems with vulnerabilities", desc: "Knowing where assets lag helps determine risks and improvements, so weaknesses can be fixed before anyone exploits them." },
  { name: "Mean detection & response time", desc: "The sooner a breach is detected and responded to, the smaller the loss — systems should minimise this time." },
  { name: "Data volume over the corporate network", desc: "Unrestricted internet access lets employees download anything, risking a malware invasion." },
  { name: "Incorrectly configured SSL certificates", desc: "Misconfigured certificates can let attackers extract critical information using the company's digital identity." },
  { name: "Deactivation time of former-employee credentials", desc: "Access and rights must be terminated immediately when someone leaves, or sensitive information is put at risk." },
];

export const someMetricsB: SomeMetric[] = [
  { name: "Users with higher access levels", desc: "Individuals with wider data access must be efficiently monitored, and unnecessary access minimised." },
  { name: "Open communication ports over time", desc: "Inbound and outbound ports must be monitored individually — avoid NetBIOS inbound, watch SSL outbound, and track remote-session protocols." },
  { name: "Third-party access to systems", desc: "Critical systems need proper mapping of which third parties are able to reach them." },
  { name: "Frequency of third-party access reviews", desc: "Regularly reviewing third-party network access helps identify suspicious activity at their end." },
  { name: "Partners' cybersecurity policy strength", desc: "The more business partners with strict cybersecurity policies, the lower the chances of a cyberattack reaching you." },
];

/* --- Good vs Bad metric ------------------------------------------------------- */
export const goodQualities = ["Definable", "Comprehensive", "Has room for comparison"];

export const goodBadNote =
  "It is also important not to waste time tracking things that are ever-fluctuating or that never change.";

export const goodBadPairs: { good: string; bad: string }[] = [
  { good: "Percentage of AV/EPP events.", bad: "Frequency of security issues." },
  { good: "Cost of event control.", bad: "Frequency of closed risks." },
  { good: "Malware instances.", bad: "Closed security tickets." },
  { good: "Re-returning vulnerabilities.", bad: "Log management." },
  { good: "CIS score per head.", bad: "AV detection." },
];

/* --- Challenges ------------------------------------------------------------ */
export const challenges = [
  "Tracks activity but not outcomes — a major limitation, since outcomes add more value.",
  "A metric gives a simple dashboard of security status, but in the process it also reveals how prepared the organization really is.",
  "There is a communication gap between the security function and the people they report to, so the metric becomes incomprehensible for management.",
  "Metric ideas are not hard-wired — they change over time, so treating a metric as an exact science may not help an organization.",
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q17 = { q: string; options: string[]; answer: number; why: string };

export const questions17: Q17[] = [
  {
    q: "Which of the following best represents a cybersecurity metric?",
    options: [
      "Installing antivirus software",
      "Number of detected malware attacks per week",
      "Writing a security policy",
      "Using a firewall",
    ],
    answer: 1,
    why: "A metric is a measurable value tracked over time — a weekly malware-attack count is data you can chart and act on. The others are controls, not measurements of those controls.",
  },
  {
    q: "What is the primary purpose of cybersecurity metrics?",
    options: [
      "To completely eliminate cyberattacks",
      "To measure and improve security performance",
      "To replace security tools",
      "To increase system speed",
    ],
    answer: 1,
    why: "Metrics convert security activity into measurable, actionable values so an organization can track and improve its posture — they support decisions, not replace tools or guarantee zero attacks.",
  },
  {
    q: "A company tracks detection and response time of incidents. This is:",
    options: ["Technical Metric", "Strategic Metric", "Compliance Metric", "Operational Metric"],
    answer: 3,
    why: "Operational metrics track day-to-day security activity and team performance — incident response time is the textbook example.",
  },
  {
    q: "Which of the following is a compliance metric?",
    options: ["Number of open ports", "Incident response time", "Audit pass rate", "Malware detection count"],
    answer: 2,
    why: "Compliance metrics confirm adherence to legal, regulatory and industry standards — audit pass rate is used directly for audits and certifications.",
  },
  {
    q: "High vulnerabilities but no incidents detected—what does this indicate?",
    options: ["System is secure", "Metrics are wrong", "Potential future risk exists", "Vulnerabilities are irrelevant"],
    answer: 2,
    why: "Metrics track activity, not guaranteed outcomes. Unaddressed vulnerabilities are latent risk — the absence of an incident so far doesn't mean the exposure has gone away.",
  },
  {
    q: "Which is a bad cybersecurity metric?",
    options: ["Mean Time to Respond (MTTR)", "Percentage of patched systems", "Frequency of security issues", "Number of vulnerabilities"],
    answer: 2,
    why: "\"Frequency of security issues\" is vague and ever-fluctuating with no fixed baseline for comparison — a good metric must be definable, comprehensive and comparable over time.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents17: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why", "Good metric qualities"] },
  { section: "Types", items: ["Types overview", "Technical & Operational", "Strategic & Compliance"] },
  { section: "Practice", items: ["Uses", "Metrics in use · I", "Metrics in use · II", "Good vs bad", "Challenges"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Q06", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL17 = 20;
