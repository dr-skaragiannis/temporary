/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 18
   Security Management System
------------------------------------------------------------------ */

export const CH18_TITLE = "Security Management System";
export const ch18Stamp = "Last Updated : 24 Apr, 2026";

export const ch18Intro =
  "A Security Management System (SMS), also known as an Information Security Management System (ISMS), is a structured approach used to protect an organization's data, assets, people and infrastructure from security threats.";

export const ch18Bullets = [
  "Ensures protection of sensitive organizational information",
  "Combines cybersecurity, physical security and policies",
  "Reduces risks related to data breaches and theft",
  "Helps organizations achieve compliance and trust",
  "Builds a strong security culture within the organization",
];

/* --- Key components ------------------------------------------------- */
export type Component = {
  i: string;
  name: string;
  lead: string;
  points: string[];
  tone: "phos" | "amber" | "sage";
};

export const components: Component[] = [
  {
    i: "01",
    name: "Cybersecurity",
    lead: "Protects digital systems from cyber threats.",
    points: [
      "Firewalls, antivirus software and encryption block unauthorized access",
      "Prevents hacking, malware infections and data breaches",
    ],
    tone: "phos",
  },
  {
    i: "02",
    name: "Physical Security",
    lead: "Protects physical infrastructure and equipment.",
    points: [
      "CCTV surveillance, access cards, alarms and security guards",
      "Prevents theft, vandalism and unauthorized entry",
    ],
    tone: "amber",
  },
  {
    i: "03",
    name: "Security Policies",
    lead: "Define rules and guidelines for security behavior.",
    points: [
      "Password policies, access control rules and data classification",
      "Ensures employees follow standardized security practices",
    ],
    tone: "sage",
  },
  {
    i: "04",
    name: "Security Awareness & Training",
    lead: "Reduces risks caused by human error.",
    points: [
      "Educates employees on phishing, weak passwords and unsafe behavior",
      "Builds a security-first mindset",
    ],
    tone: "phos",
  },
];

/* --- Features -------------------------------------------------------------- */
export type FeatureItem = { label: string; desc: string };
export type Feature = {
  i: string;
  name: string;
  lead: string;
  items: FeatureItem[];
  caseStudy?: { label: string; text: string };
};

export const features: Feature[] = [
  {
    i: "01",
    name: "Physical Safety",
    lead: "Security management relates to the physical safety of buildings, people and products.",
    items: [
      { label: "Access Control", desc: "Keycard systems or biometric locks restrict entry to server rooms." },
      { label: "Surveillance", desc: "CCTV cameras monitor premises 24/7." },
      { label: "Alarms", desc: "Fire or intrusion alerts notify security teams in real-time." },
    ],
    caseStudy: {
      label: "Case study · 2022",
      text: "A warehouse used Verkada CCTV to identify a break-in and recovered $50,000 in stolen goods.",
    },
  },
  {
    i: "02",
    name: "Asset Identification",
    lead: "Security management is the identification of the organization's assets — mapping everything from data to hardware and software.",
    items: [
      { label: "Inventory Tools", desc: "Tenable or Censys scan for servers, devices and APIs." },
      { label: "Data Classification", desc: "Classifies data as public, internal or confidential to prioritize protection." },
    ],
  },
  {
    i: "03",
    name: "Security Procedures",
    lead: "Information classification, risk assessment and risk analysis identify threats, categorize assets and rate their exposure.",
    items: [
      { label: "Risk Assessment", desc: "Rates risks according to CVSS scores (e.g., a weak password rates 7.5/10)." },
      { label: "Threat Analysis", desc: "Identifies threats like ransomware or insider attacks." },
      { label: "Incident Response", desc: "Breach plans (e.g., isolate impacted servers within 1 hour)." },
    ],
    caseStudy: {
      label: "Case study · 2023",
      text: "A bank used Splunk to analyze threats, preventing a ransomware attack from encrypting customer data.",
    },
  },
];

/* --- Importance -------------------------------------------------------------- */
export type Importance = { i: string; name: string; lead: string; points: string[] };

export const importance: Importance[] = [
  {
    i: "01",
    name: "Protection of Intellectual Property",
    lead: "Organizations invest heavily in innovation. Without security controls, valuable ideas, software or designs can be stolen.",
    points: ["Protects research, algorithms and trade secrets", "Maintains competitive advantage"],
  },
  {
    i: "02",
    name: "Data Integrity",
    lead: "Ensures that business data remains accurate and trustworthy.",
    points: ["Prevents unauthorized modification of financial, sales or operational data", "Maintains confidence in business decisions and analytics"],
  },
  {
    i: "03",
    name: "Protection of PII",
    lead: "Employees and customers share personal data that must be protected.",
    points: ["Prevents identity theft and privacy violations", "Helps organizations comply with legal regulations"],
  },
  {
    i: "04",
    name: "System Interconnectivity Security",
    lead: "Modern systems are interconnected.",
    points: ["Weakness in one system can compromise others", "SMS ensures all connected systems meet security standards"],
  },
];

/* --- Components & operations (tools) ------------------------------------------- */
export type ToolGroup = { i: string; name: string; tools: { label: string; desc: string }[] };

export const cyberTools: ToolGroup = {
  i: "01",
  name: "Cybersecurity Tools",
  tools: [
    { label: "Firewalls", desc: "Acts as virtual bouncers, blocking unauthorized traffic." },
    { label: "Antivirus", desc: "Scans for malware like ransomware." },
    { label: "Encryption", desc: "Encrypts data so hackers cannot read it — e.g. AES-256 for databases (VeraCrypt)." },
    { label: "MFA", desc: "Requires two steps of login (password + phone code)." },
  ],
};

export const physicalTools: ToolGroup = {
  i: "02",
  name: "Physical Security",
  tools: [
    { label: "Cameras", desc: "Cloud monitoring with AI analytics." },
    { label: "Access Controls", desc: "Biometrics limit access to sensitive zones." },
    { label: "Alarms", desc: "ADT systems notify in case of break-in or fire." },
  ],
};

export const trainingStat = {
  pct: "88%",
  source: "Verizon 2023 DBIR",
  text: "of incidents are caused by human mistake — so organizations use KnowBe4 for simulated phishing or Google's Phishing Quiz for free training.",
};

export const riskTools = [
  { label: "Stay ahead of vulnerabilities", desc: "Get ahead of the vulnerabilities before the hackers do." },
  { label: "Penetration testing", desc: "e.g. Metasploit — simulate real attacks against your own systems." },
  { label: "Vulnerability scans", desc: "e.g. Nessus — continuously scan infrastructure for known weaknesses." },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q18 = { q: string; options: string[]; answer: number; why: string };

export const questions18: Q18[] = [
  {
    q: "Which component of SMS focuses on protecting buildings and equipment?",
    options: ["Cybersecurity", "Security Policies", "Physical Security", "Risk Assessment"],
    answer: 2,
    why: "Physical security covers CCTV surveillance, access cards, alarms and guards — the layer that protects infrastructure and equipment rather than digital systems.",
  },
  {
    q: "Identifying and classifying company data (public, confidential) is part of:",
    options: ["Security Awareness", "Asset Identification", "Incident Response", "Physical Safety"],
    answer: 1,
    why: "Asset identification maps all organizational assets — data, hardware and software — and data classification (public/internal/confidential) is exactly how data assets get prioritized for protection.",
  },
  {
    q: "A company implements password rules and access control policies. This falls under:",
    options: ["Cybersecurity", "Physical Security", "Security Policies", "Risk Analysis"],
    answer: 2,
    why: "Security policies define the rules and guidelines for security behavior — password policies and access control rules are the textbook example.",
  },
  {
    q: "Why is employee training critical in a Security Management System?",
    options: ["It replaces technical tools", "It reduces hardware cost", "It minimizes human-related security risks", "It increases network speed"],
    answer: 2,
    why: "Verizon's 2023 DBIR found 88% of incidents are caused by human mistake — training on phishing, weak passwords and unsafe behavior closes that gap; it doesn't replace technical controls.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents18: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why", "Key components"] },
  { section: "Components", items: ["Cyber & physical", "Policies & training"] },
  { section: "Features", items: ["Overview", "Physical safety", "Asset identification", "Security procedures"] },
  { section: "Importance & operations", items: ["Importance", "Tools & controls", "Training & risk"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL18 = 19;
