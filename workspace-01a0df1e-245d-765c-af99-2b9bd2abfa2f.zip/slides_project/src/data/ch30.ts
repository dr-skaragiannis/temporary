/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 30
   Vulnerability Assessment: Types, Comparisons & Process
   Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH30_TITLE = "Vulnerability Assessment: Types, Comparisons & Process";

/* --- Types of Vulnerability Assessment ------------------------------------ */
export type VaType = { n: string; name: string; desc: string };

export const vaTypes: VaType[] = [
  {
    n: "01",
    name: "Host Vulnerability Assessment",
    desc: "Conducts analysis on servers and host systems so as to expose and contain backend attacks.",
  },
  {
    n: "02",
    name: "Database Vulnerability Assessment",
    desc: "Provides for the prevention of unauthorized access to data within the database in terms of confidentiality, integrity, and availability.",
  },
  {
    n: "03",
    name: "Network Vulnerability Assessment",
    desc: "Evaluates the security of networks to attain protection against incoming and existing network complexity.",
  },
  {
    n: "04",
    name: "Application Scan Vulnerability Assessment",
    desc: "Scans application code for application-level vulnerabilities in frontend and backend using automated tools.",
  },
];

/* --- Vulnerability Assessment vs Penetration Testing — at a glance --------- */
export type GlanceRow30 = { va: string; pt: string };

export const glanceRows30: GlanceRow30[] = [
  { va: "Identification and evaluation of potential vulnerabilities", pt: "Real-world attacks are simulated to exploit vulnerabilities" },
  { va: "Usage of manual techniques and automated systems to scan systems", pt: "Ethical hackers are involved who attempt to exploit vulnerabilities" },
  { va: "Various aspects of the system are covered", pt: "Targets specific vulnerabilities and attack vectors" },
  { va: "Conducted regularly as part of an ongoing strategy", pt: "Less frequent, and performed when needed" },
  { va: "Gives a broader perspective of potential issues", pt: "Gives deeper insight into the impact of exploiting vulnerabilities" },
  { va: "Proactive approach which helps prevent potential issues", pt: "Reactive approach which assesses the effectiveness of existing security measures" },
];

export const glanceIntro =
  "Vulnerability assessment and penetration testing are complementary disciplines: one maps the terrain, the other tests it under fire.";

/* --- Penetration Testing vs Vulnerability Assessment — detailed --------- */
export const detailIntro =
  "Penetration testing finds vulnerabilities, malicious content, flaws and risks and builds up an organization's security system to defend its IT infrastructure — an official, ethical-hacking procedure focused specifically on penetrating the information system. Vulnerability assessment is the technique of finding and measuring (scanning) security vulnerabilities in a given environment — an all-embracing assessment of the information security posture that identifies potential weaknesses and provides mitigation measures to remove them or reduce them below the risk level.";

export type DetailRow30 = { no: number; pt: string; va: string };

export const detailRows30: DetailRow30[] = [
  { no: 1, pt: "This is meant for critical, real-time systems.", va: "This is meant for non-critical systems." },
  { no: 2, pt: "This is ideal for physical environments and network architecture.", va: "This is ideal for lab environments." },
  { no: 3, pt: "It is a non-intrusive documentation, environmental review and analysis.", va: "It is a comprehensive analysis and thorough review of the target system and its environment." },
  { no: 4, pt: "It cleans up the system and gives a final report.", va: "It attempts to mitigate or eliminate the potential vulnerabilities of valuable resources." },
  { no: 5, pt: "It gathers targeted information and/or inspects the system.", va: "It allocates quantifiable value and significance to the available resources." },
  { no: 6, pt: "It tests sensitive data collection.", va: "It discovers the potential threats to each resource." },
  { no: 7, pt: "It determines the scope of an attack.", va: "It makes a directory of assets and resources in a given system." },
  { no: 8, pt: "The main focus is discovering unknown and exploitable weaknesses in normal business processes.", va: "The main focus is listing known software vulnerabilities that could be exploited." },
  { no: 9, pt: "It is a simulated cyberattack carried out by experienced ethical hackers in a well-defined and controlled environment.", va: "It is an automated assessment performed with the help of automated tools." },
  { no: 10, pt: "This is a goal-oriented procedure that should be carried out in a controlled manner.", va: "This cost-effective assessment method is often considered safe to perform." },
  { no: 11, pt: "It only identifies the exploitable security vulnerabilities.", va: "It identifies, categorizes, and quantifies security vulnerabilities." },
];

/* --- Working of Vulnerability Assessment (7 steps) -------------------------- */
export type VaStep = { n: string; name: string; desc: string };

export const vaWorkingSteps: VaStep[] = [
  { n: "01", name: "Planning and Scoping", desc: "Identify the parameters, aims and objectives, and the target system of the assessment." },
  { n: "02", name: "Discovery", desc: "Collect general information about the system — hosts, ports, software and more — using specialized software as well as manual assessment." },
  { n: "03", name: "Scanning", desc: "Scan each host in order to detect open ports and mistakes or problems in configurations." },
  { n: "04", name: "Analysis", desc: "Analyze the scan information to identify what matters and determine each finding's potential severity." },
  { n: "05", name: "Reporting", desc: "Record exploits and their consequences, and rank remediation recommendations." },
  { n: "06", name: "Remediation", desc: "Apply remedies, modify settings, and work on the fortification of the architecture." },
  { n: "07", name: "Follow-Up", desc: "Ensure the fix is applied, verify that it is correct, and watch for new vulnerabilities." },
];

/* --- Process of Vulnerability Assessment (4 steps) -------------------------- */
export type VaProcessStep = { n: string; name: string; desc: string };

export const vaProcessSteps: VaProcessStep[] = [
  {
    n: "01",
    name: "Testing / Vulnerability Identification",
    desc: "All aspects of a system — networks, servers and databases — are checked for possible threats, weaknesses and vulnerabilities. The goal is a list of all the possible loopholes in the security of the system. Testing is done through machines as well as manually, with all parameters kept in mind.",
  },
  {
    n: "02",
    name: "Analysis",
    desc: "The vulnerabilities produced by the first step are analyzed in detail. The goal of this analysis is to identify where things went wrong so rectification can be done easily — finding the root cause of each vulnerability.",
  },
  {
    n: "03",
    name: "Risk Assessment",
    desc: "With many vulnerabilities on hand, it becomes important to classify them by the risk they might cause. This step prioritizes vulnerabilities based on the data and systems they might affect, and gauges the severity of attacks and the damage they can cause.",
  },
  {
    n: "04",
    name: "Rectification",
    desc: "With a clear layout of the risks, their root cause and their severity in hand, corrections can begin. This final step aims at closing the gaps in security by introducing new security tools and measures.",
  },
];

/* --- Vulnerabilities commonly uncovered ------------------------------------ */
export const uncoveredIntro =
  "Regular vulnerability assessments routinely surface high-impact issues such as:";

export const commonlyUncovered: string[] = [
  "Injection attacks, such as XSS and SQL injection",
  "Authentication faults that lead to unidentified, unauthorized access to important data",
  "Insecure settings and weak defaults",
];

/* --- Vulnerability Assessment tools ---------------------------------------- */
export type VaToolCat = { n: string; name: string; desc: string };

export const vaToolCategories: VaToolCat[] = [
  { n: "01", name: "Web application simulation tools", desc: "Simulation tools that test web applications for exploitable flaws." },
  { n: "02", name: "Network service & protocol scanners", desc: "Scanners that test network services and protocols for weaknesses." },
  { n: "03", name: "Network / IP scanners", desc: "Network scanners that identify malicious packets and defects in IP addresses." },
];

/* --- Advantages / Disadvantages -------------------------------------------- */
export const vaAdvantages: string[] = [
  "Detects system weaknesses before any data breach occurs.",
  "Provides a list of possible vulnerabilities for each device in the system.",
  "Maintains security records useful for future assessments.",
  "Supports proactive risk management and improves overall security posture.",
  "Helps prioritize vulnerabilities based on severity and impact.",
];

export const vaDisadvantages: string[] = [
  "Some advanced or zero-day vulnerabilities may remain undetected.",
  "Assessment tools may not always produce fully accurate results.",
  "Requires regular execution to remain effective over time.",
  "May generate false positives that need manual verification.",
  "Implementation and maintenance can require time and resources.",
];

/* --- Knowledge check --------------------------------------------------- */
export type Q30 = { q: string; options: string[]; answer: number; why: string };

export const questions30: Q30[] = [
  {
    q: "What is the main objective of a Vulnerability Assessment?",
    options: [
      "To simulate real-world attacks",
      "To identify and rate potential risks in a system",
      "To fix all vulnerabilities immediately",
      "To monitor network traffic continuously",
    ],
    answer: 1,
    why: "A vulnerability assessment identifies, categorizes, and quantifies security vulnerabilities — it evaluates and rates risk rather than launching attacks, auto-fixing everything, or simply watching traffic.",
  },
  {
    q: "Which of the following best differentiates Vulnerability Assessment from Penetration Testing?",
    options: [
      "Both simulate real-world attacks",
      "Vulnerability assessment is reactive, penetration testing is proactive",
      "A vulnerability assessment identifies issues, and penetration testing exploits them",
      "Both are performed only once",
    ],
    answer: 2,
    why: "Vulnerability assessment identifies and evaluates potential vulnerabilities (a proactive, ongoing approach), while penetration testing simulates real attacks that actively exploit them — the reverse of option B, and unlike A or D, only one side actually attacks.",
  },
  {
    q: "Which step in the Vulnerability Assessment process involves detecting open ports and misconfigurations?",
    options: ["Planning and Scoping", "Discovery", "Scanning", "Analysis"],
    answer: 2,
    why: "Scanning is the step where each host is scanned specifically to detect open ports and mistakes or problems in configurations, after Discovery has gathered general system information.",
  },
  {
    q: "What is one major advantage of conducting regular Vulnerability Assessments?",
    options: [
      "It guarantees complete protection against all attacks",
      "It helps detect weaknesses before data breaches occur",
      "It eliminates the need for penetration testing",
      "It replaces all manual security checks",
    ],
    answer: 1,
    why: "Vulnerability assessments detect system weaknesses before any data breach occurs — they don't guarantee total protection, replace penetration testing, or remove the need for manual checks.",
  },
];

/* --- Table of contents ------------------------------------------------- */
export const contents30: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title"] },
  { section: "Types", items: ["Types of vulnerability assessment"] },
  {
    section: "VA vs Penetration Testing",
    items: ["At a glance", "Detailed differences I", "Detailed differences II"],
  },
  {
    section: "Working & process",
    items: ["Working of VA I", "Working of VA II", "Process of VA"],
  },
  {
    section: "Findings & tooling",
    items: ["Vulnerabilities uncovered", "VA tools", "Advantages", "Disadvantages"],
  },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL30 = 19;
