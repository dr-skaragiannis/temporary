/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 31
   Penetration Testing — Software Engineering
   Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH31_TITLE = "Penetration Testing — Software Engineering";
export const ch31Stamp = "Last Updated : 18 May, 2026";

export const ch31Intro =
  "Penetration testing, or pen testing, is a practice where a simulated cyber attack is conducted on your computer systems to find and fix any weak spots before real attackers can exploit them.";

export const ch31IntroPoints: string[] = [
  "It focuses on web application security by testing APIs and servers to identify vulnerabilities like code injection caused by unfiltered inputs.",
  "The results help adjust web application firewall (WAF) settings and fix any weaknesses found to boost overall security.",
  "Simulates real-world attacks to evaluate how well the system can defend against potential security threats and breaches.",
];

/* --- Penetration Testing Stages -------------------------------------------- */
export type PtStage = { n: string; name: string; desc: string };

export const ptStages: PtStage[] = [
  { n: "01", name: "Planning and Reconnaissance", desc: "Define scope, gather information, and identify targets." },
  { n: "02", name: "Scanning", desc: "Analyze the system to find open ports, services, and vulnerabilities." },
  { n: "03", name: "Gaining Access", desc: "Attempt to exploit vulnerabilities to enter the system." },
  { n: "04", name: "Maintaining Access", desc: "Check if the system remains vulnerable over time after access is gained." },
  { n: "05", name: "Analysis and Reporting", desc: "Document findings, risks, and suggest fixes for improvement." },
];

export const ptStagesIntro =
  "Penetration testing follows a structured process to identify and fix security vulnerabilities. It simulates real-world attacks to evaluate system security and improve protection.";

/* --- Penetration Testing Methods -------------------------------------------- */
export type PtMethod = { n: string; name: string; lead: string; points: string[] };

export const ptMethods: PtMethod[] = [
  {
    n: "01",
    name: "External Testing",
    lead: "Targets a company's external systems like websites, servers, and DNS to simulate real-world cyber attacks from outside.",
    points: [
      "Identifies vulnerabilities in publicly accessible systems such as web applications and servers.",
      "It simulates attacks performed by external hackers trying to gain unauthorized access.",
      "Helps organizations fix security gaps before attackers exploit them.",
    ],
  },
  {
    n: "02",
    name: "Internal Testing",
    lead: "Simulates attacks from within the organization to evaluate internal security and insider threats.",
    points: [
      "Tests internal security controls and access permissions within the organization.",
      "Identifies risks caused by compromised user accounts or insider threats.",
      "Helps improve internal defenses and data protection mechanisms.",
    ],
  },
  {
    n: "03",
    name: "Blind Testing",
    lead: "The tester has very limited information, mimicking a real attacker with minimal knowledge of the system.",
    points: [
      "Simulates realistic attack scenarios with little or no prior system knowledge.",
      "Evaluates how effectively the security team detects and responds to threats.",
      "Measures response time and incident handling capabilities.",
    ],
  },
  {
    n: "04",
    name: "Double-Blind Testing",
    lead: "Neither the tester nor the security team has prior knowledge of the test, ensuring realistic conditions.",
    points: [
      "Tests the organization's readiness for unexpected cyber attacks.",
      "Evaluates monitoring, detection, and response mechanisms under pressure.",
      "Provides insight into real-time handling of security incidents.",
    ],
  },
  {
    n: "05",
    name: "Targeted Testing",
    lead: "Both tester and security team work together, making it a collaborative and controlled testing approach.",
    points: [
      "Enables direct communication and real-time feedback between tester and team.",
      "Helps quickly identify and fix vulnerabilities during the testing process.",
      "Improves overall security awareness and team preparedness.",
    ],
  },
];

/* --- Types of Penetration Testing ------------------------------------------- */
export type PtType = { n: string; name: string; lead: string; points: string[] };

export const ptTypes: PtType[] = [
  {
    n: "01",
    name: "Black Box Penetration Testing",
    lead: "In this method, the tester has no prior knowledge of the system, which closely simulates a real-world cyber attack performed by an external hacker.",
    points: [
      "Requires more time for reconnaissance and gathering information about the target system before testing.",
      "Helps identify vulnerabilities from an external attacker's perspective without any internal access.",
    ],
  },
  {
    n: "02",
    name: "Grey Box Penetration Testing",
    lead: "In this method, the tester is provided with partial knowledge of the system, such as network details or limited user access.",
    points: [
      "Reduces the time required for information gathering while allowing more focused testing.",
      "Helps identify vulnerabilities by combining both external and internal perspectives.",
    ],
  },
  {
    n: "03",
    name: "White Box Penetration Testing",
    lead: "In this method, the tester has complete knowledge of the system, including source code, architecture, and internal structure.",
    points: [
      "Enables a detailed and in-depth security analysis of the system components.",
      "Helps uncover hidden vulnerabilities such as coding errors and misconfigurations.",
    ],
  },
];

/* --- Rules of the Penetration Testing Process ------------------------------- */
export const ptRulesIntro =
  "Penetration testing must follow certain rules to ensure it is conducted safely and ethically. These rules help protect systems while allowing effective identification of vulnerabilities.";

export const ptRules: string[] = [
  "Obtain proper authorization before starting testing to avoid legal issues.",
  "Define clear scope and objectives to limit testing to approved systems only.",
  "Avoid system damage or disruption during the testing process.",
  "Maintain confidentiality of data accessed during testing.",
  "Document findings responsibly and report vulnerabilities clearly.",
];

/* --- Penetration Testing Tools ---------------------------------------------- */
export type PtTool = { name: string; desc: string };

export const ptTools: PtTool[] = [
  { name: "Nmap", desc: "A network exploration tool and security scanner. It can be used to identify hosts and services on a network, as well as security issues." },
  { name: "Nessus", desc: "A vulnerability scanner. It can be used to find vulnerabilities in systems and applications." },
  { name: "Wireshark", desc: "A packet analyzer. It can be used to capture and analyze network traffic." },
  { name: "Burp Suite", desc: "A web application security testing tool. It can be used to find security issues in web applications." },
];

/* --- Real-life example & OWASP Top 10 --------------------------------------- */
export const caseProblem =
  "An online shopping application has weak input validation, allowing attackers to perform SQL injection or bypass authorization to access user data or manipulate orders.";

export const caseSolution =
  "Ethical hackers follow OWASP practices to identify and fix vulnerabilities in web applications before attackers can exploit them.";

export type OwaspItem = { name: string; desc: string };

export const owaspTop: OwaspItem[] = [
  { name: "SQL Injection", desc: "Injecting malicious SQL queries through input fields to access or manipulate databases." },
  { name: "Cross-Site Scripting (XSS)", desc: "Injecting malicious scripts that execute in users' browsers." },
  { name: "Broken Authentication", desc: "Weak login systems that allow attackers to bypass or steal user credentials." },
  { name: "Security Misconfiguration", desc: "Improper system or server configurations that expose sensitive data or services." },
];

/* --- Tips to follow / avoid -------------------------------------------------- */
export const tipsFollow: string[] = [
  "Test in a staging environment with explicit permission (Rules of Engagement).",
  "Use both automated scanners and manual techniques for depth.",
  "Prioritize high-impact findings like data exfiltration.",
];

export const tipsAvoid: string[] = [
  "Testing on production without approval (risk of downtime).",
  "Relying solely on automated tools — they miss logic flaws.",
  "Sharing sensitive findings insecurely.",
];

/* --- Advantages of Penetration Testing --------------------------------------- */
export const advantagesIntro31 =
  "Penetration testing helps identify system vulnerabilities, assess security risks, and improve overall application protection against cyberattacks.";

export const advantages31: string[] = [
  "The penetration test can be done to find the vulnerability which may serve as a weakness for the system.",
  "It is also done to identify the risks from the vulnerabilities.",
  "It can help determine the impact of an attack and the likelihood of it happening.",
  "It can help assess the effectiveness of security controls.",
  "It can help prioritize remediation efforts.",
];

/* --- Applications of Penetration Testing -------------------------------------- */
export const applicationsIntro31 =
  "Penetration testing is widely used across industries to strengthen system security, protect sensitive data, and prevent cyberattacks.";

export const applications31: string[] = [
  "Corporate networks are tested to identify weaknesses in firewalls, routers, and internal systems.",
  "Software development cycles use penetration testing to ensure new features do not introduce vulnerabilities.",
  "Cloud systems are tested to detect misconfigurations, weak access controls, and security gaps in virtual environments.",
];

/* --- Knowledge check --------------------------------------------------- */
export type Q31 = { q: string; options: string[]; answer: number; why: string };

export const questions31: Q31[] = [
  {
    q: "Which type of penetration testing provides complete knowledge of the system to the tester?",
    options: ["Black Box Testing", "Grey Box Testing", "White Box Testing", "Blind Testing"],
    answer: 2,
    why: "White Box Penetration Testing gives the tester complete knowledge of the system — source code, architecture and internal structure — enabling detailed, in-depth analysis, unlike Black Box (no knowledge) or Grey Box (partial knowledge).",
  },
  {
    q: "Which tool is commonly used for web application security testing?",
    options: ["Nmap", "Wireshark", "Burp Suite", "Nessus"],
    answer: 2,
    why: "Burp Suite is a web application security testing tool built to find security issues in web applications, while Nmap scans networks, Wireshark analyzes packets, and Nessus scans for vulnerabilities more broadly.",
  },
  {
    q: "Which phase involves exploiting vulnerabilities to gain system access?",
    options: ["Planning", "Scanning", "Gaining Access", "Reporting"],
    answer: 2,
    why: "Gaining Access is the stage where testers attempt to exploit discovered vulnerabilities to enter the system, after Planning defines scope and Scanning finds open ports and services.",
  },
  {
    q: "What is an important rule to follow during Penetration Testing?",
    options: [
      "Test production systems without permission",
      "Ignore reporting vulnerabilities",
      "Obtain proper authorization before testing",
      "Avoid documenting findings",
    ],
    answer: 2,
    why: "Proper authorization must be obtained before testing begins to avoid legal issues — the opposite of testing without permission, skipping reports, or avoiding documentation.",
  },
  {
    q: "What is the primary goal of Penetration Testing?",
    options: [
      "To improve UI design",
      "To identify and fix security vulnerabilities",
      "To increase database size",
      "To replace manual testing",
    ],
    answer: 1,
    why: "Penetration testing exists to find and fix weak spots before real attackers exploit them — it has nothing to do with UI design, database size, or replacing manual testing.",
  },
];

/* --- Table of contents ------------------------------------------------- */
export const contents31: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Process", items: ["Stages"] },
  { section: "Methods & types", items: ["Methods I", "Methods II", "Types"] },
  { section: "Practice", items: ["Rules", "Tools"] },
  { section: "Case study", items: ["Real-life example & OWASP Top 10", "Tips to follow & avoid"] },
  { section: "Impact", items: ["Advantages", "Applications"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL31 = 20;
