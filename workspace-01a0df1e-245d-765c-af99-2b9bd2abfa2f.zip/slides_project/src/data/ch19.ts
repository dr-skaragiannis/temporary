/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 19
   Cybersecurity Framework
------------------------------------------------------------------ */

export const CH19_TITLE = "Cybersecurity Framework";
export const ch19Stamp = "Last Updated : 4 Jun, 2026";

export const ch19Intro =
  "Cybersecurity frameworks help organizations protect digital assets and manage evolving cyber risks through a structured and consistent approach. They provide a ready foundation for implementing security practices, enabling more efficient and controlled management of information systems.";

export const ch19Bullets = [
  "Provides a reusable security foundation, reducing the need to design systems from scratch.",
  "Helps minimize system complexity through structured implementation.",
  "Supports efficient use of time and organizational resources.",
  "Enhances reliability and performance of security measures.",
  "Promotes scalability of security practices as organizations grow.",
];

/* --- Process of cybersecurity frameworks ------------------------------------- */
export type ProcessStep = { i: string; name: string; desc: string };

export const process: ProcessStep[] = [
  {
    i: "01",
    name: "Description of Current Security Rules",
    desc: "Understanding the existing security policies, tools and controls in an organization. It helps identify what protections are already in place and how effective they are.",
  },
  {
    i: "02",
    name: "Description of Required Security Guidelines",
    desc: "After analyzing the current setup, organizations define what security standards and guidelines are needed, based on best practices, compliance requirements and identified gaps.",
  },
  {
    i: "03",
    name: "Make Changes",
    desc: "Necessary improvements and updates are implemented — this may include installing new security tools, updating policies or fixing vulnerabilities.",
  },
  {
    i: "04",
    name: "Evaluate the Progress",
    desc: "Organizations monitor and assess whether the changes are effective — checking performance, testing security measures and ensuring goals are being met.",
  },
  {
    i: "05",
    name: "Risks",
    desc: "Identifying and analyzing potential threats and vulnerabilities. Understanding risks helps in taking preventive actions to protect systems and data.",
  },
];

export const processNote =
  "Cybersecurity frameworks aim to strengthen an organization's security posture through continuous improvement — the cycle repeats as threats and business needs evolve.";

/* --- Components of a cybersecurity framework ---------------------------------- */
export type FrameworkComponent = { i: string; name: string; lead: string; points: string[]; tone: "phos" | "amber" | "sage" };

export const frameworkComponents: FrameworkComponent[] = [
  {
    i: "01",
    name: "Framework Core",
    lead: "Defines security activities, outcomes and best practices.",
    points: ["Identifies required security controls", "Helps assess gaps between current and desired security levels"],
    tone: "phos",
  },
  {
    i: "02",
    name: "Implementation Tiers",
    lead: "Describe how well security policies are implemented.",
    points: ["Covers mission goals, risk tolerance and cost considerations", "Measures maturity of cybersecurity practices"],
    tone: "amber",
  },
  {
    i: "03",
    name: "Profiles",
    lead: "Organization-specific records aligned with business needs.",
    points: ["Define goals, assets and risk priorities", "Help customize the framework"],
    tone: "sage",
  },
];

/* --- Five core functions ------------------------------------------------------- */
export type CoreFunction = { i: string; name: string; points: string[] };

export const functions: CoreFunction[] = [
  { i: "01", name: "Identify", points: ["Understand assets, systems and risks", "Identify vulnerabilities and threats"] },
  { i: "02", name: "Protect", points: ["Implement safeguards to secure systems", "Includes access control, encryption and policies"] },
  { i: "03", name: "Detect", points: ["Monitor systems to identify security incidents", "Enables early breach detection"] },
  { i: "04", name: "Respond", points: ["Take action after a cyber incident", "Includes communication and containment"] },
  { i: "05", name: "Recover", points: ["Restore systems and operations", "Improve resilience against future attacks"] },
];

export const functionsNote =
  "A cybersecurity framework is built around these five core functions, which form a continuous security lifecycle.";

/* --- Need for cybersecurity framework -------------------------------------------- */
export type NeedItem = { name: string; desc: string };

export const needItems: NeedItem[] = [
  { name: "National Security", desc: "Protects sensitive defense and strategic data" },
  { name: "Digital Economy Growth", desc: "Supports India's expanding digital infrastructure" },
  { name: "Technological Advancements", desc: "Manages risks from AI, IoT and cloud systems" },
  { name: "Data Protection", desc: "Ensures integrity and security of national data" },
];

/* --- Common cybersecurity frameworks ---------------------------------------------- */
export type CommonFramework = { name: string; desc: string };

export const commonFrameworks: CommonFramework[] = [
  { name: "NIST Cybersecurity Framework", desc: "Risk-based security guidelines for organizations" },
  { name: "ISO 27001/27002", desc: "International standards for information security management" },
  { name: "FISMA", desc: "U.S. federal information security compliance framework" },
  { name: "SOC 2", desc: "Security and privacy controls for service organizations" },
  { name: "HIPAA", desc: "Protects healthcare data and privacy" },
];

/* --- Types of cybersecurity frameworks ---------------------------------------------- */
export type FrameworkType = {
  i: string;
  name: string;
  lead: string;
  examples: { name: string; desc: string }[];
  tone: "phos" | "amber" | "sage";
};

export const frameworkTypes: FrameworkType[] = [
  {
    i: "01",
    name: "Risk Management Frameworks",
    lead: "Help organizations identify, assess and manage cybersecurity risks by evaluating threats and vulnerabilities and applying appropriate controls. They support ongoing monitoring and informed decision-making to reduce security exposure.",
    examples: [
      { name: "NIST Risk Management Framework (RMF)", desc: "Integrates security and risk management into system development." },
      { name: "ISO/IEC 27005", desc: "Provides guidelines for information security risk management aligned with ISO 27001." },
    ],
    tone: "phos",
  },
  {
    i: "02",
    name: "Compliance Frameworks",
    lead: "Ensure organizations meet legal, regulatory and industry security requirements. They help protect sensitive data, avoid penalties and maintain trust through defined rules and audit standards.",
    examples: [
      { name: "GDPR", desc: "Focuses on data privacy and protection in the EU." },
      { name: "HIPAA", desc: "Sets standards for protecting healthcare information in the U.S." },
    ],
    tone: "amber",
  },
  {
    i: "03",
    name: "Control Frameworks",
    lead: "Provide structured security controls and best practices to protect systems, networks and data. They serve as practical guidelines for strengthening overall cybersecurity posture.",
    examples: [
      { name: "CIS Controls", desc: "Prioritized actions to defend against common cyber threats." },
      { name: "NIST Cybersecurity Framework (CSF)", desc: "Uses core functions: Identify, Protect, Detect, Respond, Recover." },
    ],
    tone: "sage",
  },
  {
    i: "04",
    name: "Governance Frameworks",
    lead: "Align cybersecurity and IT strategy with business objectives. They focus on accountability, decision-making structures and effective management of IT resources and risks.",
    examples: [
      { name: "COBIT", desc: "Framework for IT governance and enterprise management." },
      { name: "ITIL", desc: "Best practices for IT service management and value delivery." },
    ],
    tone: "phos",
  },
  {
    i: "05",
    name: "Incident Response Frameworks",
    lead: "Guide organizations in preparing for, detecting, responding to and recovering from cybersecurity incidents. They help minimize damage and improve resilience.",
    examples: [
      { name: "NIST SP 800-61", desc: "Computer Security Incident Handling Guide." },
      { name: "SANS Incident Response Process", desc: "Lifecycle-based approach including preparation, detection, containment, recovery and lessons learned." },
    ],
    tone: "amber",
  },
];

/* --- Benefits ------------------------------------------------------------------------ */
export const benefits = [
  "Establishes global security standards for organizations",
  "Improves collaboration between different systems and industries",
  "Reduces implementation cost through structured processes",
  "Provides flexible and reusable security models",
  "Strengthens overall cyber resilience and risk management",
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q19 = { q: string; options: string[]; answer: number; why: string };

export const questions19: Q19[] = [
  {
    q: "Which function of a cybersecurity framework focuses on restoring systems after an attack?",
    options: ["Identify", "Detect", "Respond", "Recover"],
    answer: 3,
    why: "Recover is the function dedicated to restoring systems and operations after an incident, and improving resilience against future attacks.",
  },
  {
    q: "Which component of a cybersecurity framework defines security activities and best practices?",
    options: ["Profiles", "Implementation Tiers", "Framework Core", "Risk Assessment"],
    answer: 2,
    why: "The Framework Core defines security activities, outcomes and best practices, and is used to identify required controls and assess gaps.",
  },
  {
    q: "A company customizing security controls based on its business needs is using:",
    options: ["Implementation Tiers", "Profiles", "Compliance Standards", "Risk Registers"],
    answer: 1,
    why: "Profiles are organization-specific records aligned with business needs — they define goals, assets and risk priorities to customize the framework.",
  },
  {
    q: "An organization identifies risks, applies controls, and continuously monitors improvements. This represents:",
    options: ["Static security model", "Continuous security lifecycle", "One-time compliance audit", "Physical security framework"],
    answer: 1,
    why: "Cybersecurity frameworks are built around a continuous, cyclical process — current state, required guidelines, changes, evaluation and risk analysis repeat as things evolve.",
  },
  {
    q: "Why are implementation tiers important in a cybersecurity framework?",
    options: ["They replace risk management", "They define technical tools only", "They measure maturity and risk handling capability", "They eliminate compliance requirements"],
    answer: 2,
    why: "Implementation tiers describe how well security policies are implemented, covering mission goals, risk tolerance and cost — effectively measuring the maturity of cybersecurity practices.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents19: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why", "Process"] },
  { section: "Framework anatomy", items: ["Components", "Five functions"] },
  { section: "Context", items: ["Need", "Common frameworks"] },
  { section: "Types", items: ["Overview", "Risk & compliance", "Control & governance", "Incident response"] },
  { section: "Outcomes", items: ["Benefits"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL19 = 20;
