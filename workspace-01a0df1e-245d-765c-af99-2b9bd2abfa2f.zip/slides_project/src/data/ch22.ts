/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 22
   X.509 Authentication Service
------------------------------------------------------------------ */

export const CH22_TITLE = "X.509 Authentication Service";
export const ch22Stamp = "Last Updated : 11 Apr, 2026";

export const ch22Intro =
  "X.509 represents a digital certificate based on the ITU standard defining the format of PKI certificates, serving as a certificate-based authentication framework for secure transactions and protection of private information, widely used for managing security and identity in computer networks and internet communications.";

/* --- Working of X.509 ------------------------------------------------- */
export const working = [
  "Public key certificates form the core of authentication, issued by a trusted certification authority for each user.",
  "Certificates are stored in directory servers for easy access and retrieval by users.",
  "Standard is based on ASN.1, enabling the structured representation of certificate data.",
  "Uses a public and private key pair for encryption and decryption of messages.",
  "A certificate acts like an identity proof attached to the user for authentication.",
  "Provides higher security compared to passwords, reducing the risk of theft or misuse.",
  "Authentication occurs by presenting a certificate to access protected resources.",
];

/* --- Format of the certificate ------------------------------------------------ */
export type CertField = { i: string; name: string; desc: string };

export const certFields: CertField[] = [
  { i: "01", name: "Version number", desc: "Specifies the version of the X.509 standard used for the certificate." },
  { i: "02", name: "Serial number", desc: "Unique number assigned by the certificate authority to identify the certificate." },
  { i: "03", name: "Signature Algorithm Identifier", desc: "Algorithm used for signing the certificate." },
  { i: "04", name: "Issuer name", desc: "Specifies the X.509 name of the certificate authority that issued and signed the certificate." },
  { i: "05", name: "Period of Validity", desc: "Defines the validity period of the certificate." },
  { i: "06", name: "Subject Name", desc: "Specifies the name of the user to whom the certificate is issued." },
  { i: "07", name: "Subject's public key information", desc: "Specifies the subject's public key along with the identifier of the associated algorithm." },
  { i: "08", name: "Extension block", desc: "Contains additional standard information." },
  { i: "09", name: "Signature", desc: "Contains a hash of all other fields, encrypted using the certificate authority's private key." },
];

/* --- Characteristics --------------------------------------------------------- */
export type Characteristic22 = { name: string; desc: string };

export const characteristics22: Characteristic22[] = [
  { name: "Standardized Format", desc: "Follows the ITU-T standard, ensuring interoperability across systems and platforms." },
  { name: "Based on Public Key Cryptography", desc: "Contains a public key for secure encryption, authentication and digital signing." },
  { name: "Issued by a Certificate Authority (CA)", desc: "Signed by a trusted CA that verifies and authenticates the certificate holder's identity." },
  { name: "Includes Identity Information", desc: "Stores details like Common Name, Organization, Country, and optionally Email Address." },
  { name: "Defined Validity Period", desc: "Includes start and expiration dates; becomes invalid after expiry unless renewed." },
  { name: "Supports Revocation Mechanisms", desc: "Can be revoked before expiry using CRLs or OCSP if compromised or misused." },
  { name: "Supports Trust Hierarchies", desc: "Enables trust chains through root and intermediate CAs in a scalable structure." },
  { name: "Digitally Signed", desc: "Digitally signed by the CA to ensure the certificate's authenticity and integrity." },
];

/* --- Applications ----------------------------------------------------------------- */
export type Application22 = { name: string; desc: string };

export const applications22: Application22[] = [
  { name: "Document Signing and Digital Signatures", desc: "X.509 certificates are used to verify the authenticity and integrity of digital documents through digital signatures." },
  { name: "Web Server Security (TLS/SSL Certificates)", desc: "Essential for securing websites using Transport Layer Security (TLS) or Secure Sockets Layer (SSL), enabling HTTPS and encrypting communication between web browsers and servers." },
  { name: "Email Certificates", desc: "X.509 certificates provide email encryption and authentication, ensuring the confidentiality and authenticity of email communication (e.g. using S/MIME)." },
  { name: "Code Signing", desc: "Used to digitally sign software, ensuring code integrity and verifying the identity of the software publisher." },
  { name: "Secure Shell Protocol (SSH) Keys", desc: "Although SSH typically uses a different key format, X.509 certificates can be used in certain environments for enhanced SSH authentication." },
  { name: "Digital Identities", desc: "X.509 certificates are a fundamental component in establishing digital identities for users, devices and services in secure systems." },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q22 = { q: string; options: string[]; answer: number; why: string };

export const questions22: Q22[] = [
  {
    q: "What is the primary purpose of an X.509 certificate?",
    options: ["Store user passwords", "Provide authentication using digital certificates", "Increase network speed", "Replace encryption algorithms"],
    answer: 1,
    why: "X.509 is a certificate-based authentication framework — it proves identity through a digital certificate rather than storing passwords, speeding up networks, or replacing encryption algorithms.",
  },
  {
    q: "Who issues an X.509 certificate?",
    options: ["User", "Web browser", "Certificate Authority (CA)", "Router"],
    answer: 2,
    why: "A trusted Certificate Authority (CA) issues and signs the certificate after verifying the identity of the certificate holder.",
  },
  {
    q: "Which field in an X.509 certificate ensures its integrity?",
    options: ["Version number", "Subject name", "Signature", "Serial number"],
    answer: 2,
    why: "The Signature field contains a hash of all the other fields, encrypted with the CA's private key — any tampering with the certificate would invalidate that signature.",
  },
  {
    q: "What happens if an X.509 certificate expires?",
    options: ["It becomes more secure", "It is automatically deleted", "It becomes invalid and must be renewed", "It changes its public key"],
    answer: 2,
    why: "Every certificate has a defined validity period; once it passes the expiration date, the certificate becomes invalid and must be renewed to keep being trusted.",
  },
  {
    q: "Which protocol commonly uses X.509 certificates for securing web communication?",
    options: ["FTP", "HTTP", "TLS/SSL", "SMTP"],
    answer: 2,
    why: "TLS/SSL certificates — which are X.509 certificates — are what enable HTTPS, encrypting communication between web browsers and servers.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents22: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Certificate anatomy", items: ["How it works", "Certificate format"] },
  { section: "Practice", items: ["Characteristics", "Applications"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL22 = 14;
