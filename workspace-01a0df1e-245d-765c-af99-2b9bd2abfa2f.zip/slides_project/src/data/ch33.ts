/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 33
   Intrusion Prevention System (IPS)
   Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH33_TITLE = "Intrusion Prevention System (IPS)";
export const ch33Stamp = "Last Updated : 28 Apr, 2026";

export const ch33Intro =
  "An Intrusion Prevention System (IPS) actively monitors network and system traffic to detect and block malicious activity in real time. It extends traditional IDS capabilities by not only identifying threats but also automatically preventing attacks before they cause damage.";

export const ch33IntroPoints: string[] = [
  "Monitors network and host activities continuously",
  "Uses signatures, behavior and anomaly analysis",
  "Prevents intrusions through automated responses",
  "Enhances security visibility and reduces attack impact",
];

export const workingMechIntro33 =
  "An IPS works by analyzing network traffic in real-time and comparing it against known attack patterns and signatures. When the system detects suspicious traffic, it blocks it from entering the network.";

/* --- 1. Inline Deployment --------------------------------------------------- */
export const inlineDeploymentDesc =
  "An IPS is typically deployed in-line, meaning it is placed directly in the path of network traffic between internal networks and external sources (such as the internet). This placement enables the IPS to inspect every packet that flows through, allowing it to block any malicious activity before it can do harm.";

export const inlinePositioning =
  "The IPS can be placed behind a firewall or directly between the internal network and external traffic sources.";

/* --- 2. Traffic Preprocessing ----------------------------------------------- */
export const preprocessingIntro =
  "Before deep inspection begins, the IPS preprocesses incoming traffic to ensure it's correctly interpreted:";

export type PreprocessItem = { name: string; desc: string };

export const preprocessItems: PreprocessItem[] = [
  { name: "Traffic Normalization", desc: "It standardizes traffic formats to prevent attackers from using encoding tricks to evade detection." },
  { name: "Packet Reassembly", desc: "The IPS reassembles fragmented packets to ensure no data is missed and malicious content isn't hidden in fragments." },
];

/* --- 3. Layered Packet Inspection ------------------------------------------- */
export const layeredIntro =
  "An IPS performs deep packet inspection (DPI) to understand both the structure and intent behind the network traffic. This analysis occurs at multiple layers of the OSI model:";

export type OsiLayer33 = { name: string; desc: string };

export const osiLayers33: OsiLayer33[] = [
  { name: "Network Layer", desc: "Checks packet origins and destinations." },
  { name: "Transport Layer", desc: "Examines the reliability and integrity of the connections." },
  { name: "Application Layer", desc: "Inspects the type of data being transmitted (e.g., login credentials, file transfers)." },
];

/* --- 4. Detection Mechanisms ------------------------------------------------ */
export type DetectionMech33 = { name: string; desc: string };

export const detectionMechanisms33: DetectionMech33[] = [
  { name: "Signature-Based Detection", desc: "Compares traffic against known attack patterns or signatures (like fingerprints of known malware or exploits)." },
  { name: "Anomaly-Based Detection", desc: "Flags any behavior that deviates from normal network activity, such as sudden spikes in traffic or unusual request patterns." },
  { name: "Behavior-Based Detection", desc: "Monitors and tracks actions over time, identifying suspicious patterns like repeated failed login attempts or unauthorized access attempts." },
  { name: "Policy-Based Detection", desc: "Enforces custom rules defined by administrators (e.g., blocking traffic from specific countries or blocking certain file types)." },
];

/* --- 5. Automated Response Actions ------------------------------------------ */
export type ResponseAction33 = { name: string; desc: string };

export const responseActions33: ResponseAction33[] = [
  { name: "Drop Malicious Packets", desc: "Discards harmful traffic before it reaches its target." },
  { name: "Block Source IP", desc: "Prevents further connections from the attacker's IP address." },
  { name: "Terminate Sessions", desc: "Ends suspicious or unauthorized sessions." },
  { name: "Trigger Alerts/Logs", desc: "Generates alerts or logs for the administrator to review." },
  { name: "Update Firewall Rules", desc: "Automatically adjusts firewall settings to block traffic from malicious sources." },
];

/* --- 6. Tuning and Maintenance ----------------------------------------------- */
export type Tuning33 = { name: string; desc: string };

export const tuningItems33: Tuning33[] = [
  { name: "Update Signatures", desc: "Regular updates are needed to add new attack signatures and detection patterns." },
  { name: "Reduce False Positives", desc: "Fine-tuning helps minimize alerts for non-malicious traffic, ensuring the system only triggers legitimate threats." },
  { name: "Optimize Performance", desc: "Adjust settings to ensure the IPS can handle high traffic loads without performance degradation." },
];

/* --- Types of IPS ------------------------------------------------------------ */
export type IpsType = { n: string; name: string; short: string; points: string[] };

export const ipsTypes: IpsType[] = [
  {
    n: "01",
    name: "Network-Based Intrusion Prevention System (NIPS)",
    short: "NIPS",
    points: [
      "Monitors and analyzes network traffic for suspicious activity. It is typically placed at the network perimeter.",
      "Protects the entire network from external threats by inspecting inbound and outbound traffic.",
    ],
  },
  {
    n: "02",
    name: "Host-Based Intrusion Prevention System (HIPS)",
    short: "HIPS",
    points: [
      "Runs on individual devices (hosts) within the network and monitors the traffic flowing in and out of those specific devices.",
      "Provides protection for individual systems and their processes, useful for securing critical machines.",
    ],
  },
  {
    n: "03",
    name: "Wireless Intrusion Prevention System (WIPS)",
    short: "WIPS",
    points: [
      "Monitors wireless network traffic to detect and block suspicious activity targeting wireless protocols.",
      "Protects against wireless-specific attacks such as rogue access points or unauthorized wireless devices.",
    ],
  },
  {
    n: "04",
    name: "Network Behavior Analysis (NBA)",
    short: "NBA",
    points: [
      "Monitors network traffic patterns to identify anomalies that could signify a threat, such as Distributed Denial of Service (DDoS) attacks or malware outbreaks.",
      "Detects abnormal traffic flows and network behaviors that could indicate a potential attack.",
    ],
  },
];

/* --- Importance of an IPS ---------------------------------------------------- */
export type Importance33 = { name: string; desc: string };

export const ipsImportance: Importance33[] = [
  { name: "Protection Against Known and Unknown Threats", desc: "An IPS can block known threats and also detect and block unknown threats that haven't been seen before." },
  { name: "Real-Time Protection", desc: "An IPS can detect and block malicious traffic in real-time, preventing attacks from doing any damage." },
  { name: "Compliance Requirements", desc: "Many industries have regulations that require the use of an IPS to protect sensitive information and prevent data breaches." },
  { name: "Cost-Effective", desc: "An IPS is a cost-effective way to protect your network compared to the cost of dealing with the aftermath of a security breach." },
  { name: "Increased Network Visibility", desc: "An IPS provides increased network visibility, allowing you to see what's happening on your network and identify potential security risks." },
];

/* --- Comparison of IPS Technologies ------------------------------------------ */
export const techComparisonIntro33 =
  "Each IPS type is designed to monitor different parts of an IT environment, providing specialized protection based on where threats occur. Understanding these differences helps in selecting the right combination of technologies for a stronger security posture.";

export const techComparisonPoints33: string[] = [
  "Coverage varies from entire networks to individual hosts and wireless environments.",
  "Detection approaches include signature-based, anomaly-based and behavior-based analysis.",
  "Some IPS types are better suited for identifying large-scale attacks like DDoS, while others focus on endpoint-level threats.",
  "Using multiple IPS technologies together helps reduce security gaps and improve overall defense.",
];

/* --- IPS vs IDS ---------------------------------------------------------------- */
export const ipsVsIdsIntro =
  "The main distinction between an Intrusion Prevention System (IPS) and an Intrusion Detection System (IDS) lies in their functionality.";

export type VsItem33 = { name: string; label: string; desc: string };

export const idsSide33: VsItem33[] = [
  { name: "IDS (Intrusion Detection System)", label: "Detection Only", desc: "An IDS is a passive system that detects potential intrusions and generates alerts." },
  { name: "IDS (Intrusion Detection System)", label: "Function", desc: "It does not block or prevent attacks but informs administrators so they can take action." },
];

export const ipsSide33: VsItem33[] = [
  { name: "IPS (Intrusion Prevention System)", label: "Detection and Prevention", desc: "An IPS is an active system that detects threats and prevents them by blocking malicious traffic in real-time." },
  { name: "IPS (Intrusion Prevention System)", label: "Function", desc: "It can take automatic actions like dropping packets, blocking IP addresses and resetting connections." },
];

/* --- Knowledge check --------------------------------------------------- */
export type Q33 = { q: string; options: string[]; answer: number; why: string };

export const questions33: Q33[] = [
  {
    q: "In what scenario would an Intrusion Prevention System (IPS) be used?",
    options: [
      "To monitor network traffic, detect potential threats, and alert administrators without intervening",
      "To monitor network traffic, detect malicious activity, and automatically block it in real-time",
      "To analyze historical traffic patterns and store logs for later investigation",
      "To optimize network performance by reducing congestion and improving transfer speeds",
    ],
    answer: 1,
    why: "An IPS extends IDS by actively blocking malicious traffic in real time, not just alerting on it, analyzing history, or optimizing bandwidth.",
  },
  {
    q: "Which technique is used by an Intrusion Prevention System (IPS) to examine the full structure and intent of network traffic?",
    options: [
      "Signature Matching Detection",
      "Statistical Anomaly Detection",
      "Behavioral Baseline Detection",
      "Deep Packet Inspection (DPI)",
    ],
    answer: 3,
    why: "Deep Packet Inspection (DPI) examines traffic across multiple OSI layers — network, transport and application — to understand both structure and intent, beyond any single detection technique.",
  },
  {
    q: "Why is an IPS typically deployed inline within a network infrastructure?",
    options: [
      "To increase network bandwidth capacity",
      "To store logs of network communication",
      "To replace routers in the network",
      "To inspect and block malicious packets before they reach internal systems",
    ],
    answer: 3,
    why: "Inline placement puts the IPS directly in the traffic path so it can inspect every packet and block malicious activity before it can do harm — not to add bandwidth, log storage, or routing.",
  },
  {
    q: "What key capability distinguishes an Intrusion Prevention System (IPS) from an Intrusion Detection System (IDS)?",
    options: [
      "IPS only analyzes network traffic logs",
      "IPS only detects threats but does not respond",
      "IPS actively blocks or mitigates threats after detection",
      "IPS works only on host devices",
    ],
    answer: 2,
    why: "IPS actively blocks or mitigates threats — dropping packets, blocking IPs, resetting connections — while IDS is passive and only detects and alerts.",
  },
  {
    q: "Which analysis technique used by IPS detects attacks by comparing traffic patterns with known attack signatures?",
    options: [
      "Signature-based detection",
      "Frequency-based detection",
      "Topology-based detection",
      "Encryption-based detection",
    ],
    answer: 0,
    why: "Signature-based detection compares traffic against known attack patterns or signatures — the fingerprints of known malware or exploits.",
  },
];

/* --- Table of contents ------------------------------------------------- */
export const contents33: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  {
    section: "Working mechanism",
    items: [
      "Inline deployment",
      "Traffic preprocessing",
      "Layered packet inspection",
      "Detection mechanisms",
      "Automated response actions",
      "Tuning & maintenance",
    ],
  },
  { section: "Classification", items: ["Types of IPS"] },
  { section: "Context", items: ["Importance", "Technology comparison", "IPS vs IDS"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL33 = 20;
