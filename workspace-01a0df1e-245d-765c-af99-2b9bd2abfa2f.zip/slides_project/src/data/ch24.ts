/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 24
   Single Sign On (SSO)
------------------------------------------------------------------ */

export const CH24_TITLE = "Single Sign On (SSO)";
export const ch24Stamp = "Last Updated : 10 Apr, 2026";

export const ch24Intro =
  "Single Sign On (SSO) is a session and user authentication service that allows a user to access various apps using a single set of login credentials, such as a username and password. SSO is used by every organization as well as individuals to manage multiple credentials more efficiently.";

export const ch24IntroPoints = [
  "Since one login provides access to many services, protecting credentials is very important.",
  "SSO is often combined with Multi-Factor Authentication (MFA) for stronger security.",
  "Additional authentication methods may include OTP, Smart cards or Biometric verification.",
];

/* --- Working of SSO ------------------------------------------------------ */
export const working24 = [
  "The user tries to access a website or application. The website checks whether the user is already authenticated through the SSO system.",
  "If the user is not authenticated, the website redirects the user to the SSO login page.",
  "The user enters login credentials such as username and password on the SSO system.",
  "The credentials are sent to the SSO authentication server for verification.",
  "The SSO server contacts the Identity Provider (IdP) (for example, Active Directory) to verify the user's identity.",
  "After successful verification, the Identity Provider confirms authentication to the SSO system.",
  "The SSO system sends authentication information to the requested website, allowing the user to access the application.",
  "When the user moves to another application, the SSO system provides authentication tokens, so the user does not need to log in again.",
];

/* --- Types of SSO configurations ------------------------------------------ */
export type SsoConfig = { i: string; name: string; lead: string; points: string[]; tone: "phos" | "amber" | "sage" };

export const ssoConfigsA: SsoConfig[] = [
  {
    i: "01",
    name: "Kerberos-Based Configuration",
    lead: "This is an authentication method that uses the Kerberos protocol and ticket system to allow users to access multiple services after a single login.",
    points: [
      "A Ticket Granting Ticket (TGT) is generated after authentication.",
      "Provides secure access to multiple network services.",
      "Commonly implemented in organizational environments.",
    ],
    tone: "phos",
  },
  {
    i: "02",
    name: "SAML-Based Configuration",
    lead: "This is a configuration that uses Security Assertion Markup Language to securely exchange authentication data between systems.",
    points: [
      "Connects Identity Provider and Service Provider.",
      "Enables login across different domains.",
      "Widely used for web applications.",
    ],
    tone: "amber",
  },
  {
    i: "03",
    name: "Smart Card-Based Configuration",
    lead: "This uses a physical card containing stored credentials to authenticate users.",
    points: [
      "Requires inserting the smart card for first login.",
      "Removes the need to repeatedly type credentials.",
      "Stores certificates or passwords securely.",
    ],
    tone: "sage",
  },
];

export const ssoConfigsB: SsoConfig[] = [
  {
    i: "04",
    name: "Social Media-Based Configuration",
    lead: "Allows authentication using existing social networking accounts.",
    points: [
      "Uses accounts such as Google or Facebook.",
      "Simplifies login process for users.",
      "Risk increases if social account is compromised.",
    ],
    tone: "phos",
  },
  {
    i: "05",
    name: "Enterprise-Level Configuration",
    lead: "This is used by organizations to centrally manage user authentication across multiple internal systems.",
    points: [
      "Functions similar to a credential manager.",
      "Automatically logs users into applications.",
      "Reduces the burden of remembering multiple passwords.",
    ],
    tone: "amber",
  },
];

/* --- SSO Token -------------------------------------------------------------- */
export const ssoTokenIntro =
  "These are digital piece of information created after a user successfully logs in through Single Sign-On (SSO). It acts as proof that the user is already authenticated, so the user can access multiple applications without logging in again.";

export const ssoTokenPoints = [
  "An SSO token is generated after successful login to verify the user's identity.",
  "It allows access to multiple systems without re-entering username and password.",
  "The token is securely shared between applications for authentication.",
  "Tokens are valid only for a limited time to maintain security.",
];

/* --- Advantages --------------------------------------------------------------- */
export const advantages24 = [
  "The risk of access to third-party sites is mitigated as the website database does not store the user's login credentials.",
  "Increased convenience for users as they only need to remember and key in login information once.",
  "Increased security assurance for users as website owners do not store login credentials.",
  "Increase customer base and satisfaction as SSO provides a lower barrier to entry and seamless user experience.",
  "Reduce IT costs for managing customer's usernames and passwords.",
];

/* --- Disadvantages -------------------------------------------------------------- */
export const disadvantages24 = [
  "If the SSO token is stolen, an attacker can access multiple applications without needing login credentials.",
  "A single point of failure occurs, meaning if the SSO system is compromised, many services become vulnerable.",
  "Token expiration or configuration errors may cause login problems for users.",
  "Implementing and managing SSO tokens can be complex for organizations.",
];

/* --- Knowledge check --------------------------------------------------------------- */
export type Q24 = { q: string; options: string[]; answer: number; why: string };

export const questions24: Q24[] = [
  {
    q: "What is the main purpose of Single Sign-On (SSO)?",
    options: ["Encrypt user passwords", "Allow access to multiple applications with one login", "Store user data in one place", "Block unauthorized users"],
    answer: 1,
    why: "SSO is a session and user authentication service that lets a user access many different applications using just one set of login credentials.",
  },
  {
    q: "In SSO, where are user credentials typically verified?",
    options: ["Individual application databases", "Identity Provider (IdP)", "Web browser cache", "Local system only"],
    answer: 1,
    why: "The SSO authentication server contacts the Identity Provider (IdP), such as Active Directory, to verify the user's identity before granting access.",
  },
  {
    q: "What is the role of an SSO token?",
    options: ["Store passwords permanently", "Encrypt files", "Carry authentication data between systems", "Replace usernames"],
    answer: 2,
    why: "An SSO token is generated after successful login and is securely shared between applications to prove the user is already authenticated, so they don't need to log in again.",
  },
  {
    q: "Which SSO type uses XML to exchange authentication data?",
    options: ["Kerberos-based SSO", "Smart card-based SSO", "SAML SSO", "Social SSO"],
    answer: 2,
    why: "SAML (Security Assertion Markup Language) is an XML-based configuration that securely exchanges authentication data between an Identity Provider and a Service Provider.",
  },
  {
    q: "What is a major disadvantage of SSO?",
    options: ["Requires multiple passwords", "Slower authentication", "Single point of failure if credentials are compromised", "Cannot be used with MFA"],
    answer: 2,
    why: "Because one login unlocks many applications, a compromised SSO system or stolen token creates a single point of failure that can expose every connected service.",
  },
];

/* --- Contents ------------------------------------------------------------------------ */
export const contents24: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Mechanism", items: ["How it works"] },
  { section: "Configurations", items: ["Kerberos · SAML · Smart card", "Social media · Enterprise"] },
  { section: "Tokens & trade-offs", items: ["SSO token", "Advantages", "Disadvantages"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL24 = 16;
