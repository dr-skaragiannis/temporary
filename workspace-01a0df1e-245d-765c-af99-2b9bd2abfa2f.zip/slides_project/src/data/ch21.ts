/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 21
   Authentication Applications
   (Identity & Access Management · Windows User Management · Kerberos)
------------------------------------------------------------------ */

export const CH21_TITLE = "Authentication Applications";
export const ch21Tagline =
  "Real-world authentication systems such as Kerberos, X.509, MFA and SSO that are used to securely manage user access and identity in modern applications.";

/* ====================================================================
   PART 1 · IDENTITY AND ACCESS MANAGEMENT (IAM)
==================================================================== */
export const iamStamp = "Last Updated : 29 Apr, 2026";

export const iamIntro =
  "Identity and Access Management (IAM) is a security framework that controls who can access organizational systems and data, ensuring secure, authorized and appropriate use of resources.";

export const iamBullets = [
  "Manages digital identities and user access across systems and applications",
  "Ensures the right users access the right resources at the right time",
  "Prevents unauthorized access to sensitive and critical information",
  "Supports authentication, authorization and access monitoring",
];

export type IamBenefit = { name: string; desc: string };
export const iamBenefits: IamBenefit[] = [
  { name: "Reduced Risk", desc: "IAM minimizes internal and external data breaches by enforcing controlled access and reducing dependency on weak or stolen credentials." },
  { name: "Secure and Scalable Access", desc: "As organizations grow, IAM enables secure access for increasing numbers of users without weakening security controls." },
  { name: "Compliance Management", desc: "IAM helps organizations meet regulatory requirements such as data protection laws, audit policies and industry standards." },
  { name: "Reduced Help Desk Load", desc: "Self-service features like password resets and authentication verification reduce help desk dependency and operational overhead." },
  { name: "Competitive Advantage", desc: "IAM allows controlled external access to partners and clients, improving collaboration without compromising security." },
];

export type IamStep = { i: string; name: string; desc: string; tools?: string[] };
export const iamImplementation: IamStep[] = [
  { i: "01", name: "Analyze Organizational Needs", desc: "IAM solutions should be selected based on the organization's size, industry, workforce structure and device usage." },
  { i: "02", name: "Develop an IAM Integration Strategy", desc: "A structured strategy is required to manage identities across cloud services, on-premises systems and third-party tools." },
  {
    i: "03",
    name: "Select the Right IAM Tools",
    desc: "Key IAM components include:",
    tools: ["Access management systems", "Multi-factor authentication (MFA)", "Risk-based authentication", "Password tokens and identity verification tools"],
  },
];

export const iamRiseIntro =
  "IAM has become a foundational element of cybersecurity as organizations increasingly rely on digital infrastructure. Key areas of focus:";

export type IamFocus = { name: string; desc: string };
export const iamFocusAreas: IamFocus[] = [
  { name: "Identity Data Management", desc: "Secure handling of identity data across systems and platforms." },
  { name: "Access Management", desc: "Use of MFA, federation and stronger authentication mechanisms." },
  { name: "Access Governance", desc: "Regular auditing and enforcement of access policies." },
  { name: "Identity Lifecycle Management", desc: "Controlled creation, modification and removal of identities." },
  { name: "Data Security and Analytics", desc: "Monitoring and analyzing access patterns to detect threats." },
];

export const iamProtocolsIntro = "IAM strengthens cybersecurity by enforcing precise access controls.";
export type IamProtocol = { name: string; desc: string };
export const iamProtocols: IamProtocol[] = [
  { name: "Restricted Data Access", desc: "Users only access data relevant to their roles." },
  { name: "View-Only Access", desc: "Prevents unauthorized modification or copying of sensitive data." },
  { name: "Platform Restrictions", desc: "Limits users to approved platforms and environments." },
  { name: "Data Transfer Prevention", desc: "Prevents unauthorized sharing or exfiltration of data." },
];
export const iamProtocolsNote = "IAM complements existing security systems by adding identity-centric protection layers.";

export const iamPolicies = [
  "Identity recognition and authentication methods",
  "Role and responsibility assignment",
  "User lifecycle management (add, update, remove)",
  "Controlled access for individuals and groups",
  "Protection of sensitive data and systems from breaches",
];

export const iamAdvantages = [
  "Enhances overall security by limiting unauthorized access",
  "Improves compliance with legal and regulatory frameworks",
  "Simplifies identity and access administration",
  "Enables Single Sign-On (SSO) for better user experience",
  "Provides visibility into user behavior and access patterns",
];

export const iamLimitations = [
  "Implementation complexity, especially in large organizations",
  "High initial and operational costs",
  "Possible user resistance due to stricter controls",
  "Integration challenges with legacy systems",
  "Requires continuous monitoring and maintenance",
];

/* ====================================================================
   PART 2 · WINDOWS USER MANAGEMENT
==================================================================== */
export const winStamp = "Last Updated : 8 Aug, 2025";

export const winIntroBullets = [
  "User management in Windows is the process of creating and controlling user accounts to manage access, permissions, and system usage.",
  "It ensures only authorized users can log in and access specific files, apps, or settings.",
  "Each user account can have different roles (like Administrator or Standard User) with defined privileges.",
];

export type AccountType = { i: string; name: string; desc: string };
export const accountTypes: AccountType[] = [
  {
    i: "01",
    name: "Administrator Account",
    desc: "An Administrator Account is a user account with the highest level of control over a computer system or network. It allows the user to manage system settings, install or uninstall software, create, modify, or delete other user accounts, and access all files and configurations. This account is essential for performing system maintenance and administrative tasks.",
  },
  {
    i: "02",
    name: "User Account",
    desc: "A user account is a unique digital identity created on a computer or network, allowing an individual to access and interact with the system. It defines the user's access level, permissions, and personal settings, including desktop layout, saved files, and application preferences. This helps ensure a secure and personalized computing experience for each user.",
  },
  {
    i: "03",
    name: "Guest Account",
    desc: "A Guest Account in Windows is a restricted user profile intended for temporary users who do not have a regular account. It allows them to use the computer without accessing personal files or making any system-level changes. The guest account is useful when you want to let someone use your computer briefly without compromising your personal data or system security.",
  },
  {
    i: "04",
    name: "Root Account",
    desc: "The root account is the highest-level user account in Unix or Linux systems that has full control over the entire operating system. It can access, modify, or delete any file, install software, manage users, and change system settings without any restrictions. Due to its elevated privileges, the root account is typically reserved for critical system administration tasks to minimize the risk of accidental system damage.",
  },
];

export const createAccountSteps = [
  "Click the Start Button and open Settings.",
  "Go to Accounts.",
  "Select Family and Other People.",
  "Click Add someone else to this PC.",
  "Click I don't have this person's sign-in information.",
  "Add a user without a Microsoft account.",
  "Enter the user details and click Next.",
];

export const resetPasswordStepsA = [
  "Press and hold the Shift key on your keyboard and click on the Restart button.",
  "Click Troubleshoot.",
  "Click on Advanced Options.",
  "Press on Command Prompt.",
  "Write regedit in the Command Prompt and press Enter.",
  "Click on HKEY_LOCAL_MACHINE.",
  "Click File, then click Load Hive.",
  "Click on This PC and select the drive (e.g. Local Disk (D:)) and open it.",
  "Click on Windows and click the Open button.",
  "Find and open the folder System32.",
];

export const resetPasswordStepsB = [
  "Find the folder config and open it.",
  "Find the file \"SYSTEM\" and double-click on it.",
  "Type the key name — you can choose any name you want.",
  "Go into HKEY_LOCAL_MACHINE, then the folder you created, click \"Setup\", find \"CmdLine\" and double-click it.",
  "Go to Value data, type cmd.exe, then click OK.",
  "Click on SetupType and change the value data from 0 to 1, then click OK.",
  "Click on the key you created, then click \"File\" in the menu bar, select \"Unload Hive\" and confirm with \"Yes\". Close the folder window and exit the Command Prompt.",
  "Click Continue — the computer restarts automatically and Command Prompt opens.",
  "Write \"net user\" in the Command Prompt to see your account name.",
  "Write \"net user <Your Account Name> *\", press Enter, press Enter again for the blank password, press Enter once more to retype it, then reboot the system.",
];

export type WinTool = { i: string; name: string; desc: string; points: string[] };
export const winTools: WinTool[] = [
  {
    i: "01",
    name: "Control Panel",
    desc: "The Control Panel in Windows serves as a centralized hub where users and administrators can manage various aspects of user accounts.",
    points: [
      "Create new user accounts, including setting up standard users or administrators.",
      "Delete existing accounts, ensuring that user access is properly managed.",
      "Change the type of user account (e.g. from standard to administrator or vice versa).",
      "Set, change or remove passwords for user accounts to enhance security.",
      "Adjust User Account Control (UAC) settings, which notify the user whenever a system change requires administrator permission.",
    ],
  },
  {
    i: "02",
    name: "Settings App",
    desc: "The Settings app in Windows is a modern, user-friendly interface designed to manage and customize nearly every aspect of the operating system, gradually replacing many functions of the traditional Control Panel in Windows 10 and 11.",
    points: [
      "Add or remove user accounts and manage sign-in options such as passwords, PIN, fingerprint and facial recognition.",
      "Configure accounts for family members and other users with customized access and permissions.",
    ],
  },
  {
    i: "03",
    name: "Computer Management",
    desc: "Computer Management is a built-in Windows tool that combines several essential system management features into one unified interface, simplifying maintenance, troubleshooting and administration.",
    points: [
      "Monitor system performance and review event logs to identify errors, warnings or significant activity.",
      "Create, modify or delete user accounts and manage group memberships.",
      "Configure storage devices by formatting, partitioning and assigning drive letters.",
      "Manage which services and processes run automatically at startup.",
    ],
  },
];

/* ====================================================================
   PART 3 · KERBEROS
==================================================================== */
export const kerbStamp = "Last Updated : 30 Apr, 2026";

export const kerbIntro =
  "Kerberos provides a centralized authentication server whose function is to authenticate users to servers and servers to users.";

export const kerbBullets = [
  "Kerberos Authentication uses the server and database for client authentication.",
  "Kerberos runs as a third-party trusted server known as the Key Distribution Center.",
  "Each user and service on the network is a principal.",
];

export type KerbComponent = { i: string; name: string; lead: string; points: string[]; tone: "phos" | "amber" | "sage" };
export const kerbComponents: KerbComponent[] = [
  {
    i: "01",
    name: "Authentication Server (AS)",
    lead: "This performs initial verification of user identity and issues a ticket for further access.",
    points: ["Validates user credentials during the login process", "Generates a Ticket Granting Ticket (TGT) after successful authentication"],
    tone: "phos",
  },
  {
    i: "02",
    name: "Ticket Granting Server (TGS)",
    lead: "It issues service tickets required to access specific services or servers.",
    points: ["Receives requests along with the Ticket Granting Ticket (TGT)", "Generates service-specific tickets for requested resources"],
    tone: "amber",
  },
  {
    i: "03",
    name: "Database",
    lead: "It stores user credentials and access-related information required for the authentication process.",
    points: ["Maintains records of users and their permissions", "Supports verification of access rights during authentication"],
    tone: "sage",
  },
];

export const kerbWorkingIntro =
  "Kerberos works on a trusted third-party authentication model where a central server issues time-limited tickets to enable secure authentication and access to network services without repeatedly sending passwords.";

export type KerbStep = { i: string; name: string; desc: string };
export const kerbSteps: KerbStep[] = [
  { i: "01", name: "User Request for Service", desc: "The user logs in and requests access to a network service. The request is sent to the Authentication Server (AS) to obtain a Ticket Granting Ticket (TGT)." },
  { i: "02", name: "Authentication Server Verification", desc: "The AS verifies the user credentials using its database and issues a TGT along with a session key. The response is encrypted using a key derived from the user's password." },
  { i: "03", name: "TGT Decryption and Request to TGS", desc: "The user decrypts the response using their password and obtains the TGT. It is then sent to the Ticket Granting Server (TGS) along with an authenticator containing the user identity and network address." },
  { i: "04", name: "Ticket Granting Server Processing", desc: "The TGS validates the TGT and authenticator. After successful verification, it issues a service ticket for the requested server." },
  { i: "05", name: "Service Request to Server", desc: "The user sends the service ticket and a new authenticator to the application server." },
  { i: "06", name: "Service Access Granted", desc: "The server verifies the ticket and authenticator. If valid, access to the requested service is granted." },
];

export const kerbThreats = ["Ticket forgery attempts", "Brute-force or credential stuffing attacks", "Malware-based exploitation or encryption downgrade attempts"];
export const kerbStrengths = ["Strong and upgradeable encryption support", "Highly reliable for network authentication", "Effective when combined with strong password policies and correct configuration"];

export type KerbApp = { name: string; desc: string };
export const kerbApplications: KerbApp[] = [
  { name: "User Authentication", desc: "Kerberos authenticates users using a single login. After verifying credentials, it issues a Ticket Granting Ticket (TGT) to allow secure access." },
  { name: "Single Sign-On (SSO)", desc: "Users log in once and can access multiple authorized network services without re-entering credentials, improving convenience and usability." },
  { name: "Mutual Authentication", desc: "Both client and server verify each other before communication using shared secret keys, ensuring secure and trusted connections." },
  { name: "Authorization", desc: "After authentication, Kerberos issues service tickets that define user permissions, allowing access only to authorized resources." },
  { name: "Network Security", desc: "Kerberos uses a centralized authentication server to manage credentials and control access, preventing unauthorized use of network resources." },
];

export const kerbLimitations = [
  "Each network service requires individual modification for compatibility.",
  "Does not perform efficiently in time-sharing environments.",
  "Requires a continuously available and secure authentication server.",
  "Centralized key management increases risk if compromised.",
  "Assumes client systems remain secure, which may not always hold true.",
  "Failure or breach can lead to cascading loss of trust across systems.",
  "Scalability challenges may arise in large or distributed environments.",
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q21 = { q: string; options: string[]; answer: number; why: string };

export const questions21: Q21[] = [
  {
    q: "What is the primary role of the Key Distribution Center (KDC) in Kerberos?",
    options: ["Encrypt user files", "Authenticate users and issue tickets", "Store application data", "Monitor network traffic"],
    answer: 1,
    why: "The KDC is the trusted third-party server that authenticates users and services and issues the tickets (TGT and service tickets) that grant access — it doesn't encrypt files, store app data or monitor traffic.",
  },
  {
    q: "Which component issues the Ticket Granting Ticket (TGT)?",
    options: ["Ticket Granting Server (TGS)", "Authentication Server (AS)", "Client", "Database"],
    answer: 1,
    why: "The Authentication Server (AS) validates user credentials at login and generates the TGT. The TGS later uses that TGT to issue service-specific tickets.",
  },
  {
    q: "What is the main advantage of Kerberos Single Sign-On (SSO)?",
    options: ["Faster internet speed", "Multiple passwords for security", "One-time login for multiple services", "Eliminates encryption"],
    answer: 2,
    why: "With SSO, a user logs in once and can access multiple authorized network services without re-entering credentials each time — improving convenience without weakening security.",
  },
  {
    q: "Why does Kerberos use tickets instead of sending passwords repeatedly?",
    options: ["To reduce server load only", "To improve UI design", "To enhance security by avoiding password transmission", "To store passwords in plain text"],
    answer: 2,
    why: "Tickets let a user prove identity to a service without transmitting the password itself each time, which greatly reduces the chance of the password being intercepted.",
  },
  {
    q: "Which of the following is a limitation of Kerberos?",
    options: ["Supports mutual authentication", "Provides strong encryption", "Requires synchronized system clocks", "Enables Single Sign-On"],
    answer: 2,
    why: "Kerberos tickets are time-limited, so all systems involved must keep closely synchronized clocks — a real operational limitation. The other options are actually strengths of Kerberos, not weaknesses.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents21: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title"] },
  {
    section: "IAM",
    items: [
      "What & why",
      "Benefits",
      "Implementation guide",
      "Rise in importance",
      "IAM & existing protocols",
      "Policies",
      "Advantages & limitations",
    ],
  },
  {
    section: "Windows User Management",
    items: [
      "What & why",
      "Types of accounts",
      "Creating an account",
      "Reset password · I",
      "Reset password · II",
      "Tools · Control Panel",
      "Tools · Settings & Computer Mgmt",
    ],
  },
  {
    section: "Kerberos",
    items: ["What & why", "Components", "Working of Kerberos", "Security analysis", "Applications", "Limitations"],
  },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL21 = 29;
