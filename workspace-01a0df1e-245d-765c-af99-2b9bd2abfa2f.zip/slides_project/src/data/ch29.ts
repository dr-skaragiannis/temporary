/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 29
   Dynamic Application Security Testing (DAST) & Vulnerability Assessment
   Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH29_TITLE = "DAST & Vulnerability Assessment";
export const dastStamp = "Last Updated : 18 May, 2026";
export const vaStamp = "Last Updated : 8 Apr, 2026";

/* --- Dynamic Application Security Testing (DAST) --------------------------- */
export const dastIntro =
  "Dynamic Application Security Testing (DAST) is a security testing approach that evaluates a running application to identify vulnerabilities in real time. Unlike static testing methods, DAST operates from an external perspective — simulating real-world attack scenarios without requiring access to source code.";

export const dastIntroPoints = [
  "Simulates real-world cyberattacks to identify exploitable vulnerabilities in running applications.",
  "Performs black-box security testing without requiring access to the source code.",
  "Detects threats like SQL injection, XSS, authentication flaws and misconfigurations.",
  "Enhances modern application security, compliance and continuous vulnerability management.",
];

export const dastStepsIntro =
  "DAST tools test a live web application by simulating automated attacks and monitoring the results. The testing process typically involves:";

export type DastStep = { n: string; name: string; lead: string; points: string[] };

export const dastSteps: DastStep[] = [
  {
    n: "01",
    name: "Crawling the Application",
    lead: "DAST tools begin by exploring the application to understand its structure, pages, APIs, forms and user-accessible endpoints. This process helps create a complete map of the application's attack surface before security testing starts.",
    points: [
      "Discovers web pages, APIs, forms and hidden endpoints automatically.",
      "Maps the application structure to identify potential attack entry points.",
      "Builds a complete attack surface for effective vulnerability assessment.",
    ],
  },
  {
    n: "02",
    name: "Attacking with Crafted Inputs",
    lead: "After mapping the application, DAST tools send malicious payloads and manipulated inputs to test how the application handles suspicious activity. This step simulates real-world cyberattacks to uncover exploitable security weaknesses.",
    points: [
      "Injects SQL injection, XSS and other malicious payloads automatically.",
      "Tests application behavior under simulated attack conditions.",
      "Identifies weak input validation and insecure request handling.",
    ],
  },
  {
    n: "03",
    name: "Analyzing Responses",
    lead: "The scanner carefully reviews application responses to detect unusual behavior that may reveal vulnerabilities. Error messages, unexpected outputs or sensitive data exposure often indicate security flaws attackers can exploit.",
    points: [
      "Detects abnormal responses, crashes and server-side errors.",
      "Identifies data leaks, authentication flaws and insecure configurations.",
      "Analyzes application behavior to confirm potential vulnerabilities.",
    ],
  },
  {
    n: "04",
    name: "Reporting Results",
    lead: "Once testing is complete, DAST tools generate detailed vulnerability reports with severity ratings and remediation guidance. These reports help security teams prioritize and fix issues quickly to improve application security.",
    points: [
      "Generates detailed vulnerability and risk assessment reports.",
      "Provides proof of exploit with severity-based prioritization.",
      "Offers remediation guidance for faster vulnerability resolution.",
    ],
  },
];

export type DastTool = { name: string; desc: string };

export const dastTools: DastTool[] = [
  { name: "OWASP ZAP", desc: "OWASP ZAP is an open-source DAST tool used for automated web application security testing with strong CI/CD and DevSecOps integration." },
  { name: "Burp Suite", desc: "Burp Suite provides automated and manual penetration testing features for advanced web application security analysis." },
  { name: "Acunetix", desc: "Offers fast vulnerability scanning with integrated DAST and IAST capabilities for accurate web security testing." },
  { name: "Invicti (Netsparker)", desc: "Invicti uses proof-based scanning to verify exploitable vulnerabilities and improve enterprise-scale security testing." },
  { name: "Veracode Dynamic Analysis", desc: "Veracode Dynamic Analysis is a cloud-based DAST platform designed for securing enterprise applications with automated compliance-focused scanning." },
  { name: "Checkmarx DAST", desc: "Checkmarx integrates with SAST and SCA tools to provide unified vulnerability management across the SDLC." },
];

export type DastAdvantage = { name: string; desc: string };

export const dastAdvantages: DastAdvantage[] = [
  { name: "Detects Environment-Specific Risks", desc: "Identifies vulnerabilities in server configurations, authentication flows and deployment environments." },
  { name: "Realistic Attack Simulation", desc: "Replicates attacker behavior, ensuring findings reflect real exploitable risks." },
  { name: "Technology Agnostic", desc: "Works across all programming languages and frameworks without modification." },
  { name: "Full Ecosystem Coverage", desc: "Tests APIs, integrations, databases and infrastructure components." },
  { name: "Continuous Security Automation", desc: "Easily integrates into pipelines for ongoing vulnerability detection and faster remediation." },
];

export type CompareRow29 = { dast: string; sast: string };

export const compareRows29: CompareRow29[] = [
  { dast: "Tests running applications (black-box)", sast: "Analyzes source code (white-box)" },
  { dast: "Finds runtime vulnerabilities", sast: "Finds coding flaws early" },
  { dast: "No code access required", sast: "Requires source code" },
  { dast: "Lower false positives", sast: "Higher false positives" },
  { dast: "Used in later SDLC stages", sast: "Used early in development" },
];

/* --- Vulnerability Assessment ---------------------------------------------------- */
export const vaIntro =
  "A systematic process used to identify and evaluate potential risks within information systems. Purpose focuses on detecting weaknesses that could be exploited and ensuring the protection of data confidentiality, integrity, and availability.";

export const vaIntroPoints = [
  "Identifies security flaws that attackers may exploit to compromise systems.",
  "Uses tools and techniques to analyze and measure risk levels.",
  "Helps detect issues like cross-site scripting (XSS) and SQL injection at an early stage.",
];

export type VaImportance = { name: string; desc: string };

export const vaImportance: VaImportance[] = [
  { name: "Preventing Data Breaches", desc: "Directing single and exclusive attention to every risk in line with time and noticing the recurrent threats so as to treat them before they bring about expensive security breaches." },
  { name: "Ensuring Regulatory Compliance", desc: "Conformity to the laws and evasion of the law." },
  { name: "Managing Risks", desc: "Risk priority and risk control to improve the general shareholders' risk evaluation." },
  { name: "Enhancing Security Posture", desc: "Periodic evaluations enhance security by making provisions of security to cater for emerging threats." },
  { name: "Cost-Effective Security", desc: "This solution lowers the costs associated with security incidents that occur when the vulnerabilities are not addressed as soon as they are identified." },
];

/* --- Contents ------------------------------------------------------------------------ */
export const contents29: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title"] },
  { section: "DAST", items: ["What & why", "Steps I", "Steps II", "Common tools", "Advantages", "DAST vs SAST"] },
  { section: "Vulnerability Assessment", items: ["What & why", "Importance"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL29 = 10;
