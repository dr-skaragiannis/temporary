/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 20
   Understanding Cyber Security in Critical Infrastructure
------------------------------------------------------------------ */

export const CH20_TITLE = "Cyber Security in Critical Infrastructure";
export const ch20Stamp = "Last Updated : 24 Apr, 2026";

export const ch20Intro =
  "Cybersecurity in critical infrastructure focuses on protecting essential systems and networks that support modern society from cyber threats and disruptions.";

export const ch20Bullets = [
  "Modern society relies heavily on digital systems",
  "Critical services operate through interconnected networks",
  "Cyberattacks can impact public safety and the economy",
  "Strong cybersecurity reduces national and organizational risks",
  "Protection is both a technical and strategic priority",
];

/* --- Threat landscape ------------------------------------------------- */
export type Threat = { i: string; name: string; desc: string };

export const threats: Threat[] = [
  {
    i: "01",
    name: "Cyber Warfare",
    desc: "Cyber threats could be launched by states and actors granted state support to implement espionage, launching cyberattacks that collapse critical services or destroy advisory systems.",
  },
  {
    i: "02",
    name: "Cyber Terrorism",
    desc: "Cyber terrorist groups and other non-state actors can engage in such attacks to create a sense of chaos, terror and fear.",
  },
  {
    i: "03",
    name: "Cyber Crime",
    desc: "Bypassing security systems poses an appealing opportunity, as organized crime groups exploit vulnerabilities in critical infrastructures to steal or demand money or to produce service interruptions.",
  },
  {
    i: "04",
    name: "Insider Threats",
    desc: "Insiders who are evil-minded or employees who are negligent with care are very close to serious risks. They can access vital systems by either exploiting some vulnerabilities or unintentionally leading to security lapses.",
  },
];

export const threatsNote =
  "Cyber threats may compromise critical infrastructure and can come in many different forms.";

/* --- Major challenges ---------------------------------------------------- */
export type Challenge = { i: string; name: string; desc: string };

export const challenges20: Challenge[] = [
  {
    i: "01",
    name: "Regulatory Compliance",
    desc: "Another layer of complexity and challenges arises due to complying with cybersecurity standards and laws, which forces organizations to manage a maze of requirements while preserving operational effectiveness.",
  },
  {
    i: "02",
    name: "Legacy Systems",
    desc: "The dominance of outdated systems is one of the biggest challenges to critical infrastructure cybersecurity. These outdated systems might be challenging to patch or upgrade as security was frequently overlooked during their creation. They are therefore simply a reward for hackers. These legacy systems often lack built-in features of security.",
  },
  {
    i: "03",
    name: "Resource Constraints",
    desc: "Limitations of financial or budget constraints lead to conflicting objectives that might restrict the amount of money allocated to cybersecurity precautions, leaving critical infrastructure open to sophisticated cyberattacks.",
  },
  {
    i: "04",
    name: "Interconnectedness",
    desc: "As the critical infrastructure is networked or interconnected, it makes it more vulnerable to attack as a breach in one system might give access to others.",
  },
  {
    i: "05",
    name: "Complexity",
    desc: "Critical infrastructure systems are often complex, that's why it is difficult to deploy thorough cybersecurity measures because systems are frequently complex, including a large number of components and stakeholders.",
  },
];

/* --- Best practices ------------------------------------------------------- */
export type Practice = { i: string; name: string; points: string[] };

export const practices: Practice[] = [
  {
    i: "01",
    name: "Risk Assessment",
    points: ["Identifies threats and vulnerabilities", "Helps prioritize security investments", "Forms the foundation of security planning"],
  },
  {
    i: "02",
    name: "Defense-in-Depth",
    points: ["Uses multiple layers of security", "Includes firewalls, IDS, encryption and access control", "Reduces impact of single security failure"],
  },
  {
    i: "03",
    name: "Incident Response Planning",
    points: ["Predefined procedures for cyber incidents", "Ensures quick detection, containment and recovery", "Minimizes operational disruption"],
  },
  {
    i: "04",
    name: "Collaboration and Information Sharing",
    points: ["Encourages cooperation between governments and organizations", "Improves threat intelligence and preparedness"],
  },
  {
    i: "05",
    name: "Employee Training",
    points: ["Educates staff about phishing and social engineering", "Reduces human-related security risks"],
  },
  {
    i: "06",
    name: "Continuous Monitoring",
    points: ["Real-time detection of suspicious activity", "Enables proactive defense mechanisms"],
  },
  {
    i: "07",
    name: "Patch Management",
    points: ["Regular updates close known vulnerabilities", "Reduces chances of exploitation"],
  },
];

/* --- Examples / sectors ------------------------------------------------------ */
export type Sector = { i: string; name: string; points: string[]; tone: "phos" | "amber" | "sage" };

export const sectors: Sector[] = [
  {
    i: "01",
    name: "Transportation Security",
    points: ["Encryption of communication networks", "Biometric authentication at airports and ports", "Restricted access to critical assets"],
    tone: "phos",
  },
  {
    i: "02",
    name: "Power Grid Protection",
    points: ["Firewalls and intrusion detection systems", "Network traffic monitoring and anomaly detection", "Regular penetration testing and vulnerability assessments"],
    tone: "amber",
  },
  {
    i: "03",
    name: "Financial Sector Defense",
    points: ["Protection of banking and payment systems", "Fraud detection and anomaly monitoring", "Use of multi-factor authentication and tokenization"],
    tone: "sage",
  },
  {
    i: "04",
    name: "Healthcare System Resilience",
    points: [
      "Protection of electronic health records (EHRs)",
      "Securing medical devices and telemedicine platforms",
      "Use of encryption and secure authentication",
      "Emergency response planning to ensure patient care continuity",
    ],
    tone: "phos",
  },
  {
    i: "05",
    name: "Water and Wastewater Security",
    points: [
      "Segregation of operational networks",
      "Protection of Industrial Control Systems (ICS)",
      "Firmware integrity checks and access control",
      "Cybersecurity drills and training exercises",
    ],
    tone: "amber",
  },
];

/* --- Knowledge check ---------------------------------------------------- */
export type Q20 = { q: string; options: string[]; answer: number; why: string };

export const questions20: Q20[] = [
  {
    q: "What is the main objective of cybersecurity in critical infrastructure?",
    options: ["To improve system performance", "To protect from cyber threats", "To reduce hardware costs", "To increase network speed"],
    answer: 1,
    why: "Cybersecurity in critical infrastructure exists to protect the essential systems and networks that modern society depends on from cyber threats and disruptions — not to optimise speed, cost or performance.",
  },
  {
    q: "Which threat type involves attacks by internal employees or trusted users?",
    options: ["Cyber Warfare", "Cyber Terrorism", "Ransomware Attacks", "Insider Threats"],
    answer: 3,
    why: "Insider threats come from evil-minded insiders or negligent employees who already have access to vital systems — either exploiting vulnerabilities deliberately or causing lapses unintentionally.",
  },
  {
    q: "Why are legacy systems considered a major security challenge?",
    options: ["They are too fast", "They are expensive to maintain", "They are cloud-based", "They lack modern security features and updates"],
    answer: 3,
    why: "Legacy systems were often built before security was a design priority, are difficult to patch or upgrade, and lack built-in security features — making them an easy reward for hackers.",
  },
  {
    q: "A breach in one system spreads to others due to network connections. This issue is known as:",
    options: ["Resource Constraints", "Complexity", "Interconnectedness", "Compliance Failure"],
    answer: 2,
    why: "Interconnectedness means critical infrastructure systems are networked together, so a breach in one system can give an attacker access to others.",
  },
  {
    q: "An organization uses firewalls, encryption, and access control together to prevent attacks. This approach is:",
    options: ["Risk Assessment", "Defense-in-Depth", "Incident Response", "Patch Management"],
    answer: 1,
    why: "Defense-in-depth layers multiple controls — firewalls, IDS, encryption and access control — so that a single failure doesn't compromise the whole system.",
  },
];

/* --- Contents ------------------------------------------------------------- */
export const contents20: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Threats & challenges", items: ["Threat landscape", "Major challenges"] },
  { section: "Practice", items: ["Best practices", "Examples overview"] },
  { section: "Sector examples", items: ["Transportation & power grid", "Financial & healthcare", "Water & wastewater"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Q05", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL20 = 17;
