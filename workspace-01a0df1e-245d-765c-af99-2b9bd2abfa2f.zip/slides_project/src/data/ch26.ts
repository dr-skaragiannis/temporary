/* ------------------------------------------------------------------
   INTRODUCTION TO CYBERSECURITY — CHAPTER 26
   Backup vs Recovery  ·  Module: Cyber Defense & Protection
------------------------------------------------------------------ */

export const CH26_TITLE = "Backup vs Recovery";
export const ch26Module =
  "Cyber Defense & Protection — this module covers backup strategies, secure coding practices, vulnerability assessment, penetration testing and tools like IDS/IPS to detect and prevent attacks.";
export const ch26Stamp = "Last Updated : 28 Apr, 2026";

export const ch26Intro =
  "As technology evolves, continuous data generation from work and personal use makes data protection essential. Proper backup and recovery methods help prevent permanent loss and ensure data can be restored during unexpected events.";

export const ch26IntroPoints = [
  "Safeguards data against loss, corruption or system failures",
  "Enables recovery after accidental deletion or cyber incidents",
  "Ensures business continuity and minimal downtime",
  "Supports secure and reliable data management",
];

/* --- Backup ------------------------------------------------------------- */
export const backupIntro =
  "Copy of original data stored for recovery in case of data loss. Backup serves as a key method for data protection and ensures the availability of important information during system failure or accidental deletion.";

export const backupPoints = [
  "Important data of the organization needs efficient storage of copies to protect valuable data.",
  "Copy can be stored separately or in a database on storage devices.",
  "Types include full copy, incremental copy, local copy and mirror copy.",
];

export const backupExample =
  "Modern backup solutions include cloud-based tools such as Google Drive, Microsoft OneDrive and AWS Backup, which automatically store and manage data backups.";

export type BackupType26 = { name: string; points: string[] };

export const backupTypes26: BackupType26[] = [
  {
    name: "Differential Backup",
    points: [
      "Stores all changes made since the last full backup.",
      "It requires more storage than incremental backup but allows faster recovery.",
    ],
  },
  {
    name: "Cloud Backup",
    points: [
      "Data is stored on remote cloud servers instead of local devices.",
      "It ensures accessibility, scalability and protection against physical damage.",
    ],
  },
];

export const backupAdvantages26 = [
  "Protection against data loss.",
  "Ensuring smooth workflow.",
  "Enables recovery of previous data.",
  "Users can back up the data and delete it from their system to free up space or memory.",
];

export const backupDisadvantages26 = [
  "Hardware and software expenses are higher.",
  "Maintenance cost of hardware and software increases.",
  "Failure to properly backup critical data can result in irreversible loss.",
  "Storage space requirements increase over time due to continuous data copies.",
];

/* --- Recovery -------------------------------------------------------------- */
export const recoveryIntro =
  "Recovery refers to restoring lost data by following some processes. Even if the data was backed up still lost so it can be recovered by using/implementing some recovery techniques. When a database fails due to any reason then there is a chance of data loss, so in that case recovery process helps in improve the reliability of the database.";

export const recoveryExample =
  "Recuva is a data recovery tool. Using Recuva you can restore lost and deleted files.";

export const disasterRecoveryIntro =
  "Disaster recovery planning involves preparing strategies to restore systems, data and operations after major failures such as cyberattacks, hardware crashes or natural disasters.";

export const disasterRecoveryPoints = [
  "Defines recovery time objectives (RTO)",
  "Ensures business continuity",
  "Includes backup and recovery strategies",
  "Minimizes downtime and financial loss",
];

export const recoveryAdvantages26 = [
  "Prevents permanent loss of data by restoring important information after unexpected system failures or accidental deletion.",
  "Use of recovery tools remains cost-effective as it reduces need for expensive manual data reconstruction methods.",
  "Helps in disaster recovery by enabling quick restoration of systems and minimizing downtime during critical situations.",
  "Restores system operations quickly after failure, ensuring continuity of services and reducing operational disruption.",
];

export const recoveryDisadvantages26 = [
  "Restoration process cannot be guaranteed in all cases, especially after severe corruption or overwrite.",
  "Restoration tools may involve high cost, depending on complexity and features offered.",
  "Using untrustworthy or poorly developed data recovery software increases security risk.",
  "Recovery process may require significant time, causing delays in system restoration.",
];

/* --- Backup vs Recovery comparison table ------------------------------------ */
export type CompareRow26 = { backup: string; recovery: string };

export const compareRows26: CompareRow26[] = [
  { backup: "Replication of data for safety purpose.", recovery: "Recovery of usable data from stored copies." },
  { backup: "Maintain extra copy for future safety and protection.", recovery: "Bring system back to working state after data loss or failure." },
  { backup: "Improves data protection and reduces risk of permanent loss.", recovery: "Ensures continuity by restoring missing or corrupted information." },
  { backup: "Supports data safety and acts as foundation for data protection.", recovery: "Depends on stored copies to reconstruct system data." },
  { backup: "Common in daily business and system operations.", recovery: "Used during failure, corruption or data loss situations." },
  { backup: "Snapshot or database copy stored using backup tools.", recovery: "System data restored from saved restore points or snapshots." },
  { backup: "Stored externally on separate storage devices or cloud.", recovery: "Performed internally using stored data copies." },
  { backup: "Requires additional storage space.", recovery: "Does not require extra storage beyond existing backups." },
  { backup: "Can be manual or scheduled automatically.", recovery: "Often supported through automatic restore points." },
  { backup: "Makes restoration process possible and easier.", recovery: "Ensures system and data usability after failure." },
];

/* --- Real-world scenarios ------------------------------------------------------ */
export type Scenario26 = { name: string; desc: string; backupRole: string; recoveryRole: string };

export const scenarios26: Scenario26[] = [
  {
    name: "Scenario 1 — Ransomware Attack",
    desc: "A company's systems are encrypted by ransomware, making all files inaccessible.",
    backupRole: "Backup helps restore clean copies of data",
    recoveryRole: "Recovery ensures systems return to normal operations",
  },
  {
    name: "Scenario 2 — Accidental File Deletion",
    desc: "An employee deletes important project files.",
    backupRole: "Backup allows retrieval of previous versions",
    recoveryRole: "Recovery restores files quickly without rework",
  },
  {
    name: "Scenario 3 — Hardware Failure",
    desc: "A hard drive crashes unexpectedly.",
    backupRole: "Backup stored on cloud or external device prevents permanent loss",
    recoveryRole: "Recovery restores system functionality",
  },
];

/* --- Knowledge check --------------------------------------------------------------- */
export type Q26 = { q: string; options: string[]; answer: number; why: string };

export const questions26: Q26[] = [
  {
    q: "Which statement best defines Backup?",
    options: ["Restoring lost data after failure.", "Storing a copy of original data separately.", "Improving database reliability", "Guaranteeing atomicity of transactions."],
    answer: 1,
    why: "Backup is the copy of original data stored separately for recovery in case of data loss — restoring lost data is Recovery, not Backup.",
  },
  {
    q: "Which of the following is an example of Recovery?",
    options: ["SnapManager is creating a database copy.", "Recuva restores deleted files.", "Cloud storage syncing photos.", "Incremental backup of office files."],
    answer: 1,
    why: "Recuva is a data recovery tool used to restore lost and deleted files — the other options describe creating or syncing copies, which are backup activities.",
  },
  {
    q: "What is the primary goal of Backup?",
    options: ["Retrieve original data after failure.", "Improve database reliability.", "Keep an extra copy of data for protection.", "Guarantee atomicity of transactions."],
    answer: 2,
    why: "Backup's core purpose is maintaining an extra copy of data for safety and protection against loss, corruption or system failure — retrieving data after failure is what Recovery does.",
  },
  {
    q: "Which of the following is a disadvantage of Recovery?",
    options: ["Requires extra storage space.", "Not always guaranteed.", "Affordable cost.", "Smooth workflow."],
    answer: 1,
    why: "Recovery cannot always be guaranteed — especially after severe corruption or an overwrite — which is listed as a key disadvantage; requiring extra storage is a Backup trait, not Recovery's.",
  },
];

/* --- Contents ------------------------------------------------------------------------ */
export const contents26: { section: string; items: string[] }[] = [
  { section: "Foundations", items: ["Title", "What & why"] },
  { section: "Backup", items: ["What is backup", "Backup types", "Backup advantages", "Backup disadvantages"] },
  { section: "Recovery", items: ["What is recovery", "Disaster recovery planning", "Recovery advantages", "Recovery disadvantages"] },
  { section: "Comparison", items: ["Backup vs Recovery I", "Backup vs Recovery II"] },
  { section: "Practice", items: ["Real-world scenarios"] },
  { section: "Knowledge check", items: ["Briefing", "Q01", "Q02", "Q03", "Q04", "Score"] },
  { section: "Close", items: ["Takeaways"] },
];

export const TOTAL26 = 20;
