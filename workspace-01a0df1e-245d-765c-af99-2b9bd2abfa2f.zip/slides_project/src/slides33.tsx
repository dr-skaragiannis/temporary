import { motion } from "framer-motion";
import { Row, Slide, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch33Intro,
  ch33IntroPoints,
  ch33Stamp,
  contents33,
  detectionMechanisms33,
  idsSide33,
  inlineDeploymentDesc,
  inlinePositioning,
  ipsImportance,
  ipsSide33,
  ipsTypes,
  ipsVsIdsIntro,
  layeredIntro,
  osiLayers33,
  preprocessingIntro,
  preprocessItems,
  questions33,
  responseActions33,
  techComparisonIntro33,
  techComparisonPoints33,
  TOTAL33,
  tuningItems33,
  workingMechIntro33,
} from "./data/ch33";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "inline traffic block" backdrop
================================================================== */
function InlineBlockBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="ibbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="ibbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* inline traffic path with a gate */}
      <g transform="translate(740 260)" opacity="0.9">
        <line x1="0" y1="0" x2="150" y2="0" stroke="#3DF07A" strokeWidth="2.5" />
        <circle cx="0" cy="0" r="6" fill="#0B0F0D" stroke="#3DF07A" strokeWidth="2.5" />
        <circle cx="60" cy="0" r="6" fill="#0B0F0D" stroke="#3DF07A" strokeWidth="2.5" />
        {/* gate */}
        <rect x="140" y="-30" width="10" height="60" fill="#FFB020" />
        {/* blocked packet */}
        <circle cx="200" cy="0" r="6" fill="#FFB020" opacity="0.5" />
        <line x1="185" y1="-15" x2="215" y2="15" stroke="#FFB020" strokeWidth="2.5" />
        <line x1="215" y1="-15" x2="185" y2="15" stroke="#FFB020" strokeWidth="2.5" />
      </g>
      <g transform="translate(1000 260)" filter="url(#ibbGlow)">
        <circle cx="0" cy="0" r="40" fill="none" stroke="#3DF07A" strokeWidth="2.5" />
        <path d="M-14 0 L-4 12 L16 -12" fill="none" stroke="#3DF07A" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <rect width="1200" height="700" fill="url(#ibbFade)" />
    </svg>
  );
}

export function TitleSlide33({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <InlineBlockBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 33 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.33&nbsp;//&nbsp;IPS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL33}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 33</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">Intrusion Prevention</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">System (IPS)</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch33Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(11)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to IPS vs IDS</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Working stages", "Six"], ["Detection mechanisms", "Four"], ["IPS types", "Four"], ["Doc revision", ch33Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide33() {
  return (
    <Slide tag="SEC // CH.33 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch33Intro} dense>
      <div>
        {ch33IntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · INLINE DEPLOYMENT
================================================================== */
export function InlineDeploymentSlide33() {
  return (
    <Slide tag="SEC // CH.33 // MECHANISM 1/6" num="03" title={<>Inline <span className="text-phos">deployment</span></>} lede={workingMechIntro33} dense>
      <div className="border-l-2 border-phos bg-panel/50 p-5">
        <span className="font-mono text-[9.5px] tracked text-phos">01 · Inline Deployment</span>
        <p className="mt-2.5 text-[13.5px] font-light leading-[1.6] text-sage/85">{inlineDeploymentDesc}</p>
        <div className="mt-4 border-t border-sage/15 pt-4">
          <span className="font-mono text-[9px] tracked text-muted">POSITIONING</span>
          <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{inlinePositioning}</p>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · TRAFFIC PREPROCESSING
================================================================== */
export function PreprocessingSlide33() {
  return (
    <Slide tag="SEC // CH.33 // MECHANISM 2/6" num="04" title={<>Traffic <span className="text-phos">preprocessing</span></>} lede={preprocessingIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {preprocessItems.map((p, n) => (
          <motion.div key={p.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.55] text-muted">{p.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · LAYERED PACKET INSPECTION
================================================================== */
export function LayeredInspectionSlide33() {
  return (
    <Slide tag="SEC // CH.33 // MECHANISM 3/6" num="05" title={<>Layered packet <span className="text-phos">inspection</span></>} lede={layeredIntro} dense>
      <div className="grid gap-4 sm:grid-cols-3">
        {osiLayers33.map((l, n) => (
          <motion.div key={l.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }}>0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{l.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.55] text-muted">{l.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · DETECTION MECHANISMS
================================================================== */
export function DetectionMechanismsSlide33() {
  return (
    <Slide tag="SEC // CH.33 // MECHANISM 4/6" num="06" title={<>Detection <span className="text-phos">mechanisms</span></>} lede="The IPS uses various detection mechanisms to identify threats:" dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {detectionMechanisms33.map((d, n) => (
          <motion.div key={d.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n % 2 === 0 ? TONE.phos : TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n % 2 === 0 ? TONE.phos : TONE.amber }}>0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{d.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{d.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · AUTOMATED RESPONSE ACTIONS
================================================================== */
export function ResponseActionsSlide33() {
  return (
    <Slide tag="SEC // CH.33 // MECHANISM 5/6" num="07" title={<>Automated <span className="text-phos">response actions</span></>} lede="Once a threat is detected, the IPS can immediately take action to mitigate it:" dense>
      <div>
        {responseActions33.map((r, n) => (
          <Row key={r.name} i={String(n + 1).padStart(2, "0")} label={r.name} desc={r.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · TUNING AND MAINTENANCE
================================================================== */
export function TuningSlide33() {
  return (
    <Slide tag="SEC // CH.33 // MECHANISM 6/6" num="08" title={<>Tuning &amp; <span className="text-phos">maintenance</span></>} lede="An IPS requires regular updates and fine-tuning to stay effective:" dense>
      <div className="grid gap-4 sm:grid-cols-3">
        {tuningItems33.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · TYPES OF IPS
================================================================== */
export function TypesSlide33() {
  return (
    <Slide tag="SEC // CH.33 // CLASSIFICATION" num="09" title={<>Types of <span className="text-phos">IPS</span></>} lede="IPS systems can be classified into the following types based on their monitoring focus and deployment:" dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {ipsTypes.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n % 2 === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-4">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n % 2 === 0 ? TONE.phos : TONE.amber }}>{t.n} · {t.short}</span>
              <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n % 2 === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · IMPORTANCE OF AN IPS
================================================================== */
export function ImportanceSlide33() {
  return (
    <Slide tag="SEC // CH.33 // VALUE" num="10" title={<>Importance of an <span className="text-phos">IPS</span></>} dense>
      <div>
        {ipsImportance.map((p, n) => (
          <Row key={p.name} i={String(n + 1).padStart(2, "0")} label={p.name} desc={p.desc} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · COMPARISON OF IPS TECHNOLOGIES
================================================================== */
export function TechComparisonSlide33() {
  return (
    <Slide tag="SEC // CH.33 // COMPARISON" num="11" title={<>Comparison of IPS <span className="text-phos">technologies</span></>} lede={techComparisonIntro33} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {techComparisonPoints33.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · IPS vs IDS
================================================================== */
export function VsIdsSlide33() {
  return (
    <Slide tag="SEC // CH.33 // COMPARISON" num="12" title={<>IPS <span className="text-phos">vs</span> IDS</>} lede={ipsVsIdsIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="border border-amber/30 bg-panel/50 p-4">
          <span className="font-mono text-[9.5px] tracked text-amber">IDS (Intrusion Detection System)</span>
          <div className="mt-3 space-y-3">
            {idsSide33.map((v) => (
              <div key={v.label} className="border-t border-sage/15 pt-3 first:border-t-0 first:pt-0">
                <span className="font-mono text-[9px] tracked text-muted">{v.label.toUpperCase()}</span>
                <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="border border-phos/30 bg-panel/50 p-4">
          <span className="font-mono text-[9.5px] tracked text-phos">IPS (Intrusion Prevention System)</span>
          <div className="mt-3 space-y-3">
            {ipsSide33.map((v) => (
              <div key={v.label} className="border-t border-sage/15 pt-3 first:border-t-0 first:pt-0">
                <span className="font-mono text-[9px] tracked text-muted">{v.label.toUpperCase()}</span>
                <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-sage/85">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide33({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.33 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><span className="inline-block border border-amber/40 px-2 py-[3px] font-mono text-[9.5px] leading-none tracked text-amber">Knowledge check</span></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Detect,
          <br />
          <span className="text-phos glow">then block.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering when an IPS is used, deep packet inspection,
          why inline deployment matters, what sets IPS apart from IDS, and
          signature-based detection. Select an answer to reveal it
          instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(13)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   14–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide33({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions33[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.33 // CHECK // Q0${n + 1}`} num={String(14 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Intrusion Prevention"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide33({ answers }: { answers: (number | null)[] }) {
  const score = questions33.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions33.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every packet gets inspected and every threat gets blocked." : pct >= 60 ? "Solid. Re-read the working mechanism and IPS-vs-IDS sections." : "Revisit the working mechanism and detection mechanism sections, then retake.";
  return (
    <Slide tag="SEC // CH.33 // CHECK // RESULT" num="19" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions33.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions33.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions33.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide33() {
  const items = [
    ["01", "IPS acts, IDS only alerts", "It extends detection with automated, real-time blocking — dropping packets, blocking IPs, terminating sessions, and updating firewall rules."],
    ["02", "Six stages inside the mechanism", "Inline deployment, preprocessing, layered inspection, detection, automated response, and ongoing tuning all work together in real time."],
    ["03", "Deep packet inspection spans the stack", "Network, transport and application layer checks combine to understand both the structure and intent of traffic."],
    ["04", "Four detection philosophies, one goal", "Signature-based, anomaly-based, behavior-based and policy-based detection each catch a different kind of threat."],
    ["05", "Four deployment flavors", "NIPS, HIPS, WIPS and NBA each protect a different surface — network perimeter, individual hosts, wireless traffic, or behavioral patterns."],
    ["06", "IPS and IDS are on the same team", "IDS observes and alerts; IPS observes and acts — many environments deploy both to combine visibility with automated protection."],
  ];
  return (
    <Slide tag="SEC // CH.33 // CLOSE" num="20" title={<>Chapter 33 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 33 · Intrusion Prevention System (IPS)</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents33.length} sections · {TOTAL33} slides</span>
      </div>
    </Slide>
  );
}
