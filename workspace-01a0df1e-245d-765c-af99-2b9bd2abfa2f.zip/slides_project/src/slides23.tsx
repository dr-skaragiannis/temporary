import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  advancedMethods23,
  advantages23,
  ch23Intro,
  ch23IntroPoints,
  ch23Stamp,
  components23,
  contents23,
  disadvantages23,
  importance23,
  primaryMethods23,
  questions23,
  selectingIntro,
  strength23,
  tokenMethods23,
  TOTAL23,
} from "./data/ch23";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "layered factors" backdrop
================================================================== */
function LayeredFactorsBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="lfFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="lfGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* three stacked factor badges: knowledge (key), possession (device), inherence (fingerprint) */}
      <g transform="translate(770 150)">
        <rect x="0" y="0" width="300" height="86" fill="#0B0F0D" stroke="#3DF07A" strokeOpacity="0.5" strokeWidth="1.3" />
        <circle cx="34" cy="43" r="16" fill="none" stroke="#3DF07A" strokeWidth="2" />
        <rect x="30" y="43" width="4" height="16" fill="#3DF07A" />
        <path d="M34 59 h10" stroke="#3DF07A" strokeWidth="2" />
        <text x="64" y="34" fill="#3DF07A" fontFamily="IBM Plex Mono, monospace" fontSize="11" letterSpacing="0.6">KNOWLEDGE FACTOR</text>
        <text x="64" y="54" fill="#C7D2C9" fontFamily="IBM Plex Mono, monospace" fontSize="9.5" opacity="0.7">password · PIN · security answer</text>
      </g>
      <g transform="translate(800 258)">
        <rect x="0" y="0" width="300" height="86" fill="#0B0F0D" stroke="#FFB020" strokeOpacity="0.5" strokeWidth="1.3" />
        <rect x="20" y="27" width="26" height="42" rx="3" fill="none" stroke="#FFB020" strokeWidth="2" />
        <line x1="20" y1="60" x2="46" y2="60" stroke="#FFB020" strokeWidth="1.4" />
        <text x="64" y="42" fill="#FFB020" fontFamily="IBM Plex Mono, monospace" fontSize="11" letterSpacing="0.6">POSSESSION FACTOR</text>
        <text x="64" y="62" fill="#C7D2C9" fontFamily="IBM Plex Mono, monospace" fontSize="9.5" opacity="0.7">device · OTP app · hardware token</text>
      </g>
      <g transform="translate(830 366)" filter="url(#lfGlow)">
        <rect x="0" y="0" width="300" height="86" fill="#0B0F0D" stroke="#C7D2C9" strokeOpacity="0.5" strokeWidth="1.3" />
        <path d="M33 24 a13 13 0 0 1 13 13 v6 a13 13 0 0 1 -6 11" fill="none" stroke="#C7D2C9" strokeWidth="1.8" strokeLinecap="round" />
        <path d="M27 55 v-18 a10 10 0 0 1 19 -5" fill="none" stroke="#C7D2C9" strokeWidth="1.8" strokeLinecap="round" />
        <path d="M33 55 v-14 a5 5 0 0 1 10 -2" fill="none" stroke="#C7D2C9" strokeWidth="1.8" strokeLinecap="round" />
        <text x="64" y="42" fill="#C7D2C9" fontFamily="IBM Plex Mono, monospace" fontSize="11" letterSpacing="0.6">INHERENT FACTOR</text>
        <text x="64" y="62" fill="#C7D2C9" fontFamily="IBM Plex Mono, monospace" fontSize="9.5" opacity="0.7">fingerprint · face · iris</text>
      </g>
      <rect width="1200" height="700" fill="url(#lfFade)" />
    </svg>
  );
}

export function TitleSlide23({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <LayeredFactorsBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Identity briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 23 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.23&nbsp;//&nbsp;MFA</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL23}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 23</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Multi-Factor</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Authentication</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch23Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(5)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to authentication methods</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Factor types", "Three"], ["Authentication methods", "Ten"], ["Advantages listed", "Six"], ["Doc revision", ch23Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide23() {
  return (
    <Slide tag="SEC // CH.23 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch23Intro} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {ch23IntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · COMPONENTS OF MFA
================================================================== */
export function ComponentsSlide23() {
  return (
    <Slide tag="SEC // CH.23 // BUILDING BLOCKS" num="03" title={<>Components of <span className="text-phos">MFA</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-3">
        {components23.map((c, n) => (
          <motion.div key={c.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: [TONE.phos, TONE.amber, TONE.sage][n] }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.55] text-muted">{c.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · IMPORTANCE
================================================================== */
export function ImportanceSlide23() {
  return (
    <Slide tag="SEC // CH.23 // WHY IT MATTERS" num="04" title={<>Importance of <span className="text-phos">Multi-Factor Authentication</span></>} dense>
      <div>
        {importance23.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.04} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · SELECTING AUTHENTICATION METHODS (overview)
================================================================== */
export function SelectingSlide23() {
  return (
    <Slide tag="SEC // CH.23 // STRATEGY" num="05" title={<>Selecting <span className="text-phos">authentication methods</span></>} lede={selectingIntro} dense>
      <motion.div variants={rise}>
        <Panel className="p-5">
          <div className="font-mono text-[9.5px] tracked text-amber">Method categories covered next</div>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Primary methods", "Advanced methods", "Token-based methods", "Strength & security"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
          </div>
        </Panel>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   06 · PRIMARY AUTHENTICATION AND VERIFICATION METHODS
================================================================== */
export function PrimaryMethodsSlide23() {
  return (
    <Slide tag="SEC // CH.23 // METHODS" num="06" title={<>Primary authentication &amp; <span className="text-phos">verification methods</span></>} dense>
      <div>
        {primaryMethods23.map((m, n) => (
          <Row key={m.name} i={String(n + 1).padStart(2, "0")} label={m.name} desc={m.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · ADVANCED AUTHENTICATION METHODS
================================================================== */
export function AdvancedMethodsSlide23() {
  return (
    <Slide tag="SEC // CH.23 // METHODS" num="07" title={<>Advanced <span className="text-phos">authentication methods</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {advancedMethods23.map((m, n) => (
          <motion.div key={m.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.92rem] uppercase leading-tight tracking-tight text-sage">{m.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{m.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · TOKEN-BASED AUTHENTICATION
================================================================== */
export function TokenMethodsSlide23() {
  return (
    <Slide tag="SEC // CH.23 // METHODS" num="08" title={<>Token-based <span className="text-phos">authentication</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {tokenMethods23.map((m, n) => (
          <motion.div key={m.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{m.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.55] text-muted">{m.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · STRENGTH AND SECURITY OF AUTHENTICATION METHODS
================================================================== */
export function StrengthSlide23() {
  return (
    <Slide tag="SEC // CH.23 // EVALUATION" num="09" title={<>Strength &amp; security of <span className="text-phos">authentication methods</span></>} dense>
      <div>
        {strength23.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.04} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · ADVANTAGES
================================================================== */
export function AdvantagesSlide23() {
  return (
    <Slide tag="SEC // CH.23 // TRADE-OFFS" num="10" title={<>Advantages of <span className="text-phos">MFA</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {advantages23.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.05 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · DISADVANTAGES
================================================================== */
export function DisadvantagesSlide23() {
  return (
    <Slide tag="SEC // CH.23 // TRADE-OFFS" num="11" title={<>Disadvantages of <span className="text-phos">MFA</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {disadvantages23.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.05 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide23({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.23 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Stack the
          <br />
          <span className="text-phos glow">factors.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering what MFA is, the "something you have" factor,
          why layered security beats a single factor, biometric methods and a
          common trade-off of MFA. Select an answer to reveal it instantly —
          the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(12)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   13–17 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide23({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions23[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.23 // CHECK // Q0${n + 1}`} num={String(13 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "MFA"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   18 · SCORE
================================================================== */
export function ScoreSlide23({ answers }: { answers: (number | null)[] }) {
  const score = questions23.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions23.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every factor checks out." : pct >= 60 ? "Solid. Re-read the components and the method categories." : "Revisit the components of MFA and the authentication methods, then retake.";
  return (
    <Slide tag="SEC // CH.23 // CHECK // RESULT" num="18" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions23.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions23.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions23.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide23() {
  const items = [
    ["01", "MFA layers proof, not just passwords", "Combining knowledge, possession and inherent factors means one stolen credential is no longer enough to break in."],
    ["02", "Three factor types cover most methods", "Knowledge (something you know), possession (something you have) and inherence (something you are) map onto every method in this chapter."],
    ["03", "Redundancy matters", "Configuring more than one method keeps access reliable if a phone is lost or a service is unavailable."],
    ["04", "Not all methods are equally strong", "Biometrics, hardware tokens and authenticator apps generally outrank SMS and security questions for security."],
    ["05", "MFA is a trade-off", "It adds real protection but also adds time, setup complexity and a dependency on the possession factor."],
    ["06", "It's everywhere that matters", "Banking, email and enterprise systems already lean on MFA as a baseline expectation, not an optional extra."],
  ];
  return (
    <Slide tag="SEC // CH.23 // CLOSE" num="19" title={<>Chapter 23 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 23 · Multi-Factor Authentication (MFA)</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents23.length} sections · {TOTAL23} slides</span>
      </div>
    </Slide>
  );
}
