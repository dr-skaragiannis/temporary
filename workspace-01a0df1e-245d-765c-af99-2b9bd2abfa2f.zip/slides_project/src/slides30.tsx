import { motion } from "framer-motion";
import { Row, Slide, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  CH30_TITLE,
  commonlyUncovered,
  contents30,
  detailIntro,
  detailRows30,
  glanceIntro,
  glanceRows30,
  questions30,
  TOTAL30,
  uncoveredIntro,
  vaAdvantages,
  vaDisadvantages,
  vaProcessSteps,
  vaToolCategories,
  vaTypes,
  vaWorkingSteps,
} from "./data/ch30";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   Shared two-column compare table
================================================================== */
function TwoColTable({
  headL,
  headR,
  rows,
}: {
  headL: string;
  headR: string;
  rows: { l: string; r: string }[];
}) {
  return (
    <div className="border border-sage/15" style={{ borderRadius: 2 }}>
      <div className="grid grid-cols-2 border-b border-sage/20 bg-panel/70">
        <div className="border-r border-sage/15 px-4 py-2.5 font-mono text-[10px] tracked text-phos">{headL}</div>
        <div className="px-4 py-2.5 font-mono text-[10px] tracked text-amber">{headR}</div>
      </div>
      {rows.map((r, n) => (
        <motion.div key={r.l} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.06 } } }} className="grid grid-cols-2 border-b border-sage/10 last:border-b-0 odd:bg-panel/25">
          <div className="border-r border-sage/10 px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.l}</div>
          <div className="px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.r}</div>
        </motion.div>
      ))}
    </div>
  );
}

/* ==================================================================
   Numbered three-column table — S.No · Penetration Testing · Vuln. Assessment
================================================================== */
function NumTable({ rows }: { rows: { no: number; l: string; r: string }[] }) {
  return (
    <div className="border border-sage/15" style={{ borderRadius: 2 }}>
      <div className="grid grid-cols-[2.4rem_1fr_1fr] border-b border-sage/20 bg-panel/70">
        <div className="border-r border-sage/15 px-2 py-2.5 font-mono text-[9.5px] tracked text-muted">#</div>
        <div className="border-r border-sage/15 px-4 py-2.5 font-mono text-[10px] tracked text-amber">PENETRATION TESTING</div>
        <div className="px-4 py-2.5 font-mono text-[10px] tracked text-phos">VULNERABILITY ASSESSMENT</div>
      </div>
      {rows.map((r, n) => (
        <motion.div key={r.no} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="grid grid-cols-[2.4rem_1fr_1fr] border-b border-sage/10 last:border-b-0 odd:bg-panel/25">
          <div className="border-r border-sage/10 px-2 py-3 font-mono text-[11px] text-muted">{r.no}</div>
          <div className="border-r border-sage/10 px-4 py-3 text-[12px] font-light leading-[1.5] text-sage/85">{r.l}</div>
          <div className="px-4 py-3 text-[12px] font-light leading-[1.5] text-sage/85">{r.r}</div>
        </motion.div>
      ))}
    </div>
  );
}

/* ==================================================================
   01 · TITLE — vector "audit checklist scan" backdrop
================================================================== */
function AuditScanBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="asbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="asbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* checklist stack */}
      <g transform="translate(760 160)" opacity="0.6">
        {[0, 1, 2, 3, 4, 5].map((n) => (
          <g key={n} transform={`translate(0 ${n * 40})`}>
            <rect x="0" y="0" width="18" height="18" fill="none" stroke={n % 2 === 0 ? "#3DF07A" : "#FFB020"} strokeWidth="2" />
            {n % 2 === 0 && <path d="M4 9 L8 13 L15 4" fill="none" stroke="#3DF07A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />}
            <rect x="30" y="4" width={160 + (n % 3) * 50} height="8" fill="#C7D2C9" opacity="0.28" />
          </g>
        ))}
      </g>
      {/* magnifier over stack */}
      <g transform="translate(910 300)" filter="url(#asbGlow)">
        <circle cx="0" cy="0" r="62" fill="none" stroke="#3DF07A" strokeWidth="3" />
        <line x1="44" y1="44" x2="98" y2="98" stroke="#3DF07A" strokeWidth="7" strokeLinecap="round" />
        <path d="M-24 -6 L-4 14 L24 -18" fill="none" stroke="#FFB020" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <rect width="1200" height="700" fill="url(#asbFade)" />
    </svg>
  );
}

export function TitleSlide30({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <AuditScanBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 30 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.30&nbsp;//&nbsp;VULN.&nbsp;ASSESSMENT</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL30}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 30</span>
              <span className="mt-1 block text-[clamp(1.5rem,4.2vw,3.6rem)] text-phos glow">Vulnerability Assessment</span>
              <span className="mt-1 block text-[clamp(1.3rem,3.4vw,2.7rem)] text-phos/85">Types, comparisons &amp; process</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              A closer look at vulnerability assessment: its four types, how it compares against penetration testing at a glance and in detail, its two working processes, the tools that support it, and where its advantages and limits lie.
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(3)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to VA vs Pen Testing</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["VA types covered", "Four"], ["Working steps", "Seven"], ["Process steps", "Four"], ["Knowledge check", "4 questions"]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · TYPES OF VULNERABILITY ASSESSMENT
================================================================== */
export function TypesSlide30() {
  return (
    <Slide tag="SEC // CH.30 // TYPES" num="02" title={<>Types of <span className="text-phos">Vulnerability Assessment</span></>} lede="Vulnerability assessment isn't a single scan — it's applied at different layers of the stack, each with a distinct target and purpose." dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {vaTypes.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n % 2 === 0 ? TONE.phos : TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked" style={{ color: n % 2 === 0 ? TONE.phos : TONE.amber }}>{t.n}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · VA vs PEN TESTING — AT A GLANCE
================================================================== */
export function GlanceSlide30() {
  return (
    <Slide tag="SEC // CH.30 // COMPARISON" num="03" title={<>Vulnerability Assessment <span className="text-phos">vs</span> Penetration Testing</>} lede={glanceIntro} dense>
      <TwoColTable headL="VULNERABILITY ASSESSMENT" headR="PENETRATION TESTING" rows={glanceRows30.map((r) => ({ l: r.va, r: r.pt }))} />
    </Slide>
  );
}

/* ==================================================================
   04 · DETAILED DIFFERENCES I (rows 1–6)
================================================================== */
export function DetailsASlide30() {
  return (
    <Slide tag="SEC // CH.30 // COMPARISON" num="04" title={<>Detailed differences <span className="text-phos">I</span></>} lede={detailIntro} dense>
      <NumTable rows={detailRows30.slice(0, 6).map((r) => ({ no: r.no, l: r.pt, r: r.va }))} />
    </Slide>
  );
}

/* ==================================================================
   05 · DETAILED DIFFERENCES II (rows 7–11)
================================================================== */
export function DetailsBSlide30() {
  return (
    <Slide tag="SEC // CH.30 // COMPARISON" num="05" title={<>Detailed differences <span className="text-phos">II</span></>} lede="Continuing the point-by-point breakdown, covering scope, focus, method, cost, and how each classifies its findings." dense>
      <NumTable rows={detailRows30.slice(6, 11).map((r) => ({ no: r.no, l: r.pt, r: r.va }))} />
    </Slide>
  );
}

/* ==================================================================
   06 · WORKING OF VA I (steps 1–4)
================================================================== */
export function WorkingASlide30() {
  return (
    <Slide tag="SEC // CH.30 // PROCESS I" num="06" title={<>Working of <span className="text-phos">Vulnerability Assessment</span> — I</>} lede="The end-to-end working process, part one:" dense>
      <div>
        {vaWorkingSteps.slice(0, 4).map((s, n) => (
          <Row key={s.name} i={s.n} label={s.name} desc={s.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · WORKING OF VA II (steps 5–7)
================================================================== */
export function WorkingBSlide30() {
  return (
    <Slide tag="SEC // CH.30 // PROCESS II" num="07" title={<>Working of <span className="text-phos">Vulnerability Assessment</span> — II</>} lede="The end-to-end working process, part two:" dense>
      <div>
        {vaWorkingSteps.slice(4, 7).map((s, n) => (
          <Row key={s.name} i={s.n} label={s.name} desc={s.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · PROCESS OF VULNERABILITY ASSESSMENT (4 steps)
================================================================== */
export function ProcessSlide30() {
  return (
    <Slide tag="SEC // CH.30 // PROCESS" num="08" title={<>Process of <span className="text-phos">Vulnerability Assessment</span></>} lede="A complementary, four-stage view of how a vulnerability assessment is carried out end to end." dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {vaProcessSteps.map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n % 2 === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-4">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n % 2 === 0 ? TONE.phos : TONE.amber }}>{s.n}</span>
              <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-2.5 text-[12px] font-light leading-[1.55] text-muted">{s.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · VULNERABILITIES COMMONLY UNCOVERED
================================================================== */
export function UncoveredSlide30() {
  return (
    <Slide tag="SEC // CH.30 // FINDINGS" num="09" title={<>Benefits of <span className="text-phos">Vulnerability Assessment</span></>} lede={uncoveredIntro} dense>
      <div>
        {commonlyUncovered.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · VULNERABILITY ASSESSMENT TOOLS
================================================================== */
export function ToolsSlide30() {
  return (
    <Slide tag="SEC // CH.30 // TOOLING" num="10" title={<>Vulnerability Assessment <span className="text-phos">tools</span></>} lede="Vulnerability assessment relies on purpose-built scanners across three layers of the stack." dense>
      <div className="grid gap-4 sm:grid-cols-3">
        {vaToolCategories.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">{t.n}</span>
            <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · ADVANTAGES
================================================================== */
export function AdvantagesSlide30() {
  return (
    <Slide tag="SEC // CH.30 // TRADE-OFFS" num="11" title={<>Advantages of <span className="text-phos">Vulnerability Assessment</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {vaAdvantages.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · DISADVANTAGES
================================================================== */
export function DisadvantagesSlide30() {
  return (
    <Slide tag="SEC // CH.30 // TRADE-OFFS" num="12" title={<>Disadvantages of <span className="text-phos">Vulnerability Assessment</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {vaDisadvantages.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide30({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 4 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.30 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><span className="inline-block border border-amber/40 px-2 py-[3px] font-mono text-[9.5px] leading-none tracked text-amber">Knowledge check</span></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Map it,
          <br />
          <span className="text-phos glow">then verify it.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Four items covering the objective of a vulnerability assessment,
          how it differs from penetration testing, which step catches
          open ports and misconfigurations, and its biggest practical
          advantage. Select an answer to reveal it instantly — the
          rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(13)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   14–17 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide30({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions30[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.30 // CHECK // Q0${n + 1}`} num={String(14 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 04</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Vulnerability Assessment"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   18 · SCORE
================================================================== */
export function ScoreSlide30({ answers }: { answers: (number | null)[] }) {
  const score = questions30.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions30.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — you've mapped VA cold, top to bottom." : pct >= 60 ? "Solid. Re-read the comparison and process sections." : "Revisit the process and comparison sections, then retake.";
  return (
    <Slide tag="SEC // CH.30 // CHECK // RESULT" num="18" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions30.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions30.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions30.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide30() {
  const items = [
    ["01", "Four layers, four assessment types", "Host, database, network and application-scan assessments each protect a different layer of the stack."],
    ["02", "VA maps; pen testing exploits", "Vulnerability assessment identifies and rates risk broadly and proactively; penetration testing simulates real attacks against specific targets."],
    ["03", "Two processes, same destination", "The seven-step working process (scoping → follow-up) and the four-step process view (identification → rectification) both drive toward closing security gaps."],
    ["04", "It surfaces the classics", "Injection flaws, authentication faults, and insecure defaults are exactly what regular assessments are built to catch."],
    ["05", "Purpose-built tooling per layer", "Web app simulators, network/protocol scanners, and IP-level scanners each cover a different surface."],
    ["06", "Strength and limits both matter", "VA is proactive, cost-effective and prioritized — but zero-days, false positives, and the need for regular re-runs are real trade-offs."],
  ];
  return (
    <Slide tag="SEC // CH.30 // CLOSE" num="19" title={<>Chapter 30 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 30 · {CH30_TITLE}</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents30.length} sections · {TOTAL30} slides</span>
      </div>
    </Slide>
  );
}
