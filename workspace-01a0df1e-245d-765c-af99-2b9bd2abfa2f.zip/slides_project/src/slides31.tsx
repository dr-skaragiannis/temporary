import { motion } from "framer-motion";
import { Row, Slide, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  advantages31,
  advantagesIntro31,
  applications31,
  applicationsIntro31,
  caseProblem,
  caseSolution,
  ch31Intro,
  ch31IntroPoints,
  ch31Stamp,
  contents31,
  owaspTop,
  ptMethods,
  ptRules,
  ptRulesIntro,
  ptStages,
  ptStagesIntro,
  ptTools,
  ptTypes,
  questions31,
  tipsAvoid,
  tipsFollow,
  TOTAL31,
} from "./data/ch31";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "targeted breach path" backdrop
================================================================== */
function BreachPathBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="bpbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="bpbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* breach path nodes */}
      <g transform="translate(760 180)" opacity="0.85">
        <path d="M0 0 L70 40 L130 20 L200 90 L260 70" fill="none" stroke="#3DF07A" strokeWidth="2" strokeDasharray="6 5" opacity="0.6" />
        {[[0, 0], [70, 40], [130, 20], [200, 90], [260, 70]].map(([x, y], n) => (
          <g key={n} transform={`translate(${x} ${y})`}>
            <circle r="7" fill={n === 4 ? "#FFB020" : "#0B0F0D"} stroke={n === 4 ? "#FFB020" : "#3DF07A"} strokeWidth="2.5" />
          </g>
        ))}
      </g>
      {/* crosshair on final node */}
      <g transform="translate(1020 250)" filter="url(#bpbGlow)">
        <circle cx="0" cy="0" r="46" fill="none" stroke="#FFB020" strokeWidth="2.5" />
        <line x1="-58" y1="0" x2="-30" y2="0" stroke="#FFB020" strokeWidth="2.5" />
        <line x1="30" y1="0" x2="58" y2="0" stroke="#FFB020" strokeWidth="2.5" />
        <line x1="0" y1="-58" x2="0" y2="-30" stroke="#FFB020" strokeWidth="2.5" />
        <line x1="0" y1="30" x2="0" y2="58" stroke="#FFB020" strokeWidth="2.5" />
      </g>
      <rect width="1200" height="700" fill="url(#bpbFade)" />
    </svg>
  );
}

export function TitleSlide31({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <BreachPathBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 31 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.31&nbsp;//&nbsp;PEN&nbsp;TEST</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL31}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 31</span>
              <span className="mt-1 block text-[clamp(1.6rem,4.6vw,3.9rem)] text-phos glow">Penetration Testing</span>
              <span className="mt-1 block text-[clamp(1.3rem,3.4vw,2.7rem)] text-phos/85">Software Engineering</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch31Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(6)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to Rules of Engagement</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Stages", "Five"], ["Methods", "Five"], ["Testing types", "Three"], ["Doc revision", ch31Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide31() {
  return (
    <Slide tag="SEC // CH.31 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch31Intro} dense>
      <div>
        {ch31IntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · STAGES
================================================================== */
export function StagesSlide31() {
  return (
    <Slide tag="SEC // CH.31 // PROCESS" num="03" title={<>Penetration Testing <span className="text-phos">stages</span></>} lede={ptStagesIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {ptStages.map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">{s.n}</span>
            <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.55] text-muted">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · METHODS I (External, Internal, Blind)
================================================================== */
export function MethodsASlide31() {
  return (
    <Slide tag="SEC // CH.31 // METHODS I" num="04" title={<>Penetration Testing <span className="text-phos">methods</span> — I</>} lede="Different methods vary how much information the tester and the organization share ahead of time." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {ptMethods.slice(0, 3).map((m, n) => (
          <motion.div key={m.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n % 2 === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-4">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n % 2 === 0 ? TONE.phos : TONE.amber }}>{m.n}</span>
              <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{m.name}</h3>
              <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{m.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {m.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[11.5px] font-light leading-[1.45] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n % 2 === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · METHODS II (Double-Blind, Targeted)
================================================================== */
export function MethodsBSlide31() {
  return (
    <Slide tag="SEC // CH.31 // METHODS II" num="05" title={<>Penetration Testing <span className="text-phos">methods</span> — II</>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {ptMethods.slice(3, 5).map((m, n) => (
          <motion.div key={m.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>{m.n}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{m.name}</h3>
              <p className="mt-2.5 text-[12.5px] font-light leading-[1.5] text-muted">{m.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {m.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · TYPES (Black / Grey / White Box)
================================================================== */
export function TypesSlide31() {
  return (
    <Slide tag="SEC // CH.31 // TYPES" num="06" title={<>Types of <span className="text-phos">Penetration Testing</span></>} lede="Types describe how much system knowledge the tester holds going in — from none to complete." dense>
      <div className="grid gap-4 sm:grid-cols-3">
        {ptTypes.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }}>
            <div className="p-4">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }}>{t.n}</span>
              <h3 className="mt-2 font-display text-[0.98rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{t.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[11.5px] font-light leading-[1.45] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : n === 1 ? TONE.amber : TONE.sage }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · RULES OF THE PENETRATION TESTING PROCESS
================================================================== */
export function RulesSlide31() {
  return (
    <Slide tag="SEC // CH.31 // ETHICS" num="07" title={<>Rules of the <span className="text-phos">Penetration Testing process</span></>} lede={ptRulesIntro} dense>
      <div>
        {ptRules.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · TOOLS
================================================================== */
export function ToolsSlide31() {
  return (
    <Slide tag="SEC // CH.31 // TOOLING" num="08" title={<>Penetration Testing <span className="text-phos">tools</span></>} lede="Common tools used in penetration testing:" dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {ptTools.map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <h3 className="font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{t.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · REAL-LIFE EXAMPLE & OWASP TOP 10
================================================================== */
export function CaseStudySlide31() {
  return (
    <Slide tag="SEC // CH.31 // CASE STUDY" num="09" title={<>Real-life example <span className="text-phos">&amp; OWASP Top 10</span></>} dense>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">Problem</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{caseProblem}</p>
          </div>
          <div className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">Solution</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{caseSolution}</p>
          </div>
        </div>
        <div>
          <span className="font-mono text-[9.5px] tracked text-muted">OWASP Top 10 — common vulnerabilities include</span>
          <div className="mt-3">
            {owaspTop.map((o, n) => (
              <Row key={o.name} i={String(n + 1).padStart(2, "0")} label={o.name} desc={o.desc} delay={n * 0.06} />
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · TIPS TO FOLLOW & AVOID
================================================================== */
export function TipsSlide31() {
  return (
    <Slide tag="SEC // CH.31 // GUIDANCE" num="10" title={<>Tips to <span className="text-phos">follow</span> &amp; what to <span className="text-amber">avoid</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="border border-phos/30 bg-panel/50 p-4">
          <span className="font-mono text-[9.5px] tracked text-phos">Follow</span>
          <ul className="mt-3 space-y-2.5">
            {tipsFollow.map((p) => (
              <li key={p} className="flex gap-2.5 text-[13px] font-light leading-[1.55] text-sage/85">
                <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.phos }} />{p}
              </li>
            ))}
          </ul>
        </div>
        <div className="border border-amber/30 bg-panel/50 p-4">
          <span className="font-mono text-[9.5px] tracked text-amber">Avoid</span>
          <ul className="mt-3 space-y-2.5">
            {tipsAvoid.map((p) => (
              <li key={p} className="flex gap-2.5 text-[13px] font-light leading-[1.55] text-sage/85">
                <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.amber }} />{p}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · ADVANTAGES
================================================================== */
export function AdvantagesSlide31() {
  return (
    <Slide tag="SEC // CH.31 // IMPACT" num="11" title={<>Advantages of <span className="text-phos">Penetration Testing</span></>} lede={advantagesIntro31} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {advantages31.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-phos bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · APPLICATIONS
================================================================== */
export function ApplicationsSlide31() {
  return (
    <Slide tag="SEC // CH.31 // IMPACT" num="12" title={<>Applications of <span className="text-phos">Penetration Testing</span></>} lede={applicationsIntro31} dense>
      <div>
        {applications31.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide31({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.31 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><span className="inline-block border border-amber/40 px-2 py-[3px] font-mono text-[9.5px] leading-none tracked text-amber">Knowledge check</span></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Authorized attack,
          <br />
          <span className="text-phos glow">verified defense.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering testing types, the tools of the trade, the
          stage where exploitation happens, the rules of engagement, and
          the overall goal of penetration testing. Select an answer to
          reveal it instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(13)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   14–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide31({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions31[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.31 // CHECK // Q0${n + 1}`} num={String(14 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Penetration Testing"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide31({ answers }: { answers: (number | null)[] }) {
  const score = questions31.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions31.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — engagement rules, methods, and toolset all locked in." : pct >= 60 ? "Solid. Re-read the methods, types, and rules sections." : "Revisit the stages, types, and rules sections, then retake.";
  return (
    <Slide tag="SEC // CH.31 // CHECK // RESULT" num="19" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions31.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions31.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions31.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide31() {
  const items = [
    ["01", "Pen testing is authorized, simulated attack", "A controlled cyber attack on your own systems, run to find and fix weak spots before real attackers do."],
    ["02", "Five stages, start to finish", "Planning & Reconnaissance → Scanning → Gaining Access → Maintaining Access → Analysis & Reporting."],
    ["03", "Methods vary by shared knowledge", "External, Internal, Blind, Double-Blind and Targeted testing each change how much the tester and the security team know beforehand."],
    ["04", "Types vary by system knowledge", "Black Box (none), Grey Box (partial) and White Box (complete) describe how much the tester knows about the target itself."],
    ["05", "Rules of engagement are non-negotiable", "Authorization, defined scope, no disruption, confidentiality, and responsible reporting keep testing safe and ethical."],
    ["06", "Real tools, real OWASP risks", "Nmap, Nessus, Wireshark and Burp Suite map directly onto OWASP Top 10 risks like SQL injection, XSS, broken authentication and misconfiguration."],
  ];
  return (
    <Slide tag="SEC // CH.31 // CLOSE" num="20" title={<>Chapter 31 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 31 · Penetration Testing — Software Engineering</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents31.length} sections · {TOTAL31} slides</span>
      </div>
    </Slide>
  );
}
