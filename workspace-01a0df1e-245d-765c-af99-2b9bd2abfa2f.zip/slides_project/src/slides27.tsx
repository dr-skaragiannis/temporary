import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  authDef,
  authLayerIntro,
  authPoints,
  authorizationPoints,
  badPython,
  cachingCode,
  cachingPoints,
  ch27Intro,
  ch27IntroPoints,
  ch27Stamp,
  clickjackingDef,
  commandCode,
  commandIntro,
  commandPoints,
  contents27,
  corsPoints,
  cspCode,
  cspIntro,
  cspPoints,
  csrfPoints,
  deserializationIntro,
  deserializationPoints,
  djangoAutoEscape,
  djangoPerResponse,
  djangoSecuritySettings,
  expressBestPractices,
  expressIntro,
  expressRisks,
  expressServerCode,
  expressSessionCode,
  expressSessionNotes,
  frontendIntro,
  frontendPoints,
  goodPython,
  importanceExample,
  importanceIntro,
  importancePoints,
  injectionIntro,
  jwtPoints,
  nosqlIntro,
  nosqlPoints,
  principles27,
  questions27,
  sessionSecurityPoints,
  sqlCode,
  sqlIntro,
  sqlPoints,
  TOTAL27,
  webAppIntro,
  webAppSubTopics,
  xssDef,
  xssImpacts,
} from "./data/ch27";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   Shared code-block component — terminal-style panel
================================================================== */
function CodeBlock({ title, lang, code }: { title: string; lang: string; code: string }) {
  return (
    <div className="border border-sage/15 bg-ink" style={{ borderRadius: 2 }}>
      <div className="flex items-center justify-between border-b border-sage/15 bg-panel/60 px-4 py-2">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-amber/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-phos/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-sage/40" />
          <span className="ml-2 font-mono text-[10.5px] tracked text-sage/70">{title}</span>
        </div>
        <span className="font-mono text-[9px] tracked text-muted">{lang}</span>
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-[11px] leading-[1.6] text-sage/90">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function BulletList({ items }: { items: ReactNode[] }) {
  return (
    <ul className="space-y-1.5">
      {items.map((it, n) => (
        <li key={n} className="flex gap-2.5 text-[13px] font-light leading-[1.5] text-sage/85">
          <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.phos }} />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  );
}

/* ==================================================================
   01 · TITLE — vector "layered shield" backdrop
================================================================== */
function LayeredShieldBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="lsFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="lsGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* code brackets inside a shield, layered */}
      <g transform="translate(920 340)" filter="url(#lsGlow)">
        {[70, 46, 22].map((r, n) => (
          <path key={n} d={`M -${r * 1.3} -${r * 1.5} L -${r * 1.3} ${r * 0.6} L 0 ${r * 1.7} L ${r * 1.3} ${r * 0.6} L ${r * 1.3} -${r * 1.5} Z`} fill="none" stroke={n === 2 ? "#3DF07A" : "#C7D2C9"} strokeOpacity={n === 2 ? 0.9 : 0.28} strokeWidth="1.6" />
        ))}
        <text x="-16" y="8" fill="#3DF07A" fontFamily="IBM Plex Mono, monospace" fontSize="22">{"</>"}</text>
      </g>
      <rect width="1200" height="700" fill="url(#lsFade)" />
    </svg>
  );
}

export function TitleSlide27({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <LayeredShieldBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 27 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.27&nbsp;//&nbsp;SECURE&nbsp;CODING</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL27}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 27</span>
              <span className="mt-1 block text-[clamp(1.7rem,5vw,4.3rem)] text-phos glow">Secure Coding</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch27Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(4)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to core principles</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Core principles", "Ten"], ["Web app risk areas", "Five"], ["Code snippets", "Twelve+"], ["Doc revision", ch27Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide27() {
  return (
    <Slide tag="SEC // CH.27 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch27Intro} dense>
      <div>
        {ch27IntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · IMPORTANCE
================================================================== */
export function ImportanceSlide27() {
  return (
    <Slide tag="SEC // CH.27 // IMPORTANCE" num="03" title={<>Importance of <span className="text-phos">secure coding</span></>} lede={importanceIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-6">
          {importancePoints.map((p, n) => (
            <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-6">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Example</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{importanceExample}</p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · INSECURE VS SECURE CODE
================================================================== */
export function CodeCompareSlide27() {
  return (
    <Slide tag="SEC // CH.27 // EXAMPLE" num="04" title={<>Insecure <span className="text-phos">vs</span> secure code</>} lede="eval() executes whatever it's given — validating and constraining input removes the danger entirely." dense>
      <div className="grid gap-4 lg:grid-cols-2">
        <CodeBlock title="bad_input.py" lang="Python" code={badPython} />
        <CodeBlock title="good_input.py" lang="Python" code={goodPython} />
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · CORE PRINCIPLES I (1–5)
================================================================== */
export function PrinciplesASlide27() {
  return (
    <Slide tag="SEC // CH.27 // PRINCIPLES I" num="05" title={<>Core principles of <span className="text-phos">secure coding</span></>} lede="These principles should act as a pre-merge checklist for every code change." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {principles27.slice(0, 5).map((p, n) => (
          <motion.div key={p.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">{p.n}</span>
            <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <div className="mt-2.5"><BulletList items={p.points} /></div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · CORE PRINCIPLES II (6–10)
================================================================== */
export function PrinciplesBSlide27() {
  return (
    <Slide tag="SEC // CH.27 // PRINCIPLES II" num="06" title={<>More core <span className="text-phos">principles</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {principles27.slice(5, 10).map((p, n) => (
          <motion.div key={p.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked text-amber">{p.n}</span>
            <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <div className="mt-2.5"><BulletList items={p.points} /></div>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · WEB APP SECURITY — INTRO
================================================================== */
export function WebAppIntroSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS" num="07" title={<>Secure coding for <span className="text-phos">web applications</span></>} lede={webAppIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {webAppSubTopics.map((t, n) => (
          <motion.div key={t} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.sage }}>
            <span className="font-mono text-[9.5px] tracked text-sage">0{n + 1}</span>
            <p className="mt-2.5 text-[12.5px] font-light leading-[1.45] text-sage/85">{t}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · XSS & CLICKJACKING — DEFINITIONS & IMPACT
================================================================== */
export function XssIntroSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // XSS" num="08" title={<>Cross-Site Scripting &amp; <span className="text-phos">Clickjacking</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel className="p-5">
          <div className="font-mono text-[9.5px] tracked text-phos">XSS</div>
          <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{xssDef}</p>
        </Panel>
        <Panel className="p-5">
          <div className="font-mono text-[9.5px] tracked text-amber">Clickjacking</div>
          <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">{clickjackingDef}</p>
        </Panel>
      </div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {xssImpacts.map((p, n) => (
          <motion.div key={p} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.06 } } }} className="border-l-2 border-amber bg-panel/50 p-4">
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <p className="mt-2 text-[12.5px] font-light leading-[1.5] text-sage/85">{p}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · XSS — DJANGO PREVENTION
================================================================== */
export function XssDjangoSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // XSS" num="09" title={<>Prevention in <span className="text-phos">Django</span></>} lede="Auto-escaping (default protection), security settings, and per-response headers." dense>
      <div className="grid gap-4 lg:grid-cols-2">
        <CodeBlock title="template.html" lang="Django" code={djangoAutoEscape} />
        <CodeBlock title="settings.py" lang="Django" code={djangoSecuritySettings} />
      </div>
      <div className="mt-4">
        <CodeBlock title="views.py — per-response headers" lang="Python" code={djangoPerResponse} />
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · FRONTEND SECURITY & CSP
================================================================== */
export function FrontendCspSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // FRONTEND" num="10" title={<>Frontend security &amp; <span className="text-phos">Content Security Policy</span></>} lede={frontendIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <BulletList items={frontendPoints} />
          <div className="mt-6">
            <div className="font-mono text-[9.5px] tracked text-amber">CSP</div>
            <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{cspIntro}</p>
            <div className="mt-3"><BulletList items={cspPoints} /></div>
          </div>
        </div>
        <div className="lg:col-span-7">
          <CodeBlock title="Content-Security-Policy" lang="HTTP header" code={cspCode} />
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · SQL INJECTION
================================================================== */
export function SqlInjectionSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // INJECTION" num="11" title={<>Injection attacks &amp; <span className="text-phos">SQL injection prevention</span></>} lede={injectionIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-6">
          <p className="mb-3 text-[13px] font-light leading-[1.55] text-sage/85">{sqlIntro}</p>
          <BulletList items={sqlPoints} />
        </div>
        <div className="lg:col-span-6">
          <CodeBlock title="query.py" lang="Python" code={sqlCode} />
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · NOSQL & COMMAND INJECTION
================================================================== */
export function NosqlCommandSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // INJECTION" num="12" title={<>NoSQL &amp; <span className="text-phos">command injection</span></>} dense>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">NoSQL Injection</div>
          <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{nosqlIntro}</p>
          <div className="mt-3"><BulletList items={nosqlPoints} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">Command Injection</div>
          <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{commandIntro}</p>
          <div className="mt-3"><BulletList items={commandPoints} /></div>
        </div>
      </div>
      <div className="mt-5">
        <CodeBlock title="convert.py" lang="Python" code={commandCode} />
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · DESERIALIZATION RISKS
================================================================== */
export function DeserializationSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // INJECTION" num="13" title={<>Deserialization <span className="text-phos">risks</span></>} lede={deserializationIntro} dense>
      <div>
        {deserializationPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   14 · AUTH & SESSIONS
================================================================== */
export function AuthSessionSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // AUTH" num="14" title={<>Authentication, authorization <span className="text-phos">&amp; sessions</span></>} lede={authLayerIntro} dense>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">Authentication</div>
          <p className="mt-2 text-[13px] font-light leading-[1.55] text-sage/85">{authDef}</p>
          <div className="mt-3"><BulletList items={authPoints} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">Session Security</div>
          <div className="mt-3"><BulletList items={sessionSecurityPoints} /></div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   15 · JWT & AUTHORIZATION
================================================================== */
export function JwtAuthzSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS // AUTH" num="15" title={<>JWT best practices &amp; <span className="text-phos">authorization</span></>} dense>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">JWT Best Practices</div>
          <div className="mt-3"><BulletList items={jwtPoints} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">Authorization</div>
          <div className="mt-3"><BulletList items={authorizationPoints} /></div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · CSRF, CORS AND CACHING
================================================================== */
export function CsrfCorsCachingSlide27() {
  return (
    <Slide tag="SEC // CH.27 // WEB APPS" num="16" title={<>CSRF, CORS <span className="text-phos">and caching</span></>} dense>
      <div className="grid gap-6 lg:grid-cols-3">
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">CSRF</div>
          <div className="mt-3"><BulletList items={csrfPoints} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">CORS</div>
          <div className="mt-3"><BulletList items={corsPoints} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-sage">Caching (sensitive data)</div>
          <div className="mt-3"><CodeBlock title="headers" lang="HTTP" code={cachingCode} /></div>
          <div className="mt-3"><BulletList items={cachingPoints} /></div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   17 · EXPRESS HARDENING — OVERVIEW
================================================================== */
export function ExpressOverviewSlide27() {
  return (
    <Slide tag="SEC // CH.27 // HARDENING" num="17" title={<>Hardening a <span className="text-phos">Node/Express API</span></>} lede={expressIntro} dense>
      <div className="grid gap-6 lg:grid-cols-3">
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">Key risks</div>
          <div className="mt-3"><BulletList items={expressRisks} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">Best practices</div>
          <div className="mt-3"><BulletList items={expressBestPractices} /></div>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-sage">For session-based auth</div>
          <div className="mt-3"><BulletList items={expressSessionNotes} /></div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   18 · EXPRESS HARDENING — server.js
================================================================== */
export function ExpressCodeASlide27() {
  return (
    <Slide tag="SEC // CH.27 // HARDENING" num="18" title={<>Full example — <span className="text-phos">server.js</span></>} lede="A single production-grade Express entry point: headers, CORS, rate limiting, validation and centralized error handling." dense>
      <CodeBlock title="server.js" lang="Node / Express" code={expressServerCode} />
    </Slide>
  );
}

/* ==================================================================
   19 · EXPRESS HARDENING — sessions + Redis + CSRF
================================================================== */
export function ExpressCodeBSlide27() {
  return (
    <Slide tag="SEC // CH.27 // HARDENING" num="19" title={<>Session-based auth — <span className="text-phos">Redis &amp; CSRF</span></>} lede="If you use sessions + cookies (stateful auth), back them with a durable store and require CSRF tokens." dense>
      <CodeBlock title="session.js" lang="Node / Express" code={expressSessionCode} />
    </Slide>
  );
}

/* ==================================================================
   20 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide27({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.27 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Trust nothing,
          <br />
          <span className="text-phos glow">validate everything.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the goal of secure coding, why eval() is
          dangerous, the least-privilege principle, and how parameterized
          queries stop SQL injection. Select an answer to reveal it
          instantly — the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(20)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   21–25 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide27({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions27[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.27 // CHECK // Q0${n + 1}`} num={String(21 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Secure Coding"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   26 · SCORE
================================================================== */
export function ScoreSlide27({ answers }: { answers: (number | null)[] }) {
  const score = questions27.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions27.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — every input is validated, every query parameterized." : pct >= 60 ? "Solid. Re-read the injection and principles sections." : "Revisit the core principles and injection sections, then retake.";
  return (
    <Slide tag="SEC // CH.27 // CHECK // RESULT" num="26" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions27.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions27.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions27.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   27 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide27() {
  const items = [
    ["01", "Security is a default, not an add-on", "Secure coding builds resilience into every layer from the start, rather than patching it in afterward."],
    ["02", "Never trust input, never execute it blindly", "eval(), raw SQL, shell interpolation and unsafe deserialization all share the same root cause — treating input as code."],
    ["03", "Ten principles form the checklist", "Secure defaults, least privilege, validated input, safe APIs, no hard-coded secrets, dependency hygiene, automated checks, defense-in-depth, safe failure and secure logging."],
    ["04", "Web apps need frontend, backend and infra coverage", "XSS/clickjacking defenses, injection prevention, strong auth/session handling and CSRF/CORS/caching rules each guard a different attack surface."],
    ["05", "Parameterization beats sanitization tricks", "Treating input as data — via parameterized queries, argument-based subprocess calls and schema validation — closes injection paths structurally."],
    ["06", "Hardening is composable", "Helmet, rate limiting, input sanitization, CORS allowlists and a durable session store combine into one production-grade Express API."],
  ];
  return (
    <Slide tag="SEC // CH.27 // CLOSE" num="27" title={<>Chapter 27 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 27 · Secure Coding</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents27.length} sections · {TOTAL27} slides</span>
      </div>
    </Slide>
  );
}
