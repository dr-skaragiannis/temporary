import { motion } from "framer-motion";
import { Row, Slide, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  compareRows29,
  contents29,
  dastAdvantages,
  dastIntro,
  dastIntroPoints,
  dastStamp,
  dastStepsIntro,
  dastSteps,
  dastTools,
  TOTAL29,
  vaImportance,
  vaIntro,
  vaIntroPoints,
} from "./data/ch29";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   Shared two-column compare table
================================================================== */
function TwoColTable({
  headL,
  headR,
  rows,
}: {
  headL: string;
  headR: string;
  rows: { l: string; r: string }[];
}) {
  return (
    <div className="border border-sage/15" style={{ borderRadius: 2 }}>
      <div className="grid grid-cols-2 border-b border-sage/20 bg-panel/70">
        <div className="border-r border-sage/15 px-4 py-2.5 font-mono text-[10px] tracked text-phos">{headL}</div>
        <div className="px-4 py-2.5 font-mono text-[10px] tracked text-amber">{headR}</div>
      </div>
      {rows.map((r, n) => (
        <motion.div key={r.l} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.06 } } }} className="grid grid-cols-2 border-b border-sage/10 last:border-b-0 odd:bg-panel/25">
          <div className="border-r border-sage/10 px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.l}</div>
          <div className="px-4 py-3 text-[12.5px] font-light leading-[1.5] text-sage/85">{r.r}</div>
        </motion.div>
      ))}
    </div>
  );
}

/* ==================================================================
   01 · TITLE — vector "live scan radar" backdrop
================================================================== */
function LiveScanBackdrop() {
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="dvFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="dvGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* radar rings scanning a live app node */}
      <g transform="translate(910 340)" filter="url(#dvGlow)">
        {[30, 60, 90].map((r, n) => (
          <circle key={n} cx="0" cy="0" r={r} fill="none" stroke="#3DF07A" strokeOpacity={0.55 - n * 0.15} strokeWidth="1.6" />
        ))}
        <circle cx="0" cy="0" r="7" fill="#3DF07A" />
        <line x1="0" y1="0" x2="82" y2="-38" stroke="#3DF07A" strokeWidth="1.6" strokeOpacity="0.7" />
        <circle cx="82" cy="-38" r="5" fill="#FFB020" />
      </g>
      <rect width="1200" height="700" fill="url(#dvFade)" />
    </svg>
  );
}

export function TitleSlide29({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <LiveScanBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Cyber Defense &amp; Protection · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 29 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.29&nbsp;//&nbsp;DAST&nbsp;&amp;&nbsp;VA</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL29}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">Module · Cyber Defense &amp; Protection</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 29</span>
              <span className="mt-1 block text-[clamp(1.7rem,5vw,4.2rem)] text-phos glow">DAST &amp; Vulnerability</span>
              <span className="mt-1 block text-[clamp(1.7rem,5vw,4.2rem)] text-phos glow">Assessment</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {dastIntro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(7)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to vulnerability assessment</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["DAST steps", "Four"], ["DAST tools surveyed", "Six"], ["VA importance factors", "Five"], ["DAST doc revision", dastStamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · DAST — WHAT & WHY
================================================================== */
export function DastIntroSlide29() {
  return (
    <Slide tag="SEC // CH.29 // DAST // DEFINITION" num="02" title={<>What is <span className="text-phos">DAST</span></>} lede={dastIntro} dense>
      <div>
        {dastIntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · DAST STEPS I (1–2)
================================================================== */
export function DastStepsASlide29() {
  return (
    <Slide tag="SEC // CH.29 // DAST // PROCESS I" num="03" title={<>Steps of <span className="text-phos">Dynamic Application Security Testing</span></>} lede={dastStepsIntro} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {dastSteps.slice(0, 2).map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked text-phos">{s.n}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{s.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {s.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.phos }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · DAST STEPS II (3–4)
================================================================== */
export function DastStepsBSlide29() {
  return (
    <Slide tag="SEC // CH.29 // DAST // PROCESS II" num="04" title={<>More DAST <span className="text-phos">working steps</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {dastSteps.slice(2, 4).map((s, n) => (
          <motion.div key={s.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked text-amber">{s.n}</span>
              <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{s.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {s.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · COMMON DAST TOOLS
================================================================== */
export function DastToolsSlide29() {
  return (
    <Slide tag="SEC // CH.29 // DAST // TOOLS" num="05" title={<>Common <span className="text-phos">DAST tools</span></>} dense>
      <div>
        {dastTools.map((t, n) => (
          <Row key={t.name} i={String(n + 1).padStart(2, "0")} label={t.name} desc={t.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · ADVANTAGES OF DAST
================================================================== */
export function DastAdvantagesSlide29() {
  return (
    <Slide tag="SEC // CH.29 // DAST // TRADE-OFFS" num="06" title={<>Advantages of <span className="text-phos">DAST</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {dastAdvantages.map((a, n) => (
          <motion.div key={a.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{a.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{a.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · DAST vs SAST
================================================================== */
export function DastVsSastSlide29() {
  return (
    <Slide tag="SEC // CH.29 // COMPARISON" num="07" title={<>DAST <span className="text-phos">vs</span> SAST</>} dense>
      <TwoColTable headL="DAST (DYNAMIC)" headR="SAST (STATIC)" rows={compareRows29.map((r) => ({ l: r.dast, r: r.sast }))} />
    </Slide>
  );
}

/* ==================================================================
   08 · VULNERABILITY ASSESSMENT — WHAT & WHY
================================================================== */
export function VaIntroSlide29() {
  return (
    <Slide tag="SEC // CH.29 // VULN. ASSESSMENT" num="08" title={<>What is <span className="text-phos">Vulnerability Assessment</span></>} lede={vaIntro} dense>
      <div>
        {vaIntroPoints.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.06} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · IMPORTANCE OF VULNERABILITY ASSESSMENT
================================================================== */
export function VaImportanceSlide29() {
  return (
    <Slide tag="SEC // CH.29 // VULN. ASSESSMENT" num="09" title={<>Importance of <span className="text-phos">Vulnerability Assessment</span></>} dense>
      <div>
        {vaImportance.map((v, n) => (
          <Row key={v.name} i={String(n + 1).padStart(2, "0")} label={v.name} desc={v.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide29() {
  const items = [
    ["01", "DAST attacks from the outside", "It's black-box testing — no source code needed — that simulates real attacks against a live, running application."],
    ["02", "Four steps mirror a real attack", "Crawl to map the surface, attack with crafted payloads, analyze the responses, then report with severity and remediation guidance."],
    ["03", "DAST and SAST are complementary", "DAST finds runtime issues later in the SDLC with fewer false positives; SAST finds coding flaws earlier by reading the source."],
    ["04", "Tool choice spans open-source to enterprise", "OWASP ZAP and Burp Suite anchor hands-on testing; Acunetix, Invicti, Veracode and Checkmarx serve automated, enterprise-scale scanning."],
    ["05", "Vulnerability assessment is systematic risk-finding", "It's a structured process to identify and evaluate weaknesses that could compromise confidentiality, integrity or availability."],
    ["06", "Assessment pays for itself", "Preventing breaches, meeting compliance, managing risk and strengthening posture all reduce the far higher cost of an unaddressed vulnerability."],
  ];
  return (
    <Slide tag="SEC // CH.29 // CLOSE" num="10" title={<>Chapter 29 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 29 · DAST &amp; Vulnerability Assessment</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents29.length} sections · {TOTAL29} slides</span>
      </div>
    </Slide>
  );
}
