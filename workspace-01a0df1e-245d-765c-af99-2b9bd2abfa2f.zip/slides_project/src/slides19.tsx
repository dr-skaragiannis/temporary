import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  benefits,
  ch19Bullets,
  ch19Intro,
  ch19Stamp,
  commonFrameworks,
  contents19,
  frameworkComponents,
  frameworkTypes,
  functions,
  functionsNote,
  needItems,
  process,
  processNote,
  questions19,
  TOTAL19,
  type FrameworkType,
} from "./data/ch19";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "blueprint scaffold" backdrop
================================================================== */
function ScaffoldBackdrop() {
  const nodes = [
    [780, 220], [960, 180], [1120, 260],
    [820, 380], [1010, 400], [1160, 470],
  ];
  const edges = [[0, 1], [1, 2], [0, 3], [1, 4], [2, 5], [3, 4], [4, 5]];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="sfFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="sfGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      <g strokeWidth="1.4" stroke="#3DF07A" strokeOpacity="0.4">
        {edges.map(([a, b], n) => (
          <line key={n} x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]} />
        ))}
      </g>
      <g filter="url(#sfGlow)">
        {nodes.map(([x, y], n) => (
          <circle key={n} cx={x} cy={y} r={n === 1 ? 9 : 6} fill={n === 1 ? "#FFB020" : "#3DF07A"} />
        ))}
      </g>
      <g transform="translate(700 520)" fontFamily="IBM Plex Mono, monospace" fontSize="11">
        <rect width="300" height="78" fill="#0B0F0D" stroke="#C7D2C9" strokeOpacity="0.3" />
        <text x="12" y="26" fill="#C7D2C9" fillOpacity="0.55">$ framework --core</text>
        <text x="12" y="48" fill="#3DF07A" fillOpacity="0.85">IDENTIFY · PROTECT · DETECT</text>
        <text x="12" y="66" fill="#3DF07A" fillOpacity="0.85">RESPOND · RECOVER</text>
      </g>
      <rect width="1200" height="700" fill="url(#sfFade)" />
    </svg>
  );
}

export function TitleSlide19({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <ScaffoldBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Structural briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 19 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.19&nbsp;//&nbsp;FRAMEWORK</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL19}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 19</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Cybersecurity</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Framework</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch19Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(4)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to the five functions</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Core components", "Three"], ["Core functions", "Five"], ["Framework types", "Five"], ["Doc revision", ch19Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide19() {
  return (
    <Slide tag="SEC // CH.19 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch19Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch19Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">In one line</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              A cybersecurity framework is a ready-made structure for security
              decisions — so organizations manage risk consistently instead of
              reinventing controls system by system.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Structured", "Reusable", "Scalable", "Consistent"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · PROCESS OF CYBERSECURITY FRAMEWORKS
================================================================== */
export function ProcessSlide19() {
  return (
    <Slide tag="SEC // CH.19 // PROCESS" num="03" title={<>Process of <span className="text-phos">cybersecurity frameworks</span></>} lede={processNote} dense>
      <div>
        {process.map((p, n) => (
          <Row key={p.i} i={p.i} label={p.name} desc={p.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · COMPONENTS OF THE FRAMEWORK
================================================================== */
export function ComponentsSlide19() {
  return (
    <Slide tag="SEC // CH.19 // COMPONENTS" num="04" title={<>Components of a <span className="text-phos">cybersecurity framework</span></>} lede="Every cybersecurity framework consists of three essential components." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {frameworkComponents.map((c, n) => (
          <motion.div key={c.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[c.tone] }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[c.tone] }}>{c.i}</span>
              <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{c.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {c.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[c.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · FIVE CORE FUNCTIONS
================================================================== */
export function FunctionsSlide19() {
  return (
    <Slide tag="SEC // CH.19 // FUNCTIONS" num="05" title={<>Five core <span className="text-phos">functions</span></>} lede={functionsNote} dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[26px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {functions.map((f, n) => (
            <motion.div key={f.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="relative">
              <div className="relative z-10 flex h-[52px] items-center">
                <span className="flex h-11 w-11 items-center justify-center border bg-ink font-mono text-[14px]" style={{ borderColor: n === 4 ? TONE.amber : TONE.phos, color: n === 4 ? TONE.amber : TONE.phos, borderRadius: 2 }}>{f.i}</span>
              </div>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{f.name}</h3>
              <ul className="mt-2.5">
                {f.points.map((p) => (
                  <li key={p} className="flex gap-2 py-1 text-[12px] font-light leading-[1.5] text-muted">
                    <span className="mt-[6px] h-1 w-1 shrink-0 bg-phos/70" />{p}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
      <motion.div variants={rise} className="mt-8 border-l-2 border-phos bg-phos/[0.06] p-4">
        <p className="text-[13px] font-light leading-[1.55] text-sage/85">
          Identify → Protect → Detect → Respond → Recover — then back to
          Identify. The five functions are a loop, not a checklist.
        </p>
      </motion.div>
    </Slide>
  );
}

/* ==================================================================
   06 · NEED FOR A CYBERSECURITY FRAMEWORK
================================================================== */
export function NeedSlide19() {
  return (
    <Slide tag="SEC // CH.19 // WHY IT'S NEEDED" num="06" title={<>Need for a <span className="text-phos">cybersecurity framework</span></>} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {needItems.map((n, idx) => (
          <motion.div key={n.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: idx * 0.08 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{idx + 1}</span>
            <h3 className="mt-2 font-display text-[1.05rem] uppercase leading-tight tracking-tight text-sage">{n.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{n.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · COMMON CYBERSECURITY FRAMEWORKS
================================================================== */
export function CommonFrameworksSlide19() {
  return (
    <Slide tag="SEC // CH.19 // KNOWN NAMES" num="07" title={<>Common <span className="text-phos">cybersecurity frameworks</span></>} dense>
      <div>
        {commonFrameworks.map((f, n) => (
          <Row key={f.name} i={String(n + 1).padStart(2, "0")} label={f.name} desc={f.desc} delay={n * 0.04} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · TYPES OVERVIEW
================================================================== */
export function TypesIndexSlide19() {
  return (
    <Slide tag="SEC // CH.19 // TYPES" num="08" title={<>Five <span className="text-phos">types</span> of framework</>} lede="Frameworks specialise by purpose — managing risk, proving compliance, hardening controls, aligning governance, or running incident response." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {frameworkTypes.map((t, n) => (
            <motion.div key={t.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.07 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 items-center justify-center border bg-ink px-3 font-mono text-[11px]" style={{ borderColor: TONE[t.tone], color: TONE[t.tone], borderRadius: 2 }}>{t.i}</span>
              </div>
              <h3 className="mt-3 font-display text-[0.92rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {t.examples.map((e) => <Tag key={e.name} tone="muted">{e.name.split(" ")[0]}</Tag>)}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared type-pair / solo detail
================================================================== */
function TypeDetailCard({ t, n }: { t: FrameworkType; n: number }) {
  return (
    <motion.div variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[t.tone] }}>
      <div className="p-5">
        <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[t.tone] }}>{t.i} · Framework type</span>
        <h3 className="mt-2 font-display text-[1.3rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
        <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{t.lead}</p>
      </div>
      <div className="mt-auto grid gap-px border-t border-sage/15 bg-sage/15 sm:grid-cols-2">
        {t.examples.map((e) => (
          <div key={e.name} className="bg-ink p-4">
            <div className="font-mono text-[9px] tracked text-amber">Example</div>
            <div className="mt-1 text-[12.5px] font-medium leading-tight text-sage">{e.name}</div>
            <p className="mt-1.5 text-[11.5px] font-light leading-[1.45] text-muted">{e.desc}</p>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export function TypesDetailA19() {
  return (
    <Slide tag="SEC // CH.19 // RISK & COMPLIANCE" num="09" title={<>Risk Management &amp; <span className="text-phos">Compliance</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {[frameworkTypes[0], frameworkTypes[1]].map((t, n) => <TypeDetailCard key={t.name} t={t} n={n} />)}
      </div>
    </Slide>
  );
}

export function TypesDetailB19() {
  return (
    <Slide tag="SEC // CH.19 // CONTROL & GOVERNANCE" num="10" title={<>Control &amp; <span className="text-phos">Governance</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {[frameworkTypes[2], frameworkTypes[3]].map((t, n) => <TypeDetailCard key={t.name} t={t} n={n} />)}
      </div>
    </Slide>
  );
}

export function TypesDetailC19() {
  return (
    <Slide tag="SEC // CH.19 // INCIDENT RESPONSE" num="11" title={<>Incident Response <span className="text-phos">Frameworks</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        <TypeDetailCard t={frameworkTypes[4]} n={0} />
        <motion.div variants={rise}>
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Why it closes the loop</div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">
              Risk management finds exposure, controls reduce it, governance
              keeps it aligned with the business — incident response is what
              runs when something still gets through. Preparation, detection,
              containment, recovery and lessons learned feed straight back
              into the framework's own Identify step.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · BENEFITS
================================================================== */
export function BenefitsSlide19() {
  return (
    <Slide tag="SEC // CH.19 // BENEFITS" num="12" title={<>Benefits of <span className="text-phos">cybersecurity frameworks</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-5">
        {benefits.map((b, n) => (
          <motion.div key={b} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.05 } } }} className="bg-ink p-4">
            <span className="font-mono text-[10px] text-phos/70">0{n + 1}</span>
            <p className="mt-2 text-[12.5px] font-light leading-[1.5] text-sage/90">{b}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide19({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.19 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Build the
          <br />
          <span className="text-phos glow">scaffold.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the five core functions, the three components,
          profiles vs tiers, and why the process is a continuous lifecycle.
          Select an answer to reveal it instantly — the rationale appears
          underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(13)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   14–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide19({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions19[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.19 // CHECK // Q0${n + 1}`} num={String(14 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Frameworks"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide19({ answers }: { answers: (number | null)[] }) {
  const score = questions19.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions19.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — the scaffold is sound." : pct >= 60 ? "Solid. Re-read the five functions and the three components." : "Revisit the components, functions and framework types, then retake.";
  return (
    <Slide tag="SEC // CH.19 // CHECK // RESULT" num="19" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions19.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions19.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions19.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide19() {
  const items = [
    ["01", "Frameworks are reusable scaffolding", "They replace 'design from scratch' with a structured, repeatable approach to security."],
    ["02", "The process never really stops", "Current state → required guidelines → changes → evaluation → risk — then around again."],
    ["03", "Three components, three jobs", "Core defines what to do, tiers measure how well it's done, profiles adapt it to the business."],
    ["04", "Five functions, one loop", "Identify, Protect, Detect, Respond, Recover — a continuous lifecycle, not a one-time checklist."],
    ["05", "Five types, five specialities", "Risk, compliance, control, governance and incident response frameworks each solve a different problem."],
    ["06", "Structure pays for itself", "Global standards, better collaboration, lower implementation cost and stronger resilience — that's the return."],
  ];
  return (
    <Slide tag="SEC // CH.19 // CLOSE" num="20" title={<>Chapter 19 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 19 · Cybersecurity Framework</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents19.length} sections · {TOTAL19} slides</span>
      </div>
    </Slide>
  );
}
