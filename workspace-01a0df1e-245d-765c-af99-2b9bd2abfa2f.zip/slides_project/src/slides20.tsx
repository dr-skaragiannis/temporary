import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  ch20Bullets,
  ch20Intro,
  ch20Stamp,
  challenges20,
  contents20,
  practices,
  questions20,
  sectors,
  threats,
  threatsNote,
  TOTAL20,
  type Sector,
} from "./data/ch20";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — vector "city grid / power lattice" backdrop
================================================================== */
function LatticeBackdrop() {
  const towers = [720, 800, 880, 970, 1060, 1140];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="ltFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="ltGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      {/* skyline of critical-infrastructure blocks */}
      <g>
        {towers.map((x, n) => {
          const h = [180, 260, 140, 300, 200, 240][n];
          return <rect key={x} x={x} y={560 - h} width="34" height={h} fill="none" stroke="#3DF07A" strokeOpacity="0.35" strokeWidth="1.4" />;
        })}
        <line x1="700" y1="560" x2="1180" y2="560" stroke="#C7D2C9" strokeOpacity="0.25" />
      </g>
      {/* power lattice / transmission lines */}
      <g stroke="#FFB020" strokeOpacity="0.5" strokeWidth="1.4">
        <path d="M700 320 L820 260 L940 320 L1060 240 L1180 300" fill="none" />
        <path d="M700 360 L820 300 L940 360 L1060 280 L1180 340" fill="none" strokeDasharray="4 6" />
      </g>
      <g filter="url(#ltGlow)">
        {[[820, 260], [1060, 240], [940, 360]].map(([x, y], n) => (
          <circle key={n} cx={x} cy={y} r="5" fill="#FFB020" />
        ))}
      </g>
      <rect width="1200" height="700" fill="url(#ltFade)" />
    </svg>
  );
}

export function TitleSlide20({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <LatticeBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">National infrastructure briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 20 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.20&nbsp;//&nbsp;CRITICAL INFRA</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL20}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.6rem,4.4vw,3.4rem)] text-sage">Chapter 20</span>
              <span className="mt-1 block text-[clamp(1.8rem,5vw,4.2rem)] text-phos glow">Cyber Security in</span>
              <span className="mt-1 block text-[clamp(1.8rem,5vw,4.2rem)] text-phos glow">Critical Infrastructure</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch20Intro}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin chapter →</button>
              <button onClick={() => go(2)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to the threat landscape</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Threat types", "Four"], ["Major challenges", "Five"], ["Best practices", "Seven"], ["Doc revision", ch20Stamp.replace("Last Updated : ", "")]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT & WHY
================================================================== */
export function IntroSlide20() {
  return (
    <Slide tag="SEC // CH.20 // DEFINITION" num="02" title={<>What it is &amp; <span className="text-phos">why it matters</span></>} lede={ch20Intro}>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {ch20Bullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">In one line</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              Power, water, transport, finance and healthcare all run on
              networked digital systems — protecting them is both a
              technical problem and a national priority.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Power grid", "Water", "Transport", "Finance", "Healthcare"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · THREAT LANDSCAPE
================================================================== */
export function ThreatLandscapeSlide20() {
  return (
    <Slide tag="SEC // CH.20 // THREATS" num="03" title={<>The threat <span className="text-phos">landscape</span></>} lede={threatsNote} dense>
      <div>
        {threats.map((t, n) => (
          <Row key={t.i} i={t.i} label={t.name} desc={t.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   04 · MAJOR CHALLENGES
================================================================== */
export function ChallengesSlide20() {
  return (
    <Slide tag="SEC // CH.20 // CHALLENGES" num="04" title={<>Major <span className="text-phos">challenges</span></>} lede="Challenges of cybersecurity for critical infrastructure." dense>
      <div>
        {challenges20.map((c, n) => (
          <Row key={c.i} i={c.i} label={c.name} desc={c.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   05 · BEST PRACTICES
================================================================== */
export function PracticesSlide20() {
  return (
    <Slide tag="SEC // CH.20 // BEST PRACTICES" num="05" title={<>Best <span className="text-phos">practices</span></>} lede="Best practices of cybersecurity in critical infrastructure." dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {practices.map((p, n) => (
          <motion.div key={p.i} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.04 } } }} className="bg-ink p-4">
            <span className="font-mono text-[10px] text-phos/70">{p.i}</span>
            <h3 className="mt-1.5 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <ul className="mt-2.5 space-y-1.5">
              {p.points.map((pt) => (
                <li key={pt} className="flex gap-2 text-[11.5px] font-light leading-[1.45] text-muted">
                  <span className="mt-[6px] h-1 w-1 shrink-0 bg-phos/70" />{pt}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   06 · EXAMPLES OVERVIEW
================================================================== */
export function SectorsIndexSlide20() {
  return (
    <Slide tag="SEC // CH.20 // SECTORS" num="06" title={<>Examples across <span className="text-phos">critical sectors</span></>} lede="Cybersecurity in critical infrastructure spans transportation, energy, finance, healthcare and water systems." dense>
      <div className="relative">
        <div className="absolute left-0 right-0 top-[18px] hidden h-px bg-sage/20 lg:block" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {sectors.map((s, n) => (
            <motion.div key={s.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: n * 0.07 } } }} className="relative">
              <div className="relative z-10 flex h-9 items-center">
                <span className="flex h-9 items-center justify-center border bg-ink px-3 font-mono text-[11px]" style={{ borderColor: TONE[s.tone], color: TONE[s.tone], borderRadius: 2 }}>{s.i}</span>
              </div>
              <h3 className="mt-3 font-display text-[0.92rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
              <p className="mt-2 text-[11.5px] font-light leading-[1.5] text-muted">{s.points[0]}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Shared sector-detail card
================================================================== */
function SectorCard({ s, n }: { s: Sector; n: number }) {
  return (
    <motion.div variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[s.tone] }}>
      <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[s.tone] }}>{s.i} · Sector</span>
      <h3 className="mt-2 font-display text-[1.15rem] uppercase leading-tight tracking-tight text-sage">{s.name}</h3>
      <ul className="mt-3 border-t border-sage/15 pt-2.5">
        {s.points.map((p) => (
          <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
            <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[s.tone] }} />{p}
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

/* ==================================================================
   07 · TRANSPORTATION & POWER GRID
================================================================== */
export function SectorsDetailA20() {
  return (
    <Slide tag="SEC // CH.20 // TRANSPORT & POWER" num="07" title={<>Transportation &amp; <span className="text-phos">power grid</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {[sectors[0], sectors[1]].map((s, n) => <SectorCard key={s.name} s={s} n={n} />)}
      </div>
    </Slide>
  );
}

/* ==================================================================
   08 · FINANCE & HEALTHCARE
================================================================== */
export function SectorsDetailB20() {
  return (
    <Slide tag="SEC // CH.20 // FINANCE & HEALTHCARE" num="08" title={<>Financial sector &amp; <span className="text-phos">healthcare</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {[sectors[2], sectors[3]].map((s, n) => <SectorCard key={s.name} s={s} n={n} />)}
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · WATER & WASTEWATER
================================================================== */
export function SectorsDetailC20() {
  return (
    <Slide tag="SEC // CH.20 // WATER & WASTEWATER" num="09" title={<>Water &amp; <span className="text-phos">wastewater security</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        <SectorCard s={sectors[4]} n={0} />
        <motion.div variants={rise}>
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">Why water systems matter</div>
            <p className="mt-3 text-[13px] font-light leading-[1.6] text-sage/85">
              Water and wastewater plants increasingly run on Industrial
              Control Systems (ICS) connected to corporate and even public
              networks. Segregating operational networks, verifying firmware
              integrity and running regular drills keep a digital breach from
              becoming a public-health incident.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide20({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.20 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Keep the
          <br />
          <span className="text-phos glow">lights on.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items covering the objective of critical-infrastructure
          security, insider threats, legacy systems, interconnectedness and
          defense-in-depth. Select an answer to reveal it instantly — the
          rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(10)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   11–15 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide20({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions20[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.20 // CHECK // Q0${n + 1}`} num={String(11 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Critical Infrastructure"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   16 · SCORE
================================================================== */
export function ScoreSlide20({ answers }: { answers: (number | null)[] }) {
  const score = questions20.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions20.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — the grid stays up." : pct >= 60 ? "Solid. Re-read the threat landscape and the five major challenges." : "Revisit the threats, challenges and defense-in-depth sections, then retake.";
  return (
    <Slide tag="SEC // CH.20 // CHECK // RESULT" num="16" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions20.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions20.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions20.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   17 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide20() {
  const items = [
    ["01", "Critical infrastructure is a target, not a bystander", "Power, water, transport, finance and healthcare are attractive targets precisely because society depends on them."],
    ["02", "Threats range from states to insiders", "Cyber warfare, cyber terrorism, organised cyber crime and insider threats all have different motives but the same attack surface."],
    ["03", "Legacy and complexity compound the risk", "Outdated systems, tight budgets, interconnection and sheer scale all make critical infrastructure harder to defend than a typical enterprise."],
    ["04", "Defense is layered, not single-point", "Risk assessment, defense-in-depth, incident response, training, monitoring and patching all have to work together."],
    ["05", "Every sector needs its own controls", "Transportation, power, finance, healthcare and water each pair general best practice with sector-specific tools."],
    ["06", "Resilience beats prevention alone", "You can't stop every attack — incident response planning and continuous monitoring are what limit the damage when one gets through."],
  ];
  return (
    <Slide tag="SEC // CH.20 // CLOSE" num="17" title={<>Chapter 20 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 20 · Cyber Security in Critical Infrastructure</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents20.length} sections · {TOTAL20} slides</span>
      </div>
    </Slide>
  );
}
