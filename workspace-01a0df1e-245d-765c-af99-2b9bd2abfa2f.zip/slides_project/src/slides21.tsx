import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  accountTypes,
  ch21Tagline,
  contents21,
  createAccountSteps,
  iamAdvantages,
  iamBenefits,
  iamBullets,
  iamFocusAreas,
  iamImplementation,
  iamIntro,
  iamLimitations,
  iamPolicies,
  iamProtocols,
  iamProtocolsIntro,
  iamProtocolsNote,
  iamRiseIntro,
  iamStamp,
  kerbApplications,
  kerbBullets,
  kerbComponents,
  kerbIntro,
  kerbLimitations,
  kerbStamp,
  kerbSteps,
  kerbStrengths,
  kerbThreats,
  kerbWorkingIntro,
  questions21,
  resetPasswordStepsA,
  resetPasswordStepsB,
  TOTAL21,
  winIntroBullets,
  winStamp,
  winTools,
} from "./data/ch21";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   00 · TITLE — vector "identity token ring" backdrop
================================================================== */
function TokenRingBackdrop() {
  const tokens = ["KERBEROS", "X.509", "MFA", "SSO"];
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <radialGradient id="trFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.2" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="trGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="4.5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />)}
        {Array.from({ length: 15 }).map((_, n) => <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />)}
      </g>
      <g transform="translate(950 330)">
        <circle r="180" fill="none" stroke="#3DF07A" strokeOpacity="0.3" strokeWidth="1.3" strokeDasharray="2 8" />
        <circle r="120" fill="none" stroke="#FFB020" strokeOpacity="0.35" strokeWidth="1.3" />
        {tokens.map((t, n) => {
          const ang = (n / tokens.length) * Math.PI * 2 - Math.PI / 2;
          const x = Math.cos(ang) * 180;
          const y = Math.sin(ang) * 180;
          return (
            <g key={t} transform={`translate(${x} ${y})`} filter="url(#trGlow)">
              <rect x="-38" y="-14" width="76" height="28" fill="#0B0F0D" stroke="#3DF07A" strokeOpacity="0.8" />
              <text x="0" y="4" textAnchor="middle" fill="#3DF07A" fontFamily="IBM Plex Mono, monospace" fontSize="10">{t}</text>
            </g>
          );
        })}
        <circle r="7" fill="#FFB020" filter="url(#trGlow)" />
      </g>
      <rect width="1200" height="700" fill="url(#trFade)" />
    </svg>
  );
}

export function TitleSlide21({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative h-full w-full overflow-x-hidden overflow-y-auto">
      <TokenRingBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Identity & access briefing · lecture use</span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">Chapter 21 of 33</span>
      </div>
      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">SEC&nbsp;//&nbsp;CH.21&nbsp;//&nbsp;AUTH APPS</span>
          </motion.div>
          <motion.span variants={rise} className="hidden font-mono text-[10px] tracked text-muted sm:block">01 / {TOTAL21}</motion.span>
        </div>
        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p variants={rise} className="font-mono text-[11px] tracked text-amber">University course · Introduction to Cybersecurity</motion.p>
            <motion.h1
              variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.7, ease: "easeOut", delay: 0.1 } } }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">Chapter 21</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Authentication</span>
              <span className="mt-1 block text-[clamp(2rem,6vw,5.2rem)] text-phos glow">Applications</span>
            </motion.h1>
            <motion.div variants={rise} className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50" />
            <motion.p variants={rise} className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]">
              {ch21Tagline}
            </motion.p>
            <motion.div variants={rise} className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => go(1)} className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Begin with IAM →</button>
              <button onClick={() => go(15)} className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos">Jump to Kerberos</button>
            </motion.div>
          </div>
          <motion.div variants={rise} className="hidden justify-end lg:col-span-4 lg:flex">
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>
        <motion.div variants={rise} className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4">
          {[["Module 1", "IAM"], ["Module 2", "Windows accounts"], ["Module 3", "Kerberos"], ["Revision", "Jun 2026"]].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] text-sage">{v}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ====================================================================
   MODULE 1 · IAM
==================================================================== */

/* 02 · IAM WHAT & WHY */
export function IamIntroSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // DEFINITION" num="02" title={<>Identity &amp; Access Management <span className="text-phos">(IAM)</span></>} lede={iamIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {iamBullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.04} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">{iamStamp}</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              IAM is the framework that decides who gets in, what they can
              touch and how that access is watched — across every system an
              organization runs.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Identity", "Authentication", "Authorization", "Monitoring"].map((t) => <Tag key={t} tone="muted">{t}</Tag>)}
            </div>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* 03 · IAM BENEFITS */
export function IamBenefitsSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // BENEFITS" num="03" title={<>Benefits of using an <span className="text-phos">IAM system</span></>} lede="IAM provides multiple organizational benefits by improving security, efficiency and compliance." dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {iamBenefits.map((b, n) => (
          <motion.div key={b.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.06 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.95rem] uppercase leading-tight tracking-tight text-sage">{b.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{b.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* 04 · IAM IMPLEMENTATION GUIDE */
export function IamImplementationSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // ROLLOUT" num="04" title={<>Implementation guide for <span className="text-phos">IAM</span></>} dense>
      <div>
        {iamImplementation.map((s, n) => (
          <Row key={s.i} i={s.i} label={s.name} desc={s.desc} delay={n * 0.06} />
        ))}
      </div>
      <motion.div variants={rise} className="mt-5 grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-4">
        {iamImplementation[2].tools?.map((t) => (
          <div key={t} className="bg-ink p-3.5 text-[12.5px] font-light leading-[1.45] text-sage/90">{t}</div>
        ))}
      </motion.div>
    </Slide>
  );
}

/* 05 · RISE IN IMPORTANCE OF IAM */
export function IamRiseSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // GROWTH" num="05" title={<>Rise in importance of <span className="text-phos">IAM</span></>} lede={iamRiseIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {iamFocusAreas.map((f, n) => (
          <motion.div key={f.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-4" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.amber }}>
            <span className="font-mono text-[9.5px] tracked text-amber">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[0.92rem] uppercase leading-tight tracking-tight text-sage">{f.name}</h3>
            <p className="mt-2.5 text-[12px] font-light leading-[1.5] text-muted">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* 06 · IAM & EXISTING CYBERSECURITY PROTOCOLS */
export function IamProtocolsSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // LAYERING" num="06" title={<>IAM &amp; existing <span className="text-phos">cybersecurity protocols</span></>} lede={iamProtocolsIntro} dense>
      <div className="grid gap-4 sm:grid-cols-2">
        {iamProtocols.map((p, n) => (
          <motion.div key={p.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.07 } } }} className="border border-sage/15 bg-panel/60 p-5" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE.phos }}>
            <span className="font-mono text-[9.5px] tracked text-phos">0{n + 1}</span>
            <h3 className="mt-2 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{p.name}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.55] text-muted">{p.desc}</p>
          </motion.div>
        ))}
      </div>
      <motion.div variants={rise} className="mt-5 border-l-2 border-phos bg-phos/[0.06] p-4">
        <p className="text-[13px] font-light leading-[1.55] text-sage/85">{iamProtocolsNote}</p>
      </motion.div>
    </Slide>
  );
}

/* 07 · IAM POLICIES */
export function IamPoliciesSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // POLICY" num="07" title={<><span className="text-phos">IAM</span> policies</>} lede="A successful IAM framework relies on well-defined policies." dense>
      <div>
        {iamPolicies.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* 08 · IAM ADVANTAGES & LIMITATIONS */
export function IamProsConsSlide21() {
  return (
    <Slide tag="SEC // CH.21 // IAM // TRADE-OFFS" num="08" title={<>IAM — <span className="text-phos">advantages &amp; limitations</span></>} dense>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">Advantages</div>
          <ul className="mt-2 border-t border-sage/15">
            {iamAdvantages.map((a, n) => (
              <motion.li key={a} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="flex gap-3 border-b border-sage/15 py-2.5 text-[13px] font-light leading-[1.5] text-sage/85">
                <span className="mt-[5px] h-1.5 w-1.5 shrink-0 bg-phos" />{a}
              </motion.li>
            ))}
          </ul>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">Limitations</div>
          <ul className="mt-2 border-t border-sage/15">
            {iamLimitations.map((l, n) => (
              <motion.li key={l} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.05 } } }} className="flex gap-3 border-b border-sage/15 py-2.5 text-[13px] font-light leading-[1.5] text-muted">
                <span className="mt-[5px] h-1.5 w-1.5 shrink-0 bg-amber" />{l}
              </motion.li>
            ))}
          </ul>
        </div>
      </div>
    </Slide>
  );
}

/* ====================================================================
   MODULE 2 · WINDOWS USER MANAGEMENT
==================================================================== */

/* 09 · WINDOWS WHAT & WHY */
export function WinIntroSlide21() {
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // DEFINITION" num="09" title={<>Windows <span className="text-phos">User Management</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {winIntroBullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.05} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">{winStamp}</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              Every Windows account carries its own role and privilege level
              — the account type you choose decides exactly what that person
              can see and change.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* 10 · TYPES OF ACCOUNTS */
export function WinAccountTypesSlide21() {
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // ACCOUNTS" num="10" title={<>Types of <span className="text-phos">accounts</span></>} lede="There are several types of accounts." dense>
      <div>
        {accountTypes.map((a, n) => (
          <Row key={a.i} i={a.i} label={a.name} desc={a.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* 11 · CREATING A NEW ACCOUNT */
export function WinCreateAccountSlide21() {
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // SETUP" num="11" title={<>Creating a new account in <span className="text-phos">Windows</span></>} lede="To create a new account, follow these steps." dense>
      <div className="grid gap-3 sm:grid-cols-2">
        {createAccountSteps.map((s, n) => (
          <motion.div key={s} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.05 } } }} className="flex gap-3 border border-sage/15 bg-panel/60 p-3.5" style={{ borderRadius: 2 }}>
            <span className="flex h-7 w-7 shrink-0 items-center justify-center border border-phos/40 font-mono text-[11px] text-phos" style={{ borderRadius: 2 }}>{n + 1}</span>
            <span className="pt-1 text-[12.5px] font-light leading-[1.5] text-sage/90">{s}</span>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* Shared reset-password step list */
function ResetSteps({ steps, offset }: { steps: string[]; offset: number }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {steps.map((s, n) => (
        <motion.div key={s} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.04 } } }} className="flex gap-3 border border-sage/15 bg-panel/60 p-3.5" style={{ borderRadius: 2 }}>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center border border-amber/40 font-mono text-[11px] text-amber" style={{ borderRadius: 2 }}>{n + 1 + offset}</span>
          <span className="pt-1 text-[12px] font-light leading-[1.48] text-sage/90">{s}</span>
        </motion.div>
      ))}
    </div>
  );
}

/* 12 · RESET PASSWORD I */
export function WinResetPasswordASlide21() {
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // RESET I" num="12" title={<>Resetting a password <span className="text-phos">— part I</span></>} lede="Steps 1–10 of the offline password-reset procedure via Advanced Startup and the registry hive." dense>
      <ResetSteps steps={resetPasswordStepsA} offset={0} />
    </Slide>
  );
}

/* 13 · RESET PASSWORD II */
export function WinResetPasswordBSlide21() {
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // RESET II" num="13" title={<>Resetting a password <span className="text-phos">— part II</span></>} lede="Steps 11–20: loading the SYSTEM hive, hijacking the sign-in screen command line, and clearing the password with net user." dense>
      <ResetSteps steps={resetPasswordStepsB} offset={10} />
    </Slide>
  );
}

/* 14 · TOOLS — CONTROL PANEL */
export function WinToolsASlide21() {
  const t = winTools[0];
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // TOOLS I" num="14" title={<>Managing accounts — <span className="text-phos">{t.name}</span></>} lede={t.desc} dense>
      <div>
        {t.points.map((p, n) => (
          <Row key={p} i={String(n + 1).padStart(2, "0")} label={p} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* 15 · TOOLS — SETTINGS APP & COMPUTER MANAGEMENT */
export function WinToolsBSlide21() {
  const [settingsApp, computerMgmt] = [winTools[1], winTools[2]];
  return (
    <Slide tag="SEC // CH.21 // WINDOWS // TOOLS II" num="15" title={<>Managing accounts — <span className="text-phos">Settings &amp; Computer Management</span></>} dense>
      <div className="grid gap-4 lg:grid-cols-2">
        {[settingsApp, computerMgmt].map((t, n) => (
          <motion.div key={t.name} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.1 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: n === 0 ? TONE.phos : TONE.amber }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: n === 0 ? TONE.phos : TONE.amber }}>{t.i} · Tool</span>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{t.name}</h3>
              <p className="mt-3 text-[12.5px] font-light leading-[1.55] text-muted">{t.desc}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {t.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[6px] h-1.5 w-1.5 shrink-0" style={{ background: n === 0 ? TONE.phos : TONE.amber }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ====================================================================
   MODULE 3 · KERBEROS
==================================================================== */

/* 16 · KERBEROS WHAT & WHY */
export function KerbIntroSlide21() {
  return (
    <Slide tag="SEC // CH.21 // KERBEROS // DEFINITION" num="16" title={<><span className="text-phos">Kerberos</span></>} lede={kerbIntro} dense>
      <div className="grid gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          {kerbBullets.map((b, n) => (
            <Row key={b} i={String(n + 1).padStart(2, "0")} label={b} delay={n * 0.05} />
          ))}
        </div>
        <motion.div variants={rise} className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-amber">{kerbStamp}</div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.6] text-sage/85">
              The trusted third party in Kerberos is called the Key
              Distribution Center (KDC) — every user and every service on the
              network is a "principal" it can vouch for.
            </p>
          </Panel>
        </motion.div>
      </div>
    </Slide>
  );
}

/* 17 · KERBEROS COMPONENTS */
export function KerbComponentsSlide21() {
  return (
    <Slide tag="SEC // CH.21 // KERBEROS // COMPONENTS" num="17" title={<>Components of <span className="text-phos">Kerberos</span></>} lede="Kerberos consists of three main components that work together to authenticate users, manage tickets and control secure access to network services." dense>
      <div className="grid gap-4 lg:grid-cols-3">
        {kerbComponents.map((c, n) => (
          <motion.div key={c.i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.08 } } }} className="flex flex-col border border-sage/15 bg-panel/60" style={{ borderRadius: 2, borderTopWidth: 2, borderTopColor: TONE[c.tone] }}>
            <div className="p-5">
              <span className="font-mono text-[9.5px] tracked" style={{ color: TONE[c.tone] }}>{c.i}</span>
              <h3 className="mt-2 font-display text-[1.1rem] uppercase leading-tight tracking-tight text-sage">{c.name}</h3>
              <p className="mt-3 text-[13px] font-light leading-[1.6] text-muted">{c.lead}</p>
            </div>
            <ul className="mt-auto border-t border-sage/15 bg-ink p-4">
              {c.points.map((p) => (
                <li key={p} className="flex gap-2.5 py-1.5 text-[12.5px] font-light leading-[1.5] text-sage/85">
                  <span className="mt-[7px] h-1.5 w-1.5 shrink-0" style={{ background: TONE[c.tone] }} />{p}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* 18 · WORKING OF KERBEROS */
export function KerbWorkingSlide21() {
  return (
    <Slide tag="SEC // CH.21 // KERBEROS // FLOW" num="18" title={<>Working of <span className="text-phos">Kerberos</span></>} lede={kerbWorkingIntro} dense>
      <div>
        {kerbSteps.map((s, n) => (
          <Row key={s.i} i={s.i} label={s.name} desc={s.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* 19 · SECURITY ANALYSIS */
export function KerbSecuritySlide21() {
  return (
    <Slide tag="SEC // CH.21 // KERBEROS // ANALYSIS" num="19" title={<>Kerberos <span className="text-phos">security analysis</span></>} lede="Kerberos is a widely used authentication protocol, but it is not completely immune to attacks." dense>
      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <div className="font-mono text-[9.5px] tracked text-amber">Security threats</div>
          <ul className="mt-2 border-t border-sage/15">
            {kerbThreats.map((t, n) => (
              <motion.li key={t} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.06 } } }} className="flex gap-3 border-b border-sage/15 py-2.5 text-[13px] font-light leading-[1.5] text-sage/85">
                <span className="mt-[5px] h-1.5 w-1.5 shrink-0 bg-amber" />{t}
              </motion.li>
            ))}
          </ul>
        </div>
        <div>
          <div className="font-mono text-[9.5px] tracked text-phos">Strengths</div>
          <ul className="mt-2 border-t border-sage/15">
            {kerbStrengths.map((t, n) => (
              <motion.li key={t} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.3, delay: n * 0.06 } } }} className="flex gap-3 border-b border-sage/15 py-2.5 text-[13px] font-light leading-[1.5] text-sage/85">
                <span className="mt-[5px] h-1.5 w-1.5 shrink-0 bg-phos" />{t}
              </motion.li>
            ))}
          </ul>
        </div>
      </div>
    </Slide>
  );
}

/* 20 · APPLICATIONS OF KERBEROS */
export function KerbApplicationsSlide21() {
  return (
    <Slide tag="SEC // CH.21 // KERBEROS // USES" num="20" title={<>Applications of <span className="text-phos">Kerberos</span></>} dense>
      <div>
        {kerbApplications.map((a, n) => (
          <Row key={a.name} i={String(n + 1).padStart(2, "0")} label={a.name} desc={a.desc} delay={n * 0.05} />
        ))}
      </div>
    </Slide>
  );
}

/* 21 · LIMITATIONS OF KERBEROS */
export function KerbLimitationsSlide21() {
  return (
    <Slide tag="SEC // CH.21 // KERBEROS // LIMITS" num="21" title={<>Limitations of <span className="text-phos">Kerberos</span></>} dense>
      <div className="grid gap-3 sm:grid-cols-2">
        {kerbLimitations.map((l, n) => (
          <motion.div key={l} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.32, delay: n * 0.05 } } }} className="flex gap-3 border border-sage/15 bg-panel/60 p-3.5" style={{ borderRadius: 2 }}>
            <span className="mt-[5px] h-1.5 w-1.5 shrink-0 bg-amber" />
            <span className="text-[12.5px] font-light leading-[1.5] text-sage/90">{l}</span>
          </motion.div>
        ))}
      </div>
    </Slide>
  );
}

/* ====================================================================
   QUIZ
==================================================================== */

/* 22 · QUIZ BRIEFING */
export function QuizIntroSlide21({ go }: { go: (n: number) => void }) {
  return (
    <motion.section variants={group} initial="hidden" animate="show" className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16">
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">Assessment instrument · 5 items</span>
        <span className="font-mono text-[9.5px] tracked text-ink">Sec // CH.21 // Check</span>
      </div>
      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}><Tag tone="amber">Knowledge check</Tag></motion.div>
        <motion.h2 variants={{ hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" }, show: { opacity: 1, clipPath: "inset(0 0% 0 0)", transition: { duration: 0.55, ease: "easeOut" } } }} className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage">
          Trust the
          <br />
          <span className="text-phos glow">ticket.</span>
        </motion.h2>
        <motion.p variants={rise} className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]">
          Five items on the Kerberos protocol — the KDC's role, who issues
          the TGT, why SSO helps, why tickets replace passwords, and a real
          operational limitation. Select an answer to reveal it instantly —
          the rationale appears underneath.
        </motion.p>
        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button onClick={() => go(22)} className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos" style={{ borderRadius: 2 }}>Start question 01 →</button>
          <span className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted" style={{ borderRadius: 2 }}>A · B · C · D — single answer</span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* 23–27 · QUESTION */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide21({ n, selected, onAnswer }: { n: number; selected: number | null; onAnswer: (c: number) => void }) {
  const q = questions21[n];
  const answered = selected !== null;
  const correct = selected === q.answer;
  return (
    <Slide tag={`SEC // CH.21 // CHECK // Q0${n + 1}`} num={String(23 + n)} title={<>Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span><span className="text-muted"> / 05</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">{q.q}</p>
          </div>
          <div className="mt-6 space-y-2">
            {[["Status", !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect"], ["Domain", "Kerberos"]].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between border-t border-sage/15 pt-2.5">
                <span className="font-mono text-[9.5px] tracked text-muted">{k}</span>
                <span className={`font-mono text-[10px] tracked ${k === "Status" ? (!answered ? "text-muted" : correct ? "text-phos" : "text-amber") : "text-sage/80"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered ? "idle" : isRight ? "right" : isPick ? "wrong" : "dim";
              return (
                <motion.button key={opt} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.06 } } }} onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${state === "right" ? "border-phos bg-deep/60" : state === "wrong" ? "border-amber bg-amber/10" : state === "dim" ? "border-sage/10 opacity-45" : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"}`} style={{ borderRadius: 2 }}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${state === "right" ? "border-phos bg-phos text-ink" : state === "wrong" ? "border-amber bg-amber text-ink" : "border-sage/35 text-sage/80"}`} style={{ borderRadius: 2 }}>{LETTERS[i]}</span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">{opt}</span>
                </motion.button>
              );
            })}
          </div>
          {answered && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: "easeOut" }} className={`mt-4 border-l-2 p-4 ${correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"}`}>
              <div className={`font-mono text-[9.5px] tracked ${correct ? "text-phos" : "text-amber"}`}>{correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}</div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">{q.why}</p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* 28 · SCORE */
export function ScoreSlide21({ answers }: { answers: (number | null)[] }) {
  const score = questions21.reduce((a, q, i) => a + (answers[i] === q.answer ? 1 : 0), 0);
  const pct = Math.round((score / questions21.length) * 100);
  const verdict = pct === 100 ? "Clean sweep — the ticket is valid." : pct >= 60 ? "Solid. Re-read the Kerberos components and the working sequence." : "Revisit the components, working steps and limitations of Kerberos, then retake.";
  return (
    <Slide tag="SEC // CH.21 // CHECK // RESULT" num="28" title={<>Your <span className="text-phos">score</span></>} dense>
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div className="border border-phos/40 bg-panel/60 p-6" style={{ borderRadius: 2 }}>
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">{score}</span>
              <span className="font-display text-[1.6rem] text-sage/50">/ {questions21.length}</span>
            </div>
            <div className="mt-5 h-2 w-full bg-sage/12" style={{ borderRadius: 2 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} className="h-full bg-phos" />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted"><span>{pct}%</span><span>{score} of {questions21.length} correct</span></div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">{verdict}</p>
          </div>
        </div>
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions21.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div key={q.q} variants={{ hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0, transition: { duration: 0.34, delay: i * 0.05 } } }} className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5">
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">Q{i + 1}</span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">{q.q}</p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer: <span className={ok ? "text-phos" : "text-amber"}>{picked === null || picked === undefined ? "— unanswered" : q.options[picked]}</span>
                      {!ok && (<>{"  ·  "}Correct: <span className="text-phos">{q.options[q.answer]}</span></>)}
                    </p>
                  </div>
                  <span className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"}`} style={{ borderRadius: 2 }}>{ok ? "Pass" : "Review"}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* 29 · TAKEAWAYS */
export function TakeawaysSlide21() {
  const items = [
    ["01", "IAM decides who, what and when", "It manages digital identities and enforces that the right users reach the right resources at the right time."],
    ["02", "IAM pays for itself operationally", "Reduced risk, self-service resets and compliance support all lower cost even as they raise security."],
    ["03", "Windows accounts carry real privilege levels", "Administrator, User, Guest and Root each grant a very different amount of control — choose deliberately."],
    ["04", "Offline password reset is a real, documented attack path", "The Shift+Restart → regedit → SETHC/CmdLine hijack sequence works precisely because physical access defeats login screens."],
    ["05", "Kerberos trades passwords for time-limited tickets", "The AS issues a TGT, the TGS issues service tickets — the password itself is never sent again."],
    ["06", "No protocol is a silver bullet", "Kerberos is strong but needs synced clocks, a resilient KDC and secure clients — the same is true of IAM and of Windows account hygiene."],
  ];
  return (
    <Slide tag="SEC // CH.21 // CLOSE" num="29" title={<>Chapter 21 — <span className="text-phos">takeaways</span></>} dense>
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.36, delay: n * 0.05 } } }} className="bg-ink p-5">
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">{h}</h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">{d}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">End of chapter 21 · Authentication Applications</span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">Contents index: {contents21.length} sections · {TOTAL21} slides</span>
      </div>
    </Slide>
  );
}
