import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import lock from "./assets/lock.jpg";
import hook from "./assets/hook.jpg";
import {
  attacks,
  ch4Bullets,
  ch4Intro,
  ch4Stamp,
  contents4,
  questions4,
  strategies,
  TOTAL4,
} from "./data/ch4";

/* ==================================================================
   01 · TITLE
================================================================== */
export function TitleSlide4({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <img
        src={lock}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-center opacity-[0.42]"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_15%_50%,rgba(11,15,13,0.97)_25%,rgba(11,15,13,0.68)_65%,rgba(11,15,13,0.92)_100%)]" />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Threat briefing · lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 04 of 08
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.04&nbsp;//&nbsp;CYBER-ATTACKS
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL4}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-9">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-amber"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 04
              </span>
              <span className="mt-1 block text-[clamp(2.4rem,7vw,6rem)] text-amber glow">
                Types of
                <br />
                Cyber Attacks
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-amber/60"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[64ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              Eight attack types, dissected — malware, phishing, ransomware,
              DDoS, SQL injection, zero-day, man-in-the-middle and password
              attacks — followed by the five strategies that stop them, and a
              map from each defence back to the threat it neutralises.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(8)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-amber hover:text-amber"
                style={{ borderRadius: 2 }}
              >
                Jump to prevention strategies
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-3 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Attack types", "Eight"],
            ["Strategies", "Five"],
            ["Most targeted layer", "Human"],
            ["Doc revision", "12 Jun 2026"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · INTRODUCTION
================================================================== */
export function IntroSlide4() {
  return (
    <Slide
      tag="SEC // CH.04 // THREAT-BRIEF"
      num="02"
      title={
        <>
          Types of <span className="text-amber">cyber attacks</span>
        </>
      }
      dense
    >
      <div className="border-y border-amber/50 py-5 md:py-6">
        <p className="max-w-[96ch] text-[clamp(1rem,1.35vw,1.25rem)] font-light leading-[1.62] text-sage">
          {ch4Intro}
        </p>
      </div>

      <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="font-mono text-[9.5px] tracked text-phos">
            What defines a cyber attack
          </div>
          <div className="mt-3 grid gap-px bg-sage/15 sm:grid-cols-2">
            {ch4Bullets.map((b, n) => (
              <motion.div
                key={b}
                variants={{
                  hidden: { opacity: 0, y: 10 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.36, delay: n * 0.07 },
                  },
                }}
                className="flex items-start gap-3 bg-ink p-4"
              >
                <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-amber" />
                <span className="text-[13.5px] font-light leading-[1.6] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-sage/20 pt-4">
            <span className="font-mono text-[9.5px] tracked text-muted">
              Section 01 · attack taxonomy
            </span>
            <span className="font-mono text-[9.5px] tracked text-amber/80">
              {ch4Stamp}
            </span>
          </div>
        </div>

        <aside className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              The chapter in numbers
            </div>
            <div className="mt-4 space-y-3.5">
              {[
                ["08", "attack types profiled"],
                ["05", "prevention strategies"],
                ["03", "layers hit most often"],
                ["01", "hardest control: people"],
              ].map(([k, v]) => (
                <div
                  key={k}
                  className="flex items-baseline gap-4 border-t border-sage/15 pt-3"
                >
                  <span className="font-display text-[1.5rem] leading-none text-amber">
                    {k}
                  </span>
                  <span className="text-[13px] font-light text-muted">{v}</span>
                </div>
              ))}
            </div>
          </Panel>

          <div className="mt-4 border-l-2 border-phos pl-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Cross-reference
            </div>
            <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">
              Severity, cost and the evolution of these attacks were covered in{" "}
              <span className="text-sage">Chapter 01 · Threat landscape</span>;
              the seven defence domains in{" "}
              <span className="text-sage">Chapter 01 · Types of cybersecurity</span>.
            </p>
          </div>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · MAJOR TYPES — INDEX
================================================================== */
export function AttackIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.04 // TAXONOMY"
      num="03"
      title={
        <>
          Major types of{" "}
          <span className="text-amber">cyber attacks</span>
        </>
      }
      lede="Eight families, each with its own entry vector and the layer it lives on. Profiled in pairs on the slides that follow."
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {attacks.map((a) => (
              <Row key={a.i} i={a.i} label={a.name} desc={a.intro} meta={a.layer} />
            ))}
          </div>
        </div>

        <aside className="lg:col-span-4">
          <div
            className="relative overflow-hidden border border-sage/15"
            style={{ borderRadius: 2 }}
          >
            <img
              src={hook}
              alt="A steel fishing hook through the flap of a dark envelope"
              className="h-[220px] w-full object-cover opacity-85 md:h-[250px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/35 to-transparent" />
            <span className="absolute bottom-3 left-3 right-3 font-mono text-[9.5px] tracked text-amber">
              Fig. 03 — The lure still works on people
            </span>
          </div>

          <Panel className="mt-4 p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Read a profile like this
            </div>
            <div className="mt-3 space-y-2">
              {[
                ["Intro", "what the attack is"],
                ["Chain", "how it lands"],
                ["Example", "a real instance"],
                ["Layer", "where it strikes"],
              ].map(([k, v]) => (
                <div
                  key={k}
                  className="flex items-baseline justify-between gap-3 border-t border-sage/15 pt-2"
                >
                  <span className="font-mono text-[10.5px] tracked-sm text-sage">
                    {k}
                  </span>
                  <span className="text-right text-[11.5px] font-light text-muted">
                    {v}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   Attack detail cards (two per slide)
================================================================== */
function AttackCard({ a, n }: { a: (typeof attacks)[number]; n: number }) {
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.42, delay: n * 0.1, ease: "easeOut" },
        },
      }}
      className="flex flex-col border border-amber/30 bg-panel/50 p-5 transition-colors duration-200 hover:border-amber/70 md:p-6"
      style={{ borderRadius: 2 }}
    >
      <div className="flex items-start justify-between gap-4">
        <span className="font-display text-[2.4rem] leading-none text-amber glow">
          {a.i}
        </span>
        <span
          className="border border-phos/45 px-2 py-1 font-mono text-[9px] tracked text-phos"
          style={{ borderRadius: 2 }}
        >
          {a.layer}
        </span>
      </div>

      <h3 className="mt-4 font-display text-[clamp(1.05rem,1.7vw,1.35rem)] uppercase leading-tight tracking-tight text-sage">
        {a.name}
      </h3>
      <p className="mt-3 max-w-[62ch] text-[14px] font-light leading-[1.65] text-muted">
        {a.intro}
      </p>

      <div className="mt-4 border-t border-sage/15 pt-3.5">
        <div className="font-mono text-[9.5px] tracked text-amber">Attack chain</div>
        <ul className="mt-2.5 space-y-2">
          {a.bullets.map((b) => (
            <li
              key={b}
              className="flex items-start gap-2.5 text-[13.5px] font-light leading-[1.55] text-sage/85"
            >
              <span className="mt-[8px] h-px w-3 shrink-0 bg-amber/70" />
              {b}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-4 border border-amber/35 bg-amber/[0.07] p-3.5">
        <div className="font-mono text-[9px] tracked text-amber">Example</div>
        <p className="mt-1.5 text-[13.5px] font-light italic leading-[1.55] text-amber/95">
          {a.example}
        </p>
      </div>

      <div className="mt-auto flex flex-wrap items-baseline justify-between gap-2 border-t border-sage/15 pt-3.5">
        <span className="font-mono text-[9px] tracked text-muted">Vector</span>
        <span className="font-mono text-[10px] tracked-sm text-sage/85">
          {a.vector}
        </span>
      </div>
    </motion.article>
  );
}

const AttackPair = ({
  from,
  num,
  head,
  tail,
}: {
  from: number;
  num: string;
  head: string;
  tail: string;
}) => (
  <Slide
    tag={`SEC // CH.04 // ATTACKS ${attacks[from].i}–${attacks[from + 1].i}`}
    num={num}
    title={
      <>
        {head} · <span className="text-amber">{tail}</span>
      </>
    }
    dense
  >
    <div className="grid items-start gap-4 md:grid-cols-2">
      {attacks.slice(from, from + 2).map((a, n) => (
        <AttackCard key={a.i} a={a} n={n} />
      ))}
    </div>
  </Slide>
);

export const AttackPair1 = () => (
  <AttackPair from={0} num="04" head="Malware" tail="Phishing" />
);
export const AttackPair2 = () => (
  <AttackPair from={2} num="05" head="Ransomware" tail="DDoS" />
);
export const AttackPair3 = () => (
  <AttackPair from={4} num="06" head="SQL Injection" tail="Zero-Day" />
);
export const AttackPair4 = () => (
  <AttackPair from={6} num="07" head="Man-in-the-Middle" tail="Password" />
);

/* ==================================================================
   08 · ATTACK MATRIX
================================================================== */
export function AttackMatrixSlide() {
  return (
    <Slide
      tag="SEC // CH.04 // ATTACK-MATRIX"
      num="08"
      title={
        <>
          Attack matrix —{" "}
          <span className="text-amber">layer &amp; vector</span>
        </>
      }
      lede="One row per attack: where it strikes and how it arrives. This is the table the five prevention strategies are mapped against."
      dense
    >
      <div
        className="overflow-x-auto border border-sage/20 bg-panel/45"
        style={{ borderRadius: 2 }}
      >
        <table className="w-full min-w-[760px] border-collapse text-left">
          <thead>
            <tr className="border-b border-amber/55 bg-amber/[0.08]">
              {["#", "Attack", "Primary layer", "Entry vector"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 font-mono text-[9.5px] tracked text-amber"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {attacks.map((a) => (
              <tr
                key={a.i}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-amber/[0.05]"
              >
                <td className="px-4 py-3.5 font-mono text-[11px] text-amber/75">
                  {a.i}
                </td>
                <td className="px-4 py-3.5 font-display text-[14px] uppercase leading-tight tracking-tight text-sage">
                  {a.name}
                </td>
                <td className="px-4 py-3.5">
                  <span
                    className="inline-block border border-phos/45 px-2 py-1 font-mono text-[9.5px] tracked text-phos"
                    style={{ borderRadius: 2 }}
                  >
                    {a.layer}
                  </span>
                </td>
                <td className="px-4 py-3.5 font-mono text-[11.5px] tracked-sm text-muted">
                  {a.vector}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · STRATEGIES — INDEX
================================================================== */
export function StrategiesIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.04 // PREVENTION"
      num="09"
      title={
        <>
          Strategies to prevent{" "}
          <span className="text-phos">cyber attacks</span>
        </>
      }
      lede="Five controls that, applied together, neutralise most of the eight attack types profiled above."
      dense
    >
      <div className="border-b border-sage/15">
        {strategies.map((s) => (
          <Row
            key={s.i}
            i={s.i}
            label={s.name}
            desc={s.desc}
            meta={`BREAKS ${s.breaks.length}`}
          />
        ))}
      </div>
      <div className="mt-5 flex flex-wrap gap-2.5">
        {strategies.map((s) => (
          <span
            key={s.i}
            className="border border-phos/35 px-2.5 py-1.5 font-mono text-[10px] tracked text-phos/85"
            style={{ borderRadius: 2 }}
          >
            {s.i} · {s.breaks.join(" · ")}
          </span>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Strategy detail cards
================================================================== */
function StrategyCard({
  s,
  n,
}: {
  s: (typeof strategies)[number];
  n: number;
}) {
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.42, delay: n * 0.09, ease: "easeOut" },
        },
      }}
      className="flex flex-col border border-phos/35 bg-panel/50 p-5 transition-colors duration-200 hover:border-phos/70 md:p-6"
      style={{ borderRadius: 2 }}
    >
      <div className="flex items-start justify-between gap-4">
        <span className="font-display text-[2.4rem] leading-none text-phos glow">
          {s.i}
        </span>
        <span
          className="border border-amber/45 px-2 py-1 font-mono text-[9px] tracked text-amber"
          style={{ borderRadius: 2 }}
        >
          {s.breaks.length} threat{s.breaks.length > 1 ? "s" : ""}
        </span>
      </div>

      <h3 className="mt-4 font-display text-[clamp(1.05rem,1.7vw,1.3rem)] uppercase leading-tight tracking-tight text-sage">
        {s.name}
      </h3>
      <p className="mt-3 text-[14px] font-light leading-[1.65] text-muted">
        {s.desc}
      </p>

      <ul className="mt-4 space-y-2 border-t border-sage/15 pt-3.5">
        {s.bullets.map((b) => (
          <li
            key={b}
            className="flex items-start gap-2.5 text-[13.5px] font-light leading-[1.55] text-sage/85"
          >
            <span className="mt-[8px] h-px w-3 shrink-0 bg-phos/70" />
            {b}
          </li>
        ))}
      </ul>

      <div className="mt-4 border-l-2 border-phos pl-4">
        <div className="font-mono text-[9px] tracked text-phos">Example</div>
        <p className="mt-1.5 text-[13.5px] font-light italic leading-[1.55] text-sage/85">
          {s.example}
        </p>
      </div>

      <div className="mt-auto pt-4">
        <div className="font-mono text-[9px] tracked text-amber">Neutralises</div>
        <div className="mt-2 flex flex-wrap gap-2">
          {s.breaks.map((b) => (
            <span
              key={b}
              className="border border-amber/40 px-2 py-1 font-mono text-[9.5px] tracked text-amber"
              style={{ borderRadius: 2 }}
            >
              {b}
            </span>
          ))}
        </div>
      </div>
    </motion.article>
  );
}

export function StrategiesDetailA() {
  return (
    <Slide
      tag="SEC // CH.04 // STRATEGIES 01–03"
      num="10"
      title={
        <>
          Passwords, MFA &amp;{" "}
          <span className="text-phos">patching</span>
        </>
      }
      dense
    >
      <div className="grid items-start gap-4 md:grid-cols-3">
        {strategies.slice(0, 3).map((s, n) => (
          <StrategyCard key={s.i} s={s} n={n} />
        ))}
      </div>
    </Slide>
  );
}

export function StrategiesDetailB() {
  return (
    <Slide
      tag="SEC // CH.04 // STRATEGIES 04–05"
      num="11"
      title={
        <>
          Links, downloads &amp;{" "}
          <span className="text-phos">protection software</span>
        </>
      }
      dense
    >
      <div className="grid items-start gap-4 md:grid-cols-2">
        {strategies.slice(3).map((s, n) => (
          <StrategyCard key={s.i} s={s} n={n} />
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   12 · DEFENCE MATRIX — strategy → threats it breaks
================================================================== */
export function DefenceMatrixSlide() {
  return (
    <Slide
      tag="SEC // CH.04 // DEFENCE-MATRIX"
      num="12"
      title={
        <>
          Defence matrix —{" "}
          <span className="text-phos">what each control breaks</span>
        </>
      }
      lede="Every strategy on this chapter answers one or more of the eight attacks. Anything left unconnected is a gap in your posture."
      dense
    >
      <div className="border-b border-sage/15">
        {strategies.map((s, n) => (
          <motion.div
            key={s.i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.06 },
              },
            }}
            className="grid grid-cols-1 gap-x-6 gap-y-3 border-t border-sage/15 py-4 transition-colors duration-200 hover:bg-phos/[0.045] md:grid-cols-[2.6rem_minmax(0,1.1fr)_auto]"
          >
            <span className="font-mono text-[11px] text-phos/70 md:pt-1">
              {s.i}
            </span>
            <div className="min-w-0">
              <div className="font-mono text-[13px] font-medium tracked-sm text-sage">
                {s.name}
              </div>
              <p className="mt-1.5 max-w-[58ch] text-[13px] font-light leading-[1.55] text-muted">
                {s.desc}
              </p>
            </div>
            <div className="flex flex-wrap items-start gap-2 md:justify-end">
              <span className="hidden self-center font-mono text-[13px] text-phos/60 md:block">
                →
              </span>
              {s.breaks.map((b) => (
                <span
                  key={b}
                  className="border border-amber/40 px-2.5 py-1.5 font-mono text-[9.5px] tracked text-amber"
                  style={{ borderRadius: 2 }}
                >
                  {b}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {[
          ["Untouched", "MITM and SQL Injection need transport encryption and secure coding — see Chapter 01 · Domains 01–03."],
          ["Strongest lever", "The human layer: four of the five strategies are behavioural, not technical."],
          ["Depth", "Controls layer: one strategy rarely covers an attack family on its own."],
        ].map(([k, v]) => (
          <div key={k} className="border-l-2 border-phos/60 pl-4">
            <div className="font-mono text-[9.5px] tracked text-phos">{k}</div>
            <p className="mt-2 text-[13px] font-light leading-[1.6] text-muted">
              {v}
            </p>
          </div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   13 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide4({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">
          Sec // CH.04 // Check
        </span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Name the attack.
          <br />
          <span className="text-amber glow">Then answer.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Five multiple-choice items covering attack goals, phishing,
          ransomware, social engineering and the role of AI. Select an answer to
          reveal it instantly — the rationale appears underneath and your
          running score is kept in the footer.
        </motion.p>

        <motion.div
          variants={rise}
          className="mt-5 border-l-2 border-phos pl-4"
        >
          <span className="font-mono text-[9.5px] tracked text-phos">
            Cross-reference
          </span>
          <p className="mt-1.5 max-w-[60ch] text-[13.5px] font-light leading-[1.6] text-muted">
            AI-driven phishing is covered in{" "}
            <span className="text-sage">Chapter 01 · Emerging trends — Rise of
            AI and Machine Learning</span>.
          </p>
        </motion.div>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(13)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   14–18 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide4({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions4[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.04 // CHECK // Q0${n + 1}`}
      num={String(14 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-amber pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              [
                "Status",
                !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect",
              ],
              ["Domain", "Attack types"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex items-baseline justify-between border-t border-sage/15 pt-2.5"
              >
                <span className="font-mono text-[9.5px] tracked text-muted">
                  {k}
                </span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.06 },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   19 · SCORE
================================================================== */
export function ScoreSlide4({ answers }: { answers: (number | null)[] }) {
  const score = questions4.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions4.length) * 100);
  const verdict =
    pct === 100
      ? "All eight attack types and all five strategies — clean sweep."
      : pct >= 60
        ? "Solid. Re-read the profile you missed and its defence."
        : "Revisit the attack matrix and defence matrix, then retake.";

  return (
    <Slide
      tag="SEC // CH.04 // CHECK // RESULT"
      num="19"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div
            className="border border-phos/40 bg-panel/60 p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions4.length}
              </span>
            </div>
            <div
              className="mt-5 h-2 w-full bg-sage/12"
              style={{ borderRadius: 2 }}
            >
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions4.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions4.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.05 },
                    },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide4() {
  const items = [
    ["01", "Eight ways in", "Malware, phishing, ransomware, DDoS, SQLi, zero-day, MITM and password attacks."],
    ["02", "Most attacks aim at people", "Phishing and social engineering exploit psychology, not a software flaw."],
    ["03", "Ransomware = encrypt and extort", "WannaCry showed how fast a single flaw becomes global downtime."],
    ["04", "Zero-day means no patch yet", "The only defence is layered detection — you cannot update what is not published."],
    ["05", "Five strategies, high coverage", "Strong passwords, MFA, updates, cautious clicking, antivirus + firewall."],
    ["06", "Map control to threat", "If an attack on the matrix has no strategy pointing at it, that is a gap."],
  ];

  return (
    <Slide
      tag="SEC // CH.04 // CLOSE"
      num="20"
      title={
        <>
          Chapter 04 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 04 · Types of Cyber Attacks
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents4.length} sections · {TOTAL4} slides
        </span>
      </div>
    </Slide>
  );
}
