import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { Mark } from "./components/mark";
import { contents, TOTAL, questions } from "./data/content";
import { contents2, TOTAL2, questions2 } from "./data/ch2";
import { contents3, TOTAL3, questions3 } from "./data/ch3";
import { contents4, TOTAL4, questions4 } from "./data/ch4";
import { contents5, TOTAL5, questions5 } from "./data/ch5";
import { contents6, TOTAL6, questions6 } from "./data/ch6";
import { contents7, TOTAL7, questions7 } from "./data/ch7";
import * as S1 from "./slides";
import * as S2 from "./slides2";
import * as S3 from "./slides3";
import * as S4 from "./slides4";
import * as S5 from "./slides5";
import * as S6 from "./slides6";
import * as S7 from "./slides7";

/* ------------------------------------------------------------------ */
type Item = { label: string; idx: number; section: string };

const buildFlat = (c: { section: string; items: string[] }[]): Item[] => {
  const out: Item[] = [];
  c.forEach((g) =>
    g.items.forEach((it) =>
      out.push({ label: it, idx: out.length, section: g.section }),
    ),
  );
  return out;
};

const CHAPTERS = [
  {
    n: 1,
    code: "CH.01",
    short: "01",
    name: "Introduction to Cybersecurity",
    rail: "Intro to Cybersecurity · Ch.01",
    flat: buildFlat(contents),
    total: TOTAL,
    quiz: { start: 18, first: 19, count: 5, score: 24 },
  },
  {
    n: 2,
    code: "CH.02",
    short: "02",
    name: "Linux Permissions",
    rail: "Linux Permissions · Ch.02",
    flat: buildFlat(contents2),
    total: TOTAL2,
    quiz: { start: 16, first: 17, count: 5, score: 22 },
  },
  {
    n: 3,
    code: "CH.03",
    short: "03",
    name: "Applications of Cybersecurity",
    rail: "Applications · Ch.03",
    flat: buildFlat(contents3),
    total: TOTAL3,
    quiz: { start: 11, first: 12, count: 6, score: 18 },
  },
  {
    n: 4,
    code: "CH.04",
    short: "04",
    name: "Types of Cyber Attacks",
    rail: "Cyber Attacks · Ch.04",
    flat: buildFlat(contents4),
    total: TOTAL4,
    quiz: { start: 12, first: 13, count: 5, score: 18 },
  },
  {
    n: 5,
    code: "CH.05",
    short: "05",
    name: "Hackers and Their Types",
    rail: "Hackers · Ch.05",
    flat: buildFlat(contents5),
    total: TOTAL5,
    quiz: { start: 14, first: 15, count: 5, score: 20 },
  },
  {
    n: 6,
    code: "CH.06",
    short: "06",
    name: "Vulnerabilities in Information Security",
    rail: "Vulnerabilities · Ch.06",
    flat: buildFlat(contents6),
    total: TOTAL6,
    quiz: { start: 15, first: 16, count: 5, score: 21 },
  },
  {
    n: 7,
    code: "CH.07",
    short: "07",
    name: "Threat Actor",
    rail: "Threat Actor · Ch.07",
    flat: buildFlat(contents7),
    total: TOTAL7,
    quiz: { start: 13, first: 14, count: 5, score: 19 },
  },
];

const QUESTION_SETS: Record<number, { q: { answer: number }[] }> = {
  1: { q: questions },
  2: { q: questions2 },
  3: { q: questions3 },
  4: { q: questions4 },
  5: { q: questions5 },
  6: { q: questions6 },
  7: { q: questions7 },
};

const INITIAL_ANSWERS = (n: number) =>
  Array.from({ length: n }, () => null as number | null);

export default function App() {
  const [ch, setCh] = useState(1);
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Record<number, (number | null)[]>>(() => ({
    1: INITIAL_ANSWERS(questions.length),
    2: INITIAL_ANSWERS(questions2.length),
    3: INITIAL_ANSWERS(questions3.length),
    4: INITIAL_ANSWERS(questions4.length),
  }));
  const [open, setOpen] = useState(false);

  const meta = CHAPTERS[ch - 1];
  const flat = meta.flat;
  const total = meta.total;
  const quiz = meta.quiz;

  const go = useCallback(
    (n: number) => {
      setI(Math.max(0, Math.min(total - 1, n)));
      setOpen(false);
    },
    [total],
  );
  const next = useCallback(() => go(i + 1), [go, i]);
  const prev = useCallback(() => go(i - 1), [go, i]);

  const jumpChapter = (n: number) => {
    setCh(n);
    setI(0);
    setOpen(false);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      const t = e.target as HTMLElement | null;
      const tag = t?.tagName ?? "";
      /* never steal keys from a text field, and let a focused
         control handle its own Space / Enter activation */
      if (
        tag === "INPUT" ||
        tag === "TEXTAREA" ||
        tag === "SELECT" ||
        t?.isContentEditable
      )
        return;
      if ((tag === "BUTTON" || tag === "A") && (k === " " || k === "Enter"))
        return;
      if (k === "ArrowRight" || k === "PageDown" || k === " ") {
        e.preventDefault();
        next();
      } else if (k === "ArrowLeft" || k === "PageUp") {
        e.preventDefault();
        prev();
      } else if (k === "Home") {
        go(0);
      } else if (k === "End") {
        go(total - 1);
      } else if (k === "i" || k === "I") {
        setOpen((o) => !o);
      } else if (k === "Escape") {
        setOpen(false);
      } else if (["1", "2", "3", "4", "5", "6", "7"].includes(k)) {
        jumpChapter(Number(k));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  /* ---- quiz ---- */
  const chapterAnswers = answers[ch] ?? [];
  const qStart = quiz.first;
  const qEnd = quiz.first + quiz.count - 1;
  const activeQuestions = QUESTION_SETS[ch].q as {
    q: string;
    options: string[];
    answer: number;
    why: string;
  }[];

  const setAnswer = (n: number, c: number) =>
    setAnswers((prevA) => {
      const arr = [...(prevA[ch] ?? [])];
      arr[n] = c;
      return { ...prevA, [ch]: arr };
    });

  const score = useMemo(
    () =>
      activeQuestions.reduce(
        (a, q, n) => a + (chapterAnswers[n] === q.answer ? 1 : 0),
        0,
      ),
    [activeQuestions, chapterAnswers],
  );

  /* ---- slide router ---- */
  const slide = useMemo(() => {
    if (i >= qStart && i <= qEnd) {
      const n = i - qStart;
      const sel = chapterAnswers[n];
      const onAnswer = (c: number) => setAnswer(n, c);
      if (ch === 1)
        return <S1.QuestionSlide n={n} selected={sel} onAnswer={onAnswer} />;
      if (ch === 2)
        return <S2.QuestionSlide2 n={n} selected={sel} onAnswer={onAnswer} />;
      return <S3.QuestionSlide3 n={n} selected={sel} onAnswer={onAnswer} />;
    }
    if (i === quiz.score) {
      if (ch === 1) return <S1.ScoreSlide answers={chapterAnswers} />;
      if (ch === 2) return <S2.ScoreSlide2 answers={chapterAnswers} />;
      return <S3.ScoreSlide3 answers={chapterAnswers} />;
    }

    if (ch === 1) {
      switch (i) {
        case 0:
          return <S1.TitleSlide go={go} />;
        case 1:
          return <S1.DefinitionSlide />;
        case 2:
          return <S1.PracticeSlide />;
        case 3:
          return <S1.ObjectivesSlide />;
        case 4:
          return <S1.StandardsSlide />;
        case 5:
          return <S1.AtStakeSlide />;
        case 6:
          return <S1.TriadSlide />;
        case 7:
          return <S1.TriadDetailSlide />;
        case 8:
          return <S1.DomainsIndexSlide />;
        case 9:
          return <S1.DomainsDetailA />;
        case 10:
          return <S1.DomainsDetailB />;
        case 11:
          return <S1.AttackTableSlide />;
        case 12:
          return <S1.ThreatWheelSlide />;
        case 13:
          return <S1.ThreatsSlide />;
        case 14:
          return <S1.NumbersSlide />;
        case 15:
          return <S1.ForensicsSlide />;
        case 16:
          return <S1.TrendsSlide />;
        case 17:
          return <S1.ChallengesSlide />;
        case 18:
          return <S1.QuizIntroSlide go={go} />;
        default:
          return <S1.TakeawaysSlide />;
      }
    }

    if (ch === 2) {
      switch (i) {
        case 0:
          return <S2.TitleSlide2 go={go} />;
        case 1:
          return <S2.WhySlide />;
        case 2:
          return <S2.ThreePermsSlide />;
        case 3:
          return <S2.OwnershipSlide />;
        case 4:
          return <S2.OperatorsSlide />;
        case 5:
          return <S2.NineCharsSlide />;
        case 6:
          return <S2.ClassRefSlide />;
        case 7:
          return <S2.LsSlide />;
        case 8:
          return <S2.NameiStatSlide />;
        case 9:
          return <S2.ChmodSymbolicSlide />;
        case 10:
          return <S2.SymbolicExamplesSlide />;
        case 11:
          return <S2.OctalSlide />;
        case 12:
          return <S2.ModeReadingSlide />;
        case 13:
          return <S2.SpecialPermsSlide />;
        case 14:
          return <S2.ChownSlide />;
        case 15:
          return <S2.SimulatorSlide />;
        case 16:
          return <S2.QuizIntroSlide2 go={go} />;
        default:
          return <S2.TakeawaysSlide2 />;
      }
    }

    if (ch === 7) {
      switch (i) {
        case 0:
          return <S7.TitleSlide7 go={go} />;
        case 1:
          return <S7.IntroSlide7 />;
        case 2:
          return <S7.ActorIndexSlide />;
        case 3:
          return <S7.ActorPair1 />;
        case 4:
          return <S7.ActorPair2 />;
        case 5:
          return <S7.ActorSoloSlide />;
        case 6:
          return <S7.ActorMatrixSlide />;
        case 7:
          return <S7.WorkflowSlide />;
        case 8:
          return <S7.KillChainSlide />;
        case 9:
          return <S7.BreakChainSlide />;
        case 10:
          return <S7.CasesSlide />;
        case 11:
          return <S7.DetectionA />;
        case 12:
          return <S7.DetectionB />;
        case 13:
          return <S7.QuizIntroSlide7 go={go} />;
        default:
          return <S7.TakeawaysSlide7 />;
      }
    }

    if (ch === 6) {
      switch (i) {
        case 0:
          return <S6.TitleSlide6 go={go} />;
        case 1:
          return <S6.IntroSlide6 />;
        case 2:
          return <S6.VulnIndexSlide />;
        case 3:
          return <S6.HardwareExamples />;
        case 4:
          return <S6.HardwareDefence />;
        case 5:
          return <S6.SoftwareExamples />;
        case 6:
          return <S6.SoftwareDefence />;
        case 7:
          return <S6.NetworkExamples />;
        case 8:
          return <S6.NetworkDefence />;
        case 9:
          return <S6.ProceduralExamples />;
        case 10:
          return <S6.ProceduralDefence />;
        case 11:
          return <S6.HumanExamples />;
        case 12:
          return <S6.HumanDefence />;
        case 13:
          return <S6.TestingSlide />;
        case 14:
          return <S6.CveSlide />;
        case 15:
          return <S6.QuizIntroSlide6 go={go} />;
        default:
          return <S6.TakeawaysSlide6 />;
      }
    }

    if (ch === 5) {
      switch (i) {
        case 0:
          return <S5.TitleSlide5 go={go} />;
        case 1:
          return <S5.IntroSlide5 />;
        case 2:
          return <S5.SpectrumSlide />;
        case 3:
          return <S5.PrimaryTypesSlide />;
        case 4:
          return <S5.HatMatrixSlide />;
        case 5:
          return <S5.OtherIndexSlide />;
        case 6:
          return <S5.OtherDetailA />;
        case 7:
          return <S5.OtherDetailB />;
        case 8:
          return <S5.InsiderSlide />;
        case 9:
          return <S5.DevicesSlide />;
        case 10:
          return <S5.PreventionSlide />;
        case 11:
          return <S5.HardeningSlide />;
        case 12:
          return <S5.MethodologySlide />;
        case 13:
          return <S5.TeamsSlide />;
        case 14:
          return <S5.QuizIntroSlide5 go={go} />;
        default:
          return <S5.TakeawaysSlide5 />;
      }
    }

    if (ch === 4) {
      switch (i) {
        case 0:
          return <S4.TitleSlide4 go={go} />;
        case 1:
          return <S4.IntroSlide4 />;
        case 2:
          return <S4.AttackIndexSlide />;
        case 3:
          return <S4.AttackPair1 />;
        case 4:
          return <S4.AttackPair2 />;
        case 5:
          return <S4.AttackPair3 />;
        case 6:
          return <S4.AttackPair4 />;
        case 7:
          return <S4.AttackMatrixSlide />;
        case 8:
          return <S4.StrategiesIndexSlide />;
        case 9:
          return <S4.StrategiesDetailA />;
        case 10:
          return <S4.StrategiesDetailB />;
        case 11:
          return <S4.DefenceMatrixSlide />;
        case 12:
          return <S4.QuizIntroSlide4 go={go} />;
        default:
          return <S4.TakeawaysSlide4 />;
      }
    }

    switch (i) {
      case 0:
        return <S3.TitleSlide3 go={go} />;
      case 1:
        return <S3.ApplicationsIndexSlide />;
      case 2:
        return <S3.ApplicationsDetailA />;
      case 3:
        return <S3.ApplicationsDetailB />;
      case 4:
        return <S3.ToolsSlide />;
      case 5:
        return <S3.CiaIntroSlide />;
      case 6:
        return <S3.ConfidentialitySlide />;
      case 7:
        return <S3.IntegritySlide />;
      case 8:
        return <S3.HashSlide />;
      case 9:
        return <S3.AvailabilitySlide />;
      case 10:
        return <S3.MatrixSlide />;
      case 11:
        return <S3.QuizIntroSlide3 go={go} />;
      default:
        return <S3.TakeawaysSlide3 />;
    }
  }, [ch, i, answers, go, qStart, qEnd, quiz.score, chapterAnswers]);

  const pct = ((i + 1) / total) * 100;
  const inQuiz = i >= quiz.start && i <= quiz.score;
  const section = flat[i]?.section ?? "";

  const chapterTabs = (compact = false) => (
    <div className="flex items-center gap-1.5">
      {CHAPTERS.map((c) => (
        <button
          key={c.n}
          onClick={() => jumpChapter(c.n)}
          title={c.name}
          className={`border px-2 py-1.5 font-mono text-[9.5px] tracked transition-colors ${
            ch === c.n
              ? "border-phos bg-phos text-ink"
              : "border-sage/25 text-sage/70 hover:border-phos hover:text-phos"
          }`}
          style={{ borderRadius: 2 }}
        >
          <span className="sm:hidden">{c.n}</span>
          <span className="hidden sm:inline">
            {compact ? c.short : c.code}
          </span>
        </button>
      ))}
    </div>
  );

  return (
    <MotionConfig reducedMotion="user">
      <div className="relative h-dvh w-full overflow-hidden bg-ink">
        {/* ============ LEFT RAIL ============ */}
        <aside className="absolute inset-y-0 left-0 z-30 hidden w-16 flex-col items-center border-r border-sage/15 bg-panel/50 py-4 md:flex">
          <button
            onClick={() => go(0)}
            aria-label="Back to this chapter's title slide"
            className="transition-opacity duration-200 hover:opacity-70"
          >
            <Mark size={24} />
          </button>

          <span
            className="mt-5 font-mono text-[9.5px] tracked text-muted"
            style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
          >
            {meta.rail}
          </span>

          <div className="relative mx-auto mt-5 w-px flex-1 bg-sage/20">
            <motion.div
              className="absolute left-0 top-0 w-px bg-phos"
              animate={{ height: `${pct}%` }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              style={{ boxShadow: "0 0 6px rgba(61,240,122,.8)" }}
            />
          </div>

          <div className="mt-5 flex flex-col items-center leading-none">
            <span className="font-mono text-[8.5px] tracked text-phos/70">
              CH{meta.short}
            </span>
            <span className="mt-1.5 font-display text-[15px] text-phos tabular-nums">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="mt-1 font-mono text-[9px] text-muted">/{total}</span>
          </div>
        </aside>

        {/* ============ MOBILE HEADER ============ */}
        <header className="absolute inset-x-0 top-0 z-30 flex h-11 items-center justify-between border-b border-sage/15 bg-panel/80 px-4 md:hidden">
          <button onClick={() => go(0)} className="flex items-center gap-2.5">
            <Mark size={17} />
            <span className="truncate max-w-[45vw] font-mono text-[9.5px] tracked text-muted">
              {meta.name}
            </span>
          </button>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[9.5px] tracked text-phos tabular-nums">
              {String(i + 1).padStart(2, "0")}/{total}
            </span>
            <button
              onClick={() => setOpen(true)}
              aria-label="Open contents"
              className="flex h-6 w-6 shrink-0 flex-col items-center justify-center gap-[3px] border border-sage/30"
            >
              <span className="h-px w-3 bg-sage" />
              <span className="h-px w-3 bg-sage" />
              <span className="h-px w-3 bg-sage" />
            </button>
          </div>
        </header>

        {/* ============ STAGE ============ */}
        <main className="absolute bottom-0 left-0 right-0 top-11 overflow-hidden md:left-16 md:top-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${ch}-${i}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16, ease: "easeOut" }}
              className="h-full w-full"
            >
              {slide}
            </motion.div>
          </AnimatePresence>

          <motion.div
            key={`sweep-${ch}-${i}`}
            aria-hidden
            initial={{ x: "-30%", opacity: 0.85 }}
            animate={{ x: "135%", opacity: 0 }}
            transition={{ duration: 0.65, ease: "easeOut" }}
            className="pointer-events-none absolute inset-y-0 left-0 z-20 w-[24%] bg-gradient-to-r from-transparent via-phos/[0.14] to-transparent"
          />
          <div
            aria-hidden
            className="scanlines pointer-events-none absolute inset-0 z-10 opacity-[0.22]"
          />
        </main>

        {/* ============ BOTTOM BAR ============ */}
        <nav className="absolute bottom-0 left-0 right-0 z-30 flex h-14 items-center justify-between gap-3 border-t border-sage/20 bg-ink/92 px-3 backdrop-blur-sm md:left-16 md:px-6">
          <div className="flex items-center gap-2">
            {chapterTabs(true)}
            <span className="mx-1 hidden h-5 w-px bg-sage/20 sm:block" />
            <button
              onClick={prev}
              disabled={i === 0}
              className="border border-sage/25 px-2.5 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos disabled:opacity-25 sm:px-3"
              style={{ borderRadius: 2 }}
            >
              ←<span className="hidden sm:inline"> Prev</span>
            </button>
            <button
              onClick={next}
              disabled={i === total - 1}
              className="border border-phos/70 px-2.5 py-2 font-mono text-[10px] tracked text-phos transition-colors duration-200 hover:bg-phos hover:text-ink disabled:opacity-25 sm:px-3"
              style={{ borderRadius: 2 }}
            >
              <span className="hidden sm:inline">Next </span>→
            </button>
          </div>

          <div className="hidden items-end gap-[5px] sm:flex">
            {Array.from({ length: total }).map((_, n) => (
              <button
                key={n}
                onClick={() => go(n)}
                title={`${String(n + 1).padStart(2, "0")} · ${flat[n]?.label ?? ""}`}
                aria-label={`Go to slide ${n + 1}`}
                className="group relative flex h-6 items-end"
              >
                <span
                  className={`block w-[3px] transition-all duration-200 ${
                    n === i
                      ? "h-5 bg-phos"
                      : n < i
                        ? "h-3 bg-phos/45 group-hover:bg-phos"
                        : "h-2 bg-sage/30 group-hover:bg-sage/70"
                  }`}
                />
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 md:gap-4">
            {inQuiz && (
              <span className="hidden font-mono text-[10px] tracked text-muted sm:block">
                Score{" "}
                <span className="text-phos">
                  {score}/{activeQuestions.length}
                </span>
              </span>
            )}
            <span className="hidden font-mono text-[9.5px] tracked text-muted lg:block">
              {section}
            </span>
            <span className="font-mono text-[10px] tracked text-sage tabular-nums">
              {String(i + 1).padStart(2, "0")}
              <span className="text-muted">/{total}</span>
            </span>
            <button
              onClick={() => setOpen(true)}
              className="hidden border border-sage/25 px-3 py-2 font-mono text-[10px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos lg:block"
              style={{ borderRadius: 2 }}
            >
              Index · I
            </button>
          </div>
        </nav>

        {/* ============ CONTENTS DRAWER ============ */}
        <AnimatePresence>
          {open && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                onClick={() => setOpen(false)}
                className="absolute inset-0 z-40 bg-ink/70 backdrop-blur-[2px]"
              />
              <motion.aside
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ duration: 0.32, ease: "easeOut" }}
                className="absolute inset-y-0 right-0 z-50 flex w-[min(380px,88vw)] flex-col border-l border-phos/35 bg-panel"
              >
                <div className="flex items-center justify-between border-b border-sage/20 px-5 py-4">
                  <span className="font-mono text-[10px] tracked text-phos">
                    Contents
                  </span>
                  <button
                    onClick={() => setOpen(false)}
                    aria-label="Close contents"
                    className="font-mono text-[13px] text-muted transition-colors hover:text-amber"
                  >
                    ✕
                  </button>
                </div>

                <div className="border-b border-sage/20 px-5 py-3.5">
                  <div className="mb-2.5 font-mono text-[9px] tracked text-muted">
                    Chapter
                  </div>
                  <div className="space-y-2">
                    {CHAPTERS.map((c) => (
                      <button
                        key={c.n}
                        onClick={() => jumpChapter(c.n)}
                        className={`flex w-full items-center gap-3 border px-3 py-2.5 text-left transition-colors ${
                          ch === c.n
                            ? "border-phos bg-deep/60"
                            : "border-sage/25 hover:border-phos/60"
                        }`}
                        style={{ borderRadius: 2 }}
                      >
                        <span
                          className={`font-mono text-[11px] ${
                            ch === c.n ? "text-phos" : "text-muted"
                          }`}
                        >
                          {c.code}
                        </span>
                        <span
                          className={`min-w-0 flex-1 truncate text-[13px] font-light ${
                            ch === c.n ? "text-phos" : "text-sage/85"
                          }`}
                        >
                          {c.name}
                        </span>
                        <span className="shrink-0 font-mono text-[9.5px] text-muted">
                          {c.total}p
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto px-5 py-4">
                  {(
                    ch === 1
                      ? contents
                      : ch === 2
                        ? contents2
                        : ch === 3
                          ? contents3
                          : ch === 4
                            ? contents4
                            : ch === 5
                              ? contents5
                              : ch === 6
                                ? contents6
                                : contents7
                  ).map(
                    (g) => (
                      <div key={g.section} className="mb-5">
                        <div className="font-mono text-[9.5px] tracked text-amber">
                          {g.section}
                        </div>
                        <div className="mt-2 border-b border-sage/15">
                          {flat
                            .filter((f) => f.section === g.section)
                            .map((f) => (
                              <button
                                key={f.idx}
                                onClick={() => go(f.idx)}
                                className={`flex w-full items-baseline gap-3 border-t border-sage/15 py-2.5 text-left transition-colors duration-150 hover:bg-phos/[0.06] ${
                                  f.idx === i ? "bg-phos/[0.09]" : ""
                                }`}
                              >
                                <span
                                  className={`font-mono text-[10.5px] tabular-nums ${
                                    f.idx === i ? "text-phos" : "text-muted"
                                  }`}
                                >
                                  {String(f.idx + 1).padStart(2, "0")}
                                </span>
                                <span
                                  className={`text-[13px] font-light ${
                                    f.idx === i ? "text-phos" : "text-sage/85"
                                  }`}
                                >
                                  {f.label}
                                </span>
                              </button>
                            ))}
                        </div>
                      </div>
                    ),
                  )}
                </div>

                <div className="border-t border-sage/20 px-5 py-3 font-mono text-[9px] tracked text-muted">
                  ← → navigate · 1 2 3 chapter · I index · Esc close
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
