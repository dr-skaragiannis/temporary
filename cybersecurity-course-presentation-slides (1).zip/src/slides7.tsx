import { useState } from "react";
import { motion } from "framer-motion";
import { Panel, Row, Slide, Tag, group, rise } from "./components/kit";
import { Mark, TriadSeal } from "./components/mark";
import {
  actors,
  actorsLead,
  cases,
  ch7Bullets,
  ch7Intro,
  ch7Stamp,
  contents7,
  detection,
  killChain,
  killChainNote,
  questions7,
  TOTAL7,
  workflowLead,
} from "./data/ch7";

const TONE: Record<string, string> = {
  phos: "#3DF07A",
  amber: "#FFB020",
  sage: "#C7D2C9",
};

/* ==================================================================
   01 · TITLE — pure vector identity (no photo budget left)
================================================================== */
function ThreatBackdrop() {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 1200 700"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
    >
      <defs>
        <radialGradient id="tbFade" cx="30%" cy="50%" r="85%">
          <stop offset="0%" stopColor="#0B0F0D" stopOpacity="0.15" />
          <stop offset="70%" stopColor="#0B0F0D" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#0B0F0D" stopOpacity="0.97" />
        </radialGradient>
        <filter id="tbGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="7" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* etched grid */}
      <g stroke="#C7D2C9" strokeOpacity="0.07">
        {Array.from({ length: 25 }).map((_, n) => (
          <line key={`v${n}`} x1={n * 50} y1="0" x2={n * 50} y2="700" />
        ))}
        {Array.from({ length: 15 }).map((_, n) => (
          <line key={`h${n}`} x1="0" y1={n * 50} x2="1200" y2={n * 50} />
        ))}
      </g>

      {/* targeting reticle, offset right */}
      <g transform="translate(915 350)" opacity="0.75">
        {[175, 125, 72].map((r, n) => (
          <circle
            key={r}
            r={r}
            fill="none"
            stroke="#3DF07A"
            strokeOpacity={0.16 + n * 0.06}
            strokeWidth="1"
            strokeDasharray={n === 1 ? "6 9" : undefined}
          />
        ))}
        <line x1="-215" y1="0" x2="-40" y2="0" stroke="#3DF07A" strokeOpacity="0.4" />
        <line x1="40" y1="0" x2="215" y2="0" stroke="#3DF07A" strokeOpacity="0.4" />
        <line x1="0" y1="-215" x2="0" y2="-40" stroke="#3DF07A" strokeOpacity="0.4" />
        <line x1="0" y1="40" x2="0" y2="215" stroke="#3DF07A" strokeOpacity="0.4" />
        <path
          d="M-175 -140 v-35 h35 M175 -140 v-35 h-35 M-175 140 v35 h35 M175 140 v35 h-35"
          fill="none"
          stroke="#3DF07A"
          strokeOpacity="0.55"
          strokeWidth="2"
        />
      </g>

      {/* actor blips */}
      {[
        [915, 350, 9, "#FFB020"],
        [812, 268, 6, "#FFB020"],
        [1018, 438, 6, "#3DF07A"],
        [868, 452, 5, "#C7D2C9"],
        [986, 254, 5, "#C7D2C9"],
      ].map(([x, y, r, c]) => (
        <g key={`${x}-${y}`} filter="url(#tbGlow)">
          <circle cx={x as number} cy={y as number} r={r as number} fill={c as string} />
          <circle
            cx={x as number}
            cy={y as number}
            r={(r as number) + 9}
            fill="none"
            stroke={c as string}
            strokeOpacity="0.3"
          />
        </g>
      ))}

      <rect width="1200" height="700" fill="url(#tbFade)" />
    </svg>
  );
}

export function TitleSlide7({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative h-full w-full overflow-x-hidden overflow-y-auto"
    >
      <ThreatBackdrop />
      <div className="scanlines absolute inset-0 opacity-[0.35]" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber/90 px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Threat briefing · lecture use
        </span>
        <span className="hidden font-mono text-[9.5px] tracked text-ink sm:block">
          Chapter 07 of 08
        </span>
      </div>

      <div className="relative flex h-full flex-col justify-between gap-8 px-5 pb-24 pt-14 sm:px-8 md:px-12 md:pb-20 md:pt-16 lg:px-16">
        <div className="flex items-start justify-between gap-8">
          <motion.div variants={rise} className="flex items-center gap-3">
            <Mark size={22} />
            <span className="font-mono text-[10px] tracked text-phos">
              SEC&nbsp;//&nbsp;CH.07&nbsp;//&nbsp;THREAT-ACTOR
            </span>
          </motion.div>
          <motion.span
            variants={rise}
            className="hidden font-mono text-[10px] tracked text-muted sm:block"
          >
            01 / {TOTAL7}
          </motion.span>
        </div>

        <div className="grid grid-cols-1 items-end gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.p
              variants={rise}
              className="font-mono text-[11px] tracked text-amber"
            >
              University course · Introduction to Cybersecurity
            </motion.p>

            <motion.h1
              variants={{
                hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
                show: {
                  opacity: 1,
                  clipPath: "inset(0 0% 0 0)",
                  transition: { duration: 0.7, ease: "easeOut", delay: 0.1 },
                },
              }}
              className="mt-4 font-display uppercase leading-[0.85] tracking-[-0.02em]"
            >
              <span className="block text-[clamp(1.9rem,5vw,4.1rem)] text-sage">
                Chapter 07
              </span>
              <span className="mt-1 block text-[clamp(3rem,9vw,7.5rem)] text-phos glow">
                Threat Actor
              </span>
            </motion.h1>

            <motion.div
              variants={rise}
              className="mt-7 h-px w-full max-w-[640px] origin-left bg-phos/50"
            />

            <motion.p
              variants={rise}
              className="mt-5 max-w-[62ch] text-[15px] font-light leading-[1.62] text-sage/85 md:text-[17px]"
            >
              {ch7Intro} Five actor types, the seven-stage Cyber Kill Chain
              they follow, two documented 2025 intrusions, and the five
              detection methods security teams use to find them.
            </motion.p>

            <motion.div
              variants={rise}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <button
                onClick={() => go(1)}
                className="border border-phos bg-phos px-5 py-3 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
                style={{ borderRadius: 2 }}
              >
                Begin chapter →
              </button>
              <button
                onClick={() => go(8)}
                className="border border-sage/30 px-5 py-3 font-mono text-[11px] tracked text-sage transition-colors duration-200 hover:border-phos hover:text-phos"
              >
                Jump to the kill chain
              </button>
            </motion.div>
          </div>

          <motion.div
            variants={rise}
            className="hidden justify-end lg:col-span-4 lg:flex"
          >
            <TriadSeal className="h-auto w-full max-w-[220px] opacity-70" />
          </motion.div>
        </div>

        <motion.div
          variants={rise}
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-sage/20 pt-4 md:grid-cols-4"
        >
          {[
            ["Actor types", "Five"],
            ["Kill chain stages", "Seven"],
            ["Detection methods", "Five"],
            ["Doc revision", "12 Jun 2026"],
          ].map(([k, v]) => (
            <div key={k}>
              <div className="font-mono text-[9.5px] tracked text-muted">{k}</div>
              <div className="mt-1 font-mono text-[12px] tracked-sm text-sage">
                {v}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   02 · WHAT A THREAT ACTOR IS
================================================================== */
export function IntroSlide7() {
  return (
    <Slide
      tag="SEC // CH.07 // DEFINITION"
      num="02"
      title={
        <>
          What is a <span className="text-phos">threat actor</span>
        </>
      }
      dense
    >
      <div className="border-y border-phos/45 py-5 md:py-6">
        <p className="max-w-[96ch] text-[clamp(1rem,1.35vw,1.25rem)] font-light leading-[1.62] text-sage">
          {ch7Intro}
        </p>
      </div>

      <div className="mt-7 grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-8">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Why identification matters
          </div>
          <div className="mt-3 border-b border-sage/15">
            {ch7Bullets.map((b, n) => (
              <motion.div
                key={b}
                variants={{
                  hidden: { opacity: 0, y: 8 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.34, delay: n * 0.06 },
                  },
                }}
                className="grid grid-cols-[2.1rem_minmax(0,1fr)] gap-x-4 border-t border-sage/15 py-3.5"
              >
                <span className="font-mono text-[11px] text-phos/70">
                  {String(n + 1).padStart(2, "0")}
                </span>
                <span className="text-[14px] font-light leading-[1.55] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
            <span className="font-mono text-[9.5px] tracked text-muted">
              Section 01 · who is on the other side
            </span>
            <span className="font-mono text-[9.5px] tracked text-amber/80">
              {ch7Stamp}
            </span>
          </div>
        </div>

        <aside className="lg:col-span-4">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Actor · motive · target
            </div>
            <div className="mt-4 space-y-3">
              {[
                ["Motive", "why they attack — money, power, ideology, protest, fear"],
                ["Method", "how they attack — the tooling and the tradecraft"],
                ["Target", "who they attack — the sector and the asset"],
              ].map(([k, v]) => (
                <div key={k} className="border-t border-sage/15 pt-3">
                  <div className="font-mono text-[11.5px] tracked-sm text-sage">
                    {k}
                  </div>
                  <p className="mt-1 text-[12.5px] font-light leading-[1.5] text-muted">
                    {v}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4 h-px w-full bg-sage/15" />
            <p className="mt-4 text-[13px] font-light leading-[1.6] text-muted">
              Attribution answers all three — which is why it drives tooling
              spend, training priorities and intelligence sharing.
            </p>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   03 · FIVE ACTOR TYPES — INDEX
================================================================== */
export function ActorIndexSlide() {
  return (
    <Slide
      tag="SEC // CH.07 // TAXONOMY"
      num="03"
      title={
        <>
          Types of <span className="text-amber">threat actors</span>
        </>
      }
      lede={actorsLead}
      dense
    >
      <div className="border-b border-sage/15">
        {actors.map((a) => (
          <Row
            key={a.key}
            i={a.i}
            label={a.name}
            desc={a.intro}
            meta={a.motive}
          />
        ))}
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {actors.map((a) => (
          <div
            key={a.key}
            className="border-l-2 bg-panel/40 px-4 py-3"
            style={{ borderColor: TONE[a.tone] }}
          >
            <div
              className="font-mono text-[9.5px] tracked"
              style={{ color: TONE[a.tone] }}
            >
              {a.short}
            </div>
            <p className="mt-1.5 font-mono text-[10.5px] leading-snug text-muted">
              {a.scale}
            </p>
          </div>
        ))}
      </div>
    </Slide>
  );
}

/* ==================================================================
   Actor detail cards
================================================================== */
function ActorCard({ a, n }: { a: (typeof actors)[number]; n: number }) {
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.42, delay: n * 0.1, ease: "easeOut" },
        },
      }}
      className="flex flex-col border bg-panel/50 p-5 transition-colors duration-200 md:p-6"
      style={{ borderRadius: 2, borderColor: `${TONE[a.tone]}55` }}
    >
      <div className="flex items-start justify-between gap-4">
        <span
          className="font-display text-[2.4rem] leading-none"
          style={{ color: TONE[a.tone] }}
        >
          {a.i}
        </span>
        <span
          className="border px-2 py-1 text-right font-mono text-[9px] tracked"
          style={{
            borderRadius: 2,
            borderColor: `${TONE[a.tone]}66`,
            color: TONE[a.tone],
          }}
        >
          {a.motive}
        </span>
      </div>

      <h3 className="mt-4 font-display text-[clamp(1.05rem,1.7vw,1.3rem)] uppercase leading-tight tracking-tight text-sage">
        {a.name}
      </h3>
      <p className="mt-3 text-[14px] font-light leading-[1.65] text-muted">
        {a.intro}
      </p>

      <ul className="mt-4 space-y-2 border-t border-sage/15 pt-3.5">
        {a.bullets.map((b) => (
          <li
            key={b}
            className="flex items-start gap-2.5 text-[13.5px] font-light leading-[1.55] text-sage/85"
          >
            <span
              className="mt-[8px] h-px w-3 shrink-0"
              style={{ background: TONE[a.tone] }}
            />
            {b}
          </li>
        ))}
      </ul>

      <div
        className="mt-4 border-l-2 pl-4"
        style={{ borderColor: TONE[a.tone] }}
      >
        <div
          className="font-mono text-[9px] tracked"
          style={{ color: TONE[a.tone] }}
        >
          Example
        </div>
        <p className="mt-1.5 text-[13.5px] font-light italic leading-[1.55] text-sage/90">
          {a.example}
        </p>
      </div>

      <div className="mt-auto flex items-baseline justify-between gap-3 border-t border-sage/15 pt-3.5">
        <span className="font-mono text-[9px] tracked text-muted">Scale</span>
        <span className="font-mono text-[10px] tracked-sm text-sage/85">
          {a.scale}
        </span>
      </div>
    </motion.article>
  );
}

const ActorPair = ({
  from,
  num,
  head,
  tail,
}: {
  from: number;
  num: string;
  head: string;
  tail: string;
}) => (
  <Slide
    tag={`SEC // CH.07 // ACTORS ${actors[from].i}–${actors[from + 1].i}`}
    num={num}
    title={
      <>
        {head} · <span className="text-amber">{tail}</span>
      </>
    }
    dense
  >
    <div className="grid items-start gap-4 md:grid-cols-2">
      {actors.slice(from, from + 2).map((a, n) => (
        <ActorCard key={a.key} a={a} n={n} />
      ))}
    </div>
  </Slide>
);

export const ActorPair1 = () => (
  <ActorPair from={0} num="04" head="Cybercriminals" tail="Nation-State" />
);
export const ActorPair2 = () => (
  <ActorPair from={2} num="05" head="Insider Threats" tail="Hacktivists" />
);

export function ActorSoloSlide() {
  const a = actors[4];
  return (
    <Slide
      tag={`SEC // CH.07 // ACTORS ${a.i}`}
      num="06"
      title={
        <>
          Cyber <span className="text-amber">Terrorists</span>
        </>
      }
      lede={a.intro}
      dense
    >
      <div className="grid gap-6 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="grid gap-px bg-sage/15 sm:grid-cols-2">
            {a.bullets.map((b, n) => (
              <motion.div
                key={b}
                variants={{
                  hidden: { opacity: 0, y: 10 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.36, delay: n * 0.08 },
                  },
                }}
                className="flex items-start gap-3 bg-ink p-5"
              >
                <span className="mt-[7px] h-1.5 w-1.5 shrink-0 bg-amber" />
                <span className="text-[14px] font-light leading-[1.6] text-sage/85">
                  {b}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-5 border-l-2 border-amber pl-5">
            <span className="font-mono text-[9.5px] tracked text-amber">
              Example
            </span>
            <p className="mt-2 max-w-[70ch] text-[15px] font-light italic leading-[1.6] text-sage/90">
              {a.example}
            </p>
          </div>
        </div>

        <aside className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Where this actor differs
            </div>
            <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
              Unlike cybercriminals, the objective is not payment — it is
              disruption and fear. Unlike nation-states, there is no diplomatic
              endgame. That combination is what puts power, healthcare and
              transport at the centre of the target list.
            </p>
            <div className="mt-4 h-px w-full bg-sage/15" />
            <div className="mt-4 space-y-2.5">
              {[
                ["Motive", a.motive],
                ["Target", "Critical infrastructure"],
                ["Signature", "Destructive malware"],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3">
                  <span className="font-mono text-[10px] tracked text-muted">
                    {k}
                  </span>
                  <span className="text-right font-mono text-[10.5px] text-sage/85">
                    {v}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   07 · ACTOR MATRIX
================================================================== */
export function ActorMatrixSlide() {
  return (
    <Slide
      tag="SEC // CH.07 // ACTOR-MATRIX"
      num="07"
      title={
        <>
          Actor matrix —{" "}
          <span className="text-phos">motive vs method</span>
        </>
      }
      lede="Five rows, five motives. This is the table that turns an alert into an attribution hypothesis."
      dense
    >
      <div
        className="overflow-x-auto border border-sage/20 bg-panel/45"
        style={{ borderRadius: 2 }}
      >
        <table className="w-full min-w-[820px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              {["Actor", "Primary motive", "Typical method", "Documented example"].map(
                (h) => (
                  <th
                    key={h}
                    className="px-4 py-3 font-mono text-[9.5px] tracked text-phos"
                  >
                    {h}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {actors.map((a) => (
              <tr
                key={a.key}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-4">
                  <span
                    className="font-display text-[14px] uppercase tracking-tight"
                    style={{ color: TONE[a.tone] }}
                  >
                    {a.short}
                  </span>
                </td>
                <td className="px-4 py-4 text-[13px] font-light text-sage/85">
                  {a.motive}
                </td>
                <td className="px-4 py-4 text-[13px] font-light text-muted">
                  {a.bullets[0]}
                </td>
                <td className="px-4 py-4 text-[13px] font-light italic text-sage/75">
                  {a.example}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-4 max-w-[92ch] font-mono text-[11.5px] leading-relaxed text-phos/80">
        Note · the same tooling appears in more than one row — ransomware is
        criminal, but a state actor can deploy it too. Motive is what separates
        the actors, not the malware family.
      </p>
    </Slide>
  );
}

/* ==================================================================
   08 · WORKFLOW — INTRO
================================================================== */
export function WorkflowSlide() {
  return (
    <Slide
      tag="SEC // CH.07 // WORKFLOW"
      num="08"
      title={
        <>
          Workflow of a <span className="text-phos">cyber attack</span>
        </>
      }
      lede={workflowLead}
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <div className="border-y border-phos/45 py-5">
            <p className="max-w-[92ch] text-[clamp(1rem,1.3vw,1.2rem)] font-light leading-[1.62] text-sage">
              Cyber attacks often follow a structured approach to successfully
              breach systems and achieve their objectives. One widely used
              model is the{" "}
              <span className="text-phos">Lockheed Martin Cyber Kill Chain</span>
              , which breaks down an attack into multiple stages, helping
              organizations understand and defend against each step.
            </p>
          </div>

          <div className="mt-6 font-mono text-[9.5px] tracked text-phos">
            Why a model helps
          </div>
          <div className="mt-3 grid gap-px bg-sage/15 sm:grid-cols-2">
            {[
              ["Predict", "Each actor type favours certain entry stages."],
              ["Detect", "A visible stage means an earlier one was missed."],
              ["Constrain", "Blocking one stage can end the whole chain."],
              ["Communicate", "A shared vocabulary for the incident report."],
            ].map(([k, v]) => (
              <div key={k} className="bg-ink p-4">
                <div className="font-mono text-[11.5px] tracked-sm text-sage">
                  {k}
                </div>
                <p className="mt-1.5 text-[13px] font-light leading-[1.55] text-muted">
                  {v}
                </p>
              </div>
            ))}
          </div>
        </div>

        <aside className="lg:col-span-5">
          <Panel className="p-5">
            <div className="font-mono text-[9.5px] tracked text-phos">
              Seven stages · one direction
            </div>
            <div className="mt-4 space-y-0">
              {killChain.map((s, n) => (
                <div
                  key={s.i}
                  className="flex items-center gap-3 border-t border-sage/15 py-2.5 first:border-t-0"
                >
                  <span
                    className={`flex h-6 w-6 shrink-0 items-center justify-center border font-mono text-[10px] ${
                      n === 6
                        ? "border-amber/70 text-amber"
                        : "border-phos/55 text-phos"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {s.i}
                  </span>
                  <span className="font-mono text-[12px] tracked-sm text-sage/85">
                    {s.name}
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-4 border-t border-sage/15 pt-4 text-[13px] font-light leading-[1.6] text-muted">
              The next slide makes each stage selectable, with the control that
              breaks it.
            </p>
          </Panel>
        </aside>
      </div>
    </Slide>
  );
}

/* ==================================================================
   09 · THE SEVEN STAGES — interactive
================================================================== */
export function KillChainSlide() {
  const [active, setActive] = useState(0);
  const s = killChain[active];

  return (
    <Slide
      tag="SEC // CH.07 // KILL-CHAIN"
      num="09"
      title={
        <>
          The seven stages of the{" "}
          <span className="text-phos">Cyber Kill Chain</span>
        </>
      }
      dense
    >
      <div className="grid gap-6 lg:grid-cols-12 lg:gap-8">
        {/* chain rail */}
        <div className="lg:col-span-5">
          <div className="relative">
            <span className="absolute left-[1.35rem] top-3 bottom-3 w-px bg-sage/20" />
            <div className="border-b border-sage/15">
              {killChain.map((k, n) => {
                const on = active === n;
                return (
                  <button
                    key={k.i}
                    onClick={() => setActive(n)}
                    className={`relative flex w-full items-center gap-4 border-t border-sage/15 py-3.5 pl-1 pr-3 text-left transition-colors duration-200 ${
                      on ? "bg-phos/[0.09]" : "hover:bg-phos/[0.04]"
                    }`}
                  >
                    <span
                      className={`z-10 flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[11px] transition-colors ${
                        on
                          ? "border-phos bg-phos text-ink"
                          : n >= 5
                            ? "border-amber/55 text-amber"
                            : "border-phos/50 bg-ink text-phos"
                      }`}
                      style={{ borderRadius: 2 }}
                    >
                      {k.i}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span
                        className={`block font-mono text-[13px] tracked-sm ${
                          on ? "text-phos" : "text-sage/85"
                        }`}
                      >
                        {k.name}
                      </span>
                    </span>
                    <span className="font-mono text-[13px] text-phos/50">
                      {on ? "●" : "→"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* detail */}
        <div className="lg:col-span-7">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="border border-phos/40 bg-panel/60 p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <span className="font-mono text-[9.5px] tracked text-phos">
                Stage {s.i} of 07
              </span>
              <span className="border border-sage/30 px-2 py-1 font-mono text-[9px] tracked text-sage/70" style={{ borderRadius: 2 }}>
                {s.label}
              </span>
            </div>
            <h3 className="mt-4 font-display text-[clamp(1.3rem,3vw,2.1rem)] uppercase leading-tight tracking-tight text-sage">
              {s.name}
            </h3>
            <p className="mt-4 max-w-[70ch] text-[15px] font-light leading-[1.7] text-sage/90">
              {s.desc}
            </p>

            <div className="mt-6 border-t border-sage/20 pt-5">
              <div className="font-mono text-[9.5px] tracked text-amber">
                Break the chain here
              </div>
              <p className="mt-2.5 max-w-[70ch] text-[14px] font-light leading-[1.65] text-muted">
                {s.breaks}
              </p>
            </div>
          </motion.div>

          <div className="mt-4 border-l-2 border-amber pl-5">
            <span className="font-mono text-[9.5px] tracked text-amber">
              Note
            </span>
            <p className="mt-2 max-w-[74ch] text-[14px] font-light leading-[1.65] text-sage/85">
              {killChainNote}
            </p>
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   10 · WHERE TO BREAK THE CHAIN
================================================================== */
export function BreakChainSlide() {
  const owners = [
    ["Recon", "OSINT hygiene · IDS alerts on scanning"],
    ["Weaponization", "Sandboxing · ASLR / DEP · content disarm"],
    ["Delivery", "Email & web filtering · USB control"],
    ["Exploitation", "Patch management · input validation"],
    ["Installation", "EDR · application allow-listing"],
    ["Command and Control", "Egress filtering · DNS monitoring"],
    ["Actions on Objectives", "DLP · encryption · segmentation · backups"],
  ];
  return (
    <Slide
      tag="SEC // CH.07 // BREAK-POINTS"
      num="10"
      title={
        <>
          Where to <span className="text-phos">break the chain</span>
        </>
      }
      lede="Every stage has a control that ends the attack there. Defence in depth means placing one at each — because, as the note says, an attacker blocked at one stage simply restarts an earlier one."
      dense
    >
      <div
        className="overflow-x-auto border border-sage/20 bg-panel/45"
        style={{ borderRadius: 2 }}
      >
        <table className="w-full min-w-[720px] border-collapse text-left">
          <thead>
            <tr className="border-b border-phos/55 bg-deep/35">
              {["#", "Stage", "Break it with"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 font-mono text-[9.5px] tracked text-phos"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {killChain.map((s, n) => (
              <tr
                key={s.i}
                className="border-b border-sage/15 transition-colors last:border-b-0 hover:bg-phos/[0.05]"
              >
                <td className="px-4 py-3.5 font-mono text-[11px] text-phos/70">
                  {s.i}
                </td>
                <td className="px-4 py-3.5 font-display text-[13.5px] uppercase tracking-tight text-sage">
                  {owners[n][0]}
                </td>
                <td className="px-4 py-3.5 text-[13.5px] font-light text-sage/85">
                  {owners[n][1]}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="border-l-2 border-phos pl-4">
          <div className="font-mono text-[9.5px] tracked text-phos">
            Living off the land
          </div>
          <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-muted">
            Because modern attackers borrow legitimate system tools, signature
            detection misses them — behavioural detection at stages 05 and 06
            is what catches a chain already in progress.
          </p>
        </div>
        <div className="border-l-2 border-amber pl-4">
          <div className="font-mono text-[9.5px] tracked text-amber">
            Stopping early is cheaper
          </div>
          <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-muted">
            Ending the chain at stage 03 costs an email filter. Ending it at
            stage 07 costs a breach notification, forensics and reputational
            damage.
          </p>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   11 · REAL-WORLD CASES
================================================================== */
export function CasesSlide() {
  return (
    <Slide
      tag="SEC // CH.07 // FIELD-EVIDENCE"
      num="11"
      title={
        <>
          Real-world examples of{" "}
          <span className="text-amber">threat actor groups</span>
        </>
      }
      lede="These cases demonstrate how threat actors operate in real environments."
      dense
    >
      <div className="grid items-start gap-4 lg:grid-cols-2">
        {cases.map((c, n) => (
          <motion.article
            key={c.title}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.42, delay: n * 0.12, ease: "easeOut" },
              },
            }}
            className="border border-amber/35 bg-panel/50 p-5 md:p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between gap-4">
              <span
                className="border border-amber bg-amber px-2 py-1 font-mono text-[9.5px] tracked text-ink"
                style={{ borderRadius: 2 }}
              >
                {c.tag}
              </span>
              <span className="font-mono text-[9.5px] tracked text-muted">
                {c.actor}
              </span>
            </div>

            <h3 className="mt-4 font-display text-[clamp(1.05rem,1.9vw,1.35rem)] uppercase leading-tight tracking-tight text-sage">
              {c.title}
            </h3>

            <ul className="mt-4 space-y-2.5 border-t border-sage/15 pt-4">
              {c.points.map((p) => (
                <li
                  key={p}
                  className="flex items-start gap-2.5 text-[13.5px] font-light leading-[1.6] text-sage/85"
                >
                  <span className="mt-[8px] h-px w-3 shrink-0 bg-amber/70" />
                  {p}
                </li>
              ))}
            </ul>

            <div className="mt-4 border-l-2 border-phos pl-4">
              <span className="font-mono text-[9px] tracked text-phos">
                What it teaches
              </span>
              <p className="mt-1.5 text-[13.5px] font-light italic leading-[1.55] text-sage/85">
                {c.lesson}
              </p>
            </div>
          </motion.article>
        ))}
      </div>

      <div className="mt-6 border-l-2 border-amber pl-5">
        <span className="font-mono text-[9.5px] tracked text-amber">
          Reading case studies
        </span>
        <p className="mt-2 max-w-[90ch] text-[14px] font-light leading-[1.65] text-sage/85">
          Both cases turn on a single exploited vulnerability and a single
          credential set — the same two conditions the kill chain describes.
          Disclosed incidents are the cheapest training material a security team
          will ever get.
        </p>
      </div>
    </Slide>
  );
}

/* ==================================================================
   12–13 · DETECTION METHODS
================================================================== */
function DetectionFor({ from, num, head }: { from: number; num: string; head: string }) {
  const slice = detection.slice(from, from + 3);
  return (
    <Slide
      tag={`SEC // CH.07 // DETECTION ${detection[from].i}–${detection[from + slice.length - 1].i}`}
      num={num}
      title={
        <>
          Identifying threat actors —{" "}
          <span className="text-phos">{head}</span>
        </>
      }
      lede={
        from === 0
          ? "Threat actors often remain hidden, but certain indicators reveal their presence. Security teams use monitoring, analytics and threat intelligence to detect attacks early."
          : undefined
      }
      dense
    >
      <div className="grid gap-4 md:grid-cols-3">
        {slice.map((d, n) => (
          <motion.article
            key={d.i}
            variants={{
              hidden: { opacity: 0, y: 14 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.4, delay: n * 0.1, ease: "easeOut" },
              },
            }}
            className="flex flex-col border border-phos/35 bg-panel/50 p-5 transition-colors hover:border-phos/70"
            style={{ borderRadius: 2 }}
          >
            <div className="flex items-start justify-between gap-3">
              <span className="font-display text-[2rem] leading-none text-phos">
                {d.i}
              </span>
              <span
                className="border border-sage/30 px-2 py-1 text-right font-mono text-[9px] tracked text-muted"
                style={{ borderRadius: 2 }}
              >
                Detect
              </span>
            </div>
            <h3 className="mt-3.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {d.name}
            </h3>
            <p className="mt-3 text-[13.5px] font-light leading-[1.65] text-muted">
              {d.desc}
            </p>

            <div className="mt-4 flex flex-wrap gap-1.5">
              {d.tools.map((t) => (
                <span
                  key={t}
                  className="border border-phos/40 px-2 py-1 font-mono text-[9.5px] text-phos"
                  style={{ borderRadius: 2 }}
                >
                  {t}
                </span>
              ))}
            </div>

            <div className="mt-4 border-t border-sage/15 pt-3.5">
              <span className="font-mono text-[9px] tracked text-amber">
                Example
              </span>
              <p className="mt-1.5 text-[13px] font-light italic leading-[1.55] text-sage/85">
                {d.example}
              </p>
            </div>
          </motion.article>
        ))}
      </div>

      {from > 0 && (
        <div className="mt-6 border-l-2 border-phos pl-5">
          <span className="font-mono text-[9.5px] tracked text-phos">
            Layered together
          </span>
          <p className="mt-2 max-w-[88ch] text-[14px] font-light leading-[1.65] text-sage/85">
            Traffic shows the channel, netstat shows the connection, SIEM shows
            the pattern, EDR shows the process and UEBA shows the person. No one
            view is sufficient — attribution comes from correlating all five.
          </p>
        </div>
      )}
    </Slide>
  );
}

export const DetectionA = () => <DetectionFor from={0} num="12" head="network & logs" />;
export const DetectionB = () => <DetectionFor from={3} num="13" head="endpoint & behaviour" />;

/* ==================================================================
   14 · QUIZ BRIEFING
================================================================== */
export function QuizIntroSlide7({ go }: { go: (n: number) => void }) {
  return (
    <motion.section
      variants={group}
      initial="hidden"
      animate="show"
      className="relative flex h-full w-full flex-col overflow-x-hidden overflow-y-auto px-5 pb-28 pt-14 sm:px-8 md:px-12 md:pt-10 lg:px-16"
    >
      <div className="grid-etch absolute inset-0 opacity-60" />
      <div className="absolute inset-x-0 top-0 flex h-8 items-center justify-between bg-amber px-5 md:px-8">
        <span className="font-mono text-[9.5px] tracked text-ink">
          Assessment instrument · 5 items
        </span>
        <span className="font-mono text-[9.5px] tracked text-ink">
          Sec // CH.07 // Check
        </span>
      </div>

      <div className="relative m-auto w-full max-w-[1100px] lg:pl-[9vw]">
        <motion.div variants={rise}>
          <Tag tone="amber">Knowledge check</Tag>
        </motion.div>
        <motion.h2
          variants={{
            hidden: { opacity: 0, clipPath: "inset(0 100% 0 0)" },
            show: {
              opacity: 1,
              clipPath: "inset(0 0% 0 0)",
              transition: { duration: 0.55, ease: "easeOut" },
            },
          }}
          className="mt-5 font-display text-[clamp(2.2rem,6.5vw,5rem)] uppercase leading-[0.9] tracking-[-0.02em] text-sage"
        >
          Identify the actor.
          <br />
          <span className="text-phos glow">Then answer.</span>
        </motion.h2>
        <motion.p
          variants={rise}
          className="mt-6 max-w-[64ch] text-[15px] font-light leading-[1.65] text-muted md:text-[17px]"
        >
          Five items covering the definition, criminal motive, nation-state
          actors, insider threats and the netstat detection command. Select an
          answer to reveal it instantly — the rationale appears underneath.
        </motion.p>

        <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
          <button
            onClick={() => go(14)}
            className="border border-phos bg-phos px-6 py-3.5 font-mono text-[11px] tracked text-ink transition-colors duration-200 hover:bg-transparent hover:text-phos"
            style={{ borderRadius: 2 }}
          >
            Start question 01 →
          </button>
          <span
            className="flex items-center gap-2 border border-sage/25 px-4 py-3.5 font-mono text-[10px] tracked text-muted"
            style={{ borderRadius: 2 }}
          >
            A · B · C · D — single answer
          </span>
        </motion.div>
      </div>
    </motion.section>
  );
}

/* ==================================================================
   15–19 · QUESTION
================================================================== */
const LETTERS = ["A", "B", "C", "D"];

export function QuestionSlide7({
  n,
  selected,
  onAnswer,
}: {
  n: number;
  selected: number | null;
  onAnswer: (c: number) => void;
}) {
  const q = questions7[n];
  const answered = selected !== null;
  const correct = selected === q.answer;

  return (
    <Slide
      tag={`SEC // CH.07 // CHECK // Q0${n + 1}`}
      num={String(15 + n)}
      title={
        <>
          Question <span className="text-phos">{String(n + 1).padStart(2, "0")}</span>
          <span className="text-muted"> / 05</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="border-l-2 border-phos pl-5">
            <p className="text-[clamp(1.1rem,2.2vw,1.6rem)] leading-[1.38] text-sage">
              {q.q}
            </p>
          </div>
          <div className="mt-6 space-y-2">
            {[
              [
                "Status",
                !answered ? "Awaiting response" : correct ? "Correct" : "Incorrect",
              ],
              ["Domain", "Threat actors"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="flex items-baseline justify-between border-t border-sage/15 pt-2.5"
              >
                <span className="font-mono text-[9.5px] tracked text-muted">
                  {k}
                </span>
                <span
                  className={`font-mono text-[10px] tracked ${
                    k === "Status"
                      ? !answered
                        ? "text-muted"
                        : correct
                          ? "text-phos"
                          : "text-amber"
                      : "text-sage/80"
                  }`}
                >
                  {v}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isPick = selected === i;
              const isRight = q.answer === i;
              const state = !answered
                ? "idle"
                : isRight
                  ? "right"
                  : isPick
                    ? "wrong"
                    : "dim";
              return (
                <motion.button
                  key={opt}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.06 },
                    },
                  }}
                  onClick={() => onAnswer(i)}
                  className={`flex items-start gap-3.5 border p-4 text-left transition-all duration-200 ${
                    state === "right"
                      ? "border-phos bg-deep/60"
                      : state === "wrong"
                        ? "border-amber bg-amber/10"
                        : state === "dim"
                          ? "border-sage/10 opacity-45"
                          : "border-sage/20 hover:border-phos/60 hover:bg-phos/[0.05]"
                  }`}
                  style={{ borderRadius: 2 }}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[12px] ${
                      state === "right"
                        ? "border-phos bg-phos text-ink"
                        : state === "wrong"
                          ? "border-amber bg-amber text-ink"
                          : "border-sage/35 text-sage/80"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className="pt-1 break-words text-[13.5px] font-light leading-[1.5] text-sage/90">
                    {opt}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {answered && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`mt-4 border-l-2 p-4 ${
                correct ? "border-phos bg-phos/[0.06]" : "border-amber bg-amber/[0.07]"
              }`}
            >
              <div
                className={`font-mono text-[9.5px] tracked ${
                  correct ? "text-phos" : "text-amber"
                }`}
              >
                {correct ? "✓ Correct — rationale" : "✕ Not quite — rationale"}
              </div>
              <p className="mt-2 text-[13.5px] font-light leading-[1.6] text-sage/85">
                {q.why}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   20 · SCORE
================================================================== */
export function ScoreSlide7({ answers }: { answers: (number | null)[] }) {
  const score = questions7.reduce(
    (a, q, i) => a + (answers[i] === q.answer ? 1 : 0),
    0,
  );
  const pct = Math.round((score / questions7.length) * 100);
  const verdict =
    pct === 100
      ? "All five actors identified — clean sweep."
      : pct >= 60
        ? "Solid. Re-read the actor you missed and the stage it prefers."
        : "Revisit the actor matrix and the kill chain, then retake.";

  return (
    <Slide
      tag="SEC // CH.07 // CHECK // RESULT"
      num="20"
      title={
        <>
          Your <span className="text-phos">score</span>
        </>
      }
      dense
    >
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-4">
          <div
            className="border border-phos/40 bg-panel/60 p-6"
            style={{ borderRadius: 2 }}
          >
            <div className="font-mono text-[9.5px] tracked text-phos">Result</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="font-display text-[clamp(4rem,11vw,7rem)] leading-[0.8] text-phos glow">
                {score}
              </span>
              <span className="font-display text-[1.6rem] text-sage/50">
                / {questions7.length}
              </span>
            </div>
            <div
              className="mt-5 h-2 w-full bg-sage/12"
              style={{ borderRadius: 2 }}
            >
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                className="h-full bg-phos"
              />
            </div>
            <div className="mt-2 flex justify-between font-mono text-[10px] tracked text-muted">
              <span>{pct}%</span>
              <span>
                {score} of {questions7.length} correct
              </span>
            </div>
            <p className="mt-4 text-[13.5px] font-light leading-[1.55] text-sage/85">
              {verdict}
            </p>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="border-b border-sage/15">
            {questions7.map((q, i) => {
              const ok = answers[i] === q.answer;
              const picked = answers[i];
              return (
                <motion.div
                  key={q.q}
                  variants={{
                    hidden: { opacity: 0, y: 8 },
                    show: {
                      opacity: 1,
                      y: 0,
                      transition: { duration: 0.34, delay: i * 0.05 },
                    },
                  }}
                  className="grid grid-cols-[2.2rem_minmax(0,1fr)_auto] items-start gap-x-4 border-t border-sage/15 py-3.5"
                >
                  <span className="pt-[2px] font-mono text-[11px] text-phos/70">
                    Q{i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-light leading-[1.45] text-sage/85">
                      {q.q}
                    </p>
                    <p className="mt-1 break-words font-mono text-[11px] text-muted">
                      Your answer:{" "}
                      <span className={ok ? "text-phos" : "text-amber"}>
                        {picked === null ? "— unanswered" : q.options[picked]}
                      </span>
                      {!ok && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="text-phos">{q.options[q.answer]}</span>
                        </>
                      )}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 border px-2 py-1 font-mono text-[9px] tracked ${
                      ok ? "border-phos/60 text-phos" : "border-amber/60 text-amber"
                    }`}
                    style={{ borderRadius: 2 }}
                  >
                    {ok ? "Pass" : "Review"}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Slide>
  );
}

/* ==================================================================
   21 · TAKEAWAYS
================================================================== */
export function TakeawaysSlide7() {
  const items = [
    ["01", "Know who you are defending against", "Motive, method and target differ for every actor type — and they drive every other decision."],
    ["02", "Crime is the volume, states are the depth", "Cybercriminals optimize for profit; nation-states accept years of dwell time."],
    ["03", "Insiders arrive with valid credentials", "The controls are behavioural, not perimeter — and the anomaly is often invisible in isolation."],
    ["04", "Attacks are staged, not improvised", "Seven kill-chain stages, each one a place where a defender can end it."],
    ["05", "Blocked means redirected", "Stuck at any stage, an attacker restarts an earlier one — depth beats a single wall."],
    ["06", "Detection is five simultaneous views", "Traffic, connections, logs, processes and behaviour — correlation is the capability."],
  ];

  return (
    <Slide
      tag="SEC // CH.07 // CLOSE"
      num="21"
      title={
        <>
          Chapter 07 — <span className="text-phos">takeaways</span>
        </>
      }
      dense
    >
      <div className="grid gap-px bg-sage/15 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(([i, h, d], n) => (
          <motion.div
            key={i}
            variants={{
              hidden: { opacity: 0, y: 10 },
              show: {
                opacity: 1,
                y: 0,
                transition: { duration: 0.36, delay: n * 0.05 },
              },
            }}
            className="bg-ink p-5"
          >
            <span className="font-mono text-[11px] text-amber/80">{i}</span>
            <h3 className="mt-2.5 font-display text-[1rem] uppercase leading-tight tracking-tight text-sage">
              {h}
            </h3>
            <p className="mt-2.5 text-[13px] font-light leading-[1.6] text-muted">
              {d}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-phos/40 pt-5">
        <div className="flex items-center gap-3">
          <Mark size={20} />
          <span className="font-mono text-[10px] tracked text-phos">
            End of chapter 07 · Threat Actor
          </span>
        </div>
        <span className="font-mono text-[10px] tracked text-muted">
          Contents index: {contents7.length} sections · {TOTAL7} slides
        </span>
      </div>
    </Slide>
  );
}
