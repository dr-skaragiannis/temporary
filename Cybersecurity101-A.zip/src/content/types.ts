export type Lang = "en" | "el";

/** A bilingual value. Every piece of book text exists in English and Greek. */
export type L<T> = { en: T; el: T };

/**
 * Inline markup supported inside paragraph strings (rendered in the UI and
 * converted to LaTeX):  **bold**   *italic*   `code`
 */
export type Block =
  | string
  | { t: "list"; items: string[]; ordered?: boolean }
  | { t: "table"; caption?: string; head: string[]; rows: string[][] }
  | { t: "box"; kind: "example" | "note" | "key"; title: string; text: string };

export interface Section {
  id: string; // e.g. "1.3"
  title: L<string>;
  body: L<Block[]>;
}

export interface Term {
  term: string;
  def: string;
}

export interface Chapter {
  n: number;
  part: number;
  title: L<string>;
  subtitle: L<string>;
  level: L<string>;
  hours: string;
  intro: L<string[]>;
  outcomes: L<string[]>;
  sections: Section[];
  terms: L<Term[]>;
  summary: L<string[]>;
  questions: L<string[]>;
}

export interface Part {
  n: number;
  title: L<string>;
  blurb: L<string>;
}
