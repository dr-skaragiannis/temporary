import type { Lang } from "./content/types";

const S = {
  library: { en: "Revised bilingual edition", el: "Αναθεωρημένη δίγλωσση έκδοση" },
  contents: { en: "Contents", el: "Περιεχόμενα" },
  home: { en: "Cover & overview", el: "Εξώφυλλο & επισκόπηση" },
  preface: { en: "Preface", el: "Πρόλογος" },
  report: { en: "Editorial analysis", el: "Επιμελητική ανάλυση" },
  latex: { en: "LaTeX studio", el: "Εργαστήριο LaTeX" },
  part: { en: "Part", el: "Μέρος" },
  chapter: { en: "Chapter", el: "Κεφάλαιο" },
  chapters: { en: "chapters", el: "κεφάλαια" },
  sections: { en: "sections", el: "ενότητες" },
  hours: { en: "h study", el: "ώρες μελέτης" },
  outcomes: { en: "Learning outcomes", el: "Μαθησιακά αποτελέσματα" },
  outcomesLead: { en: "After studying this chapter you should be able to:", el: "Μετά τη μελέτη του κεφαλαίου θα πρέπει να μπορείτε:" },
  terms: { en: "Key terms", el: "Βασικοί όροι" },
  summary: { en: "Chapter summary", el: "Σύνοψη κεφαλαίου" },
  questions: { en: "Review questions", el: "Ερωτήσεις ανασκόπησης" },
  onThisPage: { en: "On this page", el: "Σε αυτή τη σελίδα" },
  prev: { en: "Previous", el: "Προηγούμενο" },
  next: { en: "Next", el: "Επόμενο" },
  search: { en: "Search the book…", el: "Αναζήτηση στο βιβλίο…" },
  noResults: { en: "No results", el: "Δεν βρέθηκαν αποτελέσματα" },
  start: { en: "Start reading", el: "Έναρξη ανάγνωσης" },
  viewReport: { en: "What changed and why", el: "Τι άλλαξε και γιατί" },
  parallel: { en: "Parallel", el: "Παράλληλα" },
  introduction: { en: "Introduction", el: "Εισαγωγή" },
  readTime: { en: "min read", el: "λεπτά ανάγνωσης" },
  words: { en: "words", el: "λέξεις" },
};

export type UIKey = keyof typeof S;
export const t = (k: UIKey, lang: Lang) => S[k][lang];
