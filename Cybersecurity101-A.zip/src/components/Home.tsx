import { ArrowRight, BookOpen, FileCode2, Languages, ShieldCheck, Sparkles } from "lucide-react";
import type { Lang } from "../content/types";
import { bookMeta, chapters, parts, preface } from "../content/book";
import { t } from "../i18n";
import { Inline } from "./Blocks";
import { chapterWords } from "./ChapterView";

export default function Home({ lang, go }: { lang: Lang; go: (h: string) => void }) {
  const totalWords = chapters.reduce((a, c) => a + chapterWords(c, "en") + chapterWords(c, "el"), 0);
  const stats = [
    { v: chapters.length, l: lang === "en" ? "revised chapters" : "αναθεωρημένα κεφάλαια" },
    { v: chapters.reduce((a, c) => a + c.sections.length, 0), l: lang === "en" ? "sections" : "ενότητες" },
    { v: `${Math.round(totalWords / 1000)}k`, l: lang === "en" ? "words (EN + ΕΛ)" : "λέξεις (EN + ΕΛ)" },
    { v: 2, l: lang === "en" ? "languages, one source" : "γλώσσες, μία πηγή" },
  ];

  return (
    <div className="fade-up">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[2rem] bg-slate-950 px-8 py-14 text-white shadow-2xl sm:px-14 sm:py-20">
        <div className="pointer-events-none absolute inset-0 opacity-40" style={{ backgroundImage: "radial-gradient(circle at 15% 20%, rgba(20,184,166,.45), transparent 40%), radial-gradient(circle at 85% 70%, rgba(245,158,11,.30), transparent 45%)" }} />
        <div className="pointer-events-none absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)", backgroundSize: "36px 36px" }} />
        <div className="relative max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-semibold text-teal-200">
            <Sparkles size={13} /> {bookMeta.edition[lang]}
          </div>
          <h1 className="mt-6 text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">{bookMeta.title[lang]}</h1>
          <p className="mt-4 text-lg text-slate-300 sm:text-xl">{bookMeta.subtitle[lang]}</p>
          <p className="mt-2 text-sm text-slate-400">{bookMeta.title[lang === "en" ? "el" : "en"]} · {bookMeta.author}</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <button onClick={() => go("ch-1")} className="inline-flex items-center gap-2 rounded-full bg-teal-500 px-6 py-3 text-sm font-bold text-slate-950 shadow-lg shadow-teal-500/30 transition hover:bg-teal-400">
              <BookOpen size={17} /> {t("start", lang)} <ArrowRight size={16} />
            </button>
            <button onClick={() => go("report")} className="inline-flex items-center gap-2 rounded-full border border-white/20 px-6 py-3 text-sm font-bold transition hover:bg-white/10">
              <ShieldCheck size={17} /> {t("viewReport", lang)}
            </button>
            <button onClick={() => go("latex")} className="inline-flex items-center gap-2 rounded-full border border-white/20 px-6 py-3 text-sm font-bold transition hover:bg-white/10">
              <FileCode2 size={17} /> LaTeX
            </button>
          </div>
        </div>
        <div className="relative mt-14 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {stats.map((s) => (
            <div key={s.l} className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur">
              <div className="text-3xl font-extrabold text-teal-300">{s.v}</div>
              <div className="mt-1 text-xs text-slate-400">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="mt-10 grid gap-4 md:grid-cols-3">
        {[
          { i: BookOpen, en: ["Explanatory academic prose", "Every chapter rewritten with introductions, worked examples, glossaries, summaries and review questions."], el: ["Επεξηγηματικός ακαδημαϊκός λόγος", "Κάθε κεφάλαιο ξαναγράφτηκε με εισαγωγή, παραδείγματα, γλωσσάριο, σύνοψη και ερωτήσεις ανασκόπησης."] },
          { i: Languages, en: ["Idiomatic Greek, not fragments", "Whole-paragraph Greek with consistent terminology — read it alone or in parallel with English."], el: ["Φυσικά ελληνικά, όχι αποσπάσματα", "Ενιαίες ελληνικές παράγραφοι με συνεπή ορολογία — μόνες τους ή παράλληλα με τα αγγλικά."] },
          { i: FileCode2, en: ["Editable LaTeX sources", "A complete XeLaTeX project (EN + ΕΛ) generated from the same content, ready for print."], el: ["Επεξεργάσιμα αρχεία LaTeX", "Πλήρες έργο XeLaTeX (EN + ΕΛ) από το ίδιο περιεχόμενο, έτοιμο για εκτύπωση."] },
        ].map((f, i) => (
          <div key={i} className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <f.i className="text-teal-600 dark:text-teal-400" size={22} />
            <h3 className="mt-3 font-bold">{f[lang][0]}</h3>
            <p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{f[lang][1]}</p>
          </div>
        ))}
      </section>

      {/* Parts & chapters */}
      <section className="mt-14 space-y-12">
        {parts.map((p) => {
          const chs = chapters.filter((c) => c.part === p.n);
          if (!chs.length) return null;
          return (
            <div key={p.n}>
              <div className="mb-5 flex flex-wrap items-end justify-between gap-2 border-b border-slate-200 pb-3 dark:border-slate-800">
                <div>
                  <div className="text-xs font-bold uppercase tracking-[0.2em] text-teal-600 dark:text-teal-400">{t("part", lang)} {p.n}</div>
                  <h2 className="text-2xl font-extrabold tracking-tight">{p.title[lang]}</h2>
                </div>
                <p className="max-w-md text-sm text-slate-500">{p.blurb[lang]}</p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {chs.map((c) => (
                  <button key={c.n} onClick={() => go(`ch-${c.n}`)} className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-6 text-left transition hover:-translate-y-0.5 hover:border-teal-400 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900">
                    <div className="flex items-center justify-between">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 font-mono text-sm font-bold text-teal-300 dark:bg-slate-800">{String(c.n).padStart(2, "0")}</span>
                      <span className="text-xs text-slate-400">{c.hours} {t("hours", lang)}</span>
                    </div>
                    <h3 className="mt-4 font-bold leading-snug group-hover:text-teal-700 dark:group-hover:text-teal-300">{c.title[lang]}</h3>
                    <p className="mt-2 line-clamp-2 text-sm text-slate-500">{c.subtitle[lang]}</p>
                    <div className="mt-auto flex items-center gap-2 pt-4 text-xs font-semibold text-slate-400">
                      {c.sections.length} {t("sections", lang)} · {c.level[lang]}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}

export function PrefaceView({ lang, fontSize }: { lang: Lang; fontSize: number }) {
  return (
    <article className="fade-up mx-auto max-w-3xl" style={{ fontSize }}>
      <div className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-teal-600">{bookMeta.title[lang]}</div>
      <h1 className="mb-8 text-4xl font-extrabold tracking-tight">{t("preface", lang)}</h1>
      <div className="prose-book text-slate-800 dark:text-slate-300">
        {preface[lang].map((p, i) => <p key={i}><Inline text={p} /></p>)}
      </div>
    </article>
  );
}
