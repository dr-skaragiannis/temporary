import { useEffect, useMemo, useRef, useState } from "react";
import {
  BookOpen,
  ChevronLeft,
  FileDown,
  GraduationCap,
  Library,
  Menu,
  Moon,
  Printer,
  Search,
  Sun,
  X,
} from "lucide-react";
import book1Html from "./assets/book1.html?raw";
import { chapters, figIndex, latexDoc, searchKeywords, tocItems } from "./dfir/book";
import { Preface, ReadingPaths } from "./dfir/frontmatter";
import { AuditBanner } from "./dfir/audit";
import { LinuxAppendix } from "./dfir/appendix-linux";
import { AttckMapAppendix, PlaybooksAppendix, TemplatesAppendix, ToolsAppendix } from "./dfir/appendix-c";
import { AppendixSection, FiguresGallery, ReferencesSection } from "./dfir/backmatter";
import { LabBox, QuizBox, WorkshopBox } from "./dfir/ui";

type Book = "dfir" | "fundamentals";

function useTheme() {
  const [dark, setDark] = useState(() =>
    typeof document !== "undefined" ? document.documentElement.classList.contains("dark") : false
  );
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("dfir_theme", next ? "dark" : "light");
    } catch {
      /* ignore */
    }
  };
  return { dark, toggle };
}

function TierBanner({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="mt-6 rounded-2xl overflow-hidden shadow-sm print-block">
      <div className="part-banner px-6 lg:px-8 py-5 text-white" style={{ background: "linear-gradient(120deg,#0f1c2e 0%,#1e3a5f 55%,#0e7490 100%)" }}>
        <div className="badge text-amber-300">Digital Forensics and Incident Response</div>
        <h3 className="text-xl lg:text-2xl font-black tracking-tight mt-1">{title}</h3>
        <p className="text-sm text-slate-300 mt-1 max-w-3xl">{desc}</p>
      </div>
    </div>
  );
}

const tierFor: Record<number, { title: string; desc: string } | undefined> = {
  1: { title: "Tier 1 · Foundations, Evidence Handling & Threat Baselines", desc: "Operate lawfully, preserve evidence perfectly, and model the adversary — before touching a suspect host." },
  4: { title: "Tier 2 · Host-Level Forensics and Endpoint Telemetry", desc: "Prove exactly what happened on the box: files, registry, execution, Sysmon, and memory." },
  8: { title: "Tier 3 · Core Infrastructure Services, Network Forensics & Log Telemetry", desc: "Follow the intrusion through AD, DNS, web, mail, and SSH — and prove it on the wire." },
  11: { title: "Tier 4 · Advanced Detection, Enterprise SIEM & Active Response", desc: "Correlate campaigns automatically, ship detections as code, evict adversaries, and report." },
};

function DfirReader({ fontSize }: { fontSize: number }) {
  const [active, setActive] = useState("preface");
  const [viewed, setViewed] = useState<Set<string>>(new Set(["preface"]));
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setActive(e.target.id);
            setViewed((v) => new Set(v).add(e.target.id));
          }
        }
      },
      { rootMargin: "-20% 0px -70% 0px" }
    );
    tocItems.forEach(([id]) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  const readPct = Math.round((chapters.filter((c) => viewed.has(c.id)).length / chapters.length) * 100);

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-slate-950 text-white no-print">
        <div className="absolute inset-0 hero-grid opacity-60"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900/90 to-cyan-950/80"></div>
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/20 blur-[100px] rounded-full"></div>
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-cyan-500/20 blur-[100px] rounded-full"></div>
        <div className="relative max-w-[1440px] mx-auto px-4 lg:px-8 py-12 lg:py-16 grid lg:grid-cols-[1fr_360px] gap-10 items-center">
          <div>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="badge bg-amber-500 text-slate-900 px-3 py-1 rounded-full">University Course Textbook</span>
              <span className="badge bg-white/10 border border-white/20 px-3 py-1 rounded-full">Book 2 · DFIR Series</span>
              <span className="badge bg-white/10 border border-white/20 px-3 py-1 rounded-full">Expert-audited · Beginner → Advanced</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black tracking-tight leading-[1.05]">
              Digital Forensics
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-cyan-300">&amp; Incident Response</span>
            </h1>
            <p className="mt-3 text-lg text-slate-300 font-medium">Enterprise Investigation and Active Defense</p>
            <p className="mt-4 text-slate-300/90 leading-relaxed max-w-3xl text-[15px]">
              A complete, classroom-ready textbook: <span className="text-white font-semibold">13 chapters in 4 tiers</span> —
              from lawful evidence handling and SOC operations through host forensics, infrastructure telemetry, SIEM
              correlation, and the capstone breach investigation. Every chapter ships a{" "}
              <span className="text-amber-300 font-bold">Technical Workshop, hands-on labs, and a graded quiz</span>,
              with 25 inline vector figures, a Linux forensics appendix, IR playbooks, and field-ready cheat sheets.
            </p>
            <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center"><div className="text-2xl font-black text-amber-300">13</div><div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold">Chapters</div></div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center"><div className="text-2xl font-black text-cyan-300">25</div><div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold">Vector figures</div></div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center"><div className="text-2xl font-black text-emerald-300">42</div><div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold">Labs + workshops</div></div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center"><div className="text-2xl font-black text-violet-300">83</div><div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold">Quiz questions</div></div>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#preface" className="px-5 py-3 rounded-xl bg-amber-500 text-slate-900 font-extrabold text-sm hover:bg-amber-400">Start reading →</a>
              <a href="#ch1" className="px-5 py-3 rounded-xl bg-white/10 border border-white/20 font-bold text-sm hover:bg-white/20">Skip to Chapter 1</a>
              <a href="#figures" className="px-5 py-3 rounded-xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-200 font-bold text-sm hover:bg-cyan-500/30">Browse Fig. 1–25</a>
            </div>
          </div>
          <div className="hidden lg:flex justify-center">
            <div className="cover3d w-[300px] rounded-2xl overflow-hidden bg-gradient-to-b from-slate-900 to-slate-800 border border-white/20">
              <div className="p-6 pb-4">
                <div className="badge text-amber-400">1st Edition · 2026 · Book 2</div>
                <h3 className="mt-2 font-black text-2xl leading-tight">DIGITAL FORENSICS<br />&amp; INCIDENT RESPONSE</h3>
                <p className="text-[11px] text-slate-400 mt-1 tracking-wide uppercase font-bold">Enterprise Investigation · Active Defense</p>
                <div className="mt-4 h-px bg-gradient-to-r from-amber-500 to-cyan-500"></div>
                <div className="mt-4 space-y-2 text-[11px] text-slate-300">
                  <div className="flex justify-between"><span>Tier I</span><span className="text-slate-400">Foundations & Evidence</span></div>
                  <div className="flex justify-between"><span>Tier II</span><span className="text-slate-400">Host & Endpoint</span></div>
                  <div className="flex justify-between"><span>Tier III</span><span className="text-slate-400">Infrastructure & Network</span></div>
                  <div className="flex justify-between"><span>Tier IV</span><span className="text-slate-400">SIEM & Response</span></div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="bg-white/5 rounded-lg p-2"><div className="font-black text-amber-300">13</div><div className="text-[9px] text-slate-400">Chapters</div></div>
                  <div className="bg-white/5 rounded-lg p-2"><div className="font-black text-cyan-300">25</div><div className="text-[9px] text-slate-400">Figures</div></div>
                  <div className="bg-white/5 rounded-lg p-2"><div className="font-black text-emerald-300">83</div><div className="text-[9px] text-slate-400">Quiz Qs</div></div>
                </div>
              </div>
              <div className="bg-amber-500 text-slate-900 text-center text-[11px] font-black py-2 tracking-widest">DFIR · COURSE BOOK 2</div>
            </div>
          </div>
        </div>
        <div className="relative border-t border-white/10 bg-black/30">
          <div className="max-w-[1440px] mx-auto px-4 lg:px-8 py-3 flex gap-2 overflow-x-auto text-xs font-bold">
            <a href="#ch1" className="whitespace-nowrap px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20">Tier I · Foundations & Evidence (Ch 1–3)</a>
            <a href="#ch4" className="whitespace-nowrap px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20">Tier II · Host & Endpoint (Ch 4–7)</a>
            <a href="#ch8" className="whitespace-nowrap px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20">Tier III · Infrastructure & Network (Ch 8–10)</a>
            <a href="#ch11" className="whitespace-nowrap px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20">Tier IV · SIEM & Response (Ch 11–13)</a>
          </div>
        </div>
      </section>

      <div id="layoutWrap" className={`max-w-[1440px] mx-auto px-4 lg:px-6 grid lg:grid-cols-[300px_1fr] gap-6 items-start ${collapsed ? "sidebar-collapsed" : ""}`}>
        {/* SIDEBAR */}
        <aside id="sidebar" className={`lg:sticky lg:top-[76px] max-h-[calc(100vh-90px)] overflow-y-auto py-6 no-print bg-[#f6f7f9] dark:bg-slate-950 ${mobileOpen ? "open" : ""}`}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-sm">
            <div className="px-2 py-1 flex items-center justify-between gap-2">
              <span className="font-black text-sm">Contents</span>
              <span className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-cyan-600">{readPct}% read</span>
                <button onClick={() => setCollapsed(true)} className="hidden lg:inline-flex no-print items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-extrabold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300" title="Minimize sidebar">
                  <ChevronLeft size={12} /> Hide
                </button>
                <button onClick={() => setMobileOpen(false)} className="lg:hidden p-1 rounded-lg" aria-label="Close contents">
                  <X size={16} />
                </button>
              </span>
            </div>
            <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full mx-2 mb-2 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-amber-500 to-cyan-500" style={{ width: `${readPct}%` }}></div>
            </div>
            <nav id="toc" className="space-y-1 text-[13px]">
              {tocItems.map(([id, label], i) => (
                <a
                  key={id}
                  href={`#${id}`}
                  onClick={() => setMobileOpen(false)}
                  className={`toc-link flex items-center px-2 py-1.5 rounded-lg font-semibold ${active === id ? "active" : "text-slate-600 dark:text-slate-300"}`}
                >
                  <span className="toc-step">{i + 1 > 24 ? "•" : i + 1}</span>
                  <span className="truncate">{label}</span>
                </a>
              ))}
            </nav>
            <div className="mt-3 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-[12px] leading-relaxed">
              <b>How to study.</b> Read the theory, run the workshop commands in your lab, complete both labs, then
              take the quiz. Do not skip ahead to the capstone — every chapter's evidence feeds it.
            </div>
          </div>
        </aside>
        {collapsed && (
          <button onClick={() => setCollapsed(false)} className="no-print fixed left-0 top-[38%] z-40 hidden lg:inline-flex items-center gap-2 px-3 py-2.5 rounded-r-xl bg-slate-900 dark:bg-amber-500 text-amber-400 dark:text-slate-900 font-extrabold text-xs shadow-lg" title="Show sidebar">
            <Menu size={14} /> Contents
          </button>
        )}

        {/* MAIN */}
        <main id="mainCol" className="py-6 min-w-0" style={{ fontSize }}>
          <Preface />
          <ReadingPaths />
          <AuditBanner />
          {chapters.map((c) => (
            <div key={c.id}>
              {tierFor[c.num] && <TierBanner title={tierFor[c.num]!.title} desc={tierFor[c.num]!.desc} />}
              <section id={c.id} className="chapter-sec mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
                <div className="p-6 lg:p-8 pb-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="badge bg-slate-900 dark:bg-amber-500 dark:text-slate-900 text-white px-3 py-1 rounded-full">Chapter {c.num}</span>
                    <span className="badge bg-violet-100 dark:bg-violet-900 text-violet-800 dark:text-violet-200 px-3 py-1 rounded-full">{c.badge}</span>
                    <span className="text-xs text-slate-500">⏱ {c.time}</span>
                  </div>
                  <h2 className="text-2xl lg:text-[28px] font-black tracking-tight mt-2">{c.title}</h2>
                  <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">{c.subtitle}</p>
                  <div className="mt-3 p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-900 text-sm">
                    <b>Chapter outcomes.</b> {c.outcomes}
                  </div>
                </div>
                <div className="p-6 lg:p-8 pt-4 prose-book serif">{c.body}</div>
                <div className="px-6 lg:px-8 pb-6 lg:pb-8 space-y-4">
                  <WorkshopBox num={c.num} ws={c.workshop} />
                  <LabBox title={c.labTitle}>{c.labsBody}</LabBox>
                  <QuizBox id={`q${c.num}`} num={c.num} questions={c.quiz} />
                </div>
              </section>
            </div>
          ))}
          <LinuxAppendix />
          <PlaybooksAppendix />
          <TemplatesAppendix />
          <AttckMapAppendix />
          <ToolsAppendix />
          <FiguresGallery />
          <ReferencesSection />
          <AppendixSection />
          <footer className="mt-6 text-center text-xs text-slate-500 pb-8">
            Digital Forensics and Incident Response · 1st Edition · 2026 · Interactive Textbook · 13 chapters · 25 figures · 83 quiz questions · Expert-audited
          </footer>
        </main>
      </div>
    </>
  );
}

export default function App() {
  const [book, setBook] = useState<Book>("dfir");
  const { dark, toggle } = useTheme();
  const [fontSize, setFontSize] = useState(16);
  const [query, setQuery] = useState("");
  const [showResults, setShowResults] = useState(false);
  const [latexOpen, setLatexOpen] = useState(false);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const pct = h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight);
      if (progressRef.current) progressRef.current.style.width = `${pct * 100}%`;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [book]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setLatexOpen(false);
        setShowResults(false);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const results = useMemo(() => {
    const v = query.toLowerCase().trim();
    if (v.length < 2) return [];
    const hits: { t: string; id: string; k: string }[] = [
      ...tocItems.filter((t) => t[1].toLowerCase().includes(v)).map((t): { t: string; id: string; k: string } => ({ t: t[1], id: t[0], k: "chapter" })),
      ...searchKeywords.filter((x) => x.t.toLowerCase().includes(v)).map((x) => ({ t: `${x.t.slice(0, 60)}…`, id: x.id, k: x.k })),
      ...figIndex.filter((f) => (f.n + " " + f.t).toLowerCase().includes(v)).map((f) => ({ t: `Fig. ${f.n} · ${f.t}`, id: f.anchor, k: "figure" })),
    ];
    return hits.slice(0, 14);
  }, [query]);

  const switchBook = (b: Book) => {
    setBook(b);
    setQuery("");
    setShowResults(false);
    window.scrollTo({ top: 0 });
  };

  const downloadLatex = () => {
    const blob = new Blob([latexDoc], { type: "text/x-tex" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "dfir-textbook-book.tex";
    a.click();
  };

  return (
    <div className="min-h-screen bg-[#f6f7f9] dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div ref={progressRef} id="progressBar" className="fixed top-0 left-0 h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-cyan-500 z-[100] no-print" style={{ width: "0%" }}></div>

      {/* TOP NAV */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/85 dark:bg-slate-950/85 border-b border-slate-200 dark:border-slate-800 no-print">
        <div className="max-w-[1440px] mx-auto px-4 lg:px-6 h-16 flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-slate-900 to-cyan-700 flex items-center justify-center text-white shrink-0">
              <Library size={18} />
            </div>
            <div className="min-w-0 hidden sm:block">
              <div className="font-extrabold text-[13px] lg:text-[15px] tracking-tight truncate">
                Textbook Library <span className="hidden md:inline text-slate-400 font-medium">· DFIR Series</span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">2 interactive books · 26 chapters</div>
            </div>
          </div>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded-full p-1 ml-1">
            <button
              onClick={() => switchBook("dfir")}
              className={`px-2.5 sm:px-3 py-1.5 rounded-full text-[11px] sm:text-xs font-extrabold inline-flex items-center gap-1.5 ${book === "dfir" ? "bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-900" : "text-slate-500 dark:text-slate-300"}`}
            >
              <BookOpen size={13} /> <span className="hidden sm:inline">Book 2 ·</span> DFIR
            </button>
            <button
              onClick={() => switchBook("fundamentals")}
              className={`px-2.5 sm:px-3 py-1.5 rounded-full text-[11px] sm:text-xs font-extrabold inline-flex items-center gap-1.5 ${book === "fundamentals" ? "bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-900" : "text-slate-500 dark:text-slate-300"}`}
            >
              <GraduationCap size={13} /> <span className="hidden sm:inline">Book 1 ·</span> Fundamentals
            </button>
          </div>
          <div className="flex-1"></div>
          {book === "dfir" && (
            <div className="hidden md:flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-full px-3 py-1.5 w-64 relative">
              <Search size={14} className="text-slate-400 shrink-0" />
              <input
                value={query}
                onChange={(e) => { setQuery(e.target.value); setShowResults(true); }}
                onFocus={() => setShowResults(true)}
                placeholder="Search chapters, figures, terms…"
                className="bg-transparent outline-none text-sm w-full placeholder:text-slate-400"
              />
            </div>
          )}
          <button onClick={toggle} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800" title="Theme" aria-label="Toggle theme">
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          {book === "dfir" && (
            <>
              <button onClick={() => setFontSize((f) => Math.min(19, f + 1))} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-bold" title="Larger">A+</button>
              <button onClick={() => setFontSize((f) => Math.max(14, f - 1))} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-bold" title="Smaller">A−</button>
              <button onClick={() => setLatexOpen(true)} className="hidden sm:inline-flex px-3 py-2 rounded-lg bg-slate-900 dark:bg-amber-500 dark:text-slate-900 text-white text-xs font-bold hover:opacity-90 items-center gap-1">
                <FileDown size={13} /> LaTeX
              </button>
            </>
          )}
          <button onClick={() => window.print()} className="px-3 py-2 rounded-lg bg-amber-500 text-slate-900 text-xs font-bold hover:bg-amber-400 inline-flex items-center gap-1">
            <Printer size={13} /> PDF
          </button>
        </div>
        {book === "dfir" && showResults && results.length > 0 && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 w-[92%] max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl p-2 max-h-[60vh] overflow-y-auto">
            {results.map((h, i) => (
              <a
                key={i}
                href={`#${h.id}`}
                onClick={() => { setShowResults(false); setQuery(""); }}
                className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-sm"
              >
                <span className="badge bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded">{h.k}</span>
                <span className="font-semibold truncate">{h.t}</span>
              </a>
            ))}
          </div>
        )}
      </header>

      {book === "dfir" ? (
        <DfirReader fontSize={fontSize} />
      ) : (
        <div className="no-print-none">
          <div className="bg-slate-950 text-white px-4 lg:px-8 py-4 flex flex-wrap items-center gap-3">
            <div>
              <div className="font-extrabold text-sm">Book 1 · Cybersecurity Fundamentals: Principles, Architectures, and Defensive Operations</div>
              <div className="text-xs text-slate-400">Original interactive textbook, preserved 1:1 below — search, quizzes, and labs fully functional.</div>
            </div>
          </div>
          <iframe title="Cybersecurity Fundamentals — Interactive Textbook" srcDoc={book1Html} className="w-full border-0 bg-white" style={{ height: "calc(100vh - 140px)", minHeight: 600 }} />
        </div>
      )}

      {/* LATEX MODAL */}
      {latexOpen && (
        <div className="fixed inset-0 z-[80] bg-black/60 flex items-center justify-center p-4" onClick={() => setLatexOpen(false)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 relative max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setLatexOpen(false)} className="absolute top-3 right-3 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Close">
              <X size={16} />
            </button>
            <h3 className="font-black text-lg">LaTeX Book Skeleton — DFIR</h3>
            <p className="text-xs text-slate-500 mt-1">Part/chapter structure mirroring this textbook, ready for print compilation.</p>
            <pre className="mono mt-3 text-[11px] leading-relaxed bg-slate-950 text-slate-100 rounded-xl p-4 overflow-auto flex-1 whitespace-pre-wrap">{latexDoc}</pre>
            <div className="mt-3 flex gap-2">
              <button onClick={downloadLatex} className="px-4 py-2 rounded-xl bg-amber-500 text-slate-900 text-sm font-extrabold hover:bg-amber-400 inline-flex items-center gap-1.5">
                <FileDown size={14} /> Download .tex
              </button>
              <button onClick={() => setLatexOpen(false)} className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm font-bold">Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
