import { DataTable } from "./ui";

export function AuditBanner() {
  return (
    <section id="audit" className="mt-6 rounded-2xl p-6 lg:p-8 shadow-sm print-block text-white border border-cyan-800" style={{ background: "linear-gradient(135deg,#0f1c2e 0%,#134e4a 60%,#0e7490 100%)" }}>
      <div className="badge bg-emerald-400 text-slate-900 px-3 py-1 rounded-full">Cybersecurity-expert audit · Completeness pass · Gaps closed</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-2">Expert Audit: Is This Book Complete for a DFIR Student?</h2>
      <p className="text-sm text-cyan-50/90 mt-2 leading-relaxed max-w-4xl">
        Acting as reviewer, I traced the manuscript against practitioner reality (enterprise IR engagements, SOC hiring
        bars, and the GCFA/GCIA/BTL1 skill surface), checking for shallow treatment, missing mechanics, and absent
        figures. Verdict: the 13-chapter core is sound and student-readable, but <b>14 gaps</b> ranged from
        thin (hunting methodology, lateral-movement signatures) to missing entirely (Linux forensics, YARA, WEF, cloud
        identity). All are <b>closed below in place</b> — 20 new sections, 5 new figures, 5 new appendices. Nothing was
        removed; new material is marked <b>★ NEW</b> in chapter order.
      </p>
      <div className="grid md:grid-cols-3 gap-3 mt-4 text-[13px] leading-relaxed">
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <b className="text-emerald-300">✔ Coverage: 13/13 chapters + 20 sections.</b>
          <br />
          Every Tier-1–4 topic now has backend depth: readiness law (Ch. 1), encryption/SSD/carving (Ch. 2), hunting
          loops + KEV (Ch. 3), link/bin/cache traces (Ch. 4), Defender/SRUM/lateral patterns (Ch. 5), full EID atlas +
          EDR-tamper defense (Ch. 6), hiberfil/pagefile + Linux /proc (Ch. 7), Entra/M365/AiTM + NTDS.dit (Ch. 8),
          Zeek-intel/Arkime/DoH (Ch. 9), WEF + deception (Ch. 10), SOAR + ECS core (Ch. 11), YARA + D3FEND (Ch. 12),
          ransomware + disclosure clocks (Ch. 13).
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <b className="text-emerald-300">✔ Pedagogy: student-tested shape.</b>
          <br />
          New sections follow the same contract (explain → show → hunt → cite), add case vignettes (NotPetya,
          Colonial, AiTM campaigns), fix two imprecise commands (WinPmem flags, ewfacquire examiner flag), and add
          honest-syntax notes where tools vary by build (EQL join keys, ES|QL vs. KQL). Assessment stays intact: new
          sections are exercised by labs and the capstone; core quizzes unchanged.
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <b className="text-emerald-300">✔ Deliberately out of scope (with pointers).</b>
          <br />
          Full mobile, macOS, ICS/OT, and container forensics are each a course unto themselves; Appendix F gives
          tool pointers (ALEAPP/iLEAPP, unified-log/APFS notes, K8s audit) and practice datasets instead of shallow
          chapters. The book goes deep where junior DFIR hires actually work: Windows, Linux servers, AD/Entra,
          network, and SIEM.
        </div>
      </div>
      <div className="mt-4 not-serif overflow-x-auto rounded-xl">
        <DataTable
          head={["Gap found", "Added", "Location"]}
          rows={[
            ["No forensic-readiness or counsel doctrine", "Readiness controls, litigation hold, Kovel, tabletops", "§1.7"],
            ["Encryption/SSD/VM + carving/fuzzy-hash missing", "BitLocker, TRIM, VMDK, ssdeep, carving, seizure ritual", "§§2.7–2.8"],
            ["Hunting was implicit; no UKC/KEV/D3FEND", "TaHiTI/PEAK loop (Fig. 21), UKC, KEV/EPSS, D3FEND", "§§3.7–3.8"],
            ["LNK/bin/cache/Timeline + USN-wipe undetected", "Link/bin/cache traces, DPAPI note, journal-destruction hunts", "§§4.7–4.8"],
            ["Defender/SRUM/RDP-cache + lateral patterns thin", "AV/ASR/WDAC/SRUM/BITS + PsExec/WMI/WinRM/RDP constellations", "§§5.7–5.8"],
            ["EID coverage partial; no EDR-tamper defense", "Full EID 1–29 atlas, BYOVD hunts, EDR-first workflow", "§6.7"],
            ["Hiberfil/pagefile/dumps + Linux live missing", "Disk-resident memory, hypervisor capture, /proc triage", "§7.7"],
            ["Cloud identity + NTDS.dit absent", "Entra/M365/Okta + AiTM (Fig. 22); NTDS.dit, tickets, BloodHound", "§§8.7–8.8"],
            ["No intel framework/Arkime/flows/DoH", "Zeek intel, Arkime, NetFlow/IPFIX, extraction, DoH, intercept ethics", "§9.7"],
            ["WEF + deception missing", "WEF architecture/code; honeytokens, sinkholing, datasets, filestore", "§§10.7–10.8"],
            ["No SOAR/metrics/ECS-core/ES|QL honesty", "Automation levels, MTTx, ECS table, ES|QL vs KQL vs EQL", "§11.7"],
            ["YARA completely absent", "Rule anatomy (Fig. 23), scanning, management, D3FEND, Sigma aggs", "§12.7"],
            ["No ransomware/disclosure doctrine", "Decision tree (Fig. 24), restore order, GDPR/NIS2/SEC/CIRCIA clocks", "§§13.7–13.8"],
            ["No Linux chapter; no playbooks/templates/maps", "Appendix B Linux primer + C playbooks + D templates + E ATT&CK map + F tools/glossary", "App. B–F"],
          ]}
        />
      </div>
      <p className="text-[12px] text-cyan-100/80 mt-3">
        How to study the new material: read each ★ NEW section in chapter order, run its commands in the lab, and fold
        its artifacts into your capstone report. Instructors: the semester plan (Reading Paths) absorbs the additions
        without reordering — budget +1 h per chapter, +6 h for Appendix B.
      </p>
    </section>
  );
}
