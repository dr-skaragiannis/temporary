import { Callout, CodeBlock, DataTable, Figure, LabBox, QuizBox, WorkshopBox } from "./ui";

export function LinuxAppendix() {
  return (
    <section id="appendix-linux" className="chapter-sec mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
      <div className="p-6 lg:p-8 pb-0">
        <div className="flex flex-wrap items-center gap-2">
          <span className="badge bg-slate-900 dark:bg-amber-500 dark:text-slate-900 text-white px-3 py-1 rounded-full">Appendix B ★ NEW</span>
          <span className="badge bg-violet-100 dark:bg-violet-900 text-violet-800 dark:text-violet-200 px-3 py-1 rounded-full">Audit addition · Server forensics</span>
          <span className="text-xs text-slate-500">⏱ 6–8 h · ~30 pages equiv.</span>
        </div>
        <h2 className="text-2xl lg:text-[28px] font-black tracking-tight mt-2">Linux Host Forensics Primer</h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">ext4 · journald/auditd · Persistence map · /proc triage · Services & containers</p>
        <div className="mt-3 p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-900 text-sm">
          <b>Appendix outcomes.</b> Recover files and timelines from ext4; exploit journald, auditd, and accounting
          logs; audit Linux persistence systematically; triage live hosts via /proc; scope service and container
          compromises.
        </div>
      </div>
      <div className="p-6 lg:p-8 pt-4 prose-book serif">
        <h4>B.1 Why Linux decides server investigations</h4>
        <p>
          Enterprise servers, cloud instances, appliances, and containers overwhelmingly run Linux — so the web,
          mail-relay, DNS, and database compromises of Ch. 8 usually end at a Linux prompt. The good news: Linux
          forensics is <i>transparent</i> (plain-text configs, queryable journals, /proc truth) and <i>tool-rich</i>{" "}
          (debugfs, journalctl, ausearch, Volatility Linux plugins). The mindset transfers directly from Windows
          chapters: prove execution, audit persistence, fuse host with network — only the artifact names change.
        </p>
        <h4>B.2 ext4: inodes, journals, and deleted recovery</h4>
        <p>
          ext4 files are <b>inodes</b> (metadata + block pointers) referenced by directory entries; deletion unlinks the
          name while the inode and blocks persist until reused — the same "deleted ≠ gone" principle as the MFT. The{" "}
          <b>journal (jbd2)</b> records metadata transactions for crash recovery and, forensically, replays recent
          creates/deletes/renames like a mini-$LogFile. Timestamps come in four: <b>atime/mtime/ctime</b> plus{" "}
          <b>crtime (btime)</b> birth time via statx — ctime (inode-change) is the timestomp-resistant anchor, since
          normal tools cannot set it arbitrarily. Recovery tooling: <span className="mono text-sm">debugfs</span>{" "}
          (inode surgery), <span className="mono text-sm">extundelete/ext4magic</span> (undelete automation), and{" "}
          <span className="mono text-sm">tune2fs -l</span> (filesystem biography: mount count, last check, features).
        </p>
        <h4>B.3 Logs that matter</h4>
        <p>
          Linux logging is layered and redundant — an attacker's cleanup must defeat <i>all</i> layers to go dark,
          which almost never happens. <b>journald</b> (<span className="mono text-sm">journalctl</span>) centralizes
          service + kernel + auth streams with structured fields and (optionally) Forward Secure Sealing for tamper
          evidence. <b>auditd</b> (<span className="mono text-sm">ausearch -k</span>) is the syscall-level witness:
          execve, file opens, and permission changes with keys you define. Around them orbit <b>auth.log/secure</b>{" "}
          (Ch. 8), <b>wtmp/btmp/lastlog</b> (successful/failed logins), <b>cron</b> logs, <b>shell histories</b>{" "}
          (per-user, attacker-edited — compare against auditd execve for the lie), and <b>package-manager logs</b>{" "}
          (dpkg/yum histories expose backdoored installs).
        </p>
        <DataTable
          head={["Log", "Query", "Catches"]}
          rows={[
            ["journald", "journalctl -u sshd --since '2026-09-20' -o verbose", "Service-scoped timelines with _PID/_EXE/_CMDLINE"],
            ["auditd", "ausearch -k execution --start recent", "Every execve incl. attacker-deleted binaries"],
            ["wtmp / btmp", "last / lastb", "Successful vs. failed logins (spray vs. success)"],
            ["shell history", "cat ~user/.bash_history + HISTTIMEFORMAT", "Typed commands — verify against auditd"],
            ["dpkg / yum log", "grep -i install /var/log/dpkg.log", "Backdoor packages + dependency confusion"],
          ]}
        />
        <h4>B.4 Persistence map</h4>
        <p>
          Linux persistence is a broad, shallow sea (Fig. 25) — audit top-down by prevalence. <b>Cron/at + systemd
          timers</b> catch scheduled tradecraft; <b>systemd units</b> (system + user, enabled + static + masked states)
          catch service persistence; <b>shell startup</b> (profile.d, bashrc, rc.local) catches interactive shells;{" "}
          <b>SSH keys</b> (<span className="mono text-sm">authorized_keys</span> fleet-wide) catch the most common
          server persistence of all; <b>LD_PRELOAD</b> (/etc/ld.so.preload) catches syscall-interception rootkits;{" "}
          <b>kernel modules</b> catch the deepest footholds. Depth items for second-pass audits: udev rules, package
          hooks (APT::Update::Pre-Invoke), inetd/xinetd, and MOTD scripts.
        </p>
        <Figure
          id="fig-linux-persist"
          label="Fig. 25 · Linux persistence map (vector) ★ NEW"
          caption={
            <>
              <b>Fig. 25.</b> Audit top-down like Fig. 8: timers and units first, kernel last. Every entry names its
              on-disk home so dead-box examiners know which paths to diff against gold images.
            </>
          }
        >
          <svg viewBox="0 0 720 240" className="w-full h-auto" role="img" aria-label="Linux persistence map">
            <g fontSize="10.5" fontWeight="700" textAnchor="middle">
              <rect x="10" y="10" width="225" height="96" rx="8" fill="#be123c" />
              <text x="122" y="30" fill="#fff">CRON / AT + TIMERS</text>
              <text x="122" y="47" fill="#ffe4e6" fontWeight="400">/etc/cron* · spool</text>
              <text x="122" y="63" fill="#ffe4e6" fontWeight="400">systemd *.timer</text>
              <text x="122" y="82" fill="#fff" fontSize="9">check FIRST</text>
              <rect x="247" y="10" width="226" height="96" rx="8" fill="#b45309" />
              <text x="360" y="30" fill="#fff">SYSTEMD UNITS</text>
              <text x="360" y="47" fill="#fef3c7" fontWeight="400">/etc/systemd/system</text>
              <text x="360" y="63" fill="#fef3c7" fontWeight="400">+ ~/.config/systemd</text>
              <text x="360" y="82" fill="#fff" fontSize="9">enabled? masked?</text>
              <rect x="485" y="10" width="225" height="96" rx="8" fill="#0e7490" />
              <text x="597" y="30" fill="#fff">SHELL STARTUP</text>
              <text x="597" y="47" fill="#e0f2fe" fontWeight="400">profile.d · bashrc</text>
              <text x="597" y="63" fill="#e0f2fe" fontWeight="400">rc.local · motd</text>
              <text x="597" y="82" fill="#fff" fontSize="9">per-user + global</text>
              <rect x="10" y="114" width="225" height="88" rx="8" fill="#7c3aed" />
              <text x="122" y="134" fill="#fff">SSH KEYS</text>
              <text x="122" y="151" fill="#ede9fe" fontWeight="400">~/.ssh/authorized_keys</text>
              <text x="122" y="167" fill="#ede9fe" fontWeight="400">fleet-wide sweep</text>
              <text x="122" y="186" fill="#fff" fontSize="9">#1 server persist</text>
              <rect x="247" y="114" width="226" height="88" rx="8" fill="#166534" />
              <text x="360" y="134" fill="#fff">LD_PRELOAD / LD.SO</text>
              <text x="360" y="151" fill="#dcfce7" fontWeight="400">/etc/ld.so.preload</text>
              <text x="360" y="167" fill="#dcfce7" fontWeight="400">+ env hijacks</text>
              <text x="360" y="186" fill="#fff" fontSize="9">userland rootkits</text>
              <rect x="485" y="114" width="225" height="88" rx="8" fill="#0f1c2e" />
              <text x="597" y="134" fill="#fbbf24">KERNEL MODULES</text>
              <text x="597" y="151" fill="#cbd5e1" fontWeight="400">lsmod vs. known-good</text>
              <text x="597" y="167" fill="#cbd5e1" fontWeight="400">modules-load.d</text>
              <text x="597" y="186" fill="#fbbf24" fontSize="9">deepest foothold</text>
            </g>
            <text x="360" y="224" textAnchor="middle" fontSize="11" fill="#64748b">Diff against gold images; any delta on a server is a finding until proven patch activity</text>
          </svg>
        </Figure>
        <h4>B.5 Live triage via /proc (and memory)</h4>
        <p>
          §7.7's /proc triad (deleted-exe, memfd, LD_PRELOAD) extends to a full pass: open deleted handles, full socket
          inventory with PIDs, mount table review (unexpected tmpfs/overlay mounts hide payloads), and process-environ
          sweeps. Capture RAM with LiME/AVML (§7.2) and analyze with Volatility's Linux plugins (
          <span className="mono text-sm">linux.pslist/pstree/lsof/bash</span>). Collection order mirrors Fig. 11:
          RAM → /proc snapshot → logs → disk — with output to external media, hashed immediately.
        </p>
        <div className="not-serif">
          <CodeBlock
            title="Bash — Linux persistence + triage sweep (read-only)"
            code={`# Persistence sweep (Fig. 25, top four rows)\nls -la /etc/cron* /var/spool/cron/ 2>/dev/null; systemctl list-timers --all\nsystemctl list-unit-files --state=enabled | head -n 30\ncat /etc/ld.so.preload 2>/dev/null; find /home /root -name authorized_keys -exec cat {} \\;\n# Live triage additions: mounts + deleted handles\ncat /proc/mounts | grep -Ev 'cgroup|proc |sysfs'; ls -l /proc/[0-9]*/fd 2>/dev/null | grep deleted`}
          />
        </div>
        <h4>B.6 Services, containers, and scope edges</h4>
        <p>
          Web and SSH forensics (§§8.4, 8.6) apply directly; add <b>docker</b> awareness for containerized estates:{" "}
          <span className="mono text-sm">docker ps -a</span> (rogue containers), <span className="mono text-sm">docker diff</span>{" "}
          (container filesystem deltas vs. image — the container's "timeline"), and daemon + K8s audit logs for
          orchestration-level actions. Scope edge cases: compromised images (rebuild from trusted registries, verify
          digests), mounted host paths (container→host escape review), and secrets in env/image layers (rotate
          everything the container could read). Full Kubernetes forensics is beyond this primer — treat the K8s audit
          log as your starting exhibit and escalate deliberately.
        </p>
        <Callout color="emerald">
          <b>Linux maxim.</b> Diff, don't eyeball: gold-image comparison for persistence, auditd for execution truth,
          and /proc for live state. The artifacts differ from Windows; the discipline is identical.
        </Callout>
      </div>
      <div className="px-6 lg:px-8 pb-6 lg:pb-8 space-y-4">
        <WorkshopBox
          num="B"
          ws={{
            title: "Linux triage in 30 minutes: persistence sweep + live state",
            env: ["Linux lab VM (snapshot!)", "Gold-image file list", "External evidence USB"],
            tabs: [
              {
                id: "persist",
                label: "Persistence sweep",
                steps: [
                  {
                    n: "1",
                    title: "Sweep timers, units, and shell startup",
                    desc: "Fig. 25 rows 1–3: anything not in the gold image is guilty until proven patch.",
                    code: [
                      {
                        title: "Bash — scheduled + service persistence",
                        text: `ls -la /etc/cron.d/ /etc/cron.daily/ /var/spool/cron/crontabs/ 2>/dev/null\nsystemctl list-timers --all --no-pager\nsystemctl list-unit-files --state=enabled --no-pager | tee /mnt/usb/units.txt\ngrep -r "curl\|wget\|bash -i\|python3 -c" /etc/cron* /etc/systemd/system/ 2>/dev/null`,
                      },
                    ],
                    expected: "short list of non-vendor timers/units — each becomes a scoped lead",
                  },
                  {
                    n: "2",
                    title: "Sweep SSH keys and LD_PRELOAD",
                    desc: "The two quietest persistence primitives: no process, no log, just access.",
                    code: [
                      {
                        title: "Bash — keys + preload",
                        text: `find /home /root -name "authorized_keys" -exec echo "== {}" \\; -exec cat {} \\;\ncat /etc/ld.so.preload 2>/dev/null || echo "no global preload"\nls -la /etc/ld.so.conf.d/`,
                      },
                    ],
                  },
                ],
              },
              {
                id: "live",
                label: "Live triage",
                steps: [
                  {
                    n: "3",
                    title: "Run the /proc triad + sockets",
                    desc: "§7.7 triad plus full socket inventory — the live-state snapshot.",
                    code: [
                      {
                        title: "Bash — live snapshot",
                        text: `ls -l /proc/[0-9]*/exe 2>/dev/null | grep deleted | tee /mnt/usb/deleted-exe.txt\ngrep -l "memfd:" /proc/[0-9]*/maps 2>/dev/null | tee /mnt/usb/memfd.txt\nss -tunap 2>/dev/null | tee /mnt/usb/sockets.txt | head -n 30\nsha256sum /mnt/usb/*.txt | tee /mnt/usb/triage.sha256`,
                      },
                    ],
                    expected: "hashed snapshot set; any deleted-exe or memfd hit escalates to memory capture",
                  },
                ],
              },
            ],
            note: (
              <>
                <b>Concept map:</b> persistence map (§B.4) · /proc triage (§B.5) → memory analysis (Ch. 7) → SIEM
                correlation (Ch. 11). Deliverable: hashed sweep outputs plus a persistence verdict table.
              </>
            ),
          }}
        />
        <LabBox title="Hands-on Lab B.1 · Persistence audit + Lab B.2 · Linux breach timeline">
          <h4 className="font-extrabold">Lab B.1 · Persistence audit (60 min)</h4>
          <ol className="list-decimal ml-5 mt-1 space-y-1">
            <li>Sweep all six Fig. 25 rows on a provided image; diff against the gold manifest.</li>
            <li>Classify every delta: patch activity / admin action / malicious / unknown — with evidence.</li>
            <li>Remove nothing yet: write the eradication order (what, in what sequence, with what verification).</li>
          </ol>
          <h4 className="font-extrabold mt-3">Lab B.2 · Linux breach timeline (75 min)</h4>
          <ol className="list-decimal ml-5 mt-1 space-y-1">
            <li>Fuse journald + auditd + auth.log + wtmp into one UTC timeline for the incident window.</li>
            <li>Identify initial access, persistence install, and first C2 — one log citation per hop.</li>
            <li>Deliver the host-findings section: timeline, persistence table, and scope statement.</li>
          </ol>
        </LabBox>
        <QuizBox
          id="qb-linux"
          num="B"
          questions={[
            { q: "ext4 ctime is the timestomp-resistant anchor because:", o: ["It is encrypted", "Normal tools cannot set it arbitrarily — it tracks inode changes", "It is stored off-disk", "It never updates"], a: 1, e: "mtime/atime are settable; ctime follows metadata changes." },
            { q: "auditd's unique value over shell history is:", o: ["Prettier output", "Kernel-level execve records that survive history-file edits", "Faster queries", "No disk use"], a: 1, e: "Attackers edit .bash_history; they rarely defeat auditd too." },
            { q: "/proc/812/exe pointing to '(deleted)' indicates:", o: ["Normal systemd behavior", "A running-but-unlinked binary — fileless or self-deleting tradecraft", "A printer job", "Disk full"], a: 1, e: "Live code with no disk path is the fileless tell." },
            { q: "The most common Linux server persistence to sweep fleet-wide is:", o: ["Kernel modules", "Rogue authorized_keys entries", "Wallpaper changes", "Browser cookies"], a: 1, e: "Planted SSH keys are quiet, reliable, and everywhere." },
            { q: "docker diff in an investigation shows:", o: ["Image download speed", "Container filesystem changes vs. its image — the container timeline", "CPU usage", "Registry passwords"], a: 1, e: "Deltas reveal dropped tools, edited configs, and staged loot." },
          ]}
        />
      </div>
    </section>
  );
}
