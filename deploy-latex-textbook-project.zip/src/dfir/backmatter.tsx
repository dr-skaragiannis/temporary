import { useMemo, useState } from "react";
import { ExternalLink, Images, ScrollText, X } from "lucide-react";
import { figIndex, REFS, type FigEntry } from "./book";
import { CodeBlock, DataTable } from "./ui";

export function FiguresGallery() {
  const [q, setQ] = useState("");
  const [ch, setCh] = useState("");
  const [open, setOpen] = useState<FigEntry | null>(null);
  const chs = useMemo(() => [...new Set(figIndex.map((f) => f.ch))], []);
  const list = figIndex.filter(
    (f) =>
      (!ch || f.ch === ch) &&
      (!q || (f.n + " " + f.t + " " + f.cap).toLowerCase().includes(q.toLowerCase()))
  );
  return (
    <section id="figures" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300 inline-flex items-center gap-1.5">
        <Images size={13} /> Figure gallery · <span id="figCount">{list.length}</span> / {figIndex.length} shown
      </div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Figure Index (Fig. 1–25)</h2>
      <p className="text-sm text-slate-500 mt-1">All figures are inline vector diagrams rendered at chapter position. Search or filter, then click any card for its teaching caption.</p>
      <div className="flex flex-col sm:flex-row gap-2 mt-3 no-print">
        <input
          id="figSearch"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search figures, e.g. beacon, MFT, Sigma…"
          className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none placeholder:text-slate-400"
        />
        <select
          id="figChFilter"
          value={ch}
          onChange={(e) => setCh(e.target.value)}
          className="bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none"
        >
          <option value="">All chapters</option>
          {chs.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>
      <div id="figGrid" className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3 mt-4">
        {list.map((f) => (
          <button
            key={f.n}
            onClick={() => setOpen(f)}
            className="text-left p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:border-cyan-400 hover:shadow-md transition group"
          >
            <div className="fig-thumb mb-2 relative">
              <svg viewBox="0 0 200 90" className="w-full h-full">
                <rect x="8" y="10" width="184" height="70" rx="8" fill="none" stroke="#94a3b8" strokeDasharray="5 4" strokeWidth="1.5" />
                <text x="100" y="42" textAnchor="middle" fontSize="15" fontWeight="800" fill="#0e7490">Fig. {f.n}</text>
                <text x="100" y="60" textAnchor="middle" fontSize="8" fill="#64748b">{f.ch} · vector inline</text>
              </svg>
              <span className="absolute top-2 right-2 text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500 text-white">INLINE VECTOR</span>
            </div>
            <div className="text-[13px] font-bold leading-snug group-hover:text-cyan-700 dark:group-hover:text-cyan-300">Fig. {f.n} · {f.t}</div>
            <div className="text-[11px] text-slate-500 mt-1">{f.ch} — click for educational caption</div>
          </button>
        ))}
        {list.length === 0 && <div className="text-sm text-slate-500 p-4">No figures match.</div>}
      </div>
      {open && (
        <div className="fixed inset-0 z-[80] bg-black/60 flex items-center justify-center p-4" onClick={() => setOpen(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 relative" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setOpen(null)} className="absolute top-3 right-3 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Close">
              <X size={16} />
            </button>
            <div className="badge text-cyan-700 dark:text-cyan-300">{open.ch} · Regenerated as inline vector diagram</div>
            <h3 className="font-black text-lg mt-1">Fig. {open.n} · {open.t}</h3>
            <p className="text-sm mt-2 leading-relaxed text-slate-600 dark:text-slate-300">{open.cap}</p>
            <div className="mt-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs leading-relaxed">
              <b>How to teach it.</b> Project the inline vector figure; ask students to (1) restate the mechanism in
              one sentence, (2) name one control or hunt it enables, (3) map it to ATT&amp;CK and the NIST lifecycle.
            </div>
            <a href={`#${open.anchor}`} onClick={() => setOpen(null)} className="mt-3 inline-flex items-center gap-1 text-sm font-bold text-cyan-700 dark:text-cyan-300">
              <ExternalLink size={14} /> Jump to Fig. {open.n} in {open.ch}
            </a>
          </div>
        </div>
      )}
    </section>
  );
}

export function ReferencesSection() {
  return (
    <section id="references" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300 inline-flex items-center gap-1.5">
        <ScrollText size={13} /> APA 7th · Standards + peer-reviewed
      </div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">References</h2>
      <ol id="refList" className="mt-3 space-y-2 text-[13.5px] leading-relaxed list-none">
        {REFS.map((r, i) => (
          <li key={i} className="pl-1" dangerouslySetInnerHTML={{ __html: `<span class="font-black text-slate-900 dark:text-white">[${i + 1}]</span> ${r}` }} />
        ))}
      </ol>
    </section>
  );
}

export function AppendixSection() {
  return (
    <section id="appendix" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-amber-600 dark:text-amber-400">Appendix · Print me for the lab bench</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Field Cheat Sheets</h2>

      <h4 className="font-extrabold mt-4">A.1 Windows Event ID quick reference</h4>
      <DataTable
        head={["ID", "Channel", "Meaning", "Hunt"]}
        rows={[
          ["4624 / 4625", "Security", "Logon success / failure + type", "Type 3/10 from first-seen sources"],
          ["4672", "Security", "Special privileges at logon", "New accounts/hosts in 4672 stream"],
          ["4688", "Security", "Process created", "Fuse with Sysmon EID 1; needs cmdline policy"],
          ["4720 / 4732", "Security", "Account created / group add", "Backdoor accounts + caller process"],
          ["1102", "Security", "Audit log cleared", "Immediate SEV-1; check SIEM copy"],
          ["7045", "System", "Service installed", "Persistence installs; ImagePath review"],
          ["4768 / 4769 / 4771", "Security (DC)", "TGT / service ticket / pre-auth fail", "Roast, DCSync recon, spray"],
          ["4662", "Security (DC)", "DS object access", "Non-DC + replication GUID = DCSync"],
          ["4104", "PowerShell", "ScriptBlock text", "Deobfuscated payloads incl. -enc"],
          ["Sysmon 1/3/10/22", "Sysmon", "Proc / net / access / DNS", "Trees, sockets→procs, lsass, C2 domains"],
        ]}
      />

      <h4 className="font-extrabold mt-4">A.2 Volatility 3 triage order</h4>
      <div className="not-serif">
        <CodeBlock
          title="Bash — memorize this sequence"
          code={`vol -f mem.raw windows.info && vol -f mem.raw windows.pstree\nvol -f mem.raw windows.psscan        # vs pslist: hidden hunt\nvol -f mem.raw windows.malfind        # injected code\nvol -f mem.raw windows.netscan        # sockets at capture\nvol -f mem.raw windows.hashdump       # credential scope`}
        />
      </div>

      <h4 className="font-extrabold mt-4">A.3 Network triage one-liners</h4>
      <div className="not-serif">
        <CodeBlock
          title="Bash — tshark + Zeek"
          code={`tshark -r c.pcap -q -z conv,ip | head -n 25\ntshark -r c.pcap -Y "dns.flags.response==0" -T fields -e dns.qry.name | sort | uniq -c | sort -rn | head\ncat conn.log | zeek-cut id.orig_h id.resp_h id.resp_p duration orig_bytes resp_bytes | awk '$4>300' | head\ncat ssl.log | zeek-cut id.orig_h ja3 SNI | sort | uniq -c | sort -n | head`}
        />
      </div>

      <h4 className="font-extrabold mt-4">A.4 T-hour eviction checklist</h4>
      <DataTable
        head={["When", "Action", "Verify"]}
        rows={[
          ["T-60", "Freeze scope (hosts/users/IPs) + dry-run all scripts", "Scope hash recorded"],
          ["T-0", "Simultaneous isolate + firewall/proxy blocks + account disables", "Eviction log, UTC per action"],
          ["T+30", "krbtgt reset #1, OAuth revocation, SPN rotation", "Helpdesk + comms plan active"],
          ["T+36h", "krbtgt reset #2 (after 2× lifetime + replication)", "All tickets invalidated"],
          ["T+72h", "Verification hunts (4768/69/4624, beacons, persistence)", "Silence = success; hits = re-scope"],
          ["T+5d", "Post-mortem + technical/executive reports + shipped detections", "Actions owned + dated"],
        ]}
      />
    </section>
  );
}
