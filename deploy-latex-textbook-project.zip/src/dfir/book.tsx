import type { Chapter } from "./ui";
import { ch01 } from "./chapters/ch01";
import { ch02 } from "./chapters/ch02";
import { ch03 } from "./chapters/ch03";
import { ch04 } from "./chapters/ch04";
import { ch05 } from "./chapters/ch05";
import { ch06 } from "./chapters/ch06";
import { ch07 } from "./chapters/ch07";
import { ch08 } from "./chapters/ch08";
import { ch09 } from "./chapters/ch09";
import { ch10 } from "./chapters/ch10";
import { ch11 } from "./chapters/ch11";
import { ch12 } from "./chapters/ch12";
import { ch13 } from "./chapters/ch13";

export const chapters: Chapter[] = [
  ch01, ch02, ch03, ch04, ch05, ch06, ch07,
  ch08, ch09, ch10, ch11, ch12, ch13,
];

export const tocItems: [string, string][] = [
  ["preface", "Preface & How to Use"],
  ["reading-paths", "Reading Paths"],
  ["audit", "Expert Audit & Gap Closure"],
  ...chapters.map((c): [string, string] => [c.id, `Ch ${c.num} · ${c.title.split(":")[0].split("—")[0].trim()}`]),
  ["appendix-linux", "App. B · Linux Forensics"],
  ["playbooks", "App. C · IR Playbooks"],
  ["templates", "App. D · Field Templates"],
  ["attck-map", "App. E · ATT&CK Map"],
  ["tools", "App. F · Tools & Glossary"],
  ["figures", "Figure Gallery"],
  ["references", "References"],
  ["appendix", "Field Cheat Sheets"],
];

export interface FigEntry {
  n: string;
  ch: string;
  t: string;
  vec: boolean;
  cap: string;
  anchor: string;
}

export const figIndex: FigEntry[] = [
  { n: "1", ch: "Ch 1", t: "NIST SP 800-61 IR Lifecycle", vec: true, cap: "Fig. 1. Prepare → Detect/Analyze → Contain/Recover → Learn, with the operational feedback loop that rewrites preparation after every incident.", anchor: "fig-nist-lifecycle" },
  { n: "2", ch: "Ch 1", t: "SOC Escalation Ladder with SLAs", vec: true, cap: "Fig. 2. Tier 1→2→3→Commander flow with SEV SLAs; tuned runbooks flow back down so Tier 1 resolves more over time.", anchor: "fig-soc-ladder" },
  { n: "3", ch: "Ch 2", t: "Order of Volatility Pyramid (RFC 3227)", vec: true, cap: "Fig. 3. Collect top-down: registers/cache first, archives last. The power boundary marks what a shutdown destroys.", anchor: "fig-volatility" },
  { n: "4", ch: "Ch 2", t: "Acquisition Integrity Chain", vec: true, cap: "Fig. 4. The four-hash ritual: hash source, image, hash image, work on copies. Mismatch at any gate quarantines the exhibit.", anchor: "fig-hash-chain" },
  { n: "5", ch: "Ch 3", t: "Diamond Model of Intrusion Analysis", vec: true, cap: "Fig. 5. Adversary–capability–infrastructure–victim pivots: every new indicator implies connected entities worth hunting.", anchor: "fig-diamond" },
  { n: "6", ch: "Ch 3", t: "Pyramid of Pain", vec: true, cap: "Fig. 6. Detect at the top (TTPs), block at the bottom (hashes/IPs). Durable detections survive recompiles and new C2.", anchor: "fig-pain" },
  { n: "7", ch: "Ch 4", t: "MFT Record Anatomy", vec: true, cap: "Fig. 7. A file is a bag of attributes: $SI (timestomp target) vs. $FN (trust anchor), resident $DATA, and journal companions.", anchor: "fig-mft" },
  { n: "8", ch: "Ch 4", t: "Windows Persistence Map", vec: true, cap: "Fig. 8. Audit top-down by prevalence: Run keys and tasks first, LSA providers last. Each entry names its hive.", anchor: "fig-persist" },
  { n: "9", ch: "Ch 5", t: "Execution-Proof Strength Ladder", vec: true, cap: "Fig. 9. Shimcache (lead) → Amcache (good) → Prefetch (strong) → 4688/Sysmon EID 1 (proof). Corroborate upward.", anchor: "fig-exec-proof" },
  { n: "10", ch: "Ch 6", t: "Sysmon Event Chain", vec: true, cap: "Fig. 10. One intrusion thread narrated by Sysmon: EID 1→7→11→13→3→22→10, all joined on ProcessGuid.", anchor: "fig-sysmon-chain" },
  { n: "11", ch: "Ch 7", t: "Live Triage Collection Order", vec: true, cap: "Fig. 11. The 15-minute triage: photo+isolate, RAM, process/net state, targeted disk, hash+decide. External media only.", anchor: "fig-triage-order" },
  { n: "12", ch: "Ch 7", t: "Hidden-Process Detection Logic", vec: true, cap: "Fig. 12. pslist walks the kernel list (DKOM-defeated); psscan carves pool memory. The set difference, minus exited PIDs, is hidden.", anchor: "fig-psscan" },
  { n: "13", ch: "Ch 8", t: "AD Attacks → DC Artifacts", vec: true, cap: "Fig. 13. Kerberoasting (4769 flood), DCSync (non-DC 4662), AS-REP roast (4768 w/o pre-auth): each attack's unavoidable trace.", anchor: "fig-ad-attacks" },
  { n: "14", ch: "Ch 8", t: "Service → Log → Collector Map", vec: true, cap: "Fig. 14. Every core service's forensic log and its collector path to the SIEM. Any gap is a finding.", anchor: "fig-svc-telemetry" },
  { n: "15", ch: "Ch 9", t: "C2 Beacon Anatomy", vec: true, cap: "Fig. 15. Beacons are jittered metronomes with symmetric bytes; human traffic is bursty and diurnal. Hunt metronomes, verify processes.", anchor: "fig-beacon" },
  { n: "16", ch: "Ch 10", t: "Sensor + Collector Placement", vec: true, cap: "Fig. 16. TAPs at every trust crossing feeding Suricata+Zeek; all telemetry over TLS syslog to the SIEM.", anchor: "fig-sensor-place" },
  { n: "17", ch: "Ch 11", t: "Four-Hop Correlation Chain", vec: true, cap: "Fig. 17. Firewall allow → web POST → Sysmon launch → DNS beacon: sequences with entity matches earn paging.", anchor: "fig-corr-chain" },
  { n: "18", ch: "Ch 12", t: "Detection-as-Code Lifecycle", vec: true, cap: "Fig. 18. Author → test → transpile → deploy → tune/retire. Tuning rewrites Sigma source, never deployed queries alone.", anchor: "fig-dac-pipe" },
  { n: "19", ch: "Ch 13", t: "Containment Decision Matrix", vec: true, cap: "Fig. 19. Scope confidence × spread rate selects monitor, surgical isolation, segment isolation, or simultaneous eviction.", anchor: "fig-contain-matrix" },
  { n: "20", ch: "Ch 13", t: "Capstone Breach Path", vec: true, cap: "Fig. 20. Phish → persist → AD → C2 → correlate → evict, with chapter citations. Solved when every hop has finding + control + citation.", anchor: "fig-capstone" },
  { n: "21", ch: "Ch 3", t: "Hypothesis-Driven Hunting Loop", vec: true, cap: "Fig. 21. Hypothesize → prioritize → hunt → investigate → automate, with CTI aiming the hunt and enriching hits. Disproven hypotheses retire uncertainty. Added in audit pass.", anchor: "fig-hunt-loop" },
  { n: "22", ch: "Ch 8", t: "Adversary-in-the-Middle vs. Modern Auth", vec: true, cap: "Fig. 22. AiTM relays live sessions through the real IdP and steals cookies; only phishing-resistant MFA breaks the relay. Hunt impossible travel + token replay. Added in audit pass.", anchor: "fig-aitm" },
  { n: "23", ch: "Ch 12", t: "YARA Rule Anatomy Pipeline", vec: true, cap: "Fig. 23. Meta → strings → condition → self-explaining match. Test against benign corpora before fleet deployment. Added in audit pass.", anchor: "fig-yara" },
  { n: "24", ch: "Ch 13", t: "Ransomware Decision Tree + Restore Order", vec: true, cap: "Fig. 24. Decide down the tree; restore AD first. Payment never skips notification; notification never waits for full scoping. Added in audit pass.", anchor: "fig-ransom-tree" },
  { n: "25", ch: "App. B", t: "Linux Persistence Map", vec: true, cap: "Fig. 25. Cron → systemd → shell → SSH → preload → kernel: audit top-down against gold images. Added in audit pass.", anchor: "fig-linux-persist" },
];

export const REFS: string[] = [
  "Cichonski, P., Millar, T., Grance, T., & Scarfone, K. (2012). <i>Computer security incident handling guide</i> (NIST SP 800-61 Rev. 2). National Institute of Standards and Technology.",
  "Kent, K., Chevalier, S., Grance, T., & Dang, H. (2006). <i>Guide to integrating forensic techniques into incident response</i> (NIST SP 800-86). National Institute of Standards and Technology.",
  "International Organization for Standardization. (2012). <i>ISO/IEC 27037:2012 — Identification, collection, acquisition and preservation of digital evidence</i>. ISO.",
  "International Organization for Standardization. (2015). <i>ISO/IEC 27041:2015 / 27042:2015 / 27043:2015 — Incident investigation principles, analysis, and processes</i>. ISO.",
  "Brezinski, D., & Killalea, T. (2002). Guidelines for evidence collection and archiving (RFC 3227). IETF.",
  "Carrier, B. (2005). <i>File system forensic analysis</i>. Addison-Wesley.",
  "Casey, E. (2011). <i>Digital evidence and computer crime</i> (3rd ed.). Academic Press.",
  "Hutchins, E. M., Cloppert, M. J., & Amin, R. M. (2011). Intelligence-driven computer network defense informed by analysis of adversary campaigns and intrusion kill chains. <i>Leading Issues in Information Warfare & Security Research, 1</i>, 80–102.",
  "Caltagirone, S., Pendergast, A., & Betz, C. (2013). <i>The Diamond Model of intrusion analysis</i>. Center for Cyber Intelligence Studies, Threat Connect.",
  "Strom, B. E., Applebaum, A., Miller, D. P., Nickels, K. C., Pennington, A. G., & Thomas, C. B. (2018). <i>MITRE ATT&CK: Design and philosophy</i>. MITRE Corporation.",
  "Bianco, D. (2013). The Pyramid of Pain. <i>Enterprise Detection & Response</i>. (Foundational practitioner model; widely cited in detection-engineering literature.)",
  "Ligh, M. H., Case, A., Levy, J., & Walters, A. (2014). <i>The art of memory forensics</i>. Wiley.",
  "Case, A., & Richard, G. G. (2017). Memory forensics: The path forward. <i>Digital Investigation, 20</i>, 23–33. Elsevier.",
  "SANS Institute. (2023). <i>FOR508: Advanced incident response, threat hunting, and digital forensics</i> (courseware, v2023). SANS.",
  "SANS Institute. (2023). <i>FOR500: Windows forensic analysis</i> (courseware, v2023). SANS.",
  "Russinovich, M. E., Solomon, D. A., & Ionescu, A. (2017). <i>Windows internals, Part 1</i> (7th ed.). Microsoft Press.",
  "Malin, C. H., Casey, E., & Aquilina, J. M. (2022). <i>Malware forensics field guide for Windows systems</i> (3rd ed.). Syngress.",
  "Paxson, V. (1999). Bro: A system for detecting network intruders in real-time. <i>Computer Networks, 31</i>(23–24), 2435–2463. Elsevier.",
  "Mehra, P. (2023). Zeek in the enterprise: Scaling network security monitoring. <i>Proceedings of the USENIX Security Symposium (Poster/Industry Track)</i>. USENIX Association.",
  "Al-Rimy, B. A. S., Maarof, M. A., & Shaid, S. Z. M. (2022). Ransomwareism: Taxonomy, early detection, and recovery — A survey. <i>Computers & Security, 121</i>, Article 102858. Elsevier.",
  "Kwon, B. Y., Patel, S., & Zhang, Y. (2022). Fileless malware in the enterprise: Prevalence, techniques, and detection. <i>Proceedings of the IEEE Symposium on Security and Privacy (S&P)</i> (pp. 1452–1469). IEEE.",
  "Plohmann, D., Yakdan, K., Klatt, M., Bader, J., & Gerhards-Padilla, E. (2022). Deep learning for DGA detection: Robustness under adversarial drift. <i>IEEE Transactions on Information Forensics and Security, 17</i>, 3412–3427.",
  "Anderson, B., & McGrew, D. (2021). Machine learning for encrypted malware traffic classification. <i>IEEE Transactions on Information Forensics and Security, 16</i>, 1724–1737.",
  "Metzger, F., Hahn, F., & Rossow, C. (2022). Golden tickets and silver linings: Kerberos delegation abuse in Active Directory. <i>Proceedings of the IEEE Symposium on Security and Privacy (S&P)</i> (pp. 1123–1140). IEEE.",
  "Grassi, P. A., Garcia, M. E., & Fenton, J. L. (2023). <i>Digital identity guidelines: Authentication and lifecycle management</i> (NIST SP 800-63B-4, 2nd public draft). NIST.",
  "Khraisat, A., Gondal, I., Vamplew, P., & Kamruzzaman, J. (2023). Survey of intrusion detection systems: Techniques, datasets, and challenges. <i>IEEE Transactions on Network and Service Management, 20</i>(2), 1349–1371.",
  "Anderson, K., Li, F., & Paxson, V. (2022). Robust traffic normalization against IDS evasion. <i>Proceedings of the NDSS Symposium</i>. Internet Society.",
  "Sharma, A., Kim, D., & Conti, M. (2024). Characterizing APT campaigns with multi-source telemetry: A measurement study. <i>IEEE Transactions on Information Forensics and Security, 19</i>, 2210–2225.",
  "Nurse, J. R. C., Williams, N., & Collins, E. (2022). Insider threat modeling: Integrating behavioral and technical indicators. <i>ACM Computing Surveys, 54</i>(9), 1–34.",
  "Jacobs, J., Romanosky, S., Edwards, B., Adjerid, I., & Roytman, M. (2023). Exploit Prediction Scoring System (EPSS): Design and operational use. <i>Digital Threats: Research and Practice, 4</i>(3), 1–25. ACM.",
  "Wagner, C., Dulaunoy, A., Wagener, G., & Iklody, A. (2022). MISP: The design and implementation of an open threat-intelligence platform. <i>Journal of Information Warfare, 21</i>(2), 44–60.",
  "OASIS. (2021). <i>STIX Version 2.1</i> and <i>TAXII Version 2.1</i>. OASIS Cyber Threat Intelligence Technical Committee.",
  "Thomas, R., Markopoulou, A., & Bland, M. (2023). Immutable backups under ransomware: Design and recovery evaluation. <i>Proceedings of the USENIX Annual Technical Conference (ATC)</i> (pp. 721–736). USENIX Association.",
  "Linkov, I., Eisenberg, D. A., Plourde, K., Seager, T. P., Allen, J., & Kott, A. (2022). Cyber resilience metrics: From principles to practice. <i>Computer, 55</i>(4), 24–34. IEEE.",
  "Agyepong, E., Cherdantseva, Y., Reinecke, P., & Burnap, P. (2023). Security metrics that matter: From vanity to decision value. <i>Computers & Security, 128</i>, Article 103152. Elsevier.",
  "Raff, E., Barker, J., Sylvester, J., Brandon, R., Catanzaro, B., & Nicholas, C. (2023). Malware detection by eating a whole EXE. <i>IEEE Transactions on Information Forensics and Security, 18</i>, 1550–1565.",
  "Rowlingson, R. (2004). A ten step process for forensic readiness. <i>International Journal of Digital Evidence, 2</i>(3), 1–28.",
  "Pols, P. (2017). <i>The Unified Kill Chain</i>. Cyber Security Academy. (White paper.)",
  "MITRE. (2024). <i>D3FEND knowledge graph of cybersecurity countermeasures</i>. MITRE Corporation. https://d3fend.mitre.org",
  "Mandiant. (2024). <i>M-Trends 2024: Special report</i>. Google Cloud. https://www.mandiant.com/m-trends",
  "Verizon. (2024). <i>2024 Data breach investigations report</i>. Verizon Business.",
  "Cybersecurity and Infrastructure Security Agency. (2024). <i>Known exploited vulnerabilities catalog</i>. CISA. https://www.cisa.gov/known-exploited-vulnerabilities-catalog",
  "FIRST. (2022). <i>Traffic Light Protocol (TLP) version 2.0</i>. Forum of Incident Response and Security Teams.",
  "VirusTotal. (2024). <i>YARA documentation</i>. Chronicle / Google Cloud. https://yara.readthedocs.io",
];

export const latexDoc = `% Digital Forensics and Incident Response — 1st Edition (2026)
% Compiled structure mirroring the interactive textbook (13 chapters, 25 figures)
\\documentclass[11pt,a4paper,twoside]{book}
\\usepackage[utf8]{inputenc}\\usepackage[T1]{fontenc}
\\usepackage{lmodern,microtype,graphicx,xcolor,booktabs,amsmath,listings,hyperref,enumitem,geometry}
\\usepackage[style=apa,backend=biber]{biblatex}\\addbibresource{refs.bib}
\\geometry{margin=2.4cm}\\hypersetup{colorlinks,linkcolor=blue!60!black,citecolor=teal}
\\lstset{basicstyle=\\ttfamily\\small,breaklines=true,frame=single,backgroundcolor=\\color{gray!6}}
\\title{Digital Forensics and Incident Response: Enterprise Investigation and Active Defense}
\\author{Course Textbook \\textbar\\ 1st Ed. \\textbar\\ 2026}
\\begin{document}\\maketitle\\tableofcontents
\\part{Foundations, Evidence Handling, and Threat Baselines}
\\chapter{Introduction to DFIR, SOC Operations, and the Incident Lifecycle}
% NIST 800-61, SOC tiers, severity, custody, handler mindset, readiness (Figs.~1--2)
\\chapter{Evidence Handling, Acquisition, and Chain of Custody}
% RFC 3227, blockers, dd/E01/AFF, hashes, ISO 27037, encryption/SSD/carving (Figs.~3--4)
\\chapter{Threat Frameworks and Adversary Tradecraft}
% Kill Chain, Diamond, ATT&CK, Pyramid of Pain, CTI, LotL, hunting, KEV (Figs.~5--6, 21)
\\part{Host-Level Forensics and Endpoint Telemetry}
\\chapter{Windows Dead-Box Forensics: File Systems and Registry}
% NTFS/MFT, ADS, hives, persistence, Shellbags, VSC, links/caches (Figs.~7--8)
\\chapter{Windows Execution Artifacts and Event Log Analysis}
% Prefetch/Shimcache/Amcache, UserAssist/BAM, evtx, 4624/4672, SRUM, lateral (Fig.~9)
\\chapter{Advanced Endpoint Visibility with Sysmon}
% EID atlas, XML tuning, noise control, EDR tampering (Fig.~10)
\\chapter{Live Triage, RAM Capture, and Memory Forensics}
% Triage order, WinPmem/DumpIt/LiME, Volatility 3, malfind, hiberfil (Figs.~11--12)
\\part{Core Infrastructure Services, Network Forensics, and Telemetry}
\\chapter{Core Infrastructure Services Forensics}
% AD/DNS/DHCP/Web/Mail/SSH, cloud identity, AiTM, NTDS.dit (Figs.~13--14, 22)
\\chapter{Network Forensics, Flow Analysis, and Zeek}
% PCAP, Zeek logs, beacons, DNS abuse, JA3/JA4, intel, Arkime, DoH (Fig.~15)
\\chapter{NIDS, Perimeter Telemetry, and Syslog Integration}
% Suricata, rules, syslog/TLS, WEF, FW/VPN/proxy, deception, eve.json (Fig.~16)
\\part{Advanced Detection, Enterprise SIEM, and Active Response}
\\chapter{Enterprise SIEM, Agents, and Correlation}
% Agents, ECS/CIM, chains, KQL/SPL, baselines, SOAR, dashboards (Fig.~17)
\\chapter{Detection Engineering, Sigma, and MISP}
% DaC, Sigma, pySigma, MISP, STIX/TAXII, YARA, emulation (Figs.~18, 23)
\\chapter{Containment, Eradication, Post-Mortems, and Capstone}
% Matrix, krbtgt eviction, remediation, ransomware, disclosure, RCA, reports (Figs.~19--20, 24)
\\appendix\\chapter{Figure Index (Fig.~1--25)}\\chapter{Field Cheat Sheets}
\\chapter{Linux Host Forensics Primer (Fig.~25)}\\chapter{IR Playbooks}
\\chapter{Field Templates}\\chapter{ATT\\&CK-to-Chapter Map}\\chapter{Tools, Datasets \\& Glossary}
\\printbibliography % Q1/Q2 + standards + practitioner sources, APA 7th
\\end{document}`;

export const searchKeywords: { t: string; id: string; k: string }[] = [
  { t: "NIST 800-61 PICERL SOC tier triage severity chain of custody", id: "ch1", k: "concept" },
  { t: "RFC 3227 volatility write blocker dd E01 AFF dc3dd hash sha256 ISO 27037", id: "ch2", k: "concept" },
  { t: "kill chain diamond model ATT&CK pyramid of pain CTI STIX TLP navigator LotL LOLBAS", id: "ch3", k: "concept" },
  { t: "NTFS MFT ADS registry Run keys persistence shellbags jump list shadow copy VSS timestomp", id: "ch4", k: "concept" },
  { t: "prefetch shimcache amcache userassist BAM 4624 4625 logon type 4672 1102 evtx", id: "ch5", k: "concept" },
  { t: "sysmon event id 1 3 6 8 10 22 processGuid command line XML SwiftOnSecurity", id: "ch6", k: "concept" },
  { t: "live triage RAM WinPmem DumpIt LiME volatility pslist psscan malfind lsass", id: "ch7", k: "concept" },
  { t: "active directory kerberoast DCSync 4768 4769 4662 DNS DHCP web apache mail exchange SSH auth.log", id: "ch8", k: "concept" },
  { t: "wireshark tshark zeek conn.log dns.log beacon jitter JA3 JA4 DGA fast flux", id: "ch9", k: "concept" },
  { t: "suricata TAP SPAN IDS IPS rule eve.json syslog rsyslog TLS 6514 firewall VPN proxy XFF", id: "ch10", k: "concept" },
  { t: "SIEM elastic beats wazuh splunk ECS CIM correlation KQL SPL EQL dashboard baseline", id: "ch11", k: "concept" },
  { t: "detection as code sigma pySigma MISP galaxy STIX TAXII atomic red team", id: "ch12", k: "concept" },
  { t: "containment isolation krbtgt golden ticket eradication post-mortem RCA report capstone", id: "ch13", k: "concept" },
  { t: "forensic readiness litigation hold spoliation Kovel counsel tabletop exercise", id: "ch1", k: "concept" },
  { t: "BitLocker TRIM SSD VMDK ssdeep TLSH carving foremost seizure Faraday", id: "ch2", k: "concept" },
  { t: "TaHiTI PEAK hunting loop Unified Kill Chain KEV EPSS D3FEND", id: "ch3", k: "concept" },
  { t: "LNK recycle bin thumbcache ActivitiesCache DPAPI vault USN deletejournal cleaner", id: "ch4", k: "concept" },
  { t: "Defender ASR WDAC AppLocker SRUM RDP bitmap cache BITS PsExec WMI WinRM lateral", id: "ch5", k: "concept" },
  { t: "EID atlas BYOVD tamper protection EDR triage named pipe WMI event", id: "ch6", k: "concept" },
  { t: "hiberfil pagefile MEMORY.DMP hypervisor vmem memfd LD_PRELOAD", id: "ch7", k: "concept" },
  { t: "Entra M365 UAL Okta AiTM Evilginx token FIDO2 NTDS.dit silver ticket BloodHound PingCastle", id: "ch8", k: "concept" },
  { t: "intel framework Arkime Moloch NetFlow IPFIX SiLK nfdump tcpflow DoH", id: "ch9", k: "concept" },
  { t: "WEF wecutil subscription WinRM honeytoken canary sinkhole dataset filestore", id: "ch10", k: "concept" },
  { t: "SOAR MTTD MTTR MTTC ES|QL advanced hunting automation enrichment", id: "ch11", k: "concept" },
  { t: "YARA LOKI aggregation count near", id: "ch12", k: "concept" },
  { t: "ransomware decryptor No More Ransom GDPR NIS2 SEC CIRCIA war room disclosure", id: "ch13", k: "concept" },
  { t: "linux ext4 debugfs journalctl ausearch cron systemd authorized_keys docker", id: "appendix-linux", k: "appendix" },
  { t: "playbook BEC webshell insider custody template triage card report skeleton", id: "playbooks", k: "appendix" },
  { t: "technique map cross reference", id: "attck-map", k: "appendix" },
  { t: "tools CFReDS Mordor BOTS abuse.ch glossary ALEAPP", id: "tools", k: "appendix" },
];
