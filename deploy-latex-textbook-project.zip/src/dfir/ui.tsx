import { useState, type ReactNode } from "react";
import { Check, Copy, FlaskConical, ListChecks, Wrench } from "lucide-react";

/* ---------- Code block with copy ---------- */
export function CodeBlock({ title, code }: { title: string; code: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };
  return (
    <div className="codeblock not-serif mt-2">
      <div className="flex items-center justify-between bg-slate-900 text-slate-200 px-3 py-1.5 rounded-t-xl text-xs font-bold">
        <span>{title}</span>
        <button
          onClick={copy}
          className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 inline-flex items-center gap-1"
        >
          {copied ? <Check size={12} /> : <Copy size={12} />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="bg-slate-950 text-slate-100 text-[12.5px] p-3 rounded-b-xl mono leading-relaxed whitespace-pre-wrap break-words">
        {code}
      </pre>
    </div>
  );
}

/* ---------- Table ---------- */
export function DataTable({
  head,
  rows,
}: {
  head: string[];
  rows: ReactNode[][];
}) {
  return (
    <div className="overflow-x-auto not-serif">
      <table className="book-table">
        <thead>
          <tr>
            {head.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {r.map((c, j) => (
                <td key={j}>{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- Figure wrapper ---------- */
export function Figure({
  id,
  label,
  children,
  caption,
}: {
  id: string;
  label: string;
  children: ReactNode;
  caption: ReactNode;
}) {
  return (
    <div id={id} className="diagram p-4 lg:p-6 not-serif print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300">{label}</div>
      <div className="mt-3">{children}</div>
      <div className="fig-cap text-slate-500 mt-3">{caption}</div>
    </div>
  );
}

/* ---------- Callout ---------- */
export function Callout({
  color = "amber",
  children,
}: {
  color?: "amber" | "cyan" | "emerald" | "rose" | "violet";
  children: ReactNode;
}) {
  const map: Record<string, string> = {
    amber: "border-amber-500 bg-amber-50 dark:bg-amber-950/20",
    cyan: "border-cyan-500 bg-cyan-50 dark:bg-cyan-950/20",
    emerald: "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20",
    rose: "border-rose-500 bg-rose-50 dark:bg-rose-950/20",
    violet: "border-violet-500 bg-violet-50 dark:bg-violet-950/20",
  };
  return (
    <div className={`mt-4 p-4 rounded-xl callout ${map[color]} text-sm leading-relaxed`}>
      {children}
    </div>
  );
}

/* ---------- Quiz ---------- */
export interface QuizQ {
  q: string;
  o: string[];
  a: number;
  e: string;
}

export function QuizBox({ id, num, questions }: { id: string; num: number | string; questions: QuizQ[] }) {
  const [sel, setSel] = useState<Record<number, number>>({});
  const [checked, setChecked] = useState(false);
  const score = questions.reduce((s, q, i) => s + (sel[i] === q.a ? 1 : 0), 0);
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-700 p-5 not-serif bg-slate-50 dark:bg-slate-800/50">
      <div className="flex items-center justify-between gap-2">
        <div className="badge text-cyan-700 dark:text-cyan-300 inline-flex items-center gap-1.5">
          <ListChecks size={14} /> End-of-chapter assessment · Ch {num}
        </div>
        <button
          onClick={() => setChecked(true)}
          className="text-xs font-bold px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-cyan-500 dark:text-slate-900 text-white shrink-0"
        >
          {checked ? "Re-check answers" : "Check answers"}
        </button>
      </div>
      <div className="mt-3 space-y-3">
        {questions.map((it, i) => (
          <div
            key={i}
            className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
          >
            <div className="text-sm font-bold">
              Q{i + 1}. {it.q}
            </div>
            <div className="mt-2 grid gap-1.5">
              {it.o.map((o, j) => {
                let cls = "bg-slate-50 dark:bg-slate-800";
                if (checked) {
                  if (j === it.a) cls = "correct";
                  else if (sel[i] === j) cls = "wrong";
                } else if (sel[i] === j) cls = "bg-slate-50 dark:bg-slate-800 ring-2 ring-cyan-500";
                return (
                  <button
                    key={j}
                    onClick={() => {
                      setSel((s) => ({ ...s, [i]: j }));
                      setChecked(false);
                    }}
                    className={`quiz-opt text-left text-[13px] px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 ${cls}`}
                  >
                    {String.fromCharCode(65 + j)}. {o}
                  </button>
                );
              })}
            </div>
            {checked && (
              <div className="text-xs mt-2 p-2 rounded-lg bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-900">
                {sel[i] === it.a ? "✔ Correct. " : sel[i] === undefined ? "○ Unanswered. " : "✘ Incorrect. "}
                {it.e}
              </div>
            )}
          </div>
        ))}
      </div>
      {checked && (
        <div className="text-sm font-bold mt-2">
          Score: {score} / {questions.length}
          {score === questions.length ? " — Excellent mastery." : " — Review the explanations above."}
        </div>
      )}
      <div id={id} className="hidden" />
    </div>
  );
}

/* ---------- Technical Workshop ---------- */
export interface WsStep {
  n: string;
  title: string;
  desc?: string;
  code?: { title: string; text: string }[];
  expected?: string;
  note?: string;
}
export interface WsTab {
  id: string;
  label: string;
  steps: WsStep[];
}
export interface Workshop {
  title: string;
  env: string[];
  tabs: WsTab[];
  note: ReactNode;
}

export function WorkshopBox({ num, ws }: { num: number | string; ws: Workshop }) {
  const [active, setActive] = useState(ws.tabs[0]?.id ?? "");
  const tab = ws.tabs.find((t) => t.id === active) ?? ws.tabs[0];
  return (
    <div className="tech-workshop rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden not-serif">
      <div className="bg-gradient-to-r from-slate-900 to-cyan-800 text-white p-4">
        <div className="badge text-amber-300 inline-flex items-center gap-1.5">
          <Wrench size={13} /> Technical Workshop {num}
        </div>
        <h4 className="font-extrabold text-[15px] mt-1">{ws.title}</h4>
        <div className="flex flex-wrap gap-1.5 mt-2 text-[11px] font-bold">
          {ws.env.map((e) => (
            <span key={e} className="px-2 py-1 rounded-lg bg-white/10">
              {e}
            </span>
          ))}
        </div>
      </div>
      <div className="bg-white dark:bg-slate-900 p-3 sm:p-4">
        <div className="tw-tabs flex flex-wrap gap-1.5 no-print">
          {ws.tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActive(t.id)}
              className={`tw-tab ${t.id === active ? "active" : ""}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="tw-panel" key={tab.id}>
          {tab.steps.map((s, i) => (
            <div className="tw-step" key={i}>
              <div className="step-num">{s.n}</div>
              <div className="flex-1 min-w-0">
                <h5>{s.title}</h5>
                {s.desc && <p>{s.desc}</p>}
                {s.code?.map((c, j) => (
                  <CodeBlock key={j} title={c.title} code={c.text} />
                ))}
                {s.expected && <div className="expected">Expected: {s.expected}</div>}
                {s.note && (
                  <div className="tw-note bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {s.note}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        <div className="tw-note bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-900">
          {ws.note}
        </div>
      </div>
    </div>
  );
}

/* ---------- Hands-on lab box ---------- */
export function LabBox({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="lab-box rounded-2xl p-5 not-serif">
      <div className="badge text-amber-700 dark:text-amber-300 inline-flex items-center gap-1.5">
        <FlaskConical size={13} /> {title}
      </div>
      <div className="mt-2 text-sm leading-relaxed space-y-2">{children}</div>
    </div>
  );
}

/* ---------- Chapter type ---------- */
export interface Chapter {
  id: string;
  num: number;
  title: string;
  subtitle: string;
  badge: string;
  time: string;
  outcomes: string;
  body: ReactNode;
  labTitle: string;
  labsBody: ReactNode;
  workshop: Workshop;
  quiz: QuizQ[];
}
