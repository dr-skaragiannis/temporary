import { useState } from "react";
import { DataTable } from "./ui";

export function Preface() {
  return (
    <section id="preface" className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-amber-600 dark:text-amber-400">Front matter · Read first</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Preface &amp; How to Use This Book</h2>
      <div className="prose-book serif mt-3">
        <p>
          <b>Scope and intent.</b> This volume is a university-level textbook for <i>Digital Forensics and Incident
          Response</i>. It trains enterprise investigators across <b>13 chapters in 4 tiers</b>: foundations and
          evidence handling (Ch. 1–3) → host forensics and endpoint telemetry (Ch. 4–7) → infrastructure services,
          network forensics, and transport (Ch. 8–10) → SIEM, detection engineering, and active response (Ch. 11–13).
          Core enterprise services — <b>DNS, DHCP, Active Directory, mail, web, SSH, VPN/firewalls, and proxies</b> —
          are mapped throughout to their forensic roles, log sources, collector placement, and SIEM integration.
        </p>
        <p>
          <b>How each chapter works.</b> Every chapter follows the same contract: expert theory in six sections with
          tables and vector figures → a <b>Technical Workshop</b> (tabbed, command-level, tool-exact) →{" "}
          <b>Hands-on Labs</b> (graded exercises with deliverables) → an <b>end-of-chapter quiz</b> with explanations.
          Figures are numbered Fig. 1–25 and gathered in the gallery (Fig. 21–25 added in the expert-audit pass); references follow APA 7th with standards
          (NIST, ISO, RFC) and peer-reviewed venues.
        </p>
      </div>
      <div className="mt-4 not-serif">
        <div className="badge text-cyan-700 dark:text-cyan-300">Tier map · 13 chapters</div>
        <DataTable
          head={["Tier", "Chapters", "Question it answers"]}
          rows={[
            ["I · Foundations, Evidence & Threat Baselines", "1 · DFIR/SOC lifecycle — 2 · Acquisition/custody — 3 · ATT&CK/CTI", "How do we investigate lawfully, preserve evidence, and model the adversary?"],
            ["II · Host Forensics & Endpoint Telemetry", "4 · Dead-box/registry — 5 · Execution/evtx — 6 · Sysmon — 7 · Memory", "What happened on this host, exactly, and can we prove it?"],
            ["III · Infrastructure, Network & Transport", "8 · AD/DNS/DHCP/web/mail/SSH — 9 · Zeek/flows — 10 · Suricata/syslog", "How did it move through our services and wires, and do we log it?"],
            ["IV · Detection, SIEM & Active Response", "11 · SIEM/correlation — 12 · Sigma/MISP — 13 · Containment/capstone", "How do we detect campaigns automatically, evict adversaries, and report?"],
          ]}
        />
      </div>
      <div className="grid md:grid-cols-3 gap-3 mt-4 not-serif">
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm leading-relaxed">
          <b>Lab safety contract.</b>
          <br />
          All workshops assume <b>isolated VMs on snapshots</b> with host-only networking. Never detonate, scan, or
          forward outside the lab; emulation that escapes containment is an incident, not an exercise.
        </div>
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm leading-relaxed">
          <b>Time budget.</b>
          <br />
          Chapters carry honest estimates (6–14 h each, ~130 h total): roughly 40% reading, 35% workshops/labs, 25%
          assessment and write-ups. The capstone (Ch. 13) is multi-session by design.
        </div>
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm leading-relaxed">
          <b>Evidence standard.</b>
          <br />
          From Ch. 2 onward, every lab artifact is hashed, UTC-stamped, and custody-logged. The course grades
          forensic discipline — not just correct answers — because courts and commanders do too.
        </div>
      </div>
      <div className="mt-4 p-4 rounded-xl callout border-amber-500 bg-amber-50 dark:bg-amber-950/20 text-sm leading-relaxed not-serif">
        <b>Learning outcomes.</b> Graduates will be able to (1) run NIST/SANS lifecycles and SOC escalations; (2)
        acquire evidence to ISO 27037/RFC 3227 standards; (3) model adversaries with ATT&amp;CK and CTI; (4–5) prove
        host activity from files, registry, and logs; (6) deploy and tune Sysmon; (7) dissect memory with Volatility;
        (8) hunt across AD/DNS/DHCP/web/mail/SSH logs; (9) corroborate on the wire with Zeek; (10) operate Suricata
        and syslog pipelines; (11) correlate in SIEM; (12) ship detections as code with MISP intel; and (13) evict
        adversaries and report to court standards.
      </div>
    </section>
  );
}

const paths: Record<string, { title: string; order: string; note: string }> = {
  linear: {
    title: "Path A · Linear BSc (default)",
    order: "Ch 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 → 9 → 10 → 11 → 12 → 13",
    note: "Full 14-week semester. Every chapter's outputs feed a later chapter; nothing is used before it is taught. Capstone last, always.",
  },
  soc: {
    title: "Path B · SOC Analyst fast-track",
    order: "Ch 1 → 3 → 5 → 6 → 8 → 9 → 10 → 11 → 12 → 13 (§§13.1, 13.4–13.5)",
    note: "Triage-to-correlation in 8 weeks. Skims dead-box depth (Ch. 4) and memory internals (Ch. 7) on first pass; returns for Tier 2 promotion.",
  },
  host: {
    title: "Path C · Host Forensics deep-dive",
    order: "Ch 1 → 2 → 4 → 5 → 6 → 7 → 3 → 13 (§§13.4–13.5)",
    note: "Examiner track: disk → logs → Sysmon → memory, then threat context and reporting. Pairs with a network elective (Ch. 8–10) in term 2.",
  },
  sprint: {
    title: "Path D · IR Sprint (2 weeks)",
    order: "Ch 1 (§§1.2–1.4) → 2 (§§2.1, 2.6) → 3 (§§3.2–3.3) → 6 (§§6.2–6.4) → 8 (§8.1) → 11 (§11.3) → 13",
    note: "Incident-commander crash course: lifecycle, live-vs-dead decisions, ATT&CK triage, Sysmon reads, AD hunts, chains, and T-hour. Not a substitute for labs.",
  },
};

export function ReadingPaths() {
  const [active, setActive] = useState("linear");
  const p = paths[active];
  return (
    <section id="reading-paths" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-amber-600 dark:text-amber-400">Study guide · Sequencing & pedagogy</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Reading Paths &amp; Semester Plan</h2>
      <p className="text-sm text-slate-600 dark:text-slate-300 mt-2 leading-relaxed max-w-4xl">
        The chapter order is deliberate — <i>lawful process → host truth → network truth → automated detection →
        active response</i> — with hard prerequisite chains (Ch. 6 before Ch. 9 fusion; Ch. 8–10 before Ch. 11
        correlation; everything before the Ch. 13 capstone). Pick a certified path below; each preserves every hard
        dependency.
      </p>
      <div className="flex flex-wrap gap-2 mt-4 no-print">
        {Object.entries(paths).map(([k, v]) => (
          <button
            key={k}
            onClick={() => setActive(k)}
            className={`px-3 py-2 rounded-xl text-xs font-extrabold ${
              k === active
                ? "bg-slate-900 text-white dark:bg-amber-500 dark:text-slate-900"
                : "bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600"
            }`}
          >
            {v.title}
          </button>
        ))}
      </div>
      <div className="mt-3 p-4 rounded-xl bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-900 text-sm leading-relaxed">
        <b>{p.title}.</b>
        <div className="mono text-[13px] mt-1">{p.order}</div>
        <div className="mt-1 text-slate-600 dark:text-slate-300">{p.note}</div>
      </div>
      <div className="mt-4 not-serif">
        <div className="badge text-cyan-700 dark:text-cyan-300">Table P-1 · 14-week semester plan (Path A)</div>
        <DataTable
          head={["Week", "Chapter", "Workshop + Lab focus", "Assessment"]}
          rows={[
            ["1", "Ch 1 · DFIR/SOC lifecycle", "Triage bench + severity drill", "Quiz 1 + case directory"],
            ["2", "Ch 2 · Acquisition/custody", "Imaging pipeline + E01 package", "Quiz 2 + custody package"],
            ["3", "Ch 3 · ATT&CK/CTI", "Navigator layer + mapping labs", "Quiz 3 + coverage layer"],
            ["4–5", "Ch 4 · Dead-box forensics", "MFT timeline + persistence audit", "Quiz 4 + timeline report"],
            ["6", "Ch 5 · Execution/evtx", "PECmd/EvtxECmd + logon matrix", "Quiz 5 + proof package"],
            ["7", "Ch 6 · Sysmon", "Deploy + tune + process hunts", "Quiz 6 + tuned config"],
            ["8", "Ch 7 · Memory forensics", "Capture + Volatility investigation", "Quiz 7 + memory findings"],
            ["9–10", "Ch 8 · Infrastructure services", "Six-service triage + AD hunt", "Quiz 8 + fused timeline"],
            ["11", "Ch 9 · Zeek/network", "PCAP autopsy + host fusion", "Quiz 9 + C2 finding"],
            ["12", "Ch 10 · Suricata/syslog", "NIDS rules + TLS pipeline", "Quiz 10 + sensor proof"],
            ["13", "Ch 11–12 · SIEM + detection", "EQL chains + Sigma/emulation", "Quizzes 11–12 + shipped rule"],
            ["14", "Ch 13 · Capstone", "T-hour drill + full investigation", "Technical + executive reports"],
          ]}
        />
      </div>
    </section>
  );
}
