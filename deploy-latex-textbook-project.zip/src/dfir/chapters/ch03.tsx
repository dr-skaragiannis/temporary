import { Callout, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>3.1 Adversary modeling: Kill Chain, Diamond Model, ATT&amp;CK</h4>
    <p>
      Three models structure adversary reasoning at different resolutions. The <b>Cyber Kill Chain</b> (Lockheed
      Martin) sequences intrusion into seven stages — reconnaissance, weaponization, delivery, exploitation,
      installation, C2, actions on objectives — and teaches <i>early disruption economics</i>. The{" "}
      <b>Diamond Model</b> (Fig. 5) relates every intrusion event across four vertices — <i>adversary, capability,
      infrastructure, victim</i> — forcing analysts to pivot: a new C2 domain (infrastructure) implies a capability
      and a victim set worth hunting. <b>MITRE ATT&amp;CK</b> catalogs the actual behaviors (TTPs) observed in the
      wild, non-linear and empirically grounded. Professionals use all three: Kill Chain for <i>where are they</i>,
      Diamond for <i>what connects</i>, ATT&amp;CK for <i>exactly what they did</i>.
    </p>
    <Figure
      id="fig-diamond"
      label="Fig. 5 · Diamond Model of intrusion analysis (vector)"
      caption={
        <>
          <b>Fig. 5.</b> Every event connects adversary, capability, infrastructure, and victim. Pivoting means
          traversing edges: infrastructure → capability (what else does this tooling do?), capability → victim (who
          else is targeted?). Meta-features (timestamp, phase) annotate each edge.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="Diamond model">
        <polygon points="360,30 560,140 360,250 160,140" fill="none" stroke="#0f1c2e" strokeWidth="2.5" className="fig-line" />
        <g fontSize="11" fontWeight="800" textAnchor="middle">
          <rect x="280" y="8" width="160" height="44" rx="8" fill="#be123c" />
          <text x="360" y="26" fill="#fff">ADVERSARY</text>
          <text x="360" y="42" fill="#ffe4e6" fontWeight="400" fontSize="10">operator / customer</text>
          <rect x="510" y="118" width="170" height="44" rx="8" fill="#0e7490" />
          <text x="595" y="136" fill="#fff">CAPABILITY</text>
          <text x="595" y="152" fill="#e0f2fe" fontWeight="400" fontSize="10">malware / technique</text>
          <rect x="280" y="208" width="160" height="44" rx="8" fill="#166534" />
          <text x="360" y="226" fill="#fff">VICTIM</text>
          <text x="360" y="242" fill="#dcfce7" fontWeight="400" fontSize="10">persona / asset</text>
          <rect x="40" y="118" width="170" height="44" rx="8" fill="#b45309" />
          <text x="125" y="136" fill="#fff">INFRASTRUCTURE</text>
          <text x="125" y="152" fill="#fef3c7" fontWeight="400" fontSize="10">domain / IP / relay</text>
        </g>
        <text x="360" y="140" textAnchor="middle" fontSize="12" fontWeight="800" fill="#0f1c2e" className="fig-halo">EVENT</text>
        <g fontSize="10" fontWeight="700" fill="#475569" textAnchor="middle" className="fig-edge">
          <text x="270" y="95">uses</text>
          <text x="450" y="95">hosts</text>
          <text x="450" y="195">targets</text>
          <text x="270" y="195">compromises</text>
        </g>
      </svg>
    </Figure>
    <h4>3.2 MITRE ATT&amp;CK matrix structure: tactics, techniques, procedures</h4>
    <p>
      ATT&amp;CK organizes adversary behavior into <b>tactics</b> (<i>why</i> — 14 Enterprise tactics from Reconnaissance
      to Impact), <b>techniques and sub-techniques</b> (<i>how</i> — e.g., T1566 Phishing, T1059.001 PowerShell), and{" "}
      <b>procedures</b> (concrete instantiations by named groups and malware). Each technique page lists detection
      guidance, data sources, and mitigations — making ATT&amp;CK a detection-engineering backlog as well as a
      taxonomy. For DFIR, the critical skill is <b>technique mapping</b>: translating raw artifacts ("Run key +
      base64 PowerShell + DNS beacon") into T1547.001 + T1059.001 + T1071.004, which immediately suggests peer
      techniques to hunt.
    </p>
    <DataTable
      head={["Tactic (why)", "Example techniques (how)", "Forensic artifacts to pull"]}
      rows={[
        ["Initial Access", "T1566 Phishing, T1190 Exploit Public App", "Mail gateway logs, web access logs (Ch. 8)"],
        ["Execution", "T1059 CLI/Scripting, T1204 User Execution", "Prefetch, Shimcache, Sysmon EID 1 (Ch. 5–6)"],
        ["Persistence", "T1547 Boot/Logon Autostart, T1053 Tasks", "Registry Run keys, scheduled tasks (Ch. 4)"],
        ["Privilege Escalation", "T1068 Exploit, T1134 Token Manipulation", "Security EID 4672/4673, Sysmon EID 10"],
        ["Defense Evasion", "T1070 Indicator Removal, T1027 Obfuscation", "EID 1102 log-clear, Sysmon config gaps"],
        ["Credential Access", "T1003 LSASS Dump, T1558 Kerberoast", "Sysmon EID 10 on lsass, DC EID 4769 (Ch. 8)"],
        ["Discovery / Lateral Movement", "T1018 Remote Discovery, T1021 RDP/SMB", "Zeek conn.log, firewall allows (Ch. 9–10)"],
        ["C2 / Exfiltration / Impact", "T1071 App-Layer C2, T1486 Ransomware", "DNS/proxy logs, MFT timelines (Ch. 9, Ch. 4)"],
      ]}
    />
    <h4>3.3 The Pyramid of Pain</h4>
    <p>
      David Bianco's <b>Pyramid of Pain</b> (Fig. 6) ranks indicators by how much pain re-tooling costs the adversary.
      Blocking a <b>hash</b> costs them a recompile (trivial); blocking an <b>IP or domain</b> costs re-registration;
      but detecting their <b>TTPs</b> — the behaviors their mission requires — forces expensive tradecraft redesign.
      DFIR consequence: IoCs (hashes, IPs) belong in <i>blocking and triage</i>, while TTPs belong in <i>detections and
      hunts</i>. A report that lists only hashes has documented the incident; a report that maps TTPs has improved the
      enterprise.
    </p>
    <Figure
      id="fig-pain"
      label="Fig. 6 · Pyramid of Pain (vector)"
      caption={
        <>
          <b>Fig. 6.</b> Higher levels = more adversary pain when denied. Mature programs detect at the top (TTPs,
          tools) and block at the bottom (hashes, IPs). Color encodes recommended use: green = detect/hunt, amber =
          block/triage.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="Pyramid of pain">
        <g fontSize="11" fontWeight="800" textAnchor="middle">
          <polygon points="360,10 420,52 300,52" fill="#166534" />
          <text x="360" y="40" fill="#fff" fontSize="9">TTPs</text>
          <polygon points="300,52 420,52 455,94 265,94" fill="#16a34a" />
          <text x="360" y="80" fill="#fff" fontSize="10">TOOLS</text>
          <polygon points="265,94 455,94 490,136 230,136" fill="#0e7490" />
          <text x="360" y="122" fill="#fff" fontSize="10">NETWORK / HOST ARTIFACTS</text>
          <polygon points="230,136 490,136 525,178 195,178" fill="#b45309" />
          <text x="360" y="164" fill="#fff" fontSize="10">DOMAIN NAMES</text>
          <polygon points="195,178 525,178 560,220 160,220" fill="#be123c" />
          <text x="360" y="206" fill="#fff" fontSize="10">IP ADDRESSES · HASHES</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="120" y1="215" x2="120" y2="40" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="100" y="130" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e" className="fig-halo" transform="rotate(-90 100 130)">ADVERSARY PAIN ↑</text>
        <g fontSize="10" fontWeight="700" fill="#64748b" textAnchor="start">
          <text x="570" y="45">detect + hunt</text>
          <text x="570" y="85">detect + hunt</text>
          <text x="570" y="125">hunt pivots</text>
          <text x="570" y="168">block 30–90 d</text>
          <text x="570" y="210">block, expires fast</text>
        </g>
        <text x="360" y="244" textAnchor="middle" fontSize="11" fill="#64748b">Rule: never write a detection you could only trigger on a single hash</text>
      </svg>
    </Figure>
    <h4>3.4 Cyber Threat Intelligence basics</h4>
    <p>
      <b>CTI</b> converts raw data into decision advantage at three levels. <b>Strategic</b> intelligence (who targets
      our sector, with what intent) informs executives and budgets. <b>Tactical/operational</b> intelligence (TTPs,
      malware, campaigns) drives detection engineering and hunting. <b>Technical</b> intelligence (IoCs, YARA, Sigma)
      feeds blocking and alerting. The CTI lifecycle — direction, collection, processing, analysis, dissemination,
      feedback — keeps feeds aligned to stakeholder requirements; unevaluated feed-stacking produces alert fatigue,
      not security. Sharing uses <b>STIX/TAXII</b> formats and <b>TLP</b> handling markings (Ch. 12 operationalizes
      MISP).
    </p>
    <DataTable
      head={["Level", "Consumer", "Question answered", "Example product"]}
      rows={[
        ["Strategic", "Executives, board", "Who threatens us and why?", "Sector threat landscape brief"],
        ["Tactical", "Hunters, detection engineers", "How do they operate?", "TTP profile + hunt hypotheses"],
        ["Operational", "SOC analysts, IR", "What is happening now?", "Campaign alert with scope guidance"],
        ["Technical", "Controls, SIEM", "What exactly to block/detect?", "IoCs, YARA, Sigma (TLP-marked)"],
      ]}
    />
    <h4>3.5 ATT&amp;CK Navigator: coverage mapping</h4>
    <p>
      <b>ATT&amp;CK Navigator</b> renders technique heatmaps as shareable JSON layers: score techniques by detection
      coverage, threat relevance, or assessment findings, then overlay layers (threat profile vs. control coverage) to
      expose gaps. DFIR uses include scoping ("the intruder used 6 techniques; 4 lack detections — assume
      under-observation"), purple-team planning, and post-incident measurement ("this incident added 3 detections,
      closing 2 high-risk gaps"). Layers are version-controlled detection debt ledgers — Workshop 3 builds one from a
      real incident narrative.
    </p>
    <h4>3.6 Living-off-the-Land (LotL)</h4>
    <p>
      <b>LotL</b> tradecraft abuses legitimate binaries and services — PowerShell, WMI, PsExec, RDP, BITS, certutil —
      so no malware hash ever appears. Distinguishing administration from attack requires <b>behavioral baselines</b>:
      <i>who</i> ran it, from <i>where</i>, with <i>what parent and arguments</i>, at <i>what hour</i>, against{" "}
      <i>what baseline volume</i>. Sysmon command-line logging (Ch. 6), parent-child anomaly detection, and rare-process
      analysis are the primary counters. The LOLBAS/LOLDrivers catalogs enumerate abusable binaries — but the deeper
      lesson is architectural: every administrative capability you deploy is adversary capability on compromise.
    </p>
    <Callout color="amber">
      <b>Exam trap.</b> LotL binaries are signed by Microsoft and allowlisted by hash. Any control strategy that ends
      at "trusted publisher" fails open against T1059/T1047/T1218. Parent process + command line + network behavior is
      the minimum viable detection triple.
    </Callout>
    <h4>3.7 ★ NEW · Hypothesis-driven threat hunting: the TaHiTI/PEAK loop</h4>
    <p>
      <b>Threat hunting</b> is the disciplined search for undetected adversaries — assuming breach and proving otherwise.
      The <b>TaHiTI/PEAK-style loop</b> (Fig. 21) keeps hunts scientific instead of vibes-based: <b>hypothesize</b> a TTP
      in <i>your</i> environment ("Kerberoastable service accounts exist; roast attempts would show as 4769 RC4 floods"),
      <b> prioritize</b> by risk × feasibility, <b>test</b> against baselined data (Ch. 11), <b>investigate</b> hits to
      full scope, <b>automate</b> survivors into Sigma detections (Ch. 12), and record <b>lessons</b> — including
      disproven hypotheses, which are successes (they retire uncertainty). CTI feeds the loop at two points: hypothesis
      generation (sector TTP profiles) and hit enrichment (is this C2 known?). A hunt with no written hypothesis is a
      fishing trip; a hunt with no automation outcome is entertainment.
    </p>
    <Figure
      id="fig-hunt-loop"
      label="Fig. 21 · Hypothesis-driven hunting loop (vector) ★ NEW"
      caption={
        <>
          <b>Fig. 21.</b> Every hunt enters at Hypothesis with a falsifiable claim and exits at Automate with a
          detection or at Lessons with retired uncertainty. CTI enters twice: to aim the hunt and to judge its catch.
          Loops that skip Automate leak value — the same adversary returns unopposed.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="Hunting loop">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="270" y="10" width="180" height="52" rx="10" fill="#0f1c2e" />
          <text x="360" y="31" fill="#fbbf24">1 · HYPOTHESIZE</text>
          <text x="360" y="47" fill="#cbd5e1" fontWeight="400" fontSize="10">TTP + where + signal</text>
          <rect x="490" y="80" width="180" height="52" rx="10" fill="#0e7490" />
          <text x="580" y="101" fill="#fff">2 · PRIORITIZE</text>
          <text x="580" y="117" fill="#e0f2fe" fontWeight="400" fontSize="10">risk × feasibility</text>
          <rect x="490" y="160" width="180" height="52" rx="10" fill="#b45309" />
          <text x="580" y="181" fill="#fff">3 · HUNT</text>
          <text x="580" y="197" fill="#fef3c7" fontWeight="400" fontSize="10">baseline vs. anomaly</text>
          <rect x="270" y="160" width="180" height="52" rx="10" fill="#be123c" />
          <text x="360" y="181" fill="#fff">4 · INVESTIGATE</text>
          <text x="360" y="197" fill="#ffe4e6" fontWeight="400" fontSize="10">scope every hit</text>
          <rect x="50" y="160" width="180" height="52" rx="10" fill="#166534" />
          <text x="140" y="181" fill="#fff">5 · AUTOMATE</text>
          <text x="140" y="197" fill="#dcfce7" fontWeight="400" fontSize="10">Sigma + close loop</text>
          <rect x="50" y="80" width="180" height="52" rx="10" fill="#7c3aed" />
          <text x="140" y="101" fill="#fff">CTI FEED (×2)</text>
          <text x="140" y="117" fill="#ede9fe" fontWeight="400" fontSize="10">aim + enrich</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2" fill="none">
          <polyline points="450,36 490,36 490,80" markerEnd="url(#dfir-a1)" />
          <line x1="580" y1="132" x2="580" y2="156" markerEnd="url(#dfir-a1)" />
          <line x1="490" y1="186" x2="454" y2="186" markerEnd="url(#dfir-a1)" />
          <line x1="270" y1="186" x2="234" y2="186" markerEnd="url(#dfir-a1)" />
          <polyline points="140,160 140,62 266,62" markerEnd="url(#dfir-a1)" />
        </g>
        <g stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="5 4">
          <line x1="230" y1="106" x2="266" y2="106" />
          <line x1="230" y1="186" x2="266" y2="186" />
        </g>
        <text x="360" y="234" textAnchor="middle" fontSize="11" fill="#64748b">Disproven hypothesis = success (uncertainty retired) · un-automated finding = debt</text>
      </svg>
    </Figure>
    <h4>3.8 ★ NEW · Beyond the basics: Unified Kill Chain, KEV, D3FEND</h4>
    <p>
      Three extensions complete the modeling toolkit. The <b>Unified Kill Chain</b> (Pols) expands Lockheed's seven
      stages to eighteen — adding pivoting, privilege escalation, defense evasion, and objectives as first-class phases —
      which maps red-team reports and ATT&CK paths far more faithfully; use it whenever the seven-stage chain feels
      lossy. <b>CISA's Known Exploited Vulnerabilities (KEV) catalog</b> lists CVEs with confirmed in-the-wild
      exploitation: during IR, KEV membership + <b>EPSS</b> probability scores prioritize which vulnerable systems to
      scope first. <b>MITRE D3FEND</b> mirrors ATT&CK defensively, mapping each offensive technique to countermeasure
      techniques — the vocabulary for justifying controls from incident TTPs (operationalized in Ch. 12). Finally, note
      the other ATT&CK matrices — <b>PRE</b> (pre-compromise recon/resource development), <b>Mobile</b>, and{" "}
      <b>ICS</b> — so enterprise, OT, and mobile investigations share one language.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 3.1 · Kill-Chain + ATT&amp;CK mapping (60 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Given a 2-page intrusion narrative (phish → macro → C2 → LSASS → RDP → exfil), assign Kill-Chain stages to each step.</li>
      <li>Map every step to ATT&amp;CK technique IDs (aim: 8+ mappings with sub-techniques where applicable).</li>
      <li>For each technique, name the single best forensic artifact proving or refuting it (chapter + log source).</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 3.2 · Pyramid-of-Pain rewrite (30 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Take a hash-and-IP-only vendor report and rewrite its recommendations at the TTP level.</li>
      <li>Draft one hunt hypothesis per TTP with data source, baseline, and anomaly definition.</li>
      <li>Peer-grade: would your detection survive a recompile + new C2 domain? If not, climb the pyramid.</li>
    </ol>
  </>
);

export const ch03: Chapter = {
  id: "ch3",
  num: 3,
  title: "Threat Frameworks and Adversary Tradecraft (MITRE ATT&CK & CTI)",
  subtitle: "Kill Chain · Diamond Model · ATT&CK · Pyramid of Pain · CTI · Navigator · LotL",
  badge: "Foundations · Threat baselines",
  time: "7–9 h · ~34 pages equiv.",
  outcomes:
    "Model intrusions with Kill Chain, Diamond, and ATT&CK; rank controls by Pyramid of Pain; consume CTI by level; build Navigator coverage layers; detect LotL behaviorally.",
  body,
  labTitle: "Hands-on Lab 3.1 · Kill-Chain + ATT&CK mapping + Lab 3.2 · Pyramid-of-Pain rewrite",
  labsBody,
  workshop: {
    title: "Threat-informed scoping: map an incident to ATT&CK and score coverage",
    env: ["ATT&CK Navigator (local)", "Incident narrative handout", "jq + python3"],
    tabs: [
      {
        id: "map",
        label: "Map techniques",
        steps: [
          {
            n: "1",
            title: "Extract the technique spine",
            desc: "Read the narrative once for story, once for verbs — every adversary verb maps to a technique.",
            code: [
              {
                title: "Bash — technique inventory",
                text: `cat > incident-techniques.txt <<'EOF'\nT1566.001 Spearphishing Attachment   # malicious xlsm\nT1059.001 PowerShell                 # base64 -enc payload\nT1071.004 DNS C2                     # TXT beacons\nT1003.001 LSASS Memory               # credential dump\nT1021.004 SSH / T1021.001 RDP        # lateral movement\nT1048 Exfiltration Over C2           # staged rar to C2\nEOF\ncat incident-techniques.txt`,
              },
            ],
          },
          {
            n: "2",
            title: "Attach data sources per technique",
            desc: "Unmapped techniques are unscoped techniques — each needs a log source that would have seen it.",
            code: [
              {
                title: "Bash — source matrix",
                text: `cat > technique-sources.tsv <<'EOF'\nT1566.001\tmail gateway + attachment detonation logs\nT1059.001\tSysmon EID 1 (command line) + ScriptBlock logging\nT1071.004\tDNS query logs + Zeek dns.log\nT1003.001\tSysmon EID 10 (lsass access) + EDR telemetry\nT1021.004\tsshd auth.log + firewall allows\nT1048\tproxy bytes-out + Zeek conn.log orig_bytes\nEOF\ncolumn -s$'\\t' -t technique-sources.tsv`,
              },
            ],
          },
        ],
      },
      {
        id: "nav",
        label: "Navigator layer",
        steps: [
          {
            n: "3",
            title: "Build a coverage layer",
            desc: "Score 0 (blind) to 3 (alerting detection); Navigator renders the heatmap from this JSON.",
            code: [
              {
                title: "Bash — Navigator layer JSON",
                text: `cat > coverage-layer.json <<'EOF'\n{\n  "name": "INC-2026-0117 coverage", "version": "4.5", "domain": "enterprise-attack",\n  "techniques": [\n    {"techniqueID": "T1566.001", "score": 2, "comment": "gateway blocks known; macro detonation partial"},\n    {"techniqueID": "T1059.001", "score": 1, "comment": "Sysmon deployed 60% fleet; no alerting"},\n    {"techniqueID": "T1071.004", "score": 0, "comment": "no DNS logging — BLIND"},\n    {"techniqueID": "T1003.001", "score": 2, "comment": "EDR blocks known dumpers"},\n    {"techniqueID": "T1021.004", "score": 1, "comment": "auth.log collected, no correlation"},\n    {"techniqueID": "T1048", "score": 0, "comment": "no egress anomaly detection — BLIND"}\n  ],\n  "gradient": {"colors": ["#ff6666", "#ffe766", "#8ec843"], "minValue": 0, "maxValue": 3}\n}\nEOF\njq '.techniques | map(select(.score==0) | .techniqueID)' coverage-layer.json`,
              },
            ],
            expected: '["T1071.004", "T1048"] — the blind spots that must shape the hunt plan',
          },
        ],
      },
      {
        id: "hunt",
        label: "Hunt plan",
        steps: [
          {
            n: "4",
            title: "Convert blind spots to hunts",
            desc: "Every score-0 technique becomes a hunt hypothesis with data source and success criteria.",
            code: [
              {
                title: "Bash — hunt cards",
                text: `cat > hunt-plan.md <<'EOF'\n## H-1 DNS C2 (T1071.004) — BLIND\n- Hypothesis: beacons hide in TXT queries to newly-registered domains\n- Data: enable DNS debug log + Zeek dns.log (Ch. 8-9); baseline query entropy\n- Hit criteria: periodic TXT to low-reputation domain from >1 host\n## H-2 Exfil over C2 (T1048) — BLIND\n- Hypothesis: staged archives egress in off-hours bursts\n- Data: proxy bytes-out + conn.log; baseline per-host egress\n- Hit criteria: >500MB off-hours egress to non-CDN host\nEOF\ncat hunt-plan.md`,
              },
            ],
          },
          {
            n: "5",
            title: "Record detection debt",
            note: "Deliverable: incident-techniques.txt + technique-sources.tsv + coverage-layer.json + hunt-plan.md. Debt rule: no incident closes with a score-0 technique unowned.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> ATT&amp;CK tactics (§3.2) · Pyramid of Pain (§3.3) → Sysmon data (§3.6, Ch. 6) → Sigma
        detections (Ch. 12). Deliverable: a Navigator layer that doubles as the incident's detection-debt ledger.
      </>
    ),
  },
  quiz: [
    { q: "The Diamond Model's four vertices are:", o: ["Adversary, capability, infrastructure, victim", "Prepare, detect, contain, recover", "Hash, IP, domain, URL", "Confidentiality, integrity, availability, utility"], a: 0, e: "Pivoting traverses adversary↔capability↔infrastructure↔victim edges." },
    { q: "T1059.001 (PowerShell) is best described as a:", o: ["Tactic", "Technique (sub-technique)", "Procedure for one group only", "Mitigation"], a: 1, e: "Techniques answer 'how'; the .001 suffix marks a sub-technique." },
    { q: "Per the Pyramid of Pain, the most durable detection level is:", o: ["File hashes", "IP addresses", "Domain names", "TTPs"], a: 3, e: "Behaviors are mission-required; re-tooling them is expensive." },
    { q: "A sector threat-landscape brief for executives is:", o: ["Technical intelligence", "Strategic intelligence", "A firewall rule", "A hash feed"], a: 1, e: "Strategic CTI answers who/why for decision-makers." },
    { q: "ATT&CK Navigator layers are primarily used to:", o: ["Encrypt C2 traffic", "Visualize and compare technique coverage as scored heatmaps", "Image disks", "Generate passwords"], a: 1, e: "Scored layers expose detection gaps at a glance." },
    { q: "The minimum viable detection triple for LotL abuse is:", o: ["Hash + IP + domain", "Parent process + command line + network behavior", "Username + password + MFA", "Make + model + serial"], a: 1, e: "Signed binaries defeat hash allowlists; behavior is the signal." },
  ],
};
