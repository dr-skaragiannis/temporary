import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>13.1 Active containment strategies</h4>
    <p>
      Containment trades adversary freedom for business continuity along a spectrum (Fig. 19): <b>monitor-and-scope</b>{" "}
      (watch while mapping the full footprint — chosen early, when eviction would scatter the intruder),{" "}
      <b>host isolation</b> (EDR network quarantine preserving power and RAM for forensics), <b>dynamic firewall
      drops</b> (block C2 IPs/domains at edge + proxy within minutes), and <b>null-routing / VLAN quarantine</b> of
      compromised subnets (last resort, business-impacting). Sequence matters: isolate <i>simultaneously</i> after
      scoping (staggered isolation warns the adversary), and always preserve a forensic copy of at least one
      representative host <i>before</i> any rebuild.
    </p>
    <Figure
      id="fig-contain-matrix"
      label="Fig. 19 · Containment decision matrix (vector)"
      caption={
        <>
          <b>Fig. 19.</b> Containment choice by scope confidence and spread rate. Fast-spreading + well-scoped =
          isolate everything now. Slow + uncertain = monitor while scoping, with pre-staged isolation. Never rebuild
          before scoping completes.
        </>
      }
    >
      <svg viewBox="0 0 720 240" className="w-full h-auto" role="img" aria-label="Containment matrix">
        <text x="360" y="18" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e">SCOPE CONFIDENCE →</text>
        <text x="18" y="130" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e" transform="rotate(-90 18 130)">SPREAD ↑</text>
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="60" y="30" width="310" height="88" rx="10" fill="#b45309" />
          <text x="215" y="52" fill="#fff">FAST + UNCERTAIN</text>
          <text x="215" y="69" fill="#fef3c7" fontWeight="400">worm / ransomware spreading</text>
          <text x="215" y="86" fill="#fff">→ ISOLATE SEGMENTS NOW</text>
          <text x="215" y="102" fill="#fef3c7" fontWeight="400">scope in parallel, accept impact</text>
          <rect x="390" y="30" width="310" height="88" rx="10" fill="#be123c" />
          <text x="545" y="52" fill="#fff">FAST + SCOPED</text>
          <text x="545" y="69" fill="#ffe4e6" fontWeight="400">footprint mapped</text>
          <text x="545" y="86" fill="#fff">→ SIMULTANEOUS EVICTION</text>
          <text x="545" y="102" fill="#ffe4e6" fontWeight="400">isolate + block + reset at T-hour</text>
          <rect x="60" y="126" width="310" height="88" rx="10" fill="#0e7490" />
          <text x="215" y="148" fill="#fff">SLOW + UNCERTAIN</text>
          <text x="215" y="165" fill="#e0f2fe" fontWeight="400">lone beacon, unclear spread</text>
          <text x="215" y="182" fill="#fff">→ MONITOR + SCOPE</text>
          <text x="215" y="198" fill="#e0f2fe" fontWeight="400">pre-stage isolation, watch 24–72 h</text>
          <rect x="390" y="126" width="310" height="88" rx="10" fill="#166534" />
          <text x="545" y="148" fill="#fff">SLOW + SCOPED</text>
          <text x="545" y="165" fill="#dcfce7" fontWeight="400">contained hosts known</text>
          <text x="545" y="182" fill="#fff">→ SURGICAL ISOLATION</text>
          <text x="545" y="198" fill="#dcfce7" fontWeight="400">host-by-host, business-hours safe</text>
        </g>
      </svg>
    </Figure>
    <h4>13.2 Active Directory &amp; identity eviction</h4>
    <p>
      Identity eviction must be <b>total and synchronized</b>, or the adversary walks back in with surviving
      credentials. Playbook: disable/purge compromised accounts (especially Domain Admins), force enterprise password
      resets in tiered order, execute the <b>double krbtgt reset</b> (reset twice with replication + ticket-lifetime
      gap to invalidate all Kerberos tickets including <b>Golden Tickets</b>), reset computer-account passwords for
      touched hosts, revoke OAuth/app consents and refresh tokens, and rotate service/SPN passwords (Kerberoastable
      accounts first). Verify with 4768/4769/4624 monitoring for 72 hours post-eviction: silence is success; any
      recurrence restarts scoping.
    </p>
    <DataTable
      head={["Eviction action", "Defeats", "Order / timing"]}
      rows={[
        ["Disable compromised accounts", "Interactive + scheduled reuse", "T-hour, all at once (scripted)"],
        ["krbtgt reset ×2 (with gap)", "Golden Tickets, all TGTs", "Reset → replicate → wait 2× max lifetime → reset"],
        ["Computer-account resets (touched hosts)", "Silver Tickets, machine persistence", "With host rebuilds"],
        ["OAuth/app-consent revocation", "Token-based mailbox/API persistence", "Same hour as password resets"],
        ["SPN/service password rotation", "Kerberoastable persistence", "Before re-enabling services"],
        ["72-h auth monitoring", "Undeclared persistence", "4768/69/4624 anomaly hunts, Tier 2 owned"],
      ]}
    />
    <h4>13.3 Service remediation: shells, keys, tasks, rebuilds</h4>
    <p>
      Eradication removes every persistence foothold catalogued in Fig. 8 plus infrastructure footholds: delete{" "}
      <b>webshells</b> (then find the upload vector — deleting shells without patching re-invites), purge rogue{" "}
      <b>SSH authorized_keys</b> fleet-wide, remove malicious <b>scheduled tasks/services/WMI subscriptions</b>, revoke
      adversary-created <b>mailbox rules and OAuth grants</b>, and <b>rebuild compromised servers from known-good
      images</b> (reimaging beats cleaning for any host with kernel-level or firmware-adjacent compromise — and for
      ransomware-detonated hosts, always). Patch the exploited vector <i>before</i> reconnecting rebuilt hosts, or the
      rebuild becomes re-compromise.
    </p>
    <h4>13.4 Blameless post-mortems &amp; root-cause analysis</h4>
    <p>
      Post-incident activity (NIST phase 4) converts cost into capability — but only if <b>blameless</b>. Structure:
      timeline review (what happened, minute by minute), <b>five-whys RCA</b> per causal branch (stopping at systemic
      causes — "patch SLA had no owner," not "admin clicked"), control-gap mapping (which layer of Fig. 16/17 failed
      and why), and <b>owned action items</b> (control, owner, deadline — no ownerless "improve awareness"). Publish
      two artifacts: the internal technical post-mortem (full detail) and the executive summary (impact, cause,
      cost, prevention). Measure: % actions closed by deadline, and detection-coverage delta (Ch. 12).
    </p>
    <h4>13.5 Forensic report writing</h4>
    <p>
      Reports serve three readers: counsel (admissibility), executives (decisions), and engineers (remediation).{" "}
      <b>Structure</b>: executive summary (1 page: scope, impact, cause, status), methodology (tools, versions,
      hashes, custody manifest), timeline (UTC, sourced per event), findings per system (evidence → analysis →
      verdict → confidence), IoC/TTP appendices (hashes, IPs, domains, YARA, Sigma), and recommendations (prioritized,
      owned). <b>Language discipline</b>: distinguish <i>observed</i> (in evidence), <i>inferred</i> (analysis with
      stated basis), and <i>unknown</i> (explicit gaps) — overstated certainty collapses under cross-examination.
      Every factual claim cites an exhibit ID.
    </p>
    <h4>13.6 Capstone: multi-stage mock breach</h4>
    <p>
      The capstone synthesizes the entire book in one campaign (Fig. 20): <b>phishing delivery</b> (mail gateway,
      Ch. 8) → <b>macro execution + persistence</b> (Sysmon EID 1, Run key, Ch. 4–6) → <b>credential theft + AD lateral
      movement</b> (LSASS dump, 4769 roast, RDP, Ch. 8) → <b>DNS exfiltration + C2</b> (tunnel, beacon, Ch. 9) →
      detection (Suricata + Sigma, Ch. 10/12) → correlation (SIEM chain, Ch. 11) → <b>containment, eviction, and
      reporting</b> (this chapter). Work it end-to-end in the lab: scope, contain, evict, remediate, report — then
      defend your report in a mock review.
    </p>
    <Figure
      id="fig-capstone"
      label="Fig. 20 · Capstone breach path (vector)"
      caption={
        <>
          <b>Fig. 20.</b> The full campaign arc with chapter citations. Trace it forward as the attacker, backward as
          the responder: every red hop has a blue detection chapter. The capstone is solved when every hop has both a
          finding and a control.
        </>
      }
    >
      <svg viewBox="0 0 720 280" className="w-full h-auto" role="img" aria-label="Capstone path">
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="160" height="80" rx="8" fill="#be123c" />
          <text x="90" y="50" fill="#fff">1 · PHISH</text>
          <text x="90" y="66" fill="#ffe4e6" fontWeight="400">xlsm + macro</text>
          <text x="90" y="82" fill="#fff" fontSize="9">detect: mail + EID 1</text>
          <text x="90" y="96" fill="#ffe4e6" fontSize="9">Ch. 8 · Ch. 6</text>
          <rect x="190" y="30" width="160" height="80" rx="8" fill="#b45309" />
          <text x="270" y="50" fill="#fff">2 · EXEC+PERSIST</text>
          <text x="270" y="66" fill="#fef3c7" fontWeight="400">powershell + Run</text>
          <text x="270" y="82" fill="#fff" fontSize="9">detect: Sigma dfir-41</text>
          <text x="270" y="96" fill="#fef3c7" fontSize="9">Ch. 4–6 · Ch. 12</text>
          <rect x="370" y="30" width="160" height="80" rx="8" fill="#7c3aed" />
          <text x="450" y="50" fill="#fff">3 · CREDS + AD</text>
          <text x="450" y="66" fill="#ede9fe" fontWeight="400">LSASS → roast → RDP</text>
          <text x="450" y="82" fill="#fff" fontSize="9">detect: EID 10 + 4769</text>
          <text x="450" y="96" fill="#ede9fe" fontSize="9">Ch. 6 · Ch. 8</text>
          <rect x="550" y="30" width="160" height="80" rx="8" fill="#0e7490" />
          <text x="630" y="50" fill="#fff">4 · C2 + EXFIL</text>
          <text x="630" y="66" fill="#e0f2fe" fontWeight="400">DNS tunnel 60 s</text>
          <text x="630" y="82" fill="#fff" fontSize="9">detect: Zeek + Suricata</text>
          <text x="630" y="96" fill="#e0f2fe" fontSize="9">Ch. 9–10</text>
          <rect x="100" y="140" width="220" height="80" rx="8" fill="#166534" />
          <text x="210" y="160" fill="#fff">5 · CORRELATE (SIEM)</text>
          <text x="210" y="176" fill="#dcfce7" fontWeight="400">four-hop chain fires</text>
          <text x="210" y="192" fill="#fff" fontSize="9">page Tier 2 + ticket</text>
          <text x="210" y="206" fill="#dcfce7" fontSize="9">Ch. 11</text>
          <rect x="350" y="140" width="260" height="80" rx="8" fill="#0f1c2e" />
          <text x="480" y="160" fill="#fbbf24">6 · EVICT + REPORT</text>
          <text x="480" y="176" fill="#cbd5e1" fontWeight="400">isolate · krbtgt×2 · rebuild</text>
          <text x="480" y="192" fill="#fbbf24" fontSize="9">post-mortem + report</text>
          <text x="480" y="206" fill="#cbd5e1" fontSize="9">Ch. 13 · Ch. 1 custody</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="70" x2="186" y2="70" markerEnd="url(#dfir-a1)" />
          <line x1="350" y1="70" x2="366" y2="70" markerEnd="url(#dfir-a1)" />
          <line x1="530" y1="70" x2="546" y2="70" markerEnd="url(#dfir-a1)" />
          <line x1="270" y1="110" x2="230" y2="136" markerEnd="url(#dfir-a1)" />
          <line x1="450" y1="110" x2="450" y2="136" markerEnd="url(#dfir-a1)" />
          <line x1="320" y1="180" x2="346" y2="180" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="244" textAnchor="middle" fontSize="11" fill="#64748b">Forward = attacker path · backward = responder trace · every hop needs finding + control + report citation</text>
      </svg>
    </Figure>
    <Callout color="emerald">
      <b>Graduation standard.</b> You can now scope an intrusion across host, identity, network, and SIEM; preserve
      evidence to court standards; evict an enterprise adversary; and write the report. The capstone proves it —
      everything else was rehearsal.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash/PowerShell — T-hour eviction checklist (scripted, simultaneous)"
        code={`# T-60: freeze scope — export final host/user/IP sets\ncat scope-hosts.txt scope-users.txt scope-ips.txt | sort -u | tee T-hour-scope.txt\n# T-0: isolate hosts (EDR API), block C2 (edge FW + proxy), disable accounts (AD)\n#   ./evict-isolate.sh --scope T-hour-scope.txt --ticket INC-2026-0117\n# T+30: krbtgt reset #1 (all DCs), revoke OAuth grants, rotate SPN passwords\n# T+36h: krbtgt reset #2 (after 2x max ticket lifetime + replication)\n# T+72h: verify — 4768/4769/4624 anomaly hunts silent, beacons dark, tickets clean\n# T+5d: post-mortem published, actions owned, detections shipped, report delivered`}
      />
    </div>
    <h4>13.7 ★ NEW · The ransomware endgame</h4>
    <p>
      Ransomware compresses the whole IR lifecycle into hours, so run the decision tree (Fig. 24), not adrenaline.{" "}
      <b>Identify the variant first</b> (ransom note + extension + C2 via ID Ransomware; check No More Ransom for free
      decryptors) — variant determines spread mechanics, leak-site behavior, and negotiation posture. <b>Payment
      default is NO</b>: it funds crime, rarely guarantees full recovery, and may violate sanctions (verify via counsel
      + law enforcement); documented exceptions (life-safety, existential business threat) still go through experienced
      counsel/negotiators, never direct chat. Assume <b>double extortion</b>: monitor leak sites and trigger breach
      notification (below) regardless of payment — encryption recovery and data exposure are separate incidents sharing
      one root cause. <b>Restore order is sacred</b>: Tier-0 identity (AD) first → backup infrastructure (verified
      clean) → security tooling → business systems → endpoints. Restoring endpoints before AD hands fresh machines to
      an adversary still holding domain admin — the classic re-encryption loop. Case echoes: NotPetya taught that
      segmentation + tested offline backups are the only wiper-grade defense; Colonial taught that OT-adjacent IT
      outages become national incidents.
    </p>
    <Figure
      id="fig-ransom-tree"
      label="Fig. 24 · Ransomware decision tree + restore order (vector) ★ NEW"
      caption={
        <>
          <b>Fig. 24.</b> Decide down the tree; restore up the lane. The two most common failures are paying without
          counsel/sanctions checks and rebuilding endpoints before identity. Time-box each decision — ransomware
          rewards the prepared, not the fast.
        </>
      }
    >
      <svg viewBox="0 0 720 300" className="w-full h-auto" role="img" aria-label="Ransomware tree">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="230" y="10" width="260" height="44" rx="8" fill="#be123c" />
          <text x="360" y="28" fill="#fff">DETONATION CONFIRMED</text>
          <text x="360" y="44" fill="#ffe4e6" fontWeight="400" fontSize="10">isolate + preserve one host for forensics</text>
          <rect x="230" y="66" width="260" height="44" rx="8" fill="#b45309" />
          <text x="360" y="84" fill="#fff">IDENTIFY VARIANT</text>
          <text x="360" y="100" fill="#fef3c7" fontWeight="400" fontSize="10">ID Ransomware · decryptor? · leak site?</text>
          <rect x="120" y="122" width="220" height="52" rx="8" fill="#166534" />
          <text x="230" y="140" fill="#fff">CLEAN BACKUPS?</text>
          <text x="230" y="156" fill="#dcfce7" fontWeight="400" fontSize="10">YES → restore lane ↓</text>
          <text x="230" y="164" fill="#fff" fontSize="9">test restore first</text>
          <rect x="380" y="122" width="220" height="52" rx="8" fill="#0f1c2e" />
          <text x="490" y="140" fill="#fbbf24">NO BACKUPS</text>
          <text x="490" y="156" fill="#cbd5e1" fontWeight="400" fontSize="10">counsel + LE + sanctions</text>
          <text x="490" y="164" fill="#fbbf24" fontSize="9">default: NO-PAY</text>
          <rect x="120" y="186" width="220" height="76" rx="8" fill="#0e7490" />
          <text x="230" y="204" fill="#fff">RESTORE LANE (order!)</text>
          <text x="230" y="220" fill="#e0f2fe" fontWeight="400" fontSize="10">1 AD Tier-0 · 2 backups</text>
          <text x="230" y="236" fill="#e0f2fe" fontWeight="400" fontSize="10">3 security tools · 4 biz · 5 endpoints</text>
          <text x="230" y="252" fill="#fef08a" fontSize="9">AD first — always</text>
          <rect x="380" y="186" width="220" height="76" rx="8" fill="#7c3aed" />
          <text x="490" y="204" fill="#fff">PARALLEL TRACK</text>
          <text x="490" y="220" fill="#ede9fe" fontWeight="400" fontSize="10">leak-site watch · notify</text>
          <text x="490" y="236" fill="#ede9fe" fontWeight="400" fontSize="10">per §13.8 clocks</text>
          <text x="490" y="252" fill="#fff" fontSize="9">exposure ≠ encryption</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2" fill="none">
          <line x1="360" y1="54" x2="360" y2="62" markerEnd="url(#dfir-a1)" />
          <polyline points="360,110 360,116 230,116 230,118" markerEnd="url(#dfir-a1)" />
          <polyline points="360,110 360,116 490,116 490,118" markerEnd="url(#dfir-a1)" />
          <line x1="230" y1="174" x2="230" y2="182" markerEnd="url(#dfir-a1)" />
          <line x1="490" y1="174" x2="490" y2="182" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="284" textAnchor="middle" fontSize="11" fill="#64748b">Payment never skips notification; notification never waits for full scoping — clocks run from awareness</text>
      </svg>
    </Figure>
    <h4>13.8 ★ NEW · Disclosure clocks and the war room</h4>
    <p>
      Breach notification is a legal countdown starting at <i>awareness</i>, not at full scoping — which is why
      commanders notify on preliminary findings and update, rather than waiting for certainty. Operate the{" "}
      <b>war room</b> on cadence: internal syncs twice daily, executive updates daily, customer/regulator comms only
      through counsel-approved statements. Roles stay fixed for the incident: commander (decisions), scribe (the
      log <i>is</i> the investigation record), host/identity/network leads, comms, and legal. Rotate humans on
      12-hour shifts; incidents longer than 72 hours without rotation produce errors, not heroes.
    </p>
    <DataTable
      head={["Regime", "Clock", "Trigger (simplified)"]}
      rows={[
        ["GDPR Art. 33/34", "72 h to authority; individuals without undue delay", "Personal-data breach with risk to rights"],
        ["NIS2 Art. 23", "24 h early warning; 72 h notification; 14 d final", "Significant incident at essential/important entity"],
        ["US SEC Reg S-K", "4 business days (8-K Item 1.05)", "Material cybersecurity incident at listed company"],
        ["US CIRCIA", "72 h to CISA (+24 h ransom payment)", "Covered-entity incidents, as final rules apply"],
        ["Sector / contract", "Varies (often 24–72 h)", "Customer DPAs, cyber-insurance, and PCI/FINRA overlays"],
      ]}
    />
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 13.1 · Containment + eviction drill (90 min, team)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Role-play T-hour: commander, host lead, identity lead, network lead, scribe — against a ticking scenario.</li>
      <li>Execute Fig. 19 placement → simultaneous isolation → krbtgt×2 → rebuild order; log every action UTC.</li>
      <li>Run the 72-h verification hunt pack; declare success or re-scope with evidence.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 13.2 · Capstone investigation + reports (multi-session)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Investigate the full Fig. 20 evidence pack (mail, Sysmon, DC, DNS, Zeek, proxy): scope every hop.</li>
      <li>Contain, evict, and remediate in the lab; collect pre/post evidence for each action.</li>
      <li>Deliver the technical report + 1-page executive brief + post-mortem actions; defend in mock review.</li>
    </ol>
  </>
);

export const ch13: Chapter = {
  id: "ch13",
  num: 13,
  title: "Enterprise Containment, Eradication, Post-Mortems, and Capstone Investigation",
  subtitle: "Containment matrix · krbtgt eviction · Remediation · Post-mortems · Reports · Capstone",
  badge: "Tier 4 · Response capstone",
  time: "12–14 h · ~50 pages equiv.",
  outcomes:
    "Choose containment by scope/spread; execute synchronized identity eviction; remediate services completely; run blameless RCAs; write court-ready reports; solve the end-to-end capstone.",
  body,
  labTitle: "Hands-on Lab 13.1 · Containment + eviction drill + Lab 13.2 · Capstone investigation + reports",
  labsBody,
  workshop: {
    title: "T-hour rehearsal: isolate, block, reset, verify",
    env: ["Lab AD forest (snapshot)", "EDR sim + firewall", "Eviction scripts + hunt pack"],
    tabs: [
      {
        id: "stage",
        label: "Stage T-hour",
        steps: [
          {
            n: "1",
            title: "Freeze and validate scope",
            desc: "Eviction scope is a versioned artifact — hosts, users, IPs, signed by the commander.",
            code: [
              {
                title: "Bash — scope freeze",
                text: `cat scope-hosts.txt scope-users.txt scope-ips.txt > T-hour-scope.txt\nsha256sum T-hour-scope.txt | tee T-hour-scope.sha256\nwc -l scope-hosts.txt scope-users.txt scope-ips.txt`,
              },
            ],
          },
          {
            n: "2",
            title: "Pre-stage all actions",
            desc: "Isolation commands, firewall blocks, and disable scripts queued — dry-run everything.",
            code: [
              {
                title: "Bash — dry run",
                text: `./evict-isolate.sh --scope T-hour-scope.txt --dry-run\n./evict-block.sh --scope T-hour-scope.txt --dry-run\n./evict-disable.sh --scope T-hour-scope.txt --dry-run`,
              },
            ],
            expected: "dry-run lists exact targets with zero errors before T-0 approval",
          },
        ],
      },
      {
        id: "evict",
        label: "Execute eviction",
        steps: [
          {
            n: "3",
            title: "T-0: simultaneous isolation + blocks + disables",
            desc: "One command window, all vectors at once — staggered eviction scatters adversaries.",
            code: [
              {
                title: "Bash — T-0",
                text: `date -u +"T-0 %FT%TZ" | tee evict-log.txt\n./evict-isolate.sh --scope T-hour-scope.txt | tee -a evict-log.txt\n./evict-block.sh --scope T-hour-scope.txt | tee -a evict-log.txt\n./evict-disable.sh --scope T-hour-scope.txt | tee -a evict-log.txt`,
              },
            ],
          },
          {
            n: "4",
            title: "krbtgt reset #1 + token revocation",
            desc: "Golden-Ticket kill, first half; OAuth revocation in the same hour.",
            code: [
              {
                title: "PowerShell — krbtgt #1 (DC, Domain Admin)",
                text: `# Reset krbtgt account password (scripted, logged); record timestamp\n# Revoke OAuth grants for compromised users (Entra/ADFS per environment)\nGet-Date -Format o  # T+krbtgt1 timestamp for the report`,
              },
            ],
            expected: "all TGTs invalidated; helpdesk surge handled per comms plan",
          },
        ],
      },
      {
        id: "verify",
        label: "Verify + report",
        steps: [
          {
            n: "5",
            title: "72-hour verification hunts",
            desc: "4768/69/4624 anomalies, beacon re-checks, new persistence screens — silence is success.",
            code: [
              {
                title: "Bash — verification pack",
                text: `./hunt-verify.sh --since T-0 --scope T-hour-scope.txt\n# expect: zero roast indicators, zero new beacons, zero unknown persistence\n# any hit -> re-scope from Ch. 8, do NOT re-evict blindly`,
              },
            ],
          },
          {
            n: "6",
            title: "Publish post-mortem + report skeleton",
            note: "Deliverable: frozen scope + eviction log + krbtgt timestamps + verification results + report skeleton with exhibit citations. Capstone teams execute this for real in Lab 13.2.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> containment matrix (§13.1) · eviction order (§13.2) · remediation (§13.3) → post-mortem
        (§13.4) + report (§13.5). Deliverable: a rehearsed, logged, verifiable T-hour.
      </>
    ),
  },
  quiz: [
    { q: "Staggered (host-by-host, hours apart) isolation risks:", o: ["Nothing", "Warning the adversary, who scatters to unscoped hosts", "Faster recovery", "Better logs"], a: 1, e: "Eviction is simultaneous after scoping — see Fig. 19." },
    { q: "krbtgt must be reset TWICE because:", o: ["Tradition", "Two resets spanning ticket lifetime + replication invalidate all tickets incl. Golden", "Passwords expire", "DCs need reboots"], a: 1, e: "Single reset leaves a validity window Golden Tickets survive." },
    { q: "Deleting webshells WITHOUT patching the upload vector causes:", o: ["Full recovery", "Re-compromise through the same hole", "Faster servers", "Log growth"], a: 1, e: "Eradication without remediation is temporary." },
    { q: "Blameless post-mortems stop the five-whys at:", o: ["The guilty individual", "Systemic causes with owned fixes", "The firewall", "The first answer"], a: 1, e: "Systems fail; fix ownership, SLAs, and controls — not people." },
    { q: "In forensic reports, 'inferred' means:", o: ["Guessed", "Analysis with stated evidentiary basis, distinct from observed fact", "Proven in court", "Unknown"], a: 1, e: "Observed/inferred/unknown discipline survives cross-examination." },
    { q: "The capstone is solved when:", o: ["One alert fires", "Every attack hop has a finding, a control, and a report citation", "The VM reboots", "Logs are deleted"], a: 1, e: "Fig. 20 completeness: red hops fully answered in blue." },
  ],
};
