import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>1.1 DFIR discipline overview: forensics vs. response</h4>
    <p>
      <b>Digital Forensics and Incident Response (DFIR)</b> unites two disciplines that share evidence but obey
      different clocks. <b>Digital forensics</b> is the post-mortem science of reconstructing past events from
      durable traces — disk images, logs, memory dumps — under strict integrity controls so findings survive legal
      scrutiny. <b>Incident response (IR)</b> is the live operational art of detecting, containing, and eradicating
      an active intrusion while the business keeps running. The central tension of this book is that{" "}
      <mark className="hl">the fastest containment action (reboot, reimage, isolate) can destroy the best forensic
      evidence (RAM, handles, ephemeral logs)</mark>. Every procedure that follows teaches responders to sequence
      volatile collection <i>before</i> disruptive containment, satisfying both clocks.
    </p>
    <DataTable
      head={["Dimension", "Digital Forensics", "Incident Response"]}
      rows={[
        ["Primary question", "What happened, exactly, and can we prove it?", "What is happening now, and how do we stop it?"],
        ["Tempo", "Methodical; weeks acceptable", "Urgent; minutes matter"],
        ["Evidence standard", "Bit-level integrity, chain of custody", "Sufficient fidelity to decide containment"],
        ["Typical outputs", "Timeline, forensic report, expert testimony", "Containment, eradication, recovery, lessons learned"],
        ["Governing standards", "ISO/IEC 27037/27041/27042, RFC 3227", "NIST SP 800-61, SANS PICERL"],
      ]}
    />
    <h4>1.2 Standard IR lifecycles: NIST SP 800-61 and SANS</h4>
    <p>
      <b>NIST SP 800-61 Rev. 2</b> structures response into four phases (Fig. 1): <b>(1) Preparation</b> — playbooks,
      tooling, logging baselines, and contacts established <i>before</i> any alert; <b>(2) Detection &amp; Analysis</b> —
      alert triage, scoping, and prioritization; <b>(3) Containment, Eradication &amp; Recovery</b> — executed as a
      tight loop, since premature eradication tips off adversaries or destroys evidence; <b>(4) Post-Incident
      Activity</b> — root-cause analysis and control improvement. The SANS <b>PICERL</b> mnemonic (Preparation,
      Identification, Containment, Eradication, Recovery, Lessons Learned) expands the middle phases for handler
      checklists but preserves identical ordering. Both models insist that phases overlap: analysis continues during
      containment, and preparation is revised after every incident.
    </p>
    <Figure
      id="fig-nist-lifecycle"
      label="Fig. 1 · NIST SP 800-61 incident response lifecycle (vector)"
      caption={
        <>
          <b>Fig. 1.</b> The four NIST phases with the operational feedback loop: detection findings re-scope
          containment, and post-incident lessons rewrite preparation. Read clockwise; the inner loop is where real
          investigations spend most of their time.
        </>
      }
    >
      <svg viewBox="0 0 720 210" className="w-full h-auto" role="img" aria-label="NIST IR lifecycle">
        <defs>
          <marker id="dfir-a1" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
            <path d="M0,0 L10,5 L0,10 z" fill="#0f1c2e" />
          </marker>
        </defs>
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="160" height="100" rx="10" fill="#0f1c2e" />
          <text x="90" y="72" fill="#fbbf24">1 · PREPARATION</text>
          <text x="90" y="90" fill="#cbd5e1" fontWeight="400" fontSize="10">Playbooks · logging</text>
          <text x="90" y="106" fill="#cbd5e1" fontWeight="400" fontSize="10">Tools · contacts</text>
          <text x="90" y="122" fill="#cbd5e1" fontWeight="400" fontSize="10">Exercises</text>
          <rect x="190" y="40" width="160" height="100" rx="10" fill="#0e7490" />
          <text x="270" y="72" fill="#fff">2 · DETECTION</text>
          <text x="270" y="90" fill="#e0f2fe" fontWeight="400" fontSize="10">&amp; ANALYSIS</text>
          <text x="270" y="106" fill="#e0f2fe" fontWeight="400" fontSize="10">Triage · scope</text>
          <text x="270" y="122" fill="#e0f2fe" fontWeight="400" fontSize="10">Prioritize</text>
          <rect x="370" y="40" width="160" height="100" rx="10" fill="#b45309" />
          <text x="450" y="72" fill="#fff">3 · CONTAIN</text>
          <text x="450" y="90" fill="#fef3c7" fontWeight="400" fontSize="10">ERADICATE</text>
          <text x="450" y="106" fill="#fef3c7" fontWeight="400" fontSize="10">RECOVER</text>
          <text x="450" y="122" fill="#fef3c7" fontWeight="400" fontSize="10">(tight loop)</text>
          <rect x="550" y="40" width="160" height="100" rx="10" fill="#166534" />
          <text x="630" y="72" fill="#fff">4 · POST-</text>
          <text x="630" y="90" fill="#dcfce7" fontWeight="400" fontSize="10">INCIDENT</text>
          <text x="630" y="106" fill="#dcfce7" fontWeight="400" fontSize="10">RCA · report</text>
          <text x="630" y="122" fill="#dcfce7" fontWeight="400" fontSize="10">Improve</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="90" x2="186" y2="90" markerEnd="url(#dfir-a1)" />
          <line x1="350" y1="90" x2="366" y2="90" markerEnd="url(#dfir-a1)" />
          <line x1="530" y1="90" x2="546" y2="90" markerEnd="url(#dfir-a1)" />
        </g>
        <g stroke="#64748b" strokeWidth="2" fill="none">
          <polyline points="630,140 630,170 90,170 90,144" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="190" textAnchor="middle" fontSize="11" fill="#64748b">Lessons-learned feedback: every incident rewrites preparation</text>
      </svg>
    </Figure>
    <h4>1.3 SOC &amp; CSIRT roles: Tier 1–3 operations</h4>
    <p>
      A <b>Security Operations Center (SOC)</b> provides continuous monitoring; a <b>CSIRT/CERT</b> owns deep
      investigation and coordination. Work flows up an escalation ladder (Fig. 2). <b>Tier 1</b> triage analysts
      monitor queues, enrich alerts with context, and close false positives against runbooks. <b>Tier 2</b> handlers
      investigate confirmed incidents, correlate across sources, and execute containment. <b>Tier 3</b> hunters and
      forensic leads perform malware analysis, memory forensics, and threat hunting, and they author detections.
      Above them, the <b>incident commander</b> owns communications, legal coordination, and business decisions. The
      professional rule: <i>escalate early with evidence attached</i> — a Tier 1 analyst who forwards raw alerts
      without enrichment pushes triage cost uphill.
    </p>
    <Figure
      id="fig-soc-ladder"
      label="Fig. 2 · SOC escalation ladder with SLAs (vector)"
      caption={
        <>
          <b>Fig. 2.</b> Escalation ladder. Each tier adds analytical depth; SLAs tighten with severity. Note the
          downward arrow: Tier 3 detection engineering pushes tuned runbooks back to Tier 1, which is how SOCs scale.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="SOC escalation ladder">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="180" y="10" width="360" height="46" rx="8" fill="#0f1c2e" />
          <text x="360" y="29" fill="#fbbf24">INCIDENT COMMANDER / CSIRT LEAD</text>
          <text x="360" y="45" fill="#cbd5e1" fontWeight="400" fontSize="10">Comms · legal · business decisions</text>
          <rect x="180" y="64" width="360" height="46" rx="8" fill="#7c3aed" />
          <text x="360" y="83" fill="#fff">TIER 3 · HUNT / FORENSICS / DETECTION ENG.</text>
          <text x="360" y="99" fill="#ede9fe" fontWeight="400" fontSize="10">Memory, malware, hunting, Sigma rules</text>
          <rect x="180" y="118" width="360" height="46" rx="8" fill="#0e7490" />
          <text x="360" y="137" fill="#fff">TIER 2 · INCIDENT HANDLER</text>
          <text x="360" y="153" fill="#e0f2fe" fontWeight="400" fontSize="10">Investigate · correlate · contain</text>
          <rect x="180" y="172" width="360" height="46" rx="8" fill="#16a34a" />
          <text x="360" y="191" fill="#fff">TIER 1 · TRIAGE ANALYST (24×7)</text>
          <text x="360" y="207" fill="#dcfce7" fontWeight="400" fontSize="10">Monitor · enrich · runbook response</text>
        </g>
        <g fontSize="10" fill="#64748b" textAnchor="start" fontWeight="700">
          <text x="552" y="40">SEV-1: 15 min</text>
          <text x="552" y="94">SEV-2: 1 h</text>
          <text x="552" y="148">SEV-3: 4 h</text>
          <text x="552" y="202">SEV-4: 1 day</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="150" y1="180" x2="150" y2="70" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="120" y="130" textAnchor="middle" fontSize="11" fontWeight="700" fill="#0f1c2e" className="fig-halo" transform="rotate(-90 120 130)">ESCALATE ↑</text>
        <g stroke="#64748b" strokeWidth="2" strokeDasharray="5 4">
          <line x1="170" y1="90" x2="170" y2="190" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="238" textAnchor="middle" fontSize="11" fill="#64748b">Alerts enter at Tier 1 · evidence-enriched escalations move up · tuned runbooks flow back down</text>
      </svg>
    </Figure>
    <h4>1.4 Triage &amp; severity classification</h4>
    <p>
      Triage converts an unbounded alert stream into a prioritized incident queue. Analysts score each candidate on{" "}
      <b>impact</b> (confidentiality, integrity, availability consequences), <b>urgency</b> (blast-radius growth rate —
      ransomware and worms outrank dormant implants), and <b>confidence</b> (true-positive likelihood from
      corroborating sources). Severity bands then drive SLAs and paging: SEV-1 (critical, enterprise-wide or
      data-breach-confirmed) pages the commander immediately, while SEV-4 (informational) becomes a ticket. Document
      the severity rationale in the ticket; severity downgrades without new evidence are a classic audit finding.
    </p>
    <DataTable
      head={["Severity", "Definition", "Examples", "Response SLA"]}
      rows={[
        ["SEV-1 Critical", "Active breach / enterprise-wide impact", "Ransomware detonated; DC compromise; confirmed exfiltration", "15 min; commander paged"],
        ["SEV-2 High", "Confirmed compromise, contained scope", "Single-host C2 beacon; phished mailbox with lateral login", "1 h; Tier 2 owns"],
        ["SEV-3 Medium", "Suspicious, unconfirmed", "Anomalous PowerShell; impossible-travel login", "4 h; Tier 1 + runbook"],
        ["SEV-4 Low", "Informational / policy", "Blocked malware at proxy; failed brute force below threshold", "1 business day"],
      ]}
    />
    <h4>1.5 Legal and ethical baselines</h4>
    <p>
      Forensic findings may become exhibits. <b>Chain of custody</b> is the documented, gap-free record of who
      collected, handled, stored, and transferred each evidence item — any gap invites a motion to exclude.{" "}
      <b>Legal admissibility</b> further requires relevance, authenticity (hash-linked imaging, write-blocking per Ch.
      2), and repeatable methods executed by qualified analysts. Privacy law constrains collection: employee
      monitoring, cross-border data transfer (GDPR), and breach-notification duties (NIS2, sectoral rules) all shape
      what may be imaged and disclosed. The ethical baseline is narrow: collect the <i>minimum necessary</i> evidence,
      protect unrelated personal data encountered, and never exceed authorization — investigation powers end where the
      scope letter ends.
    </p>
    <h4>1.6 The incident handler's mindset</h4>
    <p>
      Elite handlers combine standard operating procedures with deliberate metacognition. <b>Document contemporaneously</b>:
      every command, timestamp (UTC), and decision enters the case log <i>as executed</i>, because memory degrades
      within hours and testimony may come years later. <b>Hypothesize explicitly and falsify</b>: state the working
      theory ("phishing → credential theft → VPN login") and actively seek disconfirming evidence, countering{" "}
      <b>confirmation bias</b> and <b>anchoring</b> on the first alert. <b>Preserve before you perturb</b> (Ch. 2, Ch.
      7), <b>communicate on a schedule</b> even when there is no news, and <b>declare scope uncertainty honestly</b> —
      "contained to three hosts, two subnets still unverified" beats false confidence that later collapses.
    </p>
    <Callout color="cyan">
      <b>Handler's maxim.</b> <i>Slow is smooth, smooth is fast.</i> Ten minutes spent verifying scope before
      containment saves ten hours of rework when the adversary re-emerges from an unscoped segment.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Case log — minimal contemporaneous record (UTC, append-only)"
        code={`2026-09-26T14:02:11Z  analyst=k.osei  action=ticket SEV-2 opened (EDR alert A-8814, host FIN-WS-114)
2026-09-26T14:06:03Z  analyst=k.osei  action=host isolated via EDR (retain power/RAM); volatile triage started
2026-09-26T14:11:47Z  analyst=k.osei  action=RAM capture started (WinPmem) -> EVID-2026-041.mem, sha256 pending
2026-09-26T14:12:20Z  analyst=k.osei  decision=SEV-2 upheld; scope=1 host + mailbox; notify Tier2 lead`}
      />
    </div>
    <h4>1.7 ★ NEW · Forensic readiness, counsel, and the law around the investigation</h4>
    <p>
      <b>Forensic readiness</b> (Rowlingson) is the discipline of maximizing evidential value <i>before</i> incidents:
      logging policies that capture what courts and responders need, retention that survives dwell time, a documented
      legal basis for monitoring, trained handlers, and tested playbooks. Readiness turns investigations from archaeology
      into retrieval — compare hunting a 200-day dwell with 30-day logs (unwinnable) versus 400-day SIEM retention
      (routine). Treat the table below as a pre-incident checklist: every "no" is a finding to remediate in peacetime,
      not a surprise to discover at 3 a.m.
    </p>
    <DataTable
      head={["Readiness control", "What 'good' looks like", "Who owns it"]}
      rows={[
        ["Logging policy + legal basis", "Required sources per service (Ch. 8–10), employee notice, works-council sign-off where needed", "Security + Legal + HR"],
        ["Retention vs. dwell time", "Hot/warm/cold tiers covering ≥12 months for auth/proxy/DNS; legal-hold override", "SOC + IT ops"],
        ["Evidence capability", "Write-blockers, imagers, RAM tools, custody forms, sealed storage — inventoried quarterly", "Forensic lead"],
        ["Roles + retainers", "Commander roster, outside counsel, IR retainer, comms tree — all with 24×7 numbers", "CISO"],
        ["Exercises", "Quarterly tabletops + annual live-fire; findings tracked like vulnerabilities", "CISO + business"],
      ]}
    />
    <p>
      Two legal instruments shape every enterprise case. A <b>litigation hold</b> is a written preservation order
      suspending routine deletion the moment litigation is reasonably anticipated; violating it is{" "}
      <b>spoliation</b>, punishable by adverse-inference instructions (the court assumes deleted material was
      inculpatory). Scope holds precisely (custodians, systems, date ranges), acknowledge them in writing, and log
      compliance. Second, serious incidents run <b>under outside counsel</b> to protect work product: counsel engages
      the IR firm (the <b>Kovel</b> arrangement for consultants), reports are marked privileged, and handler notes
      assume disclosure. The practical rule for students: <i>write every ticket and report as if opposing counsel will
      read it aloud</i> — because one day they might.
    </p>
    <p>
      <b>Tabletop exercises</b> are where readiness is rehearsed: 2–3-hour facilitated scenarios (ransomware at quarter
      close, cloud-key leak, insider exfiltration) with executives, legal, IT, and comms at the table. Design injects
      that force <i>decisions</i> (pay or not? shut down or monitor? notify now or after scoping?), not trivia. Debrief
      against the NIST phases: where did we stall, who owned the decision, what playbook page was missing? A tabletop
      that produces no action items was theater — rerun it harder.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 1.1 · Severity scoring drill (45 min, no tools)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Score five vignettes (EDR beacon, blocked phish, DC anomaly, failed VPN spray, helpdesk malware report) on impact × urgency × confidence.</li>
      <li>Assign SEV-1–4 with a one-paragraph rationale each; compare against the answer key's escalation thresholds.</li>
      <li>Draft the Tier 1 → Tier 2 handoff note for the highest-severity case: alert, enrichment, scope so far, next step.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 1.2 · Custody &amp; case-log discipline (30 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Complete a chain-of-custody form for a USB evidence drive: item ID, description, collector, hashes, storage location.</li>
      <li>Maintain a UTC case log while executing Workshop 1; every command must appear with timestamp and purpose.</li>
      <li>Peer-review a partner's log for gaps: missing timestamps, unrecorded decisions, or scope claims without evidence.</li>
    </ol>
  </>
);

export const ch01: Chapter = {
  id: "ch1",
  num: 1,
  title: "Introduction to DFIR, SOC Operations, and the Incident Lifecycle",
  subtitle: "Forensics vs. response · NIST 800-61 · SOC tiers · Severity · Legal baselines · Handler mindset",
  badge: "Foundations · Start here",
  time: "6–8 h · ~30 pages equiv.",
  outcomes:
    "Distinguish forensic from response objectives; apply NIST and SANS lifecycles; route work across SOC tiers; score severity; uphold custody and admissibility basics; document like a handler.",
  body,
  labTitle: "Hands-on Lab 1.1 · Severity scoring + Lab 1.2 · Custody & case-log discipline",
  labsBody,
  workshop: {
    title: "Stand up a triage bench: ticket, severity rubric, and evidence register",
    env: ["Linux analyst VM", "Ticket template (markdown)", "Evidence register (CSV)"],
    tabs: [
      {
        id: "triage",
        label: "Ticket + severity",
        steps: [
          {
            n: "1",
            title: "Create the case directory and ticket",
            desc: "One directory per incident; the ticket is the single source of truth for scope and severity.",
            code: [
              {
                title: "Bash — case scaffold",
                text: `mkdir -p ~/cases/INC-2026-0117/{evidence,notes,exports}\ncat > ~/cases/INC-2026-0117/notes/ticket.md <<'EOF'\n# INC-2026-0117 — Suspected C2 beacon (FIN-WS-114)\n- Opened (UTC): \n- Severity: SEV-2 (proposed) — rationale: \n- Scope: hosts=  users=  subnets=\n- Handler: \n- Next review (UTC): \nEOF\ncat ~/cases/INC-2026-0117/notes/ticket.md`,
              },
            ],
          },
          {
            n: "2",
            title: "Score severity with a rubric",
            desc: "Impact × urgency × confidence forces explicit reasoning instead of gut feel.",
            code: [
              {
                title: "Bash — severity rubric",
                text: `cat > ~/cases/INC-2026-0117/notes/severity.md <<'EOF'\nImpact (1-5):      3  # single finance host, C2 suspected\nUrgency (1-5):     4  # beaconing active, lateral movement possible\nConfidence (1-5):  3  # EDR + proxy agree; host not yet examined\nBand: SEV-2  | Review in 60 min or on new host evidence\nEOF\ncat ~/cases/INC-2026-0117/notes/severity.md`,
              },
            ],
          },
        ],
      },
      {
        id: "custody",
        label: "Evidence register",
        steps: [
          {
            n: "3",
            title: "Open the evidence register",
            desc: "Every acquisition gets an ID before collection starts — never after.",
            code: [
              {
                title: "Bash — register header",
                text: `cat > ~/cases/INC-2026-0117/evidence/register.csv <<'EOF'\nitem_id,description,source,collector,utc_collected,sha256,storage\nEVID-2026-041,RAM capture FIN-WS-114,WinPmem,k.osei,,,safe-3/shelf-B\nEOF\ncolumn -s, -t ~/cases/INC-2026-0117/evidence/register.csv`,
              },
            ],
          },
          {
            n: "4",
            title: "Enforce UTC and append-only logging",
            desc: "Mixed timezones are a leading cause of timeline errors in reports.",
            code: [
              {
                title: "Bash — UTC discipline",
                text: `export TZ=UTC; date -u +"opened %Y-%m-%dT%H:%M:%SZ"\nchattr +a ~/cases/INC-2026-0117/notes/case.log 2>/dev/null || echo "append-only flag needs ext4/root — note fallback in log"\necho "$(date -u +%FT%TZ) analyst=k.osei action=case opened" | tee -a ~/cases/INC-2026-0117/notes/case.log`,
              },
            ],
            expected: "opened 2026-09-26T…Z — all subsequent entries carry UTC timestamps",
          },
        ],
      },
      {
        id: "verify",
        label: "Verify & handoff",
        steps: [
          {
            n: "A",
            title: "Self-audit the ticket",
            desc: "Severity without rationale, or scope without evidence, fails review.",
            code: [
              {
                title: "Bash — completeness check",
                text: `grep -Ei "rationale|scope|next review" ~/cases/INC-2026-0117/notes/ticket.md ~/cases/INC-2026-0117/notes/severity.md\nls -R ~/cases/INC-2026-0117`,
              },
            ],
          },
          {
            n: "B",
            title: "Write the Tier 1 → Tier 2 handoff",
            desc: "Alert, enrichment, scope, severity, next step — five lines, no prose sprawl.",
            note: "Deliverable: ticket.md + severity.md + register.csv + case.log committed to the case directory and peer-reviewed.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> NIST phases (§1.2) · SOC tiers (§1.3) · severity bands (§1.4) → custody forms (Ch 2).
        Deliverable: a complete, timestamped case directory ready to receive forensic images.
      </>
    ),
  },
  quiz: [
    { q: "The core tension between forensics and incident response is best stated as:", o: ["Forensics is slower and therefore obsolete", "Fast containment can destroy the best forensic evidence", "Response needs no documentation", "Forensics applies only to disk, never to memory"], a: 1, e: "Reboots/reimages destroy volatile evidence; sequence collection before disruption." },
    { q: "In NIST SP 800-61, containment, eradication, and recovery are:", o: ["Strictly sequential with no overlap", "A tight loop informed by ongoing analysis", "Optional for SEV-3 and below", "Performed before detection"], a: 1, e: "NIST treats them as an iterative loop; analysis continues throughout." },
    { q: "A Tier 1 analyst's highest-value contribution to an escalation is:", o: ["Raw alert forwarding at maximum speed", "Enrichment: context, scope so far, and severity rationale", "Memory forensics of the affected host", "Writing Sigma rules"], a: 1, e: "Enriched escalations let Tier 2 start deciding instead of re-triaging." },
    { q: "Confirmed ransomware detonation on multiple hosts should be classified as:", o: ["SEV-4 informational", "SEV-3 medium", "SEV-2 high", "SEV-1 critical"], a: 3, e: "Active, enterprise-impact compromise pages the commander immediately." },
    { q: "A gap in the chain of custody primarily threatens:", o: ["Network throughput", "Legal admissibility of the evidence", "Hash computation speed", "SIEM licensing"], a: 1, e: "Unaccounted handling invites motions to exclude the exhibit." },
    { q: "“Hypothesize explicitly and seek disconfirming evidence” counters:", o: ["Confirmation bias and anchoring", "Hash collisions", "Log rotation", "Encryption overhead"], a: 0, e: "Deliberate falsification is the handler's debiasing discipline." },
  ],
};
