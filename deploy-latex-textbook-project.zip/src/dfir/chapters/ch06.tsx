import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>6.1 Sysmon architecture: driver + service</h4>
    <p>
      <b>Microsoft System Monitor (Sysmon)</b> pairs a kernel-mode driver (event collection at process, image-load,
      network, and registry callbacks) with a user-mode service that filters events through an XML configuration and
      writes survivors to <b>Microsoft-Windows-Sysmon/Operational</b>. Default Windows auditing sees <i>that</i> a
      process started (4688, often without command line); Sysmon sees <i>how</i>: full command line, parent image and
      PID, file hashes, and session GUIDs that join process trees across reboots of PID numbering. Deployment is via
      GPO/SCCM/Intune with a versioned config; the driver starts early-boot, minimizing blind windows.
    </p>
    <DataTable
      head={["Component", "Role", "Forensic relevance"]}
      rows={[
        ["SysmonDrv (kernel)", "Registers process/image/network/registry callbacks", "Sees events user-mode malware tries to hide"],
        ["Sysmon64.exe (service)", "Applies XML filters, writes .evtx", "Config version determines exactly what is (not) logged"],
        ["Sysmon/Operational channel", "Structured event store", "Forward to SIEM; local retention is finite"],
        ["Config XML (e.g., SwiftOnSecurity)", "Include/exclude rules per Event ID", "Tuning = detection quality; audit it like code"],
      ]}
    />
    <h4>6.2 Process creation telemetry (Event ID 1)</h4>
    <p>
      <b>EID 1</b> is the most valuable event in Windows DFIR: UTC timestamp, Computer, User, Image, CommandLine,{" "}
      <b>ParentImage + ParentCommandLine</b>, ProcessId + ProcessGuid, file <b>hashes</b> (SHA-256/IMPHASH), and
      IntegrityLevel. Parent-child analysis defeats LotL masquerading: <span className="mono text-sm">powershell.exe</span>{" "}
      parented by <span className="mono text-sm">explorer.exe</span> at 09:00 is administration; the same binary
      parented by <span className="mono text-sm">wmiprvse.exe</span> with base64 arguments at 03:00 is T1059. Always
      join on <b>ProcessGuid</b>, never PID — PIDs recycle, GUIDs do not.
    </p>
    <h4>6.3 Network &amp; driver visibility (EID 3, EID 6, EID 22)</h4>
    <p>
      <b>EID 3</b> logs TCP/UDP connections with Image, Source/Destination IP:port, and initiating User — binding every
      socket to its owning process, which firewall logs cannot do. <b>EID 6</b> logs driver loads with signature state,
      catching rootkit and BYOVD (bring-your-own-vulnerable-driver) tradecraft. <b>EID 22 (DNSQuery)</b> logs the
      querying image for every resolution, exposing C2 domains even when network DNS logs are unavailable. Together
      they answer "which process talked to the adversary, and what resolved the domain?" — the host-side half of every
      C2 investigation (network half: Ch. 9).
    </p>
    <Figure
      id="fig-sysmon-chain"
      label="Fig. 10 · Sysmon event chain for one intrusion thread (vector)"
      caption={
        <>
          <b>Fig. 10.</b> One phishing payload narrated end-to-end by Sysmon: process creation (1) → image loads (7)
          → file drop (11) → registry persistence (13) → C2 (3) → DNS (22). Join all nodes on ProcessGuid; the parent
          chain (dashed) proves the infection vector.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="Sysmon event chain">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="160" height="70" rx="8" fill="#0f1c2e" />
          <text x="90" y="50" fill="#fbbf24">EID 1 · PROC CREATE</text>
          <text x="90" y="66" fill="#cbd5e1" fontWeight="400">WINWORD → powershell</text>
          <text x="90" y="82" fill="#fbbf24" fontSize="9">Guid .A1 · -enc …</text>
          <rect x="190" y="30" width="150" height="70" rx="8" fill="#7c3aed" />
          <text x="265" y="50" fill="#fff">EID 7 · IMAGE</text>
          <text x="265" y="66" fill="#ede9fe" fontWeight="400">unsigned DLL</text>
          <text x="265" y="82" fill="#fff" fontSize="9">Signed=false!</text>
          <rect x="360" y="30" width="150" height="70" rx="8" fill="#b45309" />
          <text x="435" y="50" fill="#fff">EID 11 · FILE</text>
          <text x="435" y="66" fill="#fef3c7" fontWeight="400">drop: \Temp\svc.exe</text>
          <text x="435" y="82" fill="#fff" fontSize="9">SHA256: 9f2c…</text>
          <rect x="530" y="30" width="180" height="70" rx="8" fill="#be123c" />
          <text x="620" y="50" fill="#fff">EID 13 · REGISTRY</text>
          <text x="620" y="66" fill="#ffe4e6" fontWeight="400">HKCU\…\Run = svc.exe</text>
          <text x="620" y="82" fill="#fff" fontSize="9">T1547.001</text>
          <rect x="100" y="140" width="200" height="70" rx="8" fill="#0e7490" />
          <text x="200" y="160" fill="#fff">EID 3 · NETWORK</text>
          <text x="200" y="176" fill="#e0f2fe" fontWeight="400">svc.exe → 45.9.148.7:443</text>
          <text x="200" y="192" fill="#fef08a" fontSize="9">5-min beacon</text>
          <rect x="330" y="140" width="200" height="70" rx="8" fill="#166534" />
          <text x="430" y="160" fill="#fff">EID 22 · DNS QUERY</text>
          <text x="430" y="176" fill="#dcfce7" fontWeight="400">svc.exe ? cdn-x7.ru</text>
          <text x="430" y="192" fill="#fff" fontSize="9">low-reputation TLD</text>
          <rect x="560" y="140" width="150" height="70" rx="8" fill="#0f1c2e" />
          <text x="635" y="160" fill="#fbbf24">EID 10 · ACCESS</text>
          <text x="635" y="176" fill="#cbd5e1" fontWeight="400">svc → lsass.exe</text>
          <text x="635" y="192" fill="#fbbf24" fontSize="9">T1003.001!</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="65" x2="186" y2="65" markerEnd="url(#dfir-a1)" />
          <line x1="340" y1="65" x2="356" y2="65" markerEnd="url(#dfir-a1)" />
          <line x1="510" y1="65" x2="526" y2="65" markerEnd="url(#dfir-a1)" />
          <line x1="200" y1="100" x2="200" y2="136" markerEnd="url(#dfir-a1)" />
          <line x1="300" y1="175" x2="326" y2="175" markerEnd="url(#dfir-a1)" />
          <line x1="530" y1="175" x2="556" y2="175" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="234" textAnchor="middle" fontSize="11" fill="#64748b">Join key: ProcessGuid · Parent chain proves vector · EID 10 on lsass escalates to credential-access incident</text>
      </svg>
    </Figure>
    <h4>6.4 Process tampering &amp; injection (EID 8, EID 10)</h4>
    <p>
      <b>EID 8 (CreateRemoteThread)</b> fires when one process starts a thread in another — the hallmark of classic DLL
      injection (T1055). <b>EID 10 (ProcessAccess)</b> logs handle grants with requested rights:{" "}
      <span className="mono text-sm">0x1010/0x1410</span> against <span className="mono text-sm">lsass.exe</span> is the
      LSASS-dump signature (T1003.001), while broad <span className="mono text-sm">0x1FFFFF</span> grants flag hollowing
      precursors. Both are noisy by default (AV, EDR, and browsers trigger them constantly), so production configs
      filter EID 10 to sensitive targets (lsass, csrss, services) and EID 8 to non-browser sources — precision over
      completeness, with full-fidelity capture reserved for incident hosts.
    </p>
    <h4>6.5 Sysmon XML configuration tuning</h4>
    <p>
      The XML schema nests <span className="mono text-sm">&lt;EventFiltering&gt;</span> rules per Event ID with{" "}
      <span className="mono text-sm">onmatch="include|exclude"</span> semantics: list what to <i>keep</i> (rare,
      high-value) and <i>drop</i> (known-benign at volume). Industry templates — <b>SwiftOnSecurity's sysmon-config</b>{" "}
      (balanced, commented, attacker-focused) and Olaf Hartong's modular fork — provide the starting point; enterprises
      then fork, version in Git, and test changes in audit mode before fleet rollout. Treat the config as detection
      code: peer review, change log, and rollback plan for every edit (Ch. 12 extends this to Detection-as-Code).
    </p>
    <h4>6.6 Noise suppression without blinding</h4>
    <p>
      Unfiltered Sysmon can emit millions of events per host per day — a SIEM budget fire. Suppress in priority order:{" "}
      <b>EID 10</b> (scope to sensitive targets), <b>EID 7 image loads</b> (unsigned + non-Microsoft only),{" "}
      <b>EID 3</b> (exclude browser/CDN chatter by destination, keep rare ports and processes), and{" "}
      <b>EID 1</b> (never exclude by image alone — exclude <i>image + parent + arguments</i> triples). The safety
      invariant: <mark className="hl">every exclusion names its residual risk and its compensating control</mark>{" "}
      (e.g., "browser EID 3 excluded; proxy logs retain URL visibility"). Review exclusions quarterly against fresh
      threat intel — adversaries migrate into whatever you stop logging.
    </p>
    <Callout color="cyan">
      <b>Golden queries (memorize).</b> Rare parent→child pairs · base64/encoded command lines · unsigned image loads ·
      lsass access grants · first-seen outbound destinations per process. These five hunts catch most commodity and
      mid-tier intrusions.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="XML — minimal high-value Sysmon filter skeleton (adapted from SwiftOnSecurity pattern)"
        code={`<Sysmon schemaversion="4.90">
  <HashAlgorithms>sha256,IMPHASH</HashAlgorithms>
  <EventFiltering>
    <!-- EID 1: keep everything EXCEPT known-benign triples -->
    <ProcessCreate onmatch="exclude">
      <ParentImage condition="is">C:\\Windows\\System32\\services.exe</ParentImage>
      <Image condition="is">C:\\Windows\\System32\\svchost.exe</Image>
    </ProcessCreate>
    <!-- EID 10: keep ONLY sensitive-target access -->
    <ProcessAccess onmatch="include">
      <TargetImage condition="is">C:\\Windows\\System32\\lsass.exe</TargetImage>
      <TargetImage condition="is">C:\\Windows\\System32\\csrss.exe</TargetImage>
    </ProcessAccess>
    <!-- EID 22: keep all DNS (cheap, high-value); exclude nothing initially -->
    <DnsQuery onmatch="exclude"></DnsQuery>
  </EventFiltering>
</Sysmon>`}
      />
    </div>
    <h4>6.7 ★ NEW · EID atlas, EDR tampering, and the EDR-first workflow</h4>
    <p>
      Students should carry the full Sysmon event map, not just the famous five. The atlas below groups every
      production-relevant Event ID by kill-chain role — process, code, network, file, registry, WMI, and
      self-protection. Two underused entries deserve emphasis: <b>EID 15 (CreateStreamHash)</b> logs ADS creation with
      hashes (the §4.2 concealment primitive, caught at birth), and <b>EID 25 (ProcessTampering)</b> fires when a
      process image is modified in memory — direct hollowing/masquerading signal. When scoping an incident, walk the
      atlas top-down and ask per group "did we log this, and did we look?"
    </p>
    <DataTable
      head={["EID", "Event", "Hunt value"]}
      rows={[
        ["1 / 5 / 25", "ProcessCreate / Ended / Tampering", "Trees, lifetimes, in-memory image modification"],
        ["6 / 7", "DriverLoad / ImageLoad", "Rootkits, BYOVD, unsigned/phantom DLLs (T1574)"],
        ["8 / 10", "CreateRemoteThread / ProcessAccess", "Injection; LSASS handle grants (T1055/T1003)"],
        ["9", "RawAccessRead", "Direct disk reads (MFT/SAM theft bypassing APIs)"],
        ["3 / 22", "NetworkConnect / DnsQuery", "Sockets→process bind; per-image C2 domains"],
        ["11 / 15 / 23–24", "FileCreate / StreamHash / Delete / Clipboard", "Drops, ADS births,wiper deletes, staged secrets"],
        ["12–14", "RegistryObject add/delete/value", "Persistence writes with before/after values"],
        ["17–18", "PipeEvent create/connect", "C2 IPC (Cobalt-Strike-class named pipes), lateral meld"],
        ["19–21 / 29", "WMI filter/consumer/binding / Summary", "Fileless persistence + execution via WMI"],
        ["4 / 16", "ServiceState / ConfigChange", "Sysmon's own health + config-hash drift (tamper alarm)"],
      ]}
    />
    <p>
      Adversaries now kill the watchers first. <b>BYOVD</b> (bring-your-own-vulnerable-driver) loads a legitimately
      signed but exploitable driver to terminate EDR/AV from kernel mode — the technique behind several
      ransomware-affiliate toolkits. Defense in depth: enable vendor <b>tamper protection</b> (uninstall/service-stop
      passwords), alert on <b>EID 6</b> for known-abused driver hashes, on <b>7045 + service-stop</b> pairs for
      security services, and on <b>EID 16</b> drift. The <b>EDR-first triage workflow</b> for any alert then runs:
      isolate host (retain power) → open the EDR process tree ±2 h → scope users/hosts touched → escalate to memory
      capture if fileless indicators appear (Ch. 7) → ticket with tree + hashes + scope. Sysmon fills whatever the
      EDR's retention or blind spots miss — the two are complements, never substitutes.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — EDR-tamper + BYOVD hunt (Sysmon + System)"
        code={`# Known-abused driver loads (maintain hash list from vendor advisories + LOTLDrivers)\nGet-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=6} -MaxEvents 500 |\n  Where-Object { $_.Message -match 'Signed.*false|gdbnt|mhyprot|procexp' }\n# Security-service stops and Sysmon config drift in the window\nGet-WinEvent -FilterHashtable @{LogName='System'; Id=7036,7040} |\n  Where-Object { $_.Message -match 'Sysmon|WinDefend|Sense|CrowdStrike|Carbon' }\nGet-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=16} -MaxEvents 5`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 6.1 · Process-tree hunt (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Import a Sysmon EID 1–3–11–13 dataset; rebuild the full tree by ProcessGuid for the incident host.</li>
      <li>Flag anomalous parent→child pairs, encoded command lines, and first-seen network destinations.</li>
      <li>Write the intrusion thread narrative: vector → execution → persistence → C2, one paragraph per hop.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 6.2 · Config tuning under budget (45 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Measure events/day per EID for a noisy config; identify the top-3 volume drivers.</li>
      <li>Write exclusions cutting volume ≥70% while preserving all five golden-query signals.</li>
      <li>Document each exclusion's residual risk + compensating control; peer-review for blind spots.</li>
    </ol>
  </>
);

export const ch06: Chapter = {
  id: "ch6",
  num: 6,
  title: "Advanced Endpoint Visibility with Microsoft Sysmon",
  subtitle: "Driver architecture · EID 1/3/6/7/8/10/11/13/22 · XML tuning · Noise control",
  badge: "Tier 2 · Endpoint telemetry",
  time: "9–11 h · ~38 pages equiv.",
  outcomes:
    "Deploy and version Sysmon configs; exploit EID 1 parent-child telemetry; bind sockets and DNS to processes; detect injection and LSASS access; tune filters without blinding.",
  body,
  labTitle: "Hands-on Lab 6.1 · Process-tree hunt + Lab 6.2 · Config tuning under budget",
  labsBody,
  workshop: {
    title: "Deploy Sysmon, detonate safely, and query the event chain",
    env: ["Windows lab VM (snapshot!)", "Sysmon + SwiftOnSecurity config", "PowerShell + Timeline Explorer"],
    tabs: [
      {
        id: "deploy",
        label: "Deploy + verify",
        steps: [
          {
            n: "1",
            title: "Install with a versioned config",
            desc: "Snapshot first; record the config hash so later drift is detectable.",
            code: [
              {
                title: "PowerShell (Admin) — install",
                text: `Checkpoint-VM -Name LAB-WIN11 -SnapshotName "pre-sysmon"\n.\\Sysmon64.exe -accepteula -i .\\sysmonconfig-v28.xml\nGet-FileHash .\\sysmonconfig-v28.xml -Algorithm SHA256\nGet-WinEvent -LogName Microsoft-Windows-Sysmon/Operational -MaxEvents 3 |
  Select-Object TimeCreated, Id`,
              },
            ],
            expected: "EID 4 (service state) + EID 16 (config hash) confirm the driver is live",
          },
          {
            n: "2",
            title: "Verify the event flow",
            desc: "EID 16 records the running config hash — mismatches mean tampering or drift.",
            code: [
              {
                title: "PowerShell — health check",
                text: `Get-Service Sysmon64 | Select-Object Status\nGet-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=16} -MaxEvents 1 |\n  Select-Object -ExpandProperty Message`,
              },
            ],
          },
        ],
      },
      {
        id: "detonate",
        label: "Safe detonation",
        steps: [
          {
            n: "3",
            title: "Generate benign-malicious signals",
            desc: "Atomic-style micro-tests: encoded PowerShell, WMI spawn, and a test C2 connection — all lab-contained.",
            code: [
              {
                title: "PowerShell — micro-tests (ISOLATED VM ONLY)",
                text: `# encoded execution (T1059.001 pattern, harmless payload)\npowershell -enc UwB0AGEAcgB0AC0AUwBsAGUAZQBwACAALQBzACAAMQAK\n# WMI-spawned process (T1047 pattern)\nwmic process call create "calc.exe"\n# test egress (documents EID 3 shape)\nTest-NetConnection -ComputerName 192.0.2.1 -Port 443 -WarningAction SilentlyContinue`,
              },
            ],
          },
          {
            n: "4",
            title: "Query the chain",
            desc: "Filter EID 1 by ParentImage + CommandLine; join EID 3 by ProcessGuid.",
            code: [
              {
                title: "PowerShell — hunt queries",
                text: `Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=1} -MaxEvents 200 |\n  Where-Object { $_.Message -match '-enc|wmic|calc' } |\n  Select-Object TimeCreated, @{n='Proc';e={($_.Message | Select-String 'Image: (.+)').Matches.Groups[1].Value}}`,
              },
            ],
            expected: "encoded powershell + wmic-spawned calc each appear with full parent chains",
          },
        ],
      },
      {
        id: "tune",
        label: "Tune + harden",
        steps: [
          {
            n: "5",
            title: "Measure and cut noise",
            desc: "Count events per ID over 1 hour; exclude only benign triples, never bare images.",
            code: [
              {
                title: "PowerShell — volume audit",
                text: `Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'} -MaxEvents 5000 |\n  Group-Object Id | Sort-Object Count -Descending | Format-Table Count, Name -AutoSize`,
              },
            ],
          },
          {
            n: "6",
            title: "Protect the config",
            desc: "Restrict config-file ACLs, alert on EID 16 changes and Sysmon service stops.",
            note: "Deliverable: installed Sysmon + config hash record + hunt-query outputs + volume audit + EID 16 monitoring note.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> EID 1 trees (§6.2) · EID 3/22 host-network bind (§6.3) · EID 8/10 injection (§6.4) → Zeek
        corroboration (Ch. 9) → Sigma rules (Ch. 12). Deliverable: a tuned, measured, monitored Sysmon deployment.
      </>
    ),
  },
  quiz: [
    { q: "Sysmon's kernel driver + user service split exists to:", o: ["Save disk space", "Collect at kernel callbacks, filter in user mode, log structured events", "Replace antivirus", "Encrypt logs"], a: 1, e: "Kernel sees broadly; the service applies config filters and writes .evtx." },
    { q: "Process trees must be joined on ProcessGuid rather than PID because:", o: ["GUIDs are shorter", "PIDs recycle; GUIDs are unique per boot+process", "PIDs are encrypted", "GUIDs include hashes"], a: 1, e: "PID reuse corrupts trees; GUIDs join reliably." },
    { q: "EID 3's unique value over firewall logs is:", o: ["Higher speed", "Binding each socket to its owning image, user, and GUID", "Blocking traffic", "Decrypting TLS"], a: 1, e: "Firewalls see flows; Sysmon sees which process owns them." },
    { q: "EID 10 handle grants against lsass.exe with 0x1010/0x1410 indicate:", o: ["Windows Update", "Likely LSASS credential dumping (T1003.001)", "Printer spooling", "DNS resolution"], a: 1, e: "VM-read rights on lsass are the dump signature." },
    { q: "The safe exclusion practice is to exclude:", o: ["Bare image names globally", "Image + parent + argument triples with documented residual risk", "All of EID 1", "Everything from Microsoft"], a: 1, e: "Triple-scoped exclusions preserve detection of abused binaries." },
    { q: "EID 16 in the Sysmon channel records:", o: ["DNS queries", "Service/config state changes including the config hash", "File creation", "Registry deletes"], a: 1, e: "EID 16 is the tamper/drift monitor for Sysmon itself." },
  ],
};
