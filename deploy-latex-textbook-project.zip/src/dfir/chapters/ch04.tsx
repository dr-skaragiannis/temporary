import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>4.1 NTFS internals: MFT, $LogFile, $UsnJrnl</h4>
    <p>
      Every file on NTFS is a record in the <b>Master File Table ($MFT)</b>: a 1024-byte entry of attributes —
      $STANDARD_INFORMATION (timestamps, flags), $FILE_NAME (name, parent MFR, timestamps), $DATA (resident content
      or run-list extents), plus security and index attributes (Fig. 7). Forensic gold hides in the details: files
      under ~700 bytes live <b>resident</b> inside the MFT itself (recoverable even when "deleted" until the record is
      reused), and <b>$FILE_NAME timestamps update only on rename/move</b>, so timestomping tools that rewrite
      $STANDARD_INFORMATION leave $FILE_NAME as a telltale. <b>$LogFile</b> journals metadata transactions for crash
      recovery (recent creates/deletes replayable), and <b>$UsnJrnl</b> logs per-file change reasons — the closest
      NTFS comes to a built-in file-activity feed.
    </p>
    <Figure
      id="fig-mft"
      label="Fig. 7 · MFT record anatomy (1024 bytes, vector)"
      caption={
        <>
          <b>Fig. 7.</b> A file is a bag of attributes, not a blob. Timestomp detection: compare $SI against $FN
          created times — divergence proves tampering. Deleted ≠ gone: unallocated MFT entries retain attributes
          until reallocated.
        </>
      }
    >
      <svg viewBox="0 0 720 220" className="w-full h-auto" role="img" aria-label="MFT record">
        <text x="10" y="20" fontSize="11" fontWeight="800" fill="#0f1c2e">MFT RECORD #48210 · 1024 bytes · IN-USE / DELETED flag @ offset 0x16</text>
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="110" height="90" rx="8" fill="#0f1c2e" />
          <text x="65" y="52" fill="#fbbf24">HEADER 42B</text>
          <text x="65" y="68" fill="#cbd5e1" fontWeight="400">LSN · seq · links</text>
          <text x="65" y="84" fill="#cbd5e1" fontWeight="400">flags: in-use?</text>
          <text x="65" y="100" fill="#fbbf24" fontSize="9">deleted ≠ wiped</text>
          <rect x="128" y="30" width="140" height="90" rx="8" fill="#0e7490" />
          <text x="198" y="52" fill="#fff">$STANDARD_INFO</text>
          <text x="198" y="68" fill="#e0f2fe" fontWeight="400">C · M · E · A times</text>
          <text x="198" y="84" fill="#e0f2fe" fontWeight="400">timestomp target</text>
          <text x="198" y="100" fill="#fef08a" fontSize="9">trust: LOW</text>
          <rect x="276" y="30" width="140" height="90" rx="8" fill="#166534" />
          <text x="346" y="52" fill="#fff">$FILE_NAME ×n</text>
          <text x="346" y="68" fill="#dcfce7" fontWeight="400">name + parent MFR</text>
          <text x="346" y="84" fill="#dcfce7" fontWeight="400">own C/M/E/A</text>
          <text x="346" y="100" fill="#bbf7d0" fontSize="9">trust: HIGH</text>
          <rect x="424" y="30" width="150" height="90" rx="8" fill="#b45309" />
          <text x="499" y="52" fill="#fff">$DATA</text>
          <text x="499" y="68" fill="#fef3c7" fontWeight="400">resident (&lt;~700B)</text>
          <text x="499" y="84" fill="#fef3c7" fontWeight="400">or run-list extents</text>
          <text x="499" y="100" fill="#fff" fontSize="9">+ ADS names here</text>
          <rect x="582" y="30" width="128" height="90" rx="8" fill="#7c3aed" />
          <text x="646" y="52" fill="#fff">OTHERS</text>
          <text x="646" y="68" fill="#ede9fe" fontWeight="400">$SECURITY</text>
          <text x="646" y="84" fill="#ede9fe" fontWeight="400">$OBJECT_ID</text>
          <text x="646" y="100" fill="#ede9fe" fontWeight="400">$REPARSE…</text>
        </g>
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="132" width="345" height="52" rx="8" fill="#f1f5f9" stroke="#0e7490" strokeWidth="1.5" />
          <text x="182" y="152" fill="#0e7490">$LogFile — metadata transaction journal</text>
          <text x="182" y="168" fill="#475569" fontWeight="400">replay recent create/delete/rename ops</text>
          <rect x="365" y="132" width="345" height="52" rx="8" fill="#f1f5f9" stroke="#166534" strokeWidth="1.5" />
          <text x="537" y="152" fill="#166534">$UsnJrnl — per-file change reasons</text>
          <text x="537" y="168" fill="#475569" fontWeight="400">DATA_EXTEND · RENAME · CLOSE …</text>
        </g>
        <text x="360" y="204" textAnchor="middle" fontSize="11" fill="#64748b">MFT + $LogFile + $UsnJrnl triangulate file activity even after deletion</text>
      </svg>
    </Figure>
    <h4>4.2 Alternate Data Streams (ADS)</h4>
    <p>
      NTFS files may carry multiple <b>$DATA attributes</b>: the default unnamed stream plus named{" "}
      <b>Alternate Data Streams</b> (<span className="mono text-sm">file.txt:hidden.exe</span>). ADS content is invisible
      to Explorer and to most directory listings, does not affect the reported file size, and survives copies within
      NTFS — a classic concealment primitive (T1564.004). Detection is straightforward once known:{" "}
      <span className="mono text-sm">dir /r</span>, PowerShell{" "}
      <span className="mono text-sm">Get-Item -Stream *</span>, or MFT parsers that enumerate all $DATA attributes.
      Note the legitimate uses (Zone.Identifier marking downloads) so triage distinguishes <i>presence</i> of ADS from{" "}
      <i>malicious</i> ADS: executables hidden in streams of documents are the finding.
    </p>
    <h4>4.3 Registry architecture: hives that matter</h4>
    <p>
      The Registry is a set of hive files, each with a forensic personality. <b>SYSTEM</b> holds services, USB device
      history (USBSTOR), and shutdown state (ShutdownTime). <b>SOFTWARE</b> holds installed programs, network
      profiles, and auto-start extensibility points. <b>SAM</b> holds local account hashes (inviting credential
      theft — protect accordingly). <b>NTUSER.DAT</b> (per user) records that user's activity: Run keys, RecentDocs,
      typed paths, and ComDlg history. <b>Amcache/Shimcache-adjacent hives</b> (SYSTEM) record execution (Ch. 5).
      Hives are transactional (LOG1/LOG2 must accompany the hive for dirty-state parsing), and deleted keys linger in
      unallocated hive cells until overwritten.
    </p>
    <DataTable
      head={["Hive (file)", "Location", "Highest-value keys"]}
      rows={[
        ["SYSTEM", "Windows\\System32\\config\\SYSTEM", "Services, USBSTOR, ControlSet\\ShutdownTime, AppCompatCache"],
        ["SOFTWARE", "Windows\\System32\\config\\SOFTWARE", "Run/RunOnce, Uninstall, NetworkList profiles"],
        ["SAM", "Windows\\System32\\config\\SAM", "Local users, groups, cached hashes (V)"],
        ["NTUSER.DAT", "Users\\<u>\\NTUSER.DAT", "Run, RecentDocs, TypedPaths, UserAssist (ROT13)"],
        ["UsrClass.dat", "Users\\<u>\\AppData\\Local\\Microsoft\\Windows", "Shellbags, Jump List AppIDs, file associations"],
      ]}
    />
    <h4>4.4 Persistence inspection: Run keys, tasks, services</h4>
    <p>
      Adversaries persist where Windows auto-starts (T1547/T1053/T1543). Audit in priority order: <b>Run/RunOnce</b>{" "}
      (HKLM + HKCU Software\\Microsoft\\Windows\\CurrentVersion\\Run), <b>scheduled tasks</b> (Task Scheduler XML +
      registry), <b>services</b> (SYSTEM\\Services with ImagePath anomalies), <b>WMI subscriptions, Winlogon helpers,
      Office add-ins, and LSA providers</b> for depth. Autoruns Daniele-style enumeration (Sysinternals Autoruns with
      VirusTotal + file-hash comparison against baselines) remains the fastest enterprise screen; every unsigned or
      rare-path entry becomes a lead. Fig. 8 maps the top persistence points to their hive homes.
    </p>
    <Figure
      id="fig-persist"
      label="Fig. 8 · Windows persistence map (vector)"
      caption={
        <>
          <b>Fig. 8.</b> Audit top-down by prevalence: Run keys and tasks catch ~80% of commodity persistence; the
          lower tier catches APT-grade mechanisms. Each entry names its hive so dead-box examiners know which file to
          parse.
        </>
      }
    >
      <svg viewBox="0 0 720 240" className="w-full h-auto" role="img" aria-label="Persistence map">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="10" width="225" height="96" rx="8" fill="#be123c" />
          <text x="122" y="30" fill="#fff">RUN / RUNONCE KEYS</text>
          <text x="122" y="47" fill="#ffe4e6" fontWeight="400">HKLM + HKCU …\Run</text>
          <text x="122" y="63" fill="#ffe4e6" fontWeight="400">SOFTWARE + NTUSER.DAT</text>
          <text x="122" y="82" fill="#fff" fontSize="9">T1547.001 · check FIRST</text>
          <rect x="247" y="10" width="226" height="96" rx="8" fill="#b45309" />
          <text x="360" y="30" fill="#fff">SCHEDULED TASKS</text>
          <text x="360" y="47" fill="#fef3c7" fontWeight="400">Tasks XML + registry</text>
          <text x="360" y="63" fill="#fef3c7" fontWeight="400">SOFTWARE\Microsoft\…\TaskCache</text>
          <text x="360" y="82" fill="#fff" fontSize="9">T1053 · hidden + COM hijack</text>
          <rect x="485" y="10" width="225" height="96" rx="8" fill="#0e7490" />
          <text x="597" y="30" fill="#fff">SERVICES + DRIVERS</text>
          <text x="597" y="47" fill="#e0f2fe" fontWeight="400">SYSTEM\CurrentControlSet\Services</text>
          <text x="597" y="63" fill="#e0f2fe" fontWeight="400">ImagePath + Start type</text>
          <text x="597" y="82" fill="#fff" fontSize="9">T1543 · Type=kernel?</text>
          <rect x="10" y="114" width="225" height="88" rx="8" fill="#7c3aed" />
          <text x="122" y="134" fill="#fff">WMI + WINLOGON</text>
          <text x="122" y="151" fill="#ede9fe" fontWeight="400">Event subscriptions</text>
          <text x="122" y="167" fill="#ede9fe" fontWeight="400">Userinit / Shell / Notify</text>
          <text x="122" y="186" fill="#fff" fontSize="9">T1546 · fileless-friendly</text>
          <rect x="247" y="114" width="226" height="88" rx="8" fill="#166534" />
          <text x="360" y="134" fill="#fff">OFFICE / BROWSER</text>
          <text x="360" y="151" fill="#dcfce7" fontWeight="400">Add-ins · extensions</text>
          <text x="360" y="167" fill="#dcfce7" fontWeight="400">NTUSER + UsrClass</text>
          <text x="360" y="186" fill="#fff" fontSize="9">T1137 · T1176</text>
          <rect x="485" y="114" width="225" height="88" rx="8" fill="#0f1c2e" />
          <text x="597" y="134" fill="#fbbf24">LSA / SSP / NETSH</text>
          <text x="597" y="151" fill="#cbd5e1" fontWeight="400">Security Packages</text>
          <text x="597" y="167" fill="#cbd5e1" fontWeight="400">SYSTEM · admin-only</text>
          <text x="597" y="186" fill="#fbbf24" fontSize="9">T1547.005 · credential theft</text>
        </g>
        <text x="360" y="224" textAnchor="middle" fontSize="11" fill="#64748b">Baseline-known-good entries first; investigate unsigned, rare-path, and recently-added entries</text>
      </svg>
    </Figure>
    <h4>4.5 User activity reconstruction: Shellbags, Jump Lists, RecentDocs</h4>
    <p>
      Even without file content, Windows narrates user behavior. <b>Shellbags</b> (UsrClass.dat) record every folder
      ever browsed in Explorer — including folders on since-removed USB drives and deleted paths. <b>Jump Lists</b>{" "}
      (AutomaticDestinations) record per-application recent files with open counts and timestamps.{" "}
      <b>RecentDocs</b> (NTUSER.DAT) records the last-opened documents by extension. Together they answer "did the
      user open the payload, and what did they browse afterward?" — the human timeline that corroborates or refutes
      execution artifacts (Ch. 5).
    </p>
    <h4>4.6 Volume Shadow Copies: time travel for examiners</h4>
    <p>
      <b>Volume Shadow Copy Service (VSS)</b> snapshots capture block-level volume states — prior registry hives,
      pre-deletion files, pre-encryption originals. Mount shadows read-only (
      <span className="mono text-sm">vssadmin list shadows</span>,{" "}
      <span className="mono text-sm">mklink /d</span> to the shadow device path, or forensic suites) and diff against
      the live volume: ransomware cases frequently yield recoverable originals, and "cleaned" Run keys reappear in
      older hives. Adversaries know this — <span className="mono text-sm">vssadmin delete shadows</span> is itself a
      high-fidelity malicious indicator (T1490) and often the first destructive act to hunt.
    </p>
    <Callout color="emerald">
      <b>Dead-box workflow (memorize).</b> Image → verify hashes → working copy → MFT timeline → persistence audit →
      user-activity corroboration → VSC diff → execution artifacts (Ch. 5). Never skip straight to "suspicious files"
      — timelines first, conclusions last.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — rapid persistence + ADS screen (live triage or mounted image)"
        code={`# ADS sweep (T1564.004): any executable stream on a document is a finding
Get-ChildItem C:\\Users -Recurse -File -ErrorAction SilentlyContinue |
  ForEach-Object { Get-Item $_.FullName -Stream * -ErrorAction SilentlyContinue |
    Where-Object { $_.Stream -ne ':$DATA' -and $_.Stream -ne 'Zone.Identifier' } |
    Select-Object @{n='File';e={$_.PSParentPath}}, Stream, Length }

# Run-key audit (HKLM + all loaded HKCU)
'Registry::HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run',
'Registry::HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run' |
  ForEach-Object { Get-ItemProperty $_ -ErrorAction SilentlyContinue }

# Shadow copies present? (absence after incident = T1490 hunt)
vssadmin list shadows`}
      />
    </div>
    <h4>4.7 ★ NEW · Shell links, bins, caches, and timelines: proving file-knowledge</h4>
    <p>
      Four artifacts prove a user <i>knew</i> a file — which is what leak and insider cases turn on. <b>Shell link
      (.lnk)</b> files record their target's full path, volume serial, MAC timestamps, and machine ID — proving a file
      was opened even from USB or network shares long since disconnected. The <b>Recycle Bin</b> pairs{" "}
      <b>$I</b> metadata (original path + deletion time) with <b>$R</b> content, narrating exactly what was deleted,
      when, and from where. The <b>thumbnail cache</b> (thumbcache_*.db) retains image thumbnails after the originals
      are wiped — viewing is proven even when possession is denied. <b>Windows Timeline</b> (ActivitiesCache.db) adds
      cross-device activity records with app, file, and duration. A related credential note: browser-saved passwords
      and Credential Manager vaults live under <b>DPAPI</b> — recoverable only with the user's master key (i.e., their
      password or a live/logged-on capture), which itself proves credential presence on the box.
    </p>
    <DataTable
      head={["Artifact", "Proves", "Location"]}
      rows={[
        [".lnk shortcuts", "File opened; target path + volume + machine", "Recent, Start Menu, per-user link dirs"],
        ["$I / $R pairs", "What was deleted, from where, when", "$Recycle.Bin\\<SID> per volume"],
        ["Thumbcache", "Images viewed (post-deletion)", "Explorer\\ThumbCacheToDelete / thumbcache_*.db"],
        ["ActivitiesCache.db", "App/file engagement across devices", "ConnectedDevicesPlatform\\ActivitiesCache.db"],
        ["DPAPI blobs + Vault", "Stored secrets existed (needs masterkey)", "Protect\\<SID>, AppData\\Local\\Microsoft\\Vault"],
      ]}
    />
    <h4>4.8 ★ NEW · Journal destruction and cleaner tools: when timelines fight back</h4>
    <p>
      Adversaries attack the timeline itself. <span className="mono text-sm">fsutil usn deletejournal</span> wipes
      $UsnJrnl — and Windows <i>creates a fresh journal with a new ID and creation time</i>, which is the tell: compare
      the live journal ID against VSC-hosted copies, and treat any journal younger than the OS install as
      destruction-until-proven-otherwise (there is no Event ID for this; ID discontinuity <i>is</i> the signal).
      $LogFile resets, Prefetch wipes, and "cleaner" tools (CCleaner, BleachBit) leave their own footprints — tool
      execution artifacts plus unnaturally uniform timestamp gaps. Workflow: query the journal first, snapshot its ID,
      and diff across shadows before trusting any file timeline.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — USN journal integrity check (live or mounted image)"
        code={`fsutil usn queryjournal C:   # record UsnJournalID + lowest/highest USN\n# Compare UsnJournalID across shadow copies: differing IDs = journal was deleted & recreated\n# Rule: journal creation newer than OS install date + incident window = T1070 tamper lead`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 4.1 · MFT timeline + timestomp hunt (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Parse a provided MFT to CSV; build a timeline filtered to the incident window (±2 h).</li>
      <li>Flag $SI/$FN timestamp divergence &gt; 1 s; document each hit as timestomp-suspect with MFR numbers.</li>
      <li>Correlate top hits with $UsnJrnl reasons; write the file-activity paragraph of the case report.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 4.2 · Persistence + VSC audit (60 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Enumerate all Fig. 8 locations on a lab image; classify each entry known-good / unknown / malicious.</li>
      <li>List shadow copies; mount the oldest and diff Run keys + one payload path against live.</li>
      <li>Produce the persistence findings table: location, value, first-seen, verdict, evidence.</li>
    </ol>
  </>
);

export const ch04: Chapter = {
  id: "ch4",
  num: 4,
  title: "Windows Dead-Box Forensics — File Systems and Registry Analysis",
  subtitle: "NTFS/MFT · ADS · Registry hives · Persistence · Shellbags · Shadow copies",
  badge: "Tier 2 · Host forensics",
  time: "9–11 h · ~40 pages equiv.",
  outcomes:
    "Decode MFT attributes and journals; detect ADS concealment and timestomping; parse all five hives; audit persistence systematically; reconstruct user activity; exploit shadow copies.",
  body,
  labTitle: "Hands-on Lab 4.1 · MFT timeline + timestomp hunt + Lab 4.2 · Persistence + VSC audit",
  labsBody,
  workshop: {
    title: "Dead-box pipeline: MFT timeline, ADS sweep, and hive triage",
    env: ["Windows examiner VM", "MFTECmd + Registry Explorer", "Lab image (mounted read-only)"],
    tabs: [
      {
        id: "mft",
        label: "MFT timeline",
        steps: [
          {
            n: "1",
            title: "Parse $MFT to CSV",
            desc: "MFTECmd extracts every attribute including $FN timestamps and ADS names.",
            code: [
              {
                title: "PowerShell — MFTECmd",
                text: `E:\\Tools\\MFTECmd.exe -f "F:\\$MFT" --csv E:\\cases\\041 --csvf mft.csv\nImport-Csv E:\\cases\\041\\mft.csv | Measure-Object | Select-Object Count`,
              },
            ],
          },
          {
            n: "2",
            title: "Window the incident and hunt timestomps",
            desc: "$SI Created vs $FN Created divergence is machine-checkable — eyeballing is malpractice.",
            code: [
              {
                title: "PowerShell — timestomp screen",
                text: `$m = Import-Csv E:\\cases\\041\\mft.csv\n# incident window filter (adjust to case)\n$m | Where-Object { $_.Created0 -ge '2026-09-20' -and $_.Created0 -le '2026-09-22' } |\n  Export-Csv E:\\cases\\041\\mft-window.csv -NoTypeInformation\n# $SI/$FN divergence\n$m | Where-Object { $_.Created0 -ne $_.FNCreated0 } |\n  Select-Object EntryNumber, FileName, Created0, FNCreated0 | Format-Table -AutoSize`,
              },
            ],
            expected: "short list of divergent MFRs — each becomes a timeline lead, not yet a conclusion",
          },
        ],
      },
      {
        id: "ads",
        label: "ADS sweep",
        steps: [
          {
            n: "3",
            title: "Enumerate all named streams",
            desc: "Filter Zone.Identifier noise; executables in streams are the signal.",
            code: [
              {
                title: "PowerShell — stream inventory",
                text: `$m | Where-Object { $_.ADS -eq 'True' } | Select-Object EntryNumber, FileName | Format-Table -AutoSize\n# targeted confirmation on disk (mounted image F:)\nGet-Item 'F:\\Users\\*' -Stream * -ErrorAction SilentlyContinue | Where-Object { $_.Stream -notmatch 'DATA|Zone' }`,
              },
            ],
          },
        ],
      },
      {
        id: "reg",
        label: "Hive triage",
        steps: [
          {
            n: "4",
            title: "Export hives + transaction logs",
            desc: "Dirty hives without LOG1/LOG2 parse incompletely — always copy the trio.",
            code: [
              {
                title: "PowerShell — hive harvest",
                text: `mkdir E:\\cases\\041\\hives\nCopy-Item 'F:\\Windows\\System32\\config\\SYSTEM*' E:\\cases\\041\\hives\\\nCopy-Item 'F:\\Windows\\System32\\config\\SOFTWARE*' E:\\cases\\041\\hives\\\nCopy-Item 'F:\\Users\\*\\NTUSER.DAT*' E:\\cases\\041\\hives\\ -Force\nGet-FileHash E:\\cases\\041\\hives\\* -Algorithm SHA256 | Export-Csv E:\\cases\\041\\hives\\hashes.csv`,
              },
            ],
          },
          {
            n: "5",
            title: "Triage Run keys, USBSTOR, ShutdownTime",
            desc: "Three questions: what persists, what USB touched this box, when did it last shut down cleanly.",
            note: "Deliverable: mft-window.csv + timestomp hits + ADS inventory + hive hashes + triage notes. Open Registry Explorer on the exported hives for Lab 4.2 depth.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> MFT attributes (§4.1) · ADS (§4.2) · hives (§4.3) → persistence map (§4.4) → execution proof
        (Ch. 5). Deliverable: a windowed timeline plus a hashed hive set ready for deep parsing.
      </>
    ),
  },
  quiz: [
    { q: "Resident $DATA means the file content:", o: ["Is encrypted", "Lives inside the 1024-byte MFT record itself", "Is stored in the cloud", "Cannot be recovered"], a: 1, e: "Small files (<~700B) fit entirely within their MFT record." },
    { q: "$FILE_NAME timestamps are more trustworthy than $STANDARD_INFORMATION because:", o: ["They are encrypted", "They update only on rename/move, which most timestomp tools miss", "They are stored off-disk", "They cannot be read"], a: 1, e: "$SI/$FN divergence is the canonical timestomp tell." },
    { q: "An executable ADS attached to a Word document most likely indicates:", o: ["Normal Office behavior", "Concealment (T1564.004) requiring investigation", "Disk corruption", "A Windows update"], a: 1, e: "Zone.Identifier is the benign ADS; executables in streams are not." },
    { q: "USB device history on Windows is found in:", o: ["NTUSER.DAT RecentDocs", "SYSTEM hive USBSTOR", "The MFT bitmap", "Pagefile"], a: 1, e: "SYSTEM\\ControlSet\\Enum\\USBSTOR records attached storage devices." },
    { q: "vssadmin delete shadows during an incident window indicates:", o: ["Routine maintenance", "T1490 shadow-copy destruction — hunt immediately", "Successful backup", "Disk defragmentation"], a: 1, e: "Attackers delete shadows to block recovery; defenders almost never do." },
    { q: "Shellbags primarily answer:", o: ["Which folders were browsed, including deleted/removed paths", "The BitLocker PIN", "Wi-Fi passwords", "CPU temperature"], a: 0, e: "Shellbags persist Explorer navigation history in UsrClass.dat." },
  ],
};
