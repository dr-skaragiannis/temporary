import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>5.1 Execution artifacts: Prefetch, Shimcache, Amcache</h4>
    <p>
      Proving <i>execution</i> — not mere presence — is the dead-box crux. Three artifacts triangulate it (Fig. 9).{" "}
      <b>Prefetch</b> (<span className="mono text-sm">C:\Windows\Prefetch\*.pf</span>) records the last 8 runs of each
      executable: run count, last-run timestamps, and files/devices touched during the first 10 seconds — enough to
      show <i>mimikatz.exe ran 3 times and touched \\DC01\share</i>. <b>Shimcache/AppCompatCache</b> (SYSTEM hive)
      records executables evaluated for compatibility — <i>presence on an execution path</i>, weaker than proof of run
      but surviving file deletion. <b>Amcache</b> (<span className="mono text-sm">Amcache.hve</span>) records first-run
      timestamps, SHA-1, and full paths including removable volumes. Rule: Prefetch + Amcache + a process-creation log
      is proof; Shimcache alone is a lead.
    </p>
    <Figure
      id="fig-exec-proof"
      label="Fig. 9 · Execution-proof strength ladder (vector)"
      caption={
        <>
          <b>Fig. 9.</b> Strength of execution evidence, weakest at bottom. Climb by corroboration: Shimcache
          (evaluated) + Amcache (first run) + Prefetch (run count/times) + EID 4688/Sysmon EID 1 (process creation) =
          proof beyond reasonable doubt.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="Execution proof ladder">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="150" y="10" width="420" height="44" rx="8" fill="#166534" />
          <text x="360" y="28" fill="#fff">PROOF · EID 4688 / SYSMON EID 1</text>
          <text x="360" y="44" fill="#dcfce7" fontWeight="400" fontSize="10">process created: image + PID + parent + cmdline + hash</text>
          <rect x="150" y="62" width="420" height="44" rx="8" fill="#0e7490" />
          <text x="360" y="80" fill="#fff">STRONG · PREFETCH (.pf)</text>
          <text x="360" y="96" fill="#e0f2fe" fontWeight="400" fontSize="10">run count + last 8 runs + files touched in first 10 s</text>
          <rect x="150" y="114" width="420" height="44" rx="8" fill="#b45309" />
          <text x="360" y="132" fill="#fff">GOOD · AMCACHE.HVE</text>
          <text x="360" y="148" fill="#fef3c7" fontWeight="400" fontSize="10">first-run time + SHA-1 + full path incl. USB volume</text>
          <rect x="150" y="166" width="420" height="40" rx="8" fill="#7c3aed" />
          <text x="360" y="184" fill="#fff">LEAD · SHIMCACHE (AppCompatCache)</text>
          <text x="360" y="199" fill="#ede9fe" fontWeight="400" fontSize="10">evaluated for compat — execution path, not proof of run</text>
        </g>
        <g fontSize="10" fontWeight="700" fill="#64748b" textAnchor="start">
          <text x="582" y="37">needs logging ON</text>
          <text x="582" y="89">needs prefetch kept</text>
          <text x="582" y="141">needs hive</text>
          <text x="582" y="192">survives deletion</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="120" y1="200" x2="120" y2="40" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="100" y="125" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e" className="fig-halo" transform="rotate(-90 100 125)">EVIDENTIARY STRENGTH ↑</text>
        <text x="360" y="228" textAnchor="middle" fontSize="11" fill="#64748b">Always corroborate upward: a lead plus a strong artifact beats either alone</text>
      </svg>
    </Figure>
    <h4>5.2 Program trace artifacts: UserAssist and BAM/DAM</h4>
    <p>
      <b>UserAssist</b> (NTUSER.DAT, ROT13-encoded) counts GUI program launches per user with last-run times and focus
      durations — ideal for "did the user double-click the payload?" <b>BAM/DAM</b> (Background Activity Moderator,
      SYSTEM hive) records last-execution timestamps for binaries including background processes, with fewer gaps than
      UserAssist on modern builds. Both are user-attributed: they bind execution to a <i>profile</i>, which Prefetch
      cannot. Decode ROT13 mechanically (Registry Explorer does it inline) and treat run-count deltas across VSS
      snapshots as execution timelines.
    </p>
    <h4>5.3 Windows Event Log architecture</h4>
    <p>
      Windows logs to binary <b>.evtx</b> channels under{" "}
      <span className="mono text-sm">C:\Windows\System32\winevt\Logs</span>. The forensic core is three channels:{" "}
      <b>Security</b> (authentication, privilege use, object access — requires audit-policy enablement),{" "}
      <b>System</b> (services, drivers, shutdowns), and <b>Application</b> (program crashes, MSI installs). Extended
      coverage lives in <b>Sysmon/Operational</b> (Ch. 6), <b>PowerShell/Operational</b> (ScriptBlock logging, EID
      4104), <b>TaskScheduler/Operational</b>, and <b>TerminalServices</b> (RDP). Size and retention are policy:
      default 20 MB Security logs on busy DCs rotate in hours — verify retention <i>before</i> scoping conclusions,
      and forward to SIEM (Ch. 10–11) so rotation never equals loss.
    </p>
    <DataTable
      head={["Channel (.evtx)", "Key Event IDs", "Answers"]}
      rows={[
        ["Security", "4624/4625 logon, 4672 special logon, 4688 process, 4720 account created, 1102 cleared", "Who authenticated, what ran, what changed"],
        ["System", "7045 service installed, 7036 state, 6005/6006 start/stop, 1/12 time change", "Persistence installs, reboots, clock tampering"],
        ["Sysmon/Operational", "EID 1/3/7/8/10/11/13/22", "Full process/network/registry narrative (Ch. 6)"],
        ["PowerShell/Operational", "4103/4104 module + scriptblock", "Deobfuscated script content incl. encoded payloads"],
        ["TerminalServices-*/RDP", "21/22/23/24/25 session lifecycle", "RDP lateral movement corroboration"],
        ["TaskScheduler/Operational", "106/140/141 task registered/updated", "T1053 persistence with author + payload path"],
      ]}
    />
    <h4>5.4 Authentication auditing: 4624/4625 and logon types</h4>
    <p>
      Every logon attempt writes <b>4624</b> (success) or <b>4625</b> (failure) with a <b>Logon Type</b> that reveals{" "}
      <i>how</i> access occurred — the single most misread field in Windows forensics. Type 3 (network) dominates
      lateral movement; Type 10 (RDP) marks interactive remote sessions; Type 4/5 (batch/service) flag scheduled
      abuse; Type 9 (RunAs) and cached Type 11/13 expose credential-reuse patterns. Correlate triples of{" "}
      <i>account + source IP/workstation + logon type</i>: a service account logging on interactively (Type 2/10), or
      any account appearing from two geographies within minutes, is the finding — not the raw 4624 count.
    </p>
    <DataTable
      head={["Logon Type", "Meaning", "Forensic reading"]}
      rows={[
        ["2 Interactive", "Local console logon", "Physical or VM-console access; rare for service accounts"],
        ["3 Network", "SMB/remote resource access", "Lateral-movement workhorse; pair with source IP"],
        ["4 Batch / 5 Service", "Scheduled task / service start", "Check parent task; attackers schedule as SYSTEM"],
        ["7 Unlock / 8 NetworkCleartext", "Workstation unlock / basic-auth network", "8 in cleartext = legacy app or downgrade attack"],
        ["9 RunAs / 10 RemoteInteractive", "Alternate creds / RDP", "10 + odd hour + new source = RDP intrusion pattern"],
        ["11 Cached / 12/13 Cached variants", "Offline cached-credential logon", "Stolen laptop scenario; compare against DC logs"],
      ]}
    />
    <h4>5.5 Privilege escalation traces: 4672, 4720, group changes</h4>
    <p>
      <b>4672</b> (special privileges assigned at logon) fires whenever an administrator-equivalent session starts —
      baseline its normal volume, then hunt the anomalies (new accounts, odd hosts, service accounts suddenly
      privileged). Account lifecycle events <b>4720</b> (created), <b>4728/4732/4756</b> (added to group), and{" "}
      <b>4738</b> (changed) narrate backdoor-account creation; pair them with the <i>caller</i> fields to identify the
      creating process. Privilege-<i>use</i> events (4673/4674, SeDebugPrivilege, SeBackupPrivilege) require sensitive-
      privilege auditing enabled — verify the audit policy first, or absence of evidence will masquerade as evidence
      of absence.
    </p>
    <h4>5.6 Log anti-forensics identification</h4>
    <p>
      Adversaries clear, shrink, or stop logging to blind defenders. <b>1102</b> (audit log cleared) is the canonical
      smoking gun — but sophisticated actors instead <b>stop the EventLog service</b> (System 7036/7040),{" "}
      <b>suspend Sysmon</b>, <b>reduce channel sizes</b> to force rotation, or <b>selectively delete with tools</b>{" "}
      that repair checksums. Hunt the meta-signals: gaps in record numbers, uptime/log-coverage mismatches, Sysmon
      config-change EID 16, and service-install EID 7045 for "cleaner" tools. Mitigation is architectural: real-time
      forwarding (WEF/Syslog, Ch. 10) means cleared local logs survive centrally — cleared-locally-but-present-in-SIEM
      is itself proof of tampering.
    </p>
    <Callout color="rose">
      <b>Absence-of-evidence rule.</b> Before concluding "no logon occurred" or "no process ran," verify: (1) the
      channel existed and was enabled, (2) retention covers the window, (3) no 1102/gap/service-stop precedes the
      gap. Unverified absence is not a finding — it is an unknown.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — logon-timeline triage (Security.evtx on a mounted image or live host)"
        code={`# RDP + network logons in the incident window, grouped by account/source/type
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624,4625; StartTime='2026-09-20'} |
  Select-Object TimeCreated,
    @{n='Acct';e={$_.Properties[5].Value}}, @{n='SrcIP';e={$_.Properties[18].Value}},
    @{n='Type';e={$_.Properties[8].Value}}, @{n='ID';e={$_.Id}} |
  Sort-Object TimeCreated | Format-Table -AutoSize

# Anti-forensics screen: clears, service stops, Sysmon changes
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=1102} -ErrorAction SilentlyContinue
Get-WinEvent -FilterHashtable @{LogName='System'; Id=7045,7036} |
  Where-Object { $_.Message -match 'EventLog|Sysmon|WinDefend' }`}
      />
    </div>
    <h4>5.7 ★ NEW · Security-product and usage telemetry: Defender, ASR, WDAC, SRUM, BITS</h4>
    <p>
      Native security controls are forensic sensors, not just blockers. <b>Defender AV operational logs</b>{" "}
      (1006/1008 detections, 1015 blocks, 1116 malware-state, 5001/5007 protection-state) give the malware timeline —
      including <i>tamper</i> transitions when protection is disabled. <b>Attack Surface Reduction (ASR) rules</b>{" "}
      fire block/audit events per rule ID: Office spawning processes, credential-guard bypass attempts, LSASS access
      blocks — each a behavior-level detection even when the payload is unknown. <b>WDAC/AppLocker</b> 8003/8004
      (blocked scripts/binaries) are allowlist-tripwires with near-zero false positives. <b>SRUM</b>{" "}
      (SRUDB.dat, SYSTEM hive) records per-application network bytes hourly — the exfil quantification source ("which
      process moved 4 GB at 2 a.m.?"). The <b>RDP bitmap cache</b> stores screen tiles of remote sessions,
      occasionally reconstructing attacker GUI activity outright. And <b>BITS</b> (Background Intelligent Transfer)
      jobs — listable via <span className="mono text-sm">bitsadmin /list /allusers</span> — are abused as a
      living-off-the-land downloader and persistence primitive (T1197).
    </p>
    <DataTable
      head={["Source", "Key IDs / store", "Signature use"]}
      rows={[
        ["Defender AV/Operational", "1006/1008/1015/1116, 5001/5007", "Malware timeline + protection-tamper proof"],
        ["ASR rules", "Per-rule block/audit events", "Behavior blocked even for unknown payloads"],
        ["WDAC / AppLocker", "8003/8004 (+ MSI/script channels)", "Allowlist trips — investigate every one"],
        ["SRUM (SRUDB.dat)", "Hourly per-app bytes + network", "Exfil attribution + volume for impact statements"],
        ["RDP bitmap cache", "Cache000*.bin tiles", "Attacker screen reconstruction (opportunistic)"],
        ["BITS jobs DB", "bitsadmin /list /allusers", "Covert download + persistence jobs"],
      ]}
    />
    <h4>5.8 ★ NEW · Lateral-movement signatures: PsExec, WMI, WinRM, RDP constellations</h4>
    <p>
      Lateral movement never emits a single event — it emits <b>constellations</b> across channels, and recognizing the
      shapes is what separates analysts from alert-readers. <b>PsExec-style (T1021 + T1543)</b>: 4624 Type 3 from the
      source → 7045 service install (PSEXESVC or random name) → 4688 child process on target → 7036/7040 service stop
      and cleanup. <b>WMI (T1047)</b>: DCOM 4624 → WMI-Activity Operational 5857/5858/5860/5861 (consumer binding) →
      wmiprvse.exe spawning the payload (4688). <b>WinRM/PSRemoting (T1021.006)</b>: Operational 91 (authentication) +
      168 (session created) + 4624, with ScriptBlock 4104 on the target narrating the remote script. <b>RDP
      (T1021.001)</b>: 4624 Type 10 + TerminalServices 21/22/23/24/25 session lifecycle + bitmap-cache writes. Hunt
      rule: query the <i>constellation</i> (all four PsExec events within minutes), never one star — single events
      have benign twins, constellations rarely do.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — PsExec constellation hunt (Security + System, incident window)"
        code={`# All four stars within the window on the TARGET host = lateral movement, not coincidence\nGet-WinEvent -FilterHashtable @{LogName='Security'; Id=4624; StartTime='2026-09-20'} |\n  Where-Object { $_.Properties[8].Value -eq 3 }          # network logon from source\nGet-WinEvent -FilterHashtable @{LogName='System'; Id=7045} | Where-Object { $_.Message -match 'PSEXESVC|remotsvc' }\nGet-WinEvent -FilterHashtable @{LogName='Security'; Id=4688} | Where-Object { $_.Message -match 'PSEXESVC' }\nGet-WinEvent -FilterHashtable @{LogName='System'; Id=7036} | Where-Object { $_.Message -match 'PSEXESVC.*stopped' }`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 5.1 · Execution-proof package (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>For three suspect binaries, collect Prefetch, Amcache, Shimcache, UserAssist, and BAM entries.</li>
      <li>Grade each binary on the Fig. 9 ladder; write the one-paragraph proof (or the honest gap).</li>
      <li>Corroborate the strongest case with EID 4688/Sysmon EID 1 and ScriptBlock logs if present.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 5.2 · Logon forensics + anti-forensics hunt (60 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Build the account × source × logon-type matrix for the incident window; flag anomalies with rationale.</li>
      <li>Screen for 1102, EventLog/Sysmon service manipulation, and record-number gaps.</li>
      <li>Deliver the authentication findings: timeline, anomalous sessions, and tamper verdict.</li>
    </ol>
  </>
);

export const ch05: Chapter = {
  id: "ch5",
  num: 5,
  title: "Windows Execution Artifacts and Event Log Analysis",
  subtitle: "Prefetch · Shimcache · Amcache · UserAssist/BAM · .evtx · 4624/4625 · 4672 · Anti-forensics",
  badge: "Tier 2 · Host forensics",
  time: "9–11 h · ~40 pages equiv.",
  outcomes:
    "Prove execution with artifact ladders; attribute runs to users; navigate .evtx channels; read logon types fluently; trace privilege escalation; detect log tampering and gaps.",
  body,
  labTitle: "Hands-on Lab 5.1 · Execution-proof package + Lab 5.2 · Logon forensics + anti-forensics hunt",
  labsBody,
  workshop: {
    title: "Execution + logon pipeline: PECmd, EvtxECmd, and timeline fusion",
    env: ["Windows examiner VM", "PECmd + EvtxECmd + Timeline Explorer", "Lab image + exported .evtx"],
    tabs: [
      {
        id: "prefetch",
        label: "Prefetch + Amcache",
        steps: [
          {
            n: "1",
            title: "Parse Prefetch directory",
            desc: "PECmd decodes run counts, last-run times, and referenced files per executable.",
            code: [
              {
                title: "PowerShell — PECmd",
                text: `E:\\Tools\\PECmd.exe -d "F:\\Windows\\Prefetch" --csv E:\\cases\\041 --csvf prefetch.csv\nImport-Csv E:\\cases\\041\\prefetch.csv |\n  Where-Object { $_.ExecutableName -match 'powershell|mimikatz|rundll32|mshta|wmic' } |\n  Select-Object ExecutableName, RunCount, LastRun | Format-Table -AutoSize`,
              },
            ],
          },
          {
            n: "2",
            title: "Parse Amcache for first-run + SHA-1",
            desc: "Amcache binds first execution to a hash and full path — the identity anchor.",
            code: [
              {
                title: "PowerShell — AmcacheParser",
                text: `E:\\Tools\\AmcacheParser.exe -f "F:\\Windows\\AppCompat\\Programs\\Amcache.hve" --csv E:\\cases\\041\nImport-Csv E:\\cases\\041\\Amcache*.csv | Where-Object { $_.SHA1 -ne '' } |\n  Select-Object -First 5 Name, SHA1, FirstRun`,
              },
            ],
            expected: "suspect binary appears with matching SHA-1 across Amcache and Prefetch rows",
          },
        ],
      },
      {
        id: "evtx",
        label: "Security.evtx",
        steps: [
          {
            n: "3",
            title: "Bulk-parse Security.evtx",
            desc: "EvtxECmd flattens .evtx to CSV for windowed analysis in Timeline Explorer.",
            code: [
              {
                title: "PowerShell — EvtxECmd",
                text: `E:\\Tools\\EvtxECmd.exe -f "F:\\Windows\\System32\\winevt\\Logs\\Security.evtx" --csv E:\\cases\\041 --csvf sec.csv\nImport-Csv E:\\cases\\041\\sec.csv | Group-Object EventId | Sort-Object Count -Descending | Select-Object -First 8 Count, Name`,
              },
            ],
          },
          {
            n: "4",
            title: "Extract the logon matrix",
            desc: "Account × source × type is the only grouping that surfaces lateral movement.",
            code: [
              {
                title: "PowerShell — logon matrix",
                text: `Import-Csv E:\\cases\\041\\sec.csv | Where-Object { $_.EventId -in 4624,4625 } |\n  Select-Object TimeCreated, EventId,\n    TargetUserName, TargetDomainName,\n    @{n='Type';e={$_.LogonType}}, @{n='Src';e={$_.IpAddress}} |\n  Sort-Object TimeCreated | Export-Csv E:\\cases\\041\\logons.csv -NoTypeInformation`,
              },
            ],
          },
        ],
      },
      {
        id: "fuse",
        label: "Fuse + verify",
        steps: [
          {
            n: "5",
            title: "Fuse execution with logons",
            desc: "Execution within minutes of a first-seen Type 3/10 logon is the lateral-movement signature.",
            code: [
              {
                title: "PowerShell — fusion check",
                text: `# Eyeball in Timeline Explorer: load prefetch.csv + logons.csv, sort by time,\n# filter window to incident ±2h. Flag: new source IP -> 4624 T3 -> EID 4688\n# rundll32/powershell within 10 min on the same host.`,
              },
            ],
          },
          {
            n: "6",
            title: "Anti-forensics verdict",
            desc: "Check 1102, service events, and record continuity before writing conclusions.",
            note: "Deliverable: prefetch.csv + Amcache hits + sec.csv + logons.csv + fused timeline + tamper verdict paragraph.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> proof ladder (§5.1–5.2) · channels (§5.3) · logon types (§5.4) → Sysmon depth (Ch. 6).
        Deliverable: an execution-proof package fused with the authentication timeline.
      </>
    ),
  },
  quiz: [
    { q: "Prefetch proves execution more strongly than Shimcache because Prefetch records:", o: ["Only filenames", "Run counts, last-run times, and files touched during execution", "Registry keys", "Network packets"], a: 1, e: "Prefetch captures actual run telemetry; Shimcache records compat evaluation." },
    { q: "UserAssist data is ROT13-encoded and stored in:", o: ["SYSTEM hive", "NTUSER.DAT per user", "Pagefile", "MFT bitmap"], a: 1, e: "UserAssist attributes GUI launches to a specific user profile." },
    { q: "Logon Type 10 with a first-seen source IP at 03:00 most likely indicates:", o: ["Routine patching", "RDP intrusion pattern requiring investigation", "Local console use", "Printer sharing"], a: 1, e: "Type 10 = RemoteInteractive (RDP); new source + odd hour = classic pattern." },
    { q: "Event ID 4672 firing for a service account that never had it before suggests:", o: ["Normal operation", "Possible privilege escalation or misuse of a privileged session", "Disk failure", "DNS outage"], a: 1, e: "4672 = special privileges at logon; new occurrences are the signal." },
    { q: "Event ID 1102 in the Security log means:", o: ["Logon success", "The audit log was cleared", "Service started", "Password changed"], a: 1, e: "1102 is the canonical log-clearing indicator." },
    { q: "Before concluding 'no logon occurred,' the analyst must FIRST verify:", o: ["The SIEM license", "Channel enabled, retention covers window, no tamper/gap precedes it", "The user's manager", "Antivirus version"], a: 1, e: "Unverified absence is an unknown, not a finding." },
  ],
};
