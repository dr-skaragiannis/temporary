import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>7.1 Live triage principles</h4>
    <p>
      <b>Live triage</b> extracts decision-grade volatile state — processes, sockets, handles, logged-on users, and RAM
      itself — from a running host while minimizing footprint and documenting every perturbation. The order follows
      RFC 3227 (Fig. 11): capture <i>most ephemeral first</i> (RAM, process table, network state), deferring disk and
      logs. Two invariants govern: <b>externalize collection</b> (run tools from read-only USB/network share, write
      output externally — never to the suspect disk) and <b>decide the power question once</b> (if RAM matters, the
      host stays powered and network-isolated, never rebooted "to see if it clears").
    </p>
    <Figure
      id="fig-triage-order"
      label="Fig. 11 · Live triage collection order (vector)"
      caption={
        <>
          <b>Fig. 11.</b> Fifteen-minute triage sequence. RAM capture precedes even process listing when fileless
          tradecraft is suspected, because every executed tool perturbs memory. Each step writes to external media
          with hashes.
        </>
      }
    >
      <svg viewBox="0 0 720 190" className="w-full h-auto" role="img" aria-label="Triage order">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="130" height="90" rx="8" fill="#be123c" />
          <text x="75" y="62" fill="#fff">0–2 MIN</text>
          <text x="75" y="79" fill="#ffe4e6" fontWeight="400">Photograph screen</text>
          <text x="75" y="95" fill="#ffe4e6" fontWeight="400">Isolate network</text>
          <text x="75" y="111" fill="#fff" fontSize="9">keep POWER on</text>
          <rect x="152" y="40" width="130" height="90" rx="8" fill="#b45309" />
          <text x="217" y="62" fill="#fff">2–7 MIN</text>
          <text x="217" y="79" fill="#fef3c7" fontWeight="400">RAM capture</text>
          <text x="217" y="95" fill="#fef3c7" fontWeight="400">WinPmem/DumpIt</text>
          <text x="217" y="111" fill="#fff" fontSize="9">→ external USB</text>
          <rect x="294" y="40" width="130" height="90" rx="8" fill="#0e7490" />
          <text x="359" y="62" fill="#fff">7–10 MIN</text>
          <text x="359" y="79" fill="#e0f2fe" fontWeight="400">procs + nets</text>
          <text x="359" y="95" fill="#e0f2fe" fontWeight="400">handles + users</text>
          <text x="359" y="111" fill="#fff" fontSize="9">tasklist/netstat</text>
          <rect x="436" y="40" width="130" height="90" rx="8" fill="#7c3aed" />
          <text x="501" y="62" fill="#fff">10–13 MIN</text>
          <text x="501" y="79" fill="#ede9fe" fontWeight="400">event logs</text>
          <text x="501" y="95" fill="#ede9fe" fontWeight="400">prefetch/MFT</text>
          <text x="501" y="111" fill="#fff" fontSize="9">targeted copy</text>
          <rect x="578" y="40" width="132" height="90" rx="8" fill="#166534" />
          <text x="644" y="62" fill="#fff">13–15 MIN</text>
          <text x="644" y="79" fill="#dcfce7" fontWeight="400">hash + log</text>
          <text x="644" y="95" fill="#dcfce7" fontWeight="400">decide: contain</text>
          <text x="644" y="111" fill="#fff" fontSize="9">or escalate</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="140" y1="85" x2="148" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="282" y1="85" x2="290" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="424" y1="85" x2="432" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="566" y1="85" x2="574" y2="85" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="155" textAnchor="middle" fontSize="11" fill="#64748b">Tools run from external media · output hashed immediately · every command logged with UTC timestamp</text>
      </svg>
    </Figure>
    <h4>7.2 RAM acquisition: WinPmem, DumpIt, LiME</h4>
    <p>
      <b>WinPmem</b> (open-source, kernel driver) offers flexible, scriptable acquisition with integrity hashing and
      is the default for Windows lab work. <b>DumpIt</b> (Comae, single executable) trades flexibility for speed —
      double-click simplicity ideal for first responders under time pressure. <b>LiME</b> (Linux Memory Extractor,
      kernel module) captures Linux RAM in LiME or raw formats for Volatility analysis. All three load a driver —
      a small, <i>documented</i> perturbation justified by the evidence gained. Acquire to external media with free
      space ≥ 1.2× RAM, hash immediately (SHA-256), and record tool versions: memory images are rarely defensible
      without their provenance notes.
    </p>
    <DataTable
      head={["Tool", "Platform", "Strength", "Watch-out"]}
      rows={[
        ["WinPmem", "Windows", "Scriptable, hashed, multiple formats", "Driver load = footprint; use matching arch build"],
        ["DumpIt (Comae)", "Windows", "Fastest field capture, single EXE", "Fewer options; verify build authenticity"],
        ["LiME", "Linux", "Standard for Linux images, Volatility-ready", "Requires matching kernel headers/module build"],
        ["AVML (MS)", "Linux", "Signed, user-mode-friendly capture", "Newer; validate Volatility plugin support"],
      ]}
    />
    <h4>7.3 Volatility 3 framework</h4>
    <p>
      <b>Volatility 3</b> analyzes memory images without prior OS profiles: it auto-detects the kernel via{" "}
      <b>symbol tables</b> (ISF JSON files mapping kernel structures per build) layered over the image's address
      spaces. Workflow: <span className="mono text-sm">windows.info</span> to confirm OS/build, then targeted plugins.
      Volatility 3's layered architecture (physical → virtual → kernel symbols) also powers <b>windows.memmap</b> and{" "}
      <b>timeliner</b> for fused timelines. Keep symbol packs versioned with the tool — mismatched symbols produce
      silent misparses, the memory-forensics equivalent of a corrupted translation.
    </p>
    <h4>7.4 Process tree analysis: pslist, pstree, psscan</h4>
    <p>
      Rootkits hide processes by <b>unlinking EPROCESS entries</b> from the kernel's active-process list — which{" "}
      <span className="mono text-sm">windows.pslist</span> walks. <span className="mono text-sm">windows.psscan</span>{" "}
      instead <b>carves pool memory for EPROCESS signatures</b>, finding unlinked and even exited processes. The
      comparison is the detection (Fig. 12): processes in psscan but absent from pslist are hidden (or exited —
      check the ExitTime to distinguish). <span className="mono text-sm">windows.pstree</span> renders parentage for
      LotL analysis identical in spirit to Sysmon EID 1 trees (Ch. 6).
    </p>
    <Figure
      id="fig-psscan"
      label="Fig. 12 · Hidden-process detection: list-walk vs. pool-carve (vector)"
      caption={
        <>
          <b>Fig. 12.</b> DKOM unlinking defeats list-walking (pslist) but not signature carving (psscan). The set
          difference is the finding; ExitTime separates truly hidden processes from dead ones awaiting scavenging.
        </>
      }
    >
      <svg viewBox="0 0 720 210" className="w-full h-auto" role="img" aria-label="pslist vs psscan">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="220" height="120" rx="10" fill="#0f1c2e" />
          <text x="120" y="52" fill="#fbbf24">pslist · LIST WALK</text>
          <text x="120" y="72" fill="#cbd5e1" fontWeight="400" fontSize="10">follows ActiveProcessLinks</text>
          <text x="120" y="90" fill="#cbd5e1" fontSize="10">sees: System, smss,</text>
          <text x="120" y="106" fill="#cbd5e1" fontSize="10">csrss, explorer, …</text>
          <text x="120" y="128" fill="#f87171" fontSize="10">MISSES unlinked evil.exe ✘</text>
          <rect x="250" y="30" width="220" height="120" rx="10" fill="#0e7490" />
          <text x="360" y="52" fill="#fff">psscan · POOL CARVE</text>
          <text x="360" y="72" fill="#e0f2fe" fontWeight="400" fontSize="10">scans for EPROCESS tags</text>
          <text x="360" y="90" fill="#e0f2fe" fontSize="10">sees: ALL of pslist +</text>
          <text x="360" y="106" fill="#e0f2fe" fontSize="10">unlinked + exited</text>
          <text x="360" y="128" fill="#fef08a" fontSize="10">FINDS evil.exe ✔</text>
          <rect x="490" y="30" width="220" height="120" rx="10" fill="#166534" />
          <text x="600" y="52" fill="#fff">VERDICT LOGIC</text>
          <text x="600" y="72" fill="#dcfce7" fontWeight="400" fontSize="10">psscan − pslist = ?</text>
          <text x="600" y="90" fill="#fff" fontSize="10">ExitTime set → exited</text>
          <text x="600" y="106" fill="#fff" fontSize="10">(dead, awaiting free)</text>
          <text x="600" y="128" fill="#bbf7d0" fontSize="10">ExitTime empty → HIDDEN</text>
        </g>
        <text x="360" y="175" textAnchor="middle" fontSize="11" fill="#64748b">DKOM unlinking hides from the OS itself — carving sees what the kernel was told to forget</text>
      </svg>
    </Figure>
    <h4>7.5 Injected code identification: malfind and hollowing</h4>
    <p>
      <span className="mono text-sm">windows.malfind</span> hunts <b>private executable memory</b> — pages marked
      executable that map to no file on disk — the telltale of DLL injection, reflective loading, and process
      hollowing (T1055). Each hit dumps disassembly plus hex for analyst review: MZ headers in private memory, RWX
      protections, and unlinked VAD regions escalate the verdict. Corroborate with{" "}
      <span className="mono text-sm">windows.vadinfo</span> (memory-region protections) and{" "}
      <span className="mono text-sm">windows.dlllist</span> vs. <span className="mono text-sm">ldrmodules</span>{" "}
      discrepancies (unlinked DLLs). .NET and browser JIT regions produce lookalikes — verdict requires the{" "}
      <i>content</i> (shellcode, PE headers, C2 strings), not just the protection flags.
    </p>
    <h4>7.6 Credential scraping artifacts</h4>
    <p>
      Memory holds what disk never sees: plaintext passwords in process buffers, NTLM hashes and Kerberos tickets in
      LSASS, RDP credentials in mstsc, and browser-session tokens. Volatility plugins{" "}
      <span className="mono text-sm">windows.hashdump</span>, <span className="mono text-sm">windows.cachedump</span>,
      and targeted <span className="mono text-sm">strings + YARA</span> sweeps recover them — equally useful to
      responders (proving credential theft scope) and to attackers (which is why LSASS protection and Credential
      Guard matter). Handle memory-derived credentials as evidence <i>and</i> as toxic material: rotate anything found,
      and redact ruthlessly in reports.
    </p>
    <Callout color="amber">
      <b>Scope rule.</b> Memory proves <i>current and recent</i> state, not history: a clean image means "no resident
      tradecraft <i>now</i>," never "never compromised." Pair every memory verdict with disk timelines (Ch. 4) and
      network history (Ch. 9).
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — Volatility 3 triage sequence (SIFT/examiner Linux)"
        code={`vol -f EVID-2026-041.mem windows.info              # confirm OS build + symbols OK\nvol -f EVID-2026-041.mem windows.pstree            # parentage overview\nvol -f EVID-2026-041.mem windows.pslist --dump    # (compare next line)\nvol -f EVID-2026-041.mem windows.psscan            # hidden/exited hunt (Fig. 12)\nvol -f EVID-2026-041.mem windows.malfind           # private-RWX injection hunt\nvol -f EVID-2026-041.mem windows.netscan           # sockets at capture time\nvol -f EVID-2026-041.mem windows.hashdump          # credential-theft scope`}
      />
    </div>
    <h4>7.7 ★ NEW · Disk-resident memory and Linux live triage</h4>
    <p>
      RAM leaves fossils on disk. <b>hiberfil.sys</b> is a compressed RAM snapshot written at hibernate — a dead-box
      host that hibernated <i>is</i> partially a memory case (parse with hibernation-aware tooling; success varies by
      Windows build and compression). <b>pagefile.sys / swap</b> holds paged-out process memory for months: sweep it
      with strings + YARA for credentials, keys, and shellcode fragments. <b>MEMORY.DMP and minidumps</b> are
      opportunistic captures — a crashed compromised host hands you its kernel state; analyze with WinDbg or
      Volatility. For virtualized fleets, prefer <b>hypervisor-level capture</b> (suspended .vmem + .vmsn): zero
      in-guest footprint, hashed at the host, and convertible for Volatility — the gold standard when available.
    </p>
    <p>
      Linux live triage centers on <b>/proc</b>, which cannot lie about running state the way userland tools (possibly
      trojaned) can. The big three checks: <b>deleted-but-running executables</b> (
      <span className="mono text-sm">/proc/&lt;pid&gt;/exe → (deleted)</span> — fileless or self-deleting tradecraft),{" "}
      <b>memfd-resident code</b> (<span className="mono text-sm">memfd:</span> entries in maps — pure in-memory
      payloads), and <b>LD_PRELOAD hijacks</b> (inspect <span className="mono text-sm">/proc/&lt;pid&gt;/environ</span>{" "}
      and /etc/ld.so.preload for injected libraries intercepting syscalls). Add socket inventory (
      <span className="mono text-sm">ss -tunap</span>), kernel-module review (<span className="mono text-sm">lsmod</span>{" "}
      vs. known-good), and deleted-open-handles (<span className="mono text-sm">ls -l /proc/*/fd | grep deleted</span>).
      Full Linux host forensics continues in Appendix B.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="Bash — Linux /proc live-triage triad (read-only, external logging)"
        code={`ls -l /proc/[0-9]*/exe 2>/dev/null | grep deleted     # running-but-unlinked binaries\n grep -l "memfd:" /proc/[0-9]*/maps 2>/dev/null        # pure in-memory payloads\ncat /etc/ld.so.preload 2>/dev/null; tr '\\0' '\\n' < /proc/1/environ | grep -i preload\nss -tunap 2>/dev/null | head -n 30                       # sockets with owning PIDs`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 7.1 · Live triage drill (60 min, paired)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>One partner "compromises" a lab VM (EICAR + scheduled task + open socket); the other triages blind in 15 min.</li>
      <li>Execute the Fig. 11 sequence from external media; log every command with UTC timestamps.</li>
      <li>Swap roles; grade each other's logs for order violations, missing hashes, and disk writes.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 7.2 · Volatility investigation (90 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Run the full triage sequence on a provided infected image; identify the hidden process.</li>
      <li>Confirm with malfind + netscan; extract the C2 IP and injected payload hash.</li>
      <li>Write the memory-findings section: process, injection, network, credentials — each with plugin + offset evidence.</li>
    </ol>
  </>
);

export const ch07: Chapter = {
  id: "ch7",
  num: 7,
  title: "Live Triage, RAM Capture, and Volatile Memory Forensics",
  subtitle: "Triage order · WinPmem/DumpIt/LiME · Volatility 3 · pslist/psscan · malfind · Credentials",
  badge: "Tier 2 · Memory forensics",
  time: "10–12 h · ~42 pages equiv.",
  outcomes:
    "Execute ordered live triage; capture RAM forensically; drive Volatility 3; expose hidden processes and injected code; assess credential-theft scope from memory.",
  body,
  labTitle: "Hands-on Lab 7.1 · Live triage drill + Lab 7.2 · Volatility investigation",
  labsBody,
  workshop: {
    title: "End-to-end memory pipeline: capture, verify, and dissect",
    env: ["Windows target VM", "SIFT/examiner Linux VM", "WinPmem + Volatility 3 + symbols"],
    tabs: [
      {
        id: "capture",
        label: "Capture + verify",
        steps: [
          {
            n: "1",
            title: "Capture RAM to external media",
            desc: "Insert examiner USB, run WinPmem from it, write the image back to it — suspect disk untouched.",
            code: [
              {
                title: "PowerShell (Admin, from E:\\ tools)",
                text: `E:\\winpmem.exe E:\\EVID-2026-041.mem  # positional output = raw image (flag spelling varies — confirm with --help)\nGet-FileHash E:\\EVID-2026-041.mem -Algorithm SHA256 | Tee-Object E:\\EVID-2026-041.sha256`,
              },
            ],
          },
          {
            n: "2",
            title: "Verify on the examiner station",
            desc: "Re-hash after transfer; confirm Volatility reads the image before releasing the scene.",
            code: [
              {
                title: "Bash — verify + smoke test",
                text: `sha256sum -c EVID-2026-041.sha256\nvol -f EVID-2026-041.mem windows.info | head -n 20`,
              },
            ],
            expected: "hash OK + windows.info prints build + DTB (symbols resolved)",
          },
        ],
      },
      {
        id: "dissect",
        label: "Dissect",
        steps: [
          {
            n: "3",
            title: "Process inventory + hidden hunt",
            desc: "pstree for the story, pslist-vs-psscan for the ghosts.",
            code: [
              {
                title: "Bash — process hunt",
                text: `vol -f EVID-2026-041.mem windows.pstree > pstree.txt\nvol -f EVID-2026-041.mem windows.pslist --quiet | awk '{print $2}' | sort -n > pslist.pids\nvol -f EVID-2026-041.mem windows.psscan --quiet | awk '{print $2}' | sort -n > psscan.pids\ncomm -13 pslist.pids psscan.pids > hidden-candidates.txt\ncat hidden-candidates.txt`,
              },
            ],
            expected: "short PID list — resolve each via ExitTime (exited vs. hidden)",
          },
          {
            n: "4",
            title: "Injection + network sweep",
            desc: "malfind for code, netscan for sockets, hashdump for credential scope.",
            code: [
              {
                title: "Bash — injection + network",
                text: `vol -f EVID-2026-041.mem windows.malfind > malfind.txt; grep -c "Process:" malfind.txt\nvol -f EVID-2026-041.mem windows.netscan > netscan.txt\ngrep -Ei "ESTABLISHED|LISTENING" netscan.txt | head`,
              },
            ],
          },
        ],
      },
      {
        id: "report",
        label: "Verdict + report",
        steps: [
          {
            n: "5",
            title: "Render the memory verdict",
            desc: "One table: process, evidence, verdict, confidence. No verdict without plugin + offset.",
            note: "Deliverable: hashed image + pstree/psscan/malfind/netscan outputs + hidden-process verdict table + credential-scope note. Memory verdicts always pair with disk + network corroboration.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> triage order (§7.1) · acquisition (§7.2) · Volatility layers (§7.3) → disk timelines (Ch.
        4) + C2 corroboration (Ch. 9). Deliverable: a defensible memory-investigation package.
      </>
    ),
  },
  quiz: [
    { q: "The FIRST collection step on a live intrusion host is:", o: ["Disk image", "RAM capture (after photo + isolation)", "Log review", "Antivirus scan"], a: 1, e: "RAM is most volatile; Fig. 11 sequences it at minutes 2–7." },
    { q: "Collection tools must run from external media because:", o: ["It is faster", "Writing to the suspect disk perturbs evidence", "USB is encrypted", "It avoids licensing"], a: 1, e: "Every write to suspect media overwrites potential evidence." },
    { q: "Volatility 3 replaced manual OS profiles with:", o: ["Guessing", "Auto-detection via ISF symbol tables", "Cloud lookup only", "No kernel support"], a: 1, e: "Symbol tables map kernel structures per build automatically." },
    { q: "A PID in psscan but not pslist, with empty ExitTime, is:", o: ["Normal", "A hidden (unlinked) process", "A printer job", "Proof of encryption"], a: 1, e: "No ExitTime = still alive but unlinked from the active list." },
    { q: "windows.malfind primarily detects:", o: ["Disk bad sectors", "Private executable memory (injected/hollowed code)", "Phishing emails", "Weak passwords"], a: 1, e: "Executable pages with no file backing = injection telltale." },
    { q: "A clean memory image proves:", o: ["Never compromised", "No resident tradecraft at capture time — history needs disk/network", "The analyst failed", "Logs are unnecessary"], a: 1, e: "Memory is current-state evidence; pair with timelines." },
  ],
};
