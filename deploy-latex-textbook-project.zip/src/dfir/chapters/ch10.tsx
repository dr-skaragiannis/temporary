import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>10.1 Suricata sensor deployment: TAPs, SPAN, IDS vs. IPS</h4>
    <p>
      <b>Suricata</b> is the open multi-threaded NIDS/NSM engine: signature matching, protocol parsing, file
      extraction, and JSON alerting at multi-gigabit rates. Placement determines value (Fig. 16): <b>network TAPs</b>{" "}
      (passive optical/electrical copies, fail-open, no dropped packets) feed core and DMZ sensors where fidelity is
      paramount; <b>SPAN/mirror ports</b> (switch-copied, cheap, lossy under load) suit tactical or budget
      deployments. <b>IDS (passive)</b> observes and alerts without touching traffic — forensically pure.{" "}
      <b>IPS (inline)</b> can drop/reset malicious flows but becomes a failure point and evidence filter: inline drops
      must log verbosely, or "blocked" becomes an unprovable claim.
    </p>
    <Figure
      id="fig-sensor-place"
      label="Fig. 16 · Sensor + collector placement reference (vector)"
      caption={
        <>
          <b>Fig. 16.</b> TAPs at internet edge, DMZ boundary, and core/distribution watch every trust crossing;
          Suricata and Zeek share the feeds (alerts + metadata); all telemetry ships over TLS syslog to the SIEM.
          No trust boundary should be unobserved.
        </>
      }
    >
      <svg viewBox="0 0 720 270" className="w-full h-auto" role="img" aria-label="Sensor placement">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="110" height="60" rx="8" fill="#64748b" />
          <text x="65" y="64" fill="#fff">INTERNET</text>
          <text x="65" y="80" fill="#e2e8f0" fontWeight="400" fontSize="10">untrusted</text>
          <rect x="140" y="40" width="110" height="60" rx="8" fill="#be123c" />
          <text x="195" y="64" fill="#fff">EDGE FW</text>
          <text x="195" y="80" fill="#ffe4e6" fontWeight="400" fontSize="10">allow/deny log</text>
          <rect x="140" y="118" width="110" height="40" rx="8" fill="#0f1c2e" />
          <text x="195" y="134" fill="#fbbf24" fontSize="10">TAP 1 · SURICATA</text>
          <text x="195" y="149" fill="#cbd5e1" fontWeight="400" fontSize="9">+ ZEEK</text>
          <rect x="270" y="40" width="110" height="60" rx="8" fill="#b45309" />
          <text x="325" y="64" fill="#fff">DMZ</text>
          <text x="325" y="80" fill="#fef3c7" fontWeight="400" fontSize="10">web / mail / VPN</text>
          <rect x="400" y="40" width="110" height="60" rx="8" fill="#0e7490" />
          <text x="455" y="64" fill="#fff">CORE FW</text>
          <text x="455" y="80" fill="#e0f2fe" fontWeight="400" fontSize="10">segment gates</text>
          <rect x="400" y="118" width="110" height="40" rx="8" fill="#0f1c2e" />
          <text x="455" y="134" fill="#fbbf24" fontSize="10">TAP 2 · SURICATA</text>
          <text x="455" y="149" fill="#cbd5e1" fontWeight="400" fontSize="9">east-west</text>
          <rect x="530" y="40" width="180" height="60" rx="8" fill="#166534" />
          <text x="620" y="64" fill="#fff">INSIDE · SERVERS + USERS</text>
          <text x="620" y="80" fill="#dcfce7" fontWeight="400" fontSize="10">AD · endpoints · DB</text>
          <rect x="530" y="118" width="180" height="40" rx="8" fill="#0f1c2e" />
          <text x="620" y="134" fill="#fbbf24" fontSize="10">SPAN · tactical / IR capture</text>
          <text x="620" y="149" fill="#cbd5e1" fontWeight="400" fontSize="9">lossy under load</text>
          <rect x="195" y="180" width="330" height="56" rx="8" fill="#0f1c2e" />
          <text x="360" y="201" fill="#fbbf24">SYSLOG over TLS (RFC 5424) → SIEM</text>
          <text x="360" y="218" fill="#cbd5e1" fontWeight="400" fontSize="10">fw + vpn + proxy + suricata eve.json + zeek · queued + hashed</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="120" y1="70" x2="136" y2="70" markerEnd="url(#dfir-a1)" />
          <line x1="250" y1="70" x2="266" y2="70" markerEnd="url(#dfir-a1)" />
          <line x1="380" y1="70" x2="396" y2="70" markerEnd="url(#dfir-a1)" />
          <line x1="510" y1="70" x2="526" y2="70" markerEnd="url(#dfir-a1)" />
        </g>
        <g stroke="#64748b" strokeWidth="1.5" strokeDasharray="5 4">
          <line x1="195" y1="100" x2="195" y2="114" />
          <line x1="455" y1="100" x2="455" y2="114" />
          <line x1="195" y1="158" x2="280" y2="180" />
          <line x1="455" y1="158" x2="400" y2="180" />
          <line x1="620" y1="158" x2="480" y2="180" />
        </g>
        <text x="360" y="256" textAnchor="middle" fontSize="11" fill="#64748b">TAP where it matters · SPAN where it moves · everything forwarded, queued, and retained</text>
      </svg>
    </Figure>
    <h4>10.2 Suricata rule authoring</h4>
    <p>
      Suricata rules combine a <b>header</b> (action, protocol, source/destination, ports, direction{" "}
      <span className="mono text-sm">-&gt;</span> or <span className="mono text-sm">&lt;&gt;</span>) with{" "}
      <b>options</b> (content matches with modifiers, flow state, thresholds, metadata). Authoring discipline: anchor
      on <b>protocol + flow-established + rare content</b> (avoid bare IP rules that rot in days), use{" "}
      <span className="mono text-sm">flowbits</span> for multi-stage logic, and set <span className="mono text-sm">threshold</span>{" "}
      to suppress scan-noise. Every custom rule carries <b>msg, classtype, reference, and sid in the local range</b>{" "}
      with a comment naming the incident or intel that justified it — rules without provenance become undeletable
      folklore.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="Suricata — C2 + webshell rules with provenance comments"
        code={`# INC-2026-0117: beacon to cdn-x7.ru — replace with intel feed in production\n alert http $HOME_NET any -> $EXTERNAL_NET any (\n  msg:"DFIR C2 beacon domain cdn-x7.ru"; flow:established,to_server;\n  http.host; content:"cdn-x7.ru"; nocase; endswith;\n  classtype:trojan-activity; reference:url,case-041;\n  sid:9000117; rev:2; threshold:type limit, track by_src, count 5, seconds 600;)\n\n# T1505.003 webshell: POST to static-asset paths with code extensions\n alert http $EXTERNAL_NET any -> $HTTP_SERVERS any (\n  msg:"DFIR possible webshell POST under static path"; flow:established,to_server;\n  http.method; content:"POST"; http.uri; pcre:"/\\/(assets|images|static)\\/[^\\s]*?\\.php/U";\n  classtype:web-application-attack; sid:9000118; rev:1;)`}
      />
    </div>
    <h4>10.3 Syslog architecture &amp; transport: rsyslog, syslog-ng, TLS</h4>
    <p>
      <b>Syslog (RFC 5424)</b> is the enterprise log-transport standard: structured messages with facility, severity,
      timestamp, hostname, app-name, and message, shipped over <b>TLS (port 6514)</b> with mutual authentication.{" "}
      <b>rsyslog</b> (modular, queue-rich) and <b>syslog-ng</b> (powerful parsing/filters) both serve as forwarders and
      relays; design for <b>disk-assisted queues</b> (survive SIEM outages without loss), <b>rate limiting</b> (one
      chatty host must not drown the pipeline), and <b>integrity</b> (TLS + optional signed hashes). Validate
      end-to-end: generate a canary event at the source, confirm structured arrival in the SIEM — unforwarded logs are
      shelfware.
    </p>
    <DataTable
      head={["Pipeline stage", "Function", "Failure mode to engineer out"]}
      rows={[
        ["Source (appliance/host)", "Emit structured syslog over TLS", "Clock skew, local-only retention, UDP loss"],
        ["Relay tier (optional)", "Buffer, filter, route by facility", "Single point of failure — cluster it"],
        ["SIEM ingestion", "Parse, normalize (ECS/CIM), index", "Unparsed = unsearchable; monitor parse-failure rate"],
        ["Archive (cold)", "Tamper-evident long retention", "No integrity proof — hash + WORM"],
      ]}
    />
    <h4>10.4 Perimeter firewall &amp; VPN logs</h4>
    <p>
      Firewalls (pfSense, Palo Alto, Fortinet) log <b>session lifecycles</b>: allow/deny verdicts with rule IDs, NAT
      translations, bytes both ways, and session end reasons. DFIR reads them for <b>egress anomalies</b> (new
      external destinations, off-hours bulk uploads), <b>ingress probes</b> (deny sweeps preceding a single allow —
      the successful exploit), and <b>policy violations</b> (direct-to-IP, nonstandard ports). <b>VPN gateways</b> add
      authentication logs (user, source, posture, MFA result) plus tunnel byte counts: impossible-travel, first-seen
      device + success, and bulk egress over VPN are the big three hunts.
    </p>
    <h4>10.5 Web proxy &amp; reverse proxy logs</h4>
    <p>
      Forward proxies see what firewalls cannot: full <b>URIs, User-Agents, categories, and verdicts</b> per user.
      Hunt fields: <b>X-Forwarded-For chains</b> (true client behind CDN/LB layers — log the full chain, trust only
      your edge's append), rare User-Agents per user, non-browser UAs from user subnets (curl/PowerShell = scripted
      access), and POST-heavy sessions to uncategorized hosts. <b>Reverse proxies</b> (WAF/LB fronting web apps)
      mirror this for inbound: attack URIs, blocked-rule IDs, and backend status codes that corroborate server access
      logs (Ch. 8) even when local logs were wiped.
    </p>
    <h4>10.6 Structured alert output: eve.json pipelines</h4>
    <p>
      Suricata's <b>eve.json</b> streams every alert, flow, DNS/HTTP/TLS record, and fileinfo object as JSON — a
      SIEM-native firehose. Ingest via Filebeat/Logstash with <b>ECS-mapped pipelines</b>, route by{" "}
      <span className="mono text-sm">event_type</span> (alert vs. flow vs. dns), and monitor pipeline health (EPS,
      drop rate, parse errors) as its own SLA. Retention split: alerts hot for a year, flows warm for 90 days, full
      eve archived cold — cost control that preserves hunting depth. Eve + Zeek + endpoint telemetry is the
      correlation substrate of Ch. 11.
    </p>
    <Callout color="emerald">
      <b>Perimeter maxim.</b> The firewall says <i>allowed or denied</i>; the proxy says <i>who asked for what</i>;
      Suricata says <i>known-bad matched</i>; Zeek says <i>what actually happened</i>. Verdicts need all four —
      never one.
    </Callout>
    <h4>10.7 ★ NEW · Windows Event Forwarding: the other enterprise transport</h4>
    <p>
      For Windows fleets, <b>Windows Event Forwarding (WEF)</b> rivals syslog: agents already exist (every host runs
      WinRM), fidelity is native (.evtx preserved exactly, Sysmon included), and <b>XPath subscriptions</b> filter at
      the source so collectors receive signal instead of noise. Two topologies: <b>source-initiated</b> (hosts push to
      collectors; scales via GPO — the enterprise default) and <b>collector-initiated</b> (collector pulls; for DMZ and
      workgroup hosts). Harden it like any pipeline: dedicated collector tier, HTTPS (5986) with mutual auth, least-
      privilege subscription ACLs, and <b>heartbeat monitoring</b> — a source that goes silent is a blind host, and
      adversaries know that stopping the forwarder is quieter than clearing the log. Choose per fleet: WEF for
      Windows/.evtx depth, syslog for appliances/network gear, both feeding the same SIEM normalization.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell / CMD — WEF quickstart (collector + subscription check)"
        code={`wecutil qc /q                         # configure Event Collector service (collector host)\nwecutil es                            # list subscriptions + runtime status\n# GPO (sources): Computer > Admin Templates > Windows Components > Event Forwarding\n#   SubscriptionManager = Server=http://wef-collector.lab:5985/wsman/SubscriptionManager/WEC\n# Monitor: alert when any source's LastHeartbeatTime exceeds 2x interval`}
      />
    </div>
    <h4>10.8 ★ NEW · Deception, sinkholes, and Suricata depth</h4>
    <p>
      The cheapest detections are traps nobody legitimate touches. <b>Honeytokens</b> (canary AWS keys, documents,
      URLs, database rows) alert on any use — false-positive rate near zero, because only thieves and scanners bite.{" "}
      <b>Honey accounts</b> in AD (privileged-looking, never used) turn any authentication into a SEV-1.{" "}
      <b>DNS sinkholing</b> repoints known-C2 domains to a walled-garden sensor during containment, enumerating every
      infected host still beaconing — scope the botnet, then isolate simultaneously (Ch. 13). On the sensor itself, go
      deeper: Suricata <b>datasets</b> match million-entry IoC sets without a rule per indicator, and the{" "}
      <b>filestore</b> engine extracts transferred files for hashing and detonation — your eve.json becomes a malware
      collection pipeline, not just an alert stream.
    </p>
    <DataTable
      head={["Deception", "Signal", "Typical false positives"]}
      rows={[
        ["Canary tokens (keys/docs/URLs)", "Any use, anywhere", "~Zero — only attackers and vuln-scanners touch them"],
        ["AD honey accounts", "Any auth attempt (4624/4768)", "Near-zero after excluding scanners"],
        ["Honeypot services (SSH/RDP/SMB)", "Full session + payloads", "Internet background noise (tune by asset)"],
        ["DNS sinkhole", "Beaconing hosts enumerated", "Stale IoCs — expire sinkholes with intel"],
      ]}
    />
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 10.1 · NIDS rule + adversarial validation (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Write three rules (C2 domain, webshell URI, scan threshold) with full metadata + provenance comments.</li>
      <li>Replay benign + malicious PCAPs; measure true/false positives per rule.</li>
      <li>Tune until FP=0 on benign while retaining all TPs; document the tuning rationale.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 10.2 · Syslog-over-TLS pipeline (60 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Configure rsyslog client → relay → (mock) SIEM over TLS with disk queues.</li>
      <li>Prove losslessness: kill the SIEM endpoint for 5 min, restore, verify zero gaps via sequence canaries.</li>
      <li>Inject malformed messages; confirm parse-failure alerting fires (not silent drops).</li>
    </ol>
  </>
);

export const ch10: Chapter = {
  id: "ch10",
  num: 10,
  title: "Network Security Monitoring (NIDS), Perimeter Telemetry, and Syslog Integration",
  subtitle: "Suricata deploy + rules · Syslog/TLS · Firewall/VPN · Proxies · eve.json",
  badge: "Tier 3 · Perimeter + transport",
  time: "9–11 h · ~40 pages equiv.",
  outcomes:
    "Place sensors on TAP/SPAN correctly; author precise Suricata rules; build lossless syslog-over-TLS pipelines; exploit firewall/VPN/proxy logs; ingest eve.json into SIEM flows.",
  body,
  labTitle: "Hands-on Lab 10.1 · NIDS rule + adversarial validation + Lab 10.2 · Syslog-over-TLS pipeline",
  labsBody,
  workshop: {
    title: "Stand up Suricata + TLS syslog forwarding in one lab",
    env: ["Linux sensor VM (2 NICs)", "Suricata + rsyslog", "Test PCAPs + SIEM mock (nc/file)"],
    tabs: [
      {
        id: "suri",
        label: "Suricata up",
        steps: [
          {
            n: "1",
            title: "Install and validate the engine",
            desc: "AF-PACKET capture on the monitor interface; stock ET-Open ruleset as baseline.",
            code: [
              {
                title: "Bash — install + self-test",
                text: `sudo apt install -y suricata suricata-update\nsudo suricata-update && sudo suricata -T -c /etc/suricata/suricata.yaml\nsudo systemctl enable --now suricata\ntail -n 5 /var/log/suricata/suricata.log`,
              },
            ],
            expected: "engine starts, ruleset loads, no packet loss on idle interface",
          },
          {
            n: "2",
            title: "Add local DFIR rules and test",
            desc: "Local rules live in a versioned file with case provenance — never inline edits.",
            code: [
              {
                title: "Bash — local rules",
                text: `sudo tee /etc/suricata/rules/dfir-local.rules > /dev/null <<'EOF'\nalert http $HOME_NET any -> $EXTERNAL_NET any (msg:"DFIR C2 test domain"; flow:established,to_server; http.host; content:"cdn-x7.ru"; nocase; classtype:trojan-activity; sid:9000117; rev:1;)\nEOF\nsudo suricata -T -c /etc/suricata/suricata.yaml && echo RULES-OK\nsuricata -r ../capture.pcap -c /etc/suricata/suricata.yaml -l ./replay/ && cat ./replay/fast.log`,
              },
            ],
            expected: "RULES-OK + replay fast.log shows the C2 alert firing on the sample",
          },
        ],
      },
      {
        id: "syslog",
        label: "Syslog TLS",
        steps: [
          {
            n: "3",
            title: "Forward eve.json over TLS",
            desc: "imfile tails eve.json; omfwd ships RFC 5424 over TLS with a disk queue.",
            code: [
              {
                title: "Bash — rsyslog TLS forward (client)",
                text: `sudo tee /etc/rsyslog.d/60-eve-tls.conf > /dev/null <<'EOF'\nmodule(load="imfile")\ninput(type="imfile" File="/var/log/suricata/eve.json" Tag="suricata-eve:")\naction(type="omfwd" Target="siem-relay.lab" Port="6514" Protocol="tcp"\n  StreamDriver="gtls" StreamDriverMode="1" StreamDriverAuthMode="anon"\n  queue.type="LinkedList" queue.filename="eveq" queue.saveonshutdown="on"\n  template="RSYSLOG_SyslogProtocol23Format")\nEOF\nsudo rsyslogd -N1 && sudo systemctl restart rsyslog`,
              },
            ],
          },
          {
            n: "4",
            title: "Prove arrival with a canary",
            desc: "Inject a marked event; confirm it lands structured at the collector.",
            code: [
              {
                title: "Bash — canary test",
                text: `logger --rfc5424 -t CANARY "dfir-pipeline-test $(date -u +%FT%TZ)"\n# on collector:\ntail -n 3 /var/log/remote/sensor01.log | grep CANARY`,
              },
            ],
            expected: "canary present with intact timestamp + hostname + tag",
          },
        ],
      },
      {
        id: "perim",
        label: "Perimeter hunt",
        steps: [
          {
            n: "5",
            title: "Fuse firewall + proxy + eve",
            desc: "One external IP across three sources: allow verdict, URI detail, alert verdict.",
            code: [
              {
                title: "Bash — triple-source pivot",
                text: `IP=45.9.148.7\ngrep "$IP" firewall-sessions.log | head -n 5      # allow? bytes? rule?\ngrep "$IP" proxy.log | cut -d' ' -f4,7,9 | head -n 5  # URIs + UAs\njq -c --arg ip "$IP" 'select(.dest_ip==$ip) | {t:.timestamp, s:.alert.signature}' eve.json | head`,
              },
            ],
          },
          {
            n: "6",
            title: "Write the perimeter finding",
            note: "Deliverable: running Suricata + versioned local rules + TLS syslog proof + triple-source pivot for one C2 IP. This eve.json stream feeds Ch. 11 correlation.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> sensor placement (§10.1) · rules (§10.2) · syslog transport (§10.3) → SIEM ingestion (Ch.
        11). Deliverable: an alerting sensor with a proven-lossless forwarding path.
      </>
    ),
  },
  quiz: [
    { q: "TAPs are preferred over SPAN for forensic sensors because TAPs:", o: ["Are cheaper", "Copy all traffic passively without switch-induced drops", "Encrypt traffic", "Need no power"], a: 1, e: "SPAN drops under load; TAPs preserve evidentiary completeness." },
    { q: "IPS differs from IDS in that IPS:", o: ["Only logs", "Sits inline and can block — becoming a failure/evidence-filter point", "Cannot alert", "Ignores rules"], a: 1, e: "Inline action trades purity for prevention; log verbosely." },
    { q: "A well-authored Suricata content rule anchors on:", o: ["Bare IPs only", "Protocol + flow-established + rare content with thresholds", "Port 80 only", "Packet size only"], a: 1, e: "Anchoring cuts FPs; thresholds tame scan noise." },
    { q: "RFC 5424 syslog over TLS should use disk-assisted queues to:", o: ["Go faster", "Survive collector outages without losing messages", "Compress logs", "Encrypt disks"], a: 1, e: "Queues bridge SIEM downtime — no gap, no blind window." },
    { q: "X-Forwarded-For chains matter because they reveal:", o: ["The true client behind CDN/LB layers", "Passwords", "Encryption keys", "CPU load"], a: 0, e: "Log the full chain; trust only your own edge's append." },
    { q: "eve.json's primary SIEM value is:", o: ["Binary efficiency", "Structured JSON alerts + flows + protocol records ready to ingest", "Packet payloads always", "Decryption"], a: 1, e: "event_type routing splits alerts, flows, dns, tls cleanly." },
  ],
};
