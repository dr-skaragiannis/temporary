import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>8.1 Active Directory &amp; identity: the forest is the target</h4>
    <p>
      <b>Active Directory</b> is both the enterprise's identity plane and its highest-value forensic surface. Domain
      Controller Security logs narrate authentication at scale: <b>4768</b> (TGT requested), <b>4769</b> (service
      ticket requested — the Kerberoasting signal when one account requests many RC4 service tickets), <b>4771</b>{" "}
      (pre-auth failure — password spray and AS-REP roast recon), and <b>4662</b> (replication/DS access — the DCSync
      tell when a non-DC account triggers it). <b>NTLM relay</b> leaves Type-3 4624s from unexpected intermediaries
      plus SMB signing-downgrade traces. Hunt posture: baseline per-account ticket volumes, alert on 4662 from
      non-DCs, and treat any <span className="mono text-sm">krbtgt</span> anomaly as a forest-level incident until
      proven otherwise (eviction: Ch. 13).
    </p>
    <Figure
      id="fig-ad-attacks"
      label="Fig. 13 · AD attacks → DC artifacts (vector)"
      caption={
        <>
          <b>Fig. 13.</b> Three identity attacks and their unavoidable DC traces. Attackers choose the technique;
          defenders choose whether the log that catches it is collected. DCSync is the highest-severity single event
          in this chapter.
        </>
      }
    >
      <svg viewBox="0 0 720 230" className="w-full h-auto" role="img" aria-label="AD attacks">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="20" width="225" height="160" rx="10" fill="#b45309" />
          <text x="122" y="42" fill="#fff">KERBEROASTING</text>
          <text x="122" y="60" fill="#fef3c7" fontWeight="400" fontSize="10">request SPN tickets →</text>
          <text x="122" y="76" fill="#fef3c7" fontWeight="400" fontSize="10">crack offline (RC4)</text>
          <text x="122" y="98" fill="#fff" fontSize="10">ARTIFACT: 4769 flood</text>
          <text x="122" y="114" fill="#fef3c7" fontWeight="400" fontSize="10">1 acct → many SPNs</text>
          <text x="122" y="130" fill="#fef3c7" fontWeight="400" fontSize="10">TicketEnc=0x17 (RC4)</text>
          <text x="122" y="152" fill="#fff" fontSize="9">FIX: AES + long SPN pw</text>
          <rect x="247" y="20" width="226" height="160" rx="10" fill="#be123c" />
          <text x="360" y="42" fill="#fff">DCSYNC</text>
          <text x="360" y="60" fill="#ffe4e6" fontWeight="400" fontSize="10">mimic DC replication →</text>
          <text x="360" y="76" fill="#ffe4e6" fontWeight="400" fontSize="10">pull all hashes</text>
          <text x="360" y="98" fill="#fff" fontSize="10">ARTIFACT: 4662</text>
          <text x="360" y="114" fill="#ffe4e6" fontWeight="400" fontSize="10">non-DC acct +</text>
          <text x="360" y="130" fill="#ffe4e6" fontWeight="400" fontSize="10">replication GUID</text>
          <text x="360" y="152" fill="#fff" fontSize="9">SEV-1 · isolate + reset</text>
          <rect x="485" y="20" width="225" height="160" rx="10" fill="#7c3aed" />
          <text x="597" y="42" fill="#fff">AS-REP ROAST</text>
          <text x="597" y="60" fill="#ede9fe" fontWeight="400" fontSize="10">no-preauth accts →</text>
          <text x="597" y="76" fill="#ede9fe" fontWeight="400" fontSize="10">crackable AS-REP</text>
          <text x="597" y="98" fill="#fff" fontSize="10">ARTIFACT: 4768</text>
          <text x="597" y="114" fill="#ede9fe" fontWeight="400" fontSize="10">pre-auth NOT used</text>
          <text x="597" y="130" fill="#ede9fe" fontWeight="400" fontSize="10">+ 4771 spray</text>
          <text x="597" y="152" fill="#fff" fontSize="9">FIX: require pre-auth</text>
        </g>
        <text x="360" y="204" textAnchor="middle" fontSize="11" fill="#64748b">All three demand DC Security logs forwarded to SIEM — local-only DC logs are a forest-wide blind spot</text>
      </svg>
    </Figure>
    <h4>8.2 DNS infrastructure: the enterprise's confession booth</h4>
    <p>
      Nearly every intrusion touches DNS: C2 resolution, phishing domains, <b>DNS tunneling/exfiltration</b> (data
      encoded in subdomain labels of TXT/NULL queries), <b>fast-flux</b> (rapid A-record churn behind one domain),
      and <b>DGA</b> (algorithmic domain storms). Sources: <b>Windows DNS debug/analytical logs</b> and{" "}
      <b>BIND query.log</b> on resolvers, Sysmon EID 22 on endpoints (Ch. 6), and Zeek dns.log on the wire (Ch. 9).
      Hunt shapes: impossible query types at volume (TXT/NULL), high-entropy labels, first-seen domains with
      metronomic query intervals, and single clients resolving disproportionate NXDOMAIN counts (DGA spray).
    </p>
    <h4>8.3 DHCP leases &amp; IP attribution</h4>
    <p>
      DHCP servers answer the attribution question "who held 10.4.17.88 at 02:14?" — unanswerable from flow logs
      alone in dynamic environments. Preserve <b>lease histories</b> (Windows DHCP audit logs, ISC dhcpd.leases,
      appliance exports) with MAC + hostname + lease start/end, retained ≥ 1 year. Forensic uses: resolving transient
      IPs in timelines, proving device presence (MAC continuity across leases), and exposing rogue devices (unknown
      MACs claiming leases). Correlate DHCP hostname/MAC with 802.1X/NAC and EDR inventory: a MAC with no managed
      identity is a rogue-or-BYOD lead.
    </p>
    <h4>8.4 Web server telemetry: Apache, Nginx, IIS</h4>
    <p>
      Web access logs record every request line — method, URI, status, bytes, referrer, User-Agent — making them the
      primary initial-access and webshell-interaction record. Hunt patterns: <b>SQLi probes</b> (
      <span className="mono text-sm">UNION SELECT</span>, quote-break sequences in URIs), <b>webshell hits</b> (POSTs
      to odd paths like <span className="mono text-sm">/images/logo.php</span> with 200s at attacker hours),{" "}
      <b>scan bursts</b> (404/403 sweeps across admin paths), and <b>500 clusters</b> (exploit attempts crashing
      handlers). IIS adds <b>cs-uri-query + sc-win32-status</b> precision; error logs reveal handler failures that
      access logs summarize. Retain raw logs centrally — attackers routinely delete local web logs post-compromise.
    </p>
    <DataTable
      head={["Signal in access log", "Example", "Meaning"]}
      rows={[
        ["POST 200 to image/upload path", "POST /assets/x.php 200 18432", "Likely webshell interaction — pull file + Sysmon EID 1"],
        ["GET 404 sweep, one source", "20+ 404s across /admin*, /wp-*, /.git", "Recon scan; check for the 200 that followed"],
        ["SQLi metacharacters in URI", "id=1' UNION SELECT", "Injection probe; check DB + 500s + WAF"],
        ["401→200 transition, one user", "3× 401 then 200 on /api/login", "Guessed/brute-forced credential OR password spray hit"],
        ["Ancient User-Agent + odd hour", "curl/7.0 at 03:12 from foreign ASN", "Scripted access; correlate with auth + proxy logs"],
      ]}
    />
    <h4>8.5 Mail server gateways: phishing delivery forensics</h4>
    <p>
      Mail gateways (Exchange transport/message-tracking, Postfix logs, SEG appliances) reconstruct the delivery leg:
      sender envelope vs. header-From mismatch (spoofing), SPF/DKIM/DMARC verdicts, attachment detonation results,
      URL-rewrite click records, and mailbox-rule creation (attacker persistence via auto-forward, T1137). Key joins:{" "}
      <b>message-ID → recipient → click/open → endpoint execution</b> (Sysmon EID 1 parented by Outlook) closes the
      phish-to-shell loop. Compromised mailboxes demand <b>OAuth/app-consent audit</b> (malicious app grants survive
      password resets) alongside credential rotation.
    </p>
    <h4>8.6 Secure Shell auditing</h4>
    <p>
      SSH is the Linux lateral-movement plane. <b>/var/log/auth.log (secure)</b> records every attempt: brute-force
      sprays (thousands of Failed password from few sources), successful logins from first-seen sources, new-key
      trust (<span className="mono text-sm">Accepted publickey</span> for unknown fingerprints — planted keys in{" "}
      <span className="mono text-sm">authorized_keys</span>), and <b>port-forwarding sessions</b> (
      <span className="mono text-sm">-R/-L</span> channels tunneling C2 or exfil through the SSH connection). Harden
      the record: <span className="mono text-sm">LogLevel VERBOSE</span> (fingerprints on login), centralized syslog
      (Ch. 10), and alerting on first-seen source + success and on authorized_keys modifications.
    </p>
    <Figure
      id="fig-svc-telemetry"
      label="Fig. 14 · Service → log source → collector map (vector)"
      caption={
        <>
          <b>Fig. 14.</b> Every core service emits at least one forensic-grade log; every log needs a collector path
          to the SIEM. Gaps in the middle column are detection blind spots; gaps in the right column are retention
          failures. Agent placement (beats/forwarders) is normative — see Ch. 11.
        </>
      }
    >
      <svg viewBox="0 0 720 300" className="w-full h-auto" role="img" aria-label="Telemetry map">
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <text x="120" y="16" fill="#0f1c2e" fontSize="11">SERVICE</text>
          <text x="360" y="16" fill="#0f1c2e" fontSize="11">FORENSIC LOG SOURCE</text>
          <text x="600" y="16" fill="#0f1c2e" fontSize="11">COLLECTOR → SIEM</text>
          <rect x="20" y="26" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="47" fill="#fbbf24">Active Directory (DC)</text>
          <rect x="250" y="26" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="47" fill="#92400e">Security 4768/69/71 + 4662</text>
          <rect x="500" y="26" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="47" fill="#fff">Winlogbeat / UF</text>
          <rect x="20" y="68" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="89" fill="#fbbf24">DNS resolvers</text>
          <rect x="250" y="68" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="89" fill="#92400e">debug log / query.log</text>
          <rect x="500" y="68" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="89" fill="#fff">Filebeat / syslog</text>
          <rect x="20" y="110" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="131" fill="#fbbf24">DHCP</text>
          <rect x="250" y="110" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="131" fill="#92400e">lease audit trail</text>
          <rect x="500" y="110" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="131" fill="#fff">syslog → SIEM</text>
          <rect x="20" y="152" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="173" fill="#fbbf24">Web (Apache/Nginx/IIS)</text>
          <rect x="250" y="152" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="173" fill="#92400e">access + error logs</text>
          <rect x="500" y="152" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="173" fill="#fff">Filebeat + WAF feed</text>
          <rect x="20" y="194" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="215" fill="#fbbf24">Mail gateway / MTA</text>
          <rect x="250" y="194" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="215" fill="#92400e">tracking + auth verdicts</text>
          <rect x="500" y="194" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="215" fill="#fff">SEG API / syslog</text>
          <rect x="20" y="236" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="257" fill="#fbbf24">SSH fleet</text>
          <rect x="250" y="236" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="257" fill="#92400e">auth.log VERBOSE</text>
          <rect x="500" y="236" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="257" fill="#fff">syslog over TLS</text>
        </g>
        <g stroke="#64748b" strokeWidth="1.5">
          {[43, 85, 127, 169, 211, 253].map((y) => (
            <g key={y}>
              <line x1="220" y1={y} x2="248" y2={y} />
              <line x1="470" y1={y} x2="498" y2={y} />
            </g>
          ))}
        </g>
        <text x="360" y="290" textAnchor="middle" fontSize="11" fill="#64748b">Audit question per row: is the source enabled, parsed, retained, and alerted? A “no” anywhere is a finding</text>
      </svg>
    </Figure>
    <Callout color="emerald">
      <b>Infrastructure maxim.</b> Attackers live in the seams <i>between</i> services — phish (mail) → shell (web) →
      tickets (AD) → tunnel (DNS) → pivot (SSH). Single-service monitoring sees hops; only cross-service correlation
      (Ch. 11) sees campaigns.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — cross-service triage one-liners (SIEM-down fallback)"
        code={`# AD: Kerberoast screen — top requesters of RC4 service tickets (EID 4769 export)\ncat dc-4769.csv | awk -F, '$NF==\"0x17\"' | cut -d, -f3 | sort | uniq -c | sort -rn | head\n# DNS: TXT/NULL volume + high-entropy labels\nawk '$6 ~ /TXT|NULL/ {print $7}' query.log | sort | uniq -c | sort -rn | head -n 20\n# Web: POSTs to non-API paths with 200s (webshell interaction shape)\nawk '$6==\"POST\" && $9==200 {print $7}' access.log | grep -Ev '^/api/' | sort | uniq -c | sort -rn | head\n# SSH: first-seen successful sources this week\n grep "Accepted" /var/log/auth.log | grep -oE '[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+' | sort -u > thisweek.txt; comm -23 thisweek.txt baseline-sources.txt`}
      />
    </div>
    <h4>8.7 ★ NEW · Cloud &amp; modern identity: Entra ID, M365, Okta, and AiTM</h4>
    <p>
      Identity has moved to the cloud, and so must the investigator. <b>Entra ID sign-in logs</b> record every
      authentication with method, Conditional Access result, device identity, and source — the cloud equivalent of
      4624, queryable at scale. <b>Identity Protection risk detections</b> flag leaked credentials, unfamiliar
      sign-ins, and token anomalies. <b>M365 Unified Audit Log (UAL)</b> is the persistence-hunter's goldmine: mailbox
      rule creation, eDiscovery searches by unexpected admins, and <b>OAuth app-consent grants</b> (malicious apps
      survive password resets — the cloud's Run key). <b>Okta system logs</b> mirror this for Okta shops: MFA
      challenges, policy changes, and API-token use. Baseline per-user sign-in geography, devices, and apps before the
      incident — cloud hunts without baselines drown in legitimate travel and sync traffic.
    </p>
    <Figure
      id="fig-aitm"
      label="Fig. 22 · Adversary-in-the-middle vs. modern auth (vector) ★ NEW"
      caption={
        <>
          <b>Fig. 22.</b> AiTM proxies relay the victim's live session — including the MFA challenge — to the real
          IdP, then steal the issued session cookie. Passwords + SMS/TOTP MFA both fall; only phishing-resistant MFA
          (FIDO2) and token protection break the relay. Hunt the right side: impossible travel, new device, replayed
          session.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="AiTM attack">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="150" height="90" rx="10" fill="#0e7490" />
          <text x="85" y="62" fill="#fff">VICTIM</text>
          <text x="85" y="79" fill="#e0f2fe" fontWeight="400" fontSize="10">clicks phish link</text>
          <text x="85" y="95" fill="#e0f2fe" fontWeight="400" fontSize="10">enters creds + MFA</text>
          <text x="85" y="114" fill="#fef08a" fontSize="9">sees real login UX</text>
          <rect x="190" y="40" width="170" height="90" rx="10" fill="#be123c" />
          <text x="275" y="62" fill="#fff">ATTACKER PROXY</text>
          <text x="275" y="79" fill="#ffe4e6" fontWeight="400" fontSize="10">relays to real IdP</text>
          <text x="275" y="95" fill="#ffe4e6" fontWeight="400" fontSize="10">MFA passes through</text>
          <text x="275" y="114" fill="#fff" fontSize="9">steals session cookie</text>
          <rect x="390" y="40" width="150" height="90" rx="10" fill="#166534" />
          <text x="465" y="62" fill="#fff">REAL IdP</text>
          <text x="465" y="79" fill="#dcfce7" fontWeight="400" fontSize="10">Entra / Okta</text>
          <text x="465" y="95" fill="#dcfce7" fontWeight="400" fontSize="10">issues session</text>
          <text x="465" y="114" fill="#fff" fontSize="9">legitimate login!</text>
          <rect x="565" y="40" width="145" height="90" rx="10" fill="#0f1c2e" />
          <text x="637" y="62" fill="#fbbf24">REPLAY</text>
          <text x="637" y="79" fill="#cbd5e1" fontWeight="400" fontSize="10">cookie reused</text>
          <text x="637" y="95" fill="#cbd5e1" fontWeight="400" fontSize="10">no MFA needed</text>
          <text x="637" y="114" fill="#fbbf24" fontSize="9">full account access</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="160" y1="85" x2="186" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="360" y1="85" x2="386" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="540" y1="85" x2="561" y2="85" markerEnd="url(#dfir-a1)" />
        </g>
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="150" width="345" height="64" rx="8" fill="#fef2f2" stroke="#be123c" strokeWidth="1.5" />
          <text x="182" y="171" fill="#be123c">HUNT: impossible travel · new device + success · risk detections · token replay</text>
          <text x="182" y="190" fill="#475569" fontWeight="400">UAL: app-consent grants + mailbox rules within 1 h of sign-in</text>
          <rect x="365" y="150" width="345" height="64" rx="8" fill="#ecfdf5" stroke="#166534" strokeWidth="1.5" />
          <text x="537" y="171" fill="#166534">DEFEND: FIDO2 / passkeys · token protection · CAE · app-consent policy</text>
          <text x="537" y="190" fill="#475569" fontWeight="400">SMS/TOTP MFA does NOT stop AiTM — plan accordingly</text>
        </g>
        <text x="360" y="236" textAnchor="middle" fontSize="11" fill="#64748b">AiTM defeats "MFA enabled" as a control statement — verify phishing-resistant MFA coverage instead</text>
      </svg>
    </Figure>
    <h4>8.8 ★ NEW · Domain-database forensics: NTDS.dit, tickets, and attack paths</h4>
    <p>
      The DC's database is the adversary's objective and the investigator's crime scene. <b>NTDS.dit</b> acquisition
      runs offline: <span className="mono text-sm">ntdsutil "ac i ntds" "ifm" "create full"</span> (IFM snapshots) or a
      VSC copy of NTDS.dit + SYSTEM hive (for the bootkey) — never parse on the live DC. Post-DCSync, compare
      extracted hashes against the SIEM's 4662 timeline to bound the theft window. <b>Silver Tickets</b> (forged
      service tickets) betray themselves: TGS presented with <i>no preceding TGT request</i> (missing 4768), RC4
      encryption on AES-capable accounts, and odd lifetimes. <b>Golden Tickets</b> (forged TGTs) show krbtgt
      usernames with absurd validity (default MITREForge-style 10 years vs. the domain's 10 hours). Hunt{" "}
      <b>4769 ticket-lifetime anomalies</b> fleet-wide — legitimate lifetimes cluster; forgeries stand alone.
      Defensively, map exposure <i>before</i> the incident with <b>BloodHound/SharpHound</b> (attack paths to Tier-0)
      and <b>PingCastle</b> (hygiene score + stale privileged accounts): every path you prune is a lateral-movement
      chapter the adversary never gets to write.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="Bash / PowerShell — NTDS acquisition + defensive AD audit"
        code={`# On a DC (forensic copy, then analyze OFFLINE with SYSTEM hive for bootkey)\nntdsutil "ac i ntds" "ifm" "create full c:\\temp\\ifm" q q\n# Defensive: attack-path + hygiene audit (run quarterly, trend the score)\nPingCastle.exe --healthcheck --server dc01.lab.local\n# Hunt: 4769 service tickets with anomalous lifetimes (group by TicketOptions/Lifetime)\n# legitimate ~10 h cluster vs. forged outliers — investigate every outlier`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 8.1 · AD attack hunt (90 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>From a DC Security export, build per-account 4769 counts; convict or clear the Kerberoast suspect.</li>
      <li>Screen 4662 for non-DC replication; screen 4771 for spray patterns; write the identity verdict.</li>
      <li>Map every finding to Fig. 13 and to the eviction steps in Ch. 13 §13.2.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 8.2 · Web + mail + SSH campaign (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Trace one campaign across all three logs: phish delivery → webshell POSTs → SSH pivot.</li>
      <li>Resolve every transient IP via the provided DHCP lease history; name the responsible MACs.</li>
      <li>Deliver the cross-service timeline: 12+ events, UTC, one row per hop with log citation.</li>
    </ol>
  </>
);

export const ch08: Chapter = {
  id: "ch8",
  num: 8,
  title: "Core Infrastructure Services Forensics (AD, DNS, DHCP, Mail, Web, SSH)",
  subtitle: "Identity attacks · DNS hunts · DHCP attribution · Web shells · Mail delivery · SSH pivots",
  badge: "Tier 3 · Infrastructure",
  time: "12–14 h · ~52 pages equiv.",
  outcomes:
    "Hunt Kerberoast/DCSync/AS-REP in DC logs; detect DNS tunneling and DGA; attribute IPs via DHCP; spot webshells in access logs; trace phishing end-to-end; audit SSH for pivots.",
  body,
  labTitle: "Hands-on Lab 8.1 · AD attack hunt + Lab 8.2 · Web + mail + SSH campaign",
  labsBody,
  workshop: {
    title: "Six-service triage: DC, DNS, DHCP, web, mail, and SSH in one session",
    env: ["Analyst Linux VM", "Sample log pack (6 sources)", "grep/awk/jq + Timeline Explorer"],
    tabs: [
      {
        id: "ad",
        label: "AD + DNS",
        steps: [
          {
            n: "1",
            title: "Kerberoast + DCSync screen",
            desc: "4769 volume per requester; 4662 from non-DCs. Either hit escalates the whole case.",
            code: [
              {
                title: "Bash — DC screens",
                text: `# Top service-ticket requesters (4769)\nawk -F, 'NR>1{print $3}' dc-4769.csv | sort | uniq -c | sort -rn | head\n# RC4-only requesters (crackable)\nawk -F, '$NF=="0x17"{print $3}' dc-4769.csv | sort | uniq -c | sort -rn | head\n# DCSync: 4662 where subject is not a DC account\nawk -F, 'NR>1 && $3 !~ /\\$$/ {print}' dc-4662.csv | head`,
              },
            ],
            expected: "one service account requesting 40+ RC4 tickets = roast in progress; any non-DC 4662 = SEV-1",
          },
          {
            n: "2",
            title: "DNS tunnel + DGA screen",
            desc: "TXT/NULL volume, label entropy, NXDOMAIN-per-client — the tunnel triad.",
            code: [
              {
                title: "Bash — DNS screens",
                text: `awk '$6 ~ /TXT|NULL/ {print $4, $7}' query.log | sort | uniq -c | sort -rn | head\nawk '$9=="NXDOMAIN" {print $4}' query.log | sort | uniq -c | sort -rn | head`,
              },
            ],
          },
        ],
      },
      {
        id: "webmail",
        label: "Web + mail",
        steps: [
          {
            n: "3",
            title: "Webshell + scan screen",
            desc: "POST-200s to odd paths, then the 404 sweep that preceded them.",
            code: [
              {
                title: "Bash — web screens",
                text: `awk '$6=="POST" && $9==200 {print $1, $7}' access.log | sort | uniq -c | sort -rn | head\nawk '$9==404 {print $1}' access.log | sort | uniq -c | sort -rn | head`,
              },
            ],
          },
          {
            n: "4",
            title: "Phish delivery trace",
            desc: "Message-ID → recipient → verdict → click: the delivery chain must be unbroken.",
            code: [
              {
                title: "Bash — mail trace",
                text: `grep "MID-88412" mail-tracking.log\n# envelope vs header From + auth verdicts\nawk '/MID-88412/ {print $5, $9, $12, $15}' mail-tracking.log`,
              },
            ],
            expected: "spoofed header-From + SPF fail + delivered + clicked = successful phish, pivot to endpoint",
          },
        ],
      },
      {
        id: "ssh",
        label: "SSH + DHCP",
        steps: [
          {
            n: "5",
            title: "SSH pivot screen + IP attribution",
            desc: "Accepted-from-first-seen is the pivot; DHCP leases name the device behind the IP.",
            code: [
              {
                title: "Bash — SSH + DHCP join",
                text: `grep "Accepted" auth.log | awk '{print $1, $2, $3, $(NF-3), $NF}' | tail -n 20\n# attribute the suspect IP at the suspect hour\ngrep "10.4.17.88" dhcpd.leases | tail -n 5`,
              },
            ],
          },
          {
            n: "6",
            title: "Fuse the campaign timeline",
            note: "Deliverable: six screens + DHCP attributions + fused UTC timeline naming every hop's log source. This timeline is the input to Ch. 9 network corroboration.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> AD artifacts (§8.1) · DNS shapes (§8.2) · web/mail/SSH (§§8.4–8.6) → packet/flow proof (Ch.
        9) → SIEM correlation (Ch. 11). Deliverable: a six-source fused timeline with attributions.
      </>
    ),
  },
  quiz: [
    { q: "A single account requesting 50 RC4 service tickets (4769, 0x17) indicates:", o: ["Normal Outlook use", "Likely Kerberoasting", "DNS failure", "Patching"], a: 1, e: "Bulk RC4 SPN-ticket requests are the roast signature." },
    { q: "Event 4662 from a non-DC workstation account means:", o: ["Routine browsing", "Possible DCSync — treat as SEV-1 until cleared", "Printer install", "VPN connect"], a: 1, e: "Only DCs should trigger replication-access DS events." },
    { q: "High-volume TXT queries with long encoded labels suggest:", o: ["Windows Update", "DNS tunneling/exfiltration", "Email delivery", "DHCP renewal"], a: 1, e: "Data rides in labels of unusual query types." },
    { q: "DHCP lease history is forensically essential because it:", o: ["Encrypts traffic", "Binds transient IPs to MAC/hostname over time", "Blocks malware", "Patches servers"], a: 1, e: "Without leases, dynamic IPs in old timelines are unattributable." },
    { q: "POST 200s to /assets/logo.php at 03:00 most likely indicate:", o: ["Image optimization", "Webshell interaction", "SEO crawl", "Backup"], a: 1, e: "Code execution under a static-asset path at attacker hours." },
    { q: "An 'Accepted publickey' for an unknown fingerprint should trigger:", o: ["Nothing", "authorized_keys audit — possible planted key", "Password reset only", "DNS flush"], a: 1, e: "Unknown trusted keys are SSH persistence until proven otherwise." },
  ],
};
