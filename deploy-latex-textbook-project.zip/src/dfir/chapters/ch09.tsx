import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>9.1 Packet analysis fundamentals: Wireshark and tshark</h4>
    <p>
      Packet capture (PCAP) is ground truth for the wire: full frames with nanosecond timestamps, filterable by{" "}
      <b>display filters</b> (<span className="mono text-sm">dns.qry.name contains "ru" and dns.flags.response == 0</span>){" "}
      and dissectable to field level. <b>Wireshark</b> provides interactive decode, conversation statistics, and TLS
      decryption with supplied keys; <b>tshark</b> provides the scriptable twin for bulk extraction (
      <span className="mono text-sm">-T fields -e dns.qry.name</span>). Capture hygiene matters: record interface,
      snaplen, filter, and hash at capture time; prefer TAPs over SPAN where fidelity is legally relevant (Ch. 10);
      and never analyze malware PCAPs on a routed host.
    </p>
    <h4>9.2 Network metadata with Zeek: conn, dns, http, ssl</h4>
    <p>
      Full PCAP is too bulky for months of retention; <b>Zeek</b> distills traffic into compact, queryable transaction
      logs. <b>conn.log</b> records every flow (endpoints, ports, proto, service guess, duration, byte counts, state
      history) — the flow backbone every other log joins. <b>dns.log</b> records queries/responses with TTLs and
      answer counts. <b>http.log</b> records methods, URIs, User-Agents, and status codes. <b>ssl.log/x509.log</b>{" "}
      record handshake parameters and certificate chains. Join key: <b>uid</b> (per-connection ID) plus timestamps —
      Zeek's equivalent of Sysmon's ProcessGuid discipline.
    </p>
    <DataTable
      head={["Zeek log", "Records", "Signature DFIR uses"]}
      rows={[
        ["conn.log", "5-tuple + duration + bytes + history flags", "Beacon intervals, data volumes, rare ports/services"],
        ["dns.log", "query + qtype + answers + TTL", "Tunnels, DGA, fast-flux, C2 domains"],
        ["http.log", "method + URI + UA + status + lengths", "Webshell POSTs, staged downloads, scan sweeps"],
        ["ssl.log", "version + cipher + SNI + JA3/JA4", "Malware TLS clients, cert anomalies, SNI lies"],
        ["x509.log", "cert subject/issuer/validity/SAN", "Self-signed C2 certs, short-lived impostors"],
        ["files.log / weird.log", "Transferred files / protocol anomalies", "Payload hashes, Heartbleed-style violations"],
      ]}
    />
    <h4>9.3 Command-and-control detection: beacons and jitter</h4>
    <p>
      Implants phone home on <b>beacon schedules</b> — fixed sleep intervals plus <b>jitter</b> (randomized skew to
      defeat naive periodicity detectors). Detection therefore measures <i>regularity under noise</i> (Fig. 15):
      inter-arrival-time distributions with low variance relative to mean, small symmetric byte counts (tasking
      check-ins), and persistence across days. Contrast human traffic: bursty, diurnal, heavy-tailed. Practical
      screens: per-(src,dst,port) connection counts with interval medians, byte symmetry ratios, and long-duration
      low-byte flows — then pivot the surviving candidates to endpoint process data (Ch. 6).
    </p>
    <Figure
      id="fig-beacon"
      label="Fig. 15 · C2 beacon anatomy vs. human traffic (vector)"
      caption={
        <>
          <b>Fig. 15.</b> Beacons are metronomes with jitter: tight interval clustering and small symmetric payloads.
          Human browsing is bursty and diurnal. Hunt the metronomes, then identify the owning process via Sysmon EID
          3 / Zeek uid joins.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="Beacon pattern">
        <text x="20" y="24" fontSize="11" fontWeight="800" fill="#be123c">C2 BEACON · 60 s sleep + 15% jitter · 400 B ⇄</text>
        <g stroke="#be123c" strokeWidth="3">
          {[40, 100, 158, 222, 280, 342, 400, 462, 520, 582, 640].map((x, i) => (
            <line key={i} x1={x} y1={34} x2={x} y2={86} />
          ))}
        </g>
        <line x1="20" y1="88" x2="700" y2="88" stroke="#94a3b8" strokeWidth="1" />
        <g fontSize="10" fill="#64748b" fontWeight="700">
          <text x="40" y="102">t+0</text><text x="222" y="102">t+180 s</text><text x="400" y="102">t+360 s</text><text x="582" y="102">t+540 s</text>
        </g>
        <text x="20" y="130" fontSize="11" fontWeight="800" fill="#0e7490">HUMAN BROWSING · bursty · diurnal · heavy-tailed</text>
        <g stroke="#0e7490" strokeWidth="3">
          <line x1="50" y1={140} x2={50} y2={120} /><line x1="58" y1={140} x2={58} y2={104} /><line x1="66" y1={140} x2={66} y2={126} />
          <line x1="230" y1={140} x2={230} y2={98} /><line x1="238" y1={140} x2={238} y2={130} />
          <line x1="470" y1={140} x2={470} y2={110} /><line x1="480" y1={140} x2={480} y2={88} /><line x1="489" y1={140} x2={489} y2={122} /><line x1="500" y1={140} x2={500} y2={132} />
          <line x1="660" y1={140} x2={660} y2={118} />
        </g>
        <line x1="20" y1="142" x2="700" y2="142" stroke="#94a3b8" strokeWidth="1" />
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="20" y="160" width="330" height="56" rx="8" fill="#fef2f2" stroke="#be123c" strokeWidth="1.5" />
          <text x="185" y="181" fill="#be123c">BEACON METRICS → hunt</text>
          <text x="185" y="198" fill="#475569" fontWeight="400" fontSize="10">interval CV &lt; 0.3 · bytes symmetric · 24×7 persistence</text>
          <rect x="370" y="160" width="330" height="56" rx="8" fill="#ecfeff" stroke="#0e7490" strokeWidth="1.5" />
          <text x="535" y="181" fill="#0e7490">HUMAN METRICS → baseline</text>
          <text x="535" y="198" fill="#475569" fontWeight="400" fontSize="10">bursts + nights silent · bytes asymmetric (down ≫ up)</text>
        </g>
        <text x="360" y="236" textAnchor="middle" fontSize="11" fill="#64748b">Beware: cloud sync and updaters beacon too — always resolve the owning process before verdict</text>
      </svg>
    </Figure>
    <h4>9.4 DNS exploitation analysis: tunnels, exfil, DGA</h4>
    <p>
      On the wire, DNS abuse shows in <b>query type, label shape, and volume</b>. Tunnels favor TXT/NULL/CNAME with
      long, high-entropy labels and steady cadence; exfiltration adds <i>outbound answer asymmetry</i> (many queries,
      tiny responses). <b>DGA</b> shows as NXDOMAIN storms: one client burning through dozens of algorithmic names
      until a hit. <b>Fast-flux</b> shows as single domains resolving to large, churning, low-TTL answer sets across
      ASNs. Zeek dns.log answers all three quantitatively — query counts per client, entropy distributions, and
      answer-set cardinality — without full-packet storage.
    </p>
    <h4>9.5 Encrypted traffic forensics: JA3/JA4 and certificates</h4>
    <p>
      TLS hides content but not <b>handshake behavior</b>. <b>JA3/JA4 fingerprints</b> hash the ClientHello's version,
      cipher list, extensions, and curves into a client identifier: malware families reuse distinctive stacks that
      differ from browsers, so rare JA3s on a host inventory are immediate leads. Complementary signals: <b>SNI vs.
      certificate vs. destination mismatches</b> (domain fronting / SNI lies), self-signed or short-validity C2 certs
      in x509.log, and <b>TLS version/cipher downgrades</b>. Limitation to respect: JA3 collides across tools and
      breaks under GREASE/randomization — treat it as a pivot, corroborated by timing, endpoints, and process data.
    </p>
    <DataTable
      head={["Encrypted-traffic signal", "Zeek source", "Interpretation"]}
      rows={[
        ["Rare JA3/JA4 for the host role", "ssl.log ja3/ja4", "Non-browser TLS stack — malware, tooling, or updater; identify process"],
        ["SNI ≠ cert CN/SAN", "ssl.log + x509.log", "SNI lie / fronting; inspect destination + cert history"],
        ["Self-signed + long-lived flow", "x509.log + conn.log", "C2-grade cert hygiene; check first-seen + beacon metrics"],
        ["TLS 1.0/weak cipher, 2026", "ssl.log version/cipher", "Legacy malware stack or downgrade; rare = suspicious"],
      ]}
    />
    <h4>9.6 Host-to-network synchronization</h4>
    <p>
      Attribution closes when host and network clocks agree: Sysmon EID 3's (process, 5-tuple, UTC) must match Zeek
      conn.log's (uid, 5-tuple, ts) within milliseconds. Prerequisites are unglamorous but decisive: <b>NTP discipline
      on all sensors and hosts</b> (verify offsets before fusion — a 7-minute DC skew once "cleared" a real
      intrusion), <b>UTC everywhere</b>, and <b>documented capture latency</b> (SPAN queuing, sensor clock notes).
      Standard join: Zeek conn.log uid → endpoint IP:port:time → Sysmon EID 3 ProcessGuid → EID 1 parent chain. That
      four-hop join is the evidentiary spine of every C2 finding in this book.
    </p>
    <Callout color="cyan">
      <b>Fusion rule.</b> A network-only C2 verdict is a hypothesis; a host-only verdict is a suspicion. The finding
      exists only where beacon metrics (network) meet owning-process identity (host) on synchronized clocks.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — tshark + Zeek triage one-liners"
        code={`# Top talkers + rare ports (tshark on capture.pcap)\ntshark -r capture.pcap -T fields -e ip.src -e tcp.dstport | sort | uniq -c | sort -rn | head\n# DNS query names + types, NXDOMAIN-heavy clients\ntshark -r capture.pcap -Y dns.flags.response==0 -T fields -e ip.src -e dns.qry.name -e dns.qry.type | head -n 40\n# Zeek: beacon candidates — high-count, low-byte, long-lived flows\ncat conn.log | zeek-cut id.orig_h id.resp_h id.resp_p duration orig_bytes resp_bytes missed_bytes \\\n | awk '$4>300 && $5<5000' | sort | uniq -c | sort -rn | head\n# Zeek: rare JA3s\ncat ssl.log | zeek-cut id.orig_h ja3 SNI | sort | uniq -c | sort -n | head`}
      />
    </div>
    <h4>9.7 ★ NEW · Enterprise capture, intel, and the DoH problem</h4>
    <p>
      Mature programs layer four capture tiers (table below). The <b>Zeek Intel Framework</b> operationalizes threat
      intel on the wire: feed it indicators (from MISP, Ch. 12) and every sighting lands in <b>intel.log</b> with
      source and context — IoC matching at line rate without SIEM round-trips. <b>Arkime (Moloch)</b> indexes
      full-packet capture for analyst drill-down: session Metadata (SPI) for hunting, one click to the packets for
      proof — deploy it where TAPs already exist (Ch. 10). <b>NetFlow/IPFIX</b> (SiLK, nfdump, ElastiFlow) keeps
      months of flow history cheaply enough for beacon-interval analysis long after PCAP aged out. For payload
      recovery, <b>tcpflow / NetworkMiner / Wireshark export-objects</b> carve transferred files from captures for
      hashing and detonation.
    </p>
    <DataTable
      head={["Tier", "Retains", "Answers (months later?)"]}
      rows={[
        ["Full PCAP / Arkime", "Every byte, hours–days", "Exact payloads, exfil content, court-grade proof"],
        ["Zeek logs + intel.log", "Transactions + IoC hits, months", "Who talked to what, when, how much"],
        ["NetFlow / IPFIX", "5-tuple + bytes, 6–12 mo", "Beacon history, lateral paths, volume anomalies"],
        ["Alert summaries", "Verdicts only, years", "That something fired — never why"],
      ]}
    />
    <p>
      <b>DNS-over-HTTPS/TLS (DoH/DoT)</b> encrypts the resolver channel this book leans on: endpoints speaking DoH to
      public resolvers bypass enterprise DNS logging entirely — a sanctioned blind spot attackers also use for C2.
      Counter with layered visibility: <b>Sysmon EID 22</b> (sees queries pre-encryption on the host), SNI monitoring
      for known-DoH endpoints, endpoint DNS policy (managed resolvers / DNS filtering agents), and proxy TLS
      inspection only where legally cleared. On that last point: <b>break-and-inspect TLS interception</b> carries
      privacy, legal, and trust costs (and breaks certificate pinning) — prefer endpoint + metadata visibility, and
      intercept only with documented legal basis, narrow scope, and user notice.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 9.1 · PCAP intrusion autopsy (90 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Profile the capture: duration, top talkers, protocol mix, DNS query inventory.</li>
      <li>Isolate the C2 channel: beacon metrics + DNS evidence + JA3/SNI analysis.</li>
      <li>Extract the payload artifacts (files.log / export objects) and hash them for the IoC package.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 9.2 · Zeek hunt + host fusion (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Run the beacon, DGA, and rare-JA3 screens across a day of Zeek logs; rank candidates.</li>
      <li>Fuse the top candidate to Sysmon EID 3/1; name the owning process and parent chain.</li>
      <li>Deliver the C2 finding: network proof + host proof + clock-sync attestation.</li>
    </ol>
  </>
);

export const ch09: Chapter = {
  id: "ch9",
  num: 9,
  title: "Network Forensics, Flow Analysis, and Zeek Telemetry",
  subtitle: "Wireshark/tshark · Zeek logs · Beacon hunting · DNS abuse · JA3/JA4 · Host fusion",
  badge: "Tier 3 · Network forensics",
  time: "10–12 h · ~44 pages equiv.",
  outcomes:
    "Dissect PCAPs with display filters; exploit all six Zeek logs; quantify beacons; detect tunnels/DGA/flux; fingerprint TLS clients; fuse network and host evidence on synced clocks.",
  body,
  labTitle: "Hands-on Lab 9.1 · PCAP intrusion autopsy + Lab 9.2 · Zeek hunt + host fusion",
  labsBody,
  workshop: {
    title: "Wire-to-host pipeline: PCAP to Zeek to Sysmon fusion",
    env: ["Security Onion / Zeek VM", "Sample intrusion PCAP", "tshark + zeek-cut + jq"],
    tabs: [
      {
        id: "pcap",
        label: "PCAP profile",
        steps: [
          {
            n: "1",
            title: "Profile before diving",
            desc: "Capture statistics first: time span, endpoints, protocols. Never start by reading packets.",
            code: [
              {
                title: "Bash — capinfos + conversations",
                text: `capinfos capture.pcap | grep -E "Duration|packets|Data size"\ntshark -r capture.pcap -q -z conv,ip | head -n 25\ntshark -r capture.pcap -q -z dns,tree | head -n 30`,
              },
            ],
          },
          {
            n: "2",
            title: "Extract DNS + HTTP inventories",
            desc: "Query names and URIs are the fastest route to the malicious thread.",
            code: [
              {
                title: "Bash — inventories",
                text: `tshark -r capture.pcap -Y "dns.flags.response==0" -T fields -e dns.qry.name | sort | uniq -c | sort -rn | head -n 25\ntshark -r capture.pcap -Y http.request -T fields -e ip.src -e http.request.method -e http.request.uri | head -n 25`,
              },
            ],
          },
        ],
      },
      {
        id: "zeek",
        label: "Zeek hunt",
        steps: [
          {
            n: "3",
            title: "Generate Zeek logs from the PCAP",
            desc: "Local Zeek turns any capture into the six-log hunting surface.",
            code: [
              {
                title: "Bash — zeek on PCAP",
                text: `mkdir -p zeek-out && cd zeek-out\nzeek -r ../capture.pcap\nls -la *.log | awk '{print $9, $5}'`,
              },
            ],
          },
          {
            n: "4",
            title: "Run the beacon + JA3 screens",
            desc: "Fig. 15 metrics in one pipeline: persistence, symmetry, rarity.",
            code: [
              {
                title: "Bash — beacon + JA3",
                text: `cat conn.log | zeek-cut id.orig_h id.resp_h id.resp_p duration orig_bytes resp_bytes | awk '$4>300' | sort | uniq -c | sort -rn | head\ncat ssl.log | zeek-cut id.orig_h ja3 SNI | sort | uniq -c | sort -n | head\ncat dns.log | zeek-cut id.orig_h query qtype_name answers | grep -E "TXT|NULL" | head`,
              },
            ],
            expected: "one internal host → one external IP:443, 300 s+ flows, small symmetric bytes, rare JA3",
          },
        ],
      },
      {
        id: "fuse",
        label: "Fuse to host",
        steps: [
          {
            n: "5",
            title: "Join Zeek uid to Sysmon",
            desc: "5-tuple + timestamp (±2 s) → EID 3 → ProcessGuid → EID 1 parent chain.",
            code: [
              {
                title: "Bash — fusion join sketch",
                text: `# 1) candidate flow: 10.4.17.88:51xxx -> 45.9.148.7:443 @ 02:14:33Z (conn.log uid C8...)\n# 2) Sysmon EID 3 same 5-tuple/time -> ProcessGuid {A1..}\n# 3) EID 1 Guid {A1..}: svc.exe parented by powershell -enc (WINWORD grandparent)\n# 4) verdict: C2 owned by injected svc.exe; beacon confirmed host+network`,
              },
            ],
          },
          {
            n: "6",
            title: "Attest clock sync and write the finding",
            note: "Deliverable: capture profile + Zeek screens + fused C2 finding with uid, GUIDs, beacon metrics, and NTP attestation. No fusion, no finding.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> Zeek logs (§9.2) · beacon metrics (§9.3) · JA3 (§9.5) → Suricata alerting (Ch. 10) → SIEM
        correlation (Ch. 11). Deliverable: a fused wire-to-host C2 finding package.
      </>
    ),
  },
  quiz: [
    { q: "Zeek's conn.log joins to other Zeek logs primarily via:", o: ["Filename", "uid + timestamps", "MAC address", "Username"], a: 1, e: "uid is the per-connection key across all Zeek logs." },
    { q: "Jitter in C2 beacons exists to:", o: ["Speed transfers", "Defeat naive fixed-interval detectors", "Encrypt payloads", "Compress data"], a: 1, e: "Randomized skew hides periodicity from simple thresholds." },
    { q: "A client generating 200 NXDOMAINs in 5 minutes most likely indicates:", o: ["Normal browsing", "DGA spray", "Video streaming", "Printing"], a: 1, e: "Algorithmic domains mostly fail until the live C2 resolves." },
    { q: "JA3 fingerprints identify TLS clients from:", o: ["Decrypted content", "ClientHello parameters (version, ciphers, extensions, curves)", "IP reputation", "DNS history"], a: 1, e: "Handshake behavior fingerprints the TLS stack, not the content." },
    { q: "SNI differing from the certificate's CN/SAN suggests:", o: ["Normal CDN behavior always", "Possible SNI lie/domain fronting needing investigation", "Faster TLS", "IPv6"], a: 1, e: "Mismatched handshake identity is a fronting/evasion indicator." },
    { q: "Host-network fusion REQUIRES:", o: ["Same vendor tools", "NTP-disciplined, UTC, documented clocks on sensors and hosts", "Decrypted traffic", "Physical access"], a: 1, e: "Millisecond joins collapse under clock skew." },
  ],
};
