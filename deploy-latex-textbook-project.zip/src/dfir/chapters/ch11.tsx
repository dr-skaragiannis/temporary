import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>11.1 Agent deployment topologies</h4>
    <p>
      SIEM value equals endpoint coverage times log quality. <b>Elastic Agent / Beats</b> (Winlogbeat for .evtx/Sysmon,
      Filebeat for web/syslog files, Packetbeat for flows), <b>Wazuh agents</b> (FIM + rootkit + inventory with a
      manager tier), and <b>Splunk Universal Forwarders</b> all follow the same placement doctrine: <b>every DC, every
      server, every endpoint</b> — no "low-risk" exceptions, because attackers specifically seek unmonitored hosts.
      Manage agents centrally (Fleet, Wazuh manager, Deployment Server), monitor agent health as its own SLA
      (silent agents are blind hosts), and pin versions: parser drift between agent releases silently breaks
      correlations.
    </p>
    <DataTable
      head={["Asset class", "Agent + inputs", "Non-negotiable logs"]}
      rows={[
        ["Domain Controllers", "Winlogbeat/UF + Sysmon", "Security 4768/69/71, 4662, 4624/25; Sysmon EID 1/10"],
        ["Windows endpoints/servers", "Elastic Agent + Sysmon", "Sysmon full, Security, PowerShell 4104, RDP channels"],
        ["Linux fleet", "Filebeat + auditd", "auth.log VERBOSE, auditd execve, sudo, cron"],
        ["Network/security appliances", "Syslog over TLS (agentless)", "FW allows/denies, VPN auth, proxy URIs, DNS"],
        ["Web/mail infrastructure", "Filebeat + API shippers", "Access/error, tracking logs, SEG verdicts"],
      ]}
    />
    <h4>11.2 Data normalization: ECS and Splunk CIM</h4>
    <p>
      Correlation requires a <b>common schema</b>: <b>Elastic Common Schema (ECS)</b> maps every source's user, host,
      IP, process, and file fields to canonical names (<span className="mono text-sm">user.name</span>,{" "}
      <span className="mono text-sm">process.parent.name</span>, <span className="mono text-sm">destination.ip</span>);
      <b> Splunk CIM</b> does the same via data models (Authentication, Network_Traffic, Endpoint_Processes). The
      forensic payoff: one query hunts across Windows, Linux, firewall, and proxy simultaneously. Operational cost:
      every unmapped field is unhuntable — monitor <b>parse-failure and unmapped-field rates</b> per source as a
      pipeline KPI, and version every ingest pipeline in Git.
    </p>
    <h4>11.3 Cross-source correlation: the four-hop chain</h4>
    <p>
      Campaigns reveal themselves only in joins. The canonical enterprise chain (Fig. 17) — <i>external firewall
      allow → web access POST → Sysmon process launch → DNS beacon</i> — links four independent sensors to one
      intrusion thread via time windows and shared entities (IP, host, user). Correlation rules encode these joins
      with <b>sequence + time-bound + entity-match</b> semantics ("same src_ip, then same host, within 30 min");
      thresholds keep them affordable. Design principle: <b>alert on chains, hunt on links</b> — single-link rules
      belong in hunting notebooks, multi-link chains earn paging.
    </p>
    <Figure
      id="fig-corr-chain"
      label="Fig. 17 · Canonical four-hop correlation chain (vector)"
      caption={
        <>
          <b>Fig. 17.</b> Four sensors, one story. Each hop shares an entity (IP → host → process → domain) within a
          30-minute window. Missing any single sensor breaks the chain — which is why Ch. 8–10 coverage is a
          prerequisite, not an accessory.
        </>
      }
    >
      <svg viewBox="0 0 720 240" className="w-full h-auto" role="img" aria-label="Correlation chain">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="50" width="160" height="110" rx="10" fill="#be123c" />
          <text x="90" y="72" fill="#fff">HOP 1 · FIREWALL</text>
          <text x="90" y="89" fill="#ffe4e6" fontWeight="400" fontSize="10">ALLOW 45.9.148.7</text>
          <text x="90" y="105" fill="#ffe4e6" fontWeight="400" fontSize="10">→ web-srv:443</text>
          <text x="90" y="125" fill="#fff" fontSize="9">entity: src_ip</text>
          <text x="90" y="141" fill="#ffe4e6" fontSize="9">t+0 min</text>
          <rect x="190" y="50" width="160" height="110" rx="10" fill="#b45309" />
          <text x="270" y="72" fill="#fff">HOP 2 · WEB LOG</text>
          <text x="270" y="89" fill="#fef3c7" fontWeight="400" fontSize="10">POST /assets/x.php</text>
          <text x="270" y="105" fill="#fef3c7" fontWeight="400" fontSize="10">200 · same src_ip</text>
          <text x="270" y="125" fill="#fff" fontSize="9">entity: src_ip+host</text>
          <text x="270" y="141" fill="#fef3c7" fontSize="9">t+4 min</text>
          <rect x="370" y="50" width="160" height="110" rx="10" fill="#0e7490" />
          <text x="450" y="72" fill="#fff">HOP 3 · SYSMON</text>
          <text x="450" y="89" fill="#e0f2fe" fontWeight="400" fontSize="10">EID 1: w3wp →</text>
          <text x="450" y="105" fill="#e0f2fe" fontWeight="400" fontSize="10">powershell -enc</text>
          <text x="450" y="125" fill="#fff" fontSize="9">entity: host+proc</text>
          <text x="450" y="141" fill="#e0f2fe" fontSize="9">t+6 min</text>
          <rect x="550" y="50" width="160" height="110" rx="10" fill="#166534" />
          <text x="630" y="72" fill="#fff">HOP 4 · DNS</text>
          <text x="630" y="89" fill="#dcfce7" fontWeight="400" fontSize="10">TXT cdn-x7.ru</text>
          <text x="630" y="105" fill="#dcfce7" fontWeight="400" fontSize="10">60 s beacon</text>
          <text x="630" y="125" fill="#fff" fontSize="9">entity: host+domain</text>
          <text x="630" y="141" fill="#dcfce7" fontSize="9">t+11 min</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="105" x2="186" y2="105" markerEnd="url(#dfir-a1)" />
          <line x1="350" y1="105" x2="366" y2="105" markerEnd="url(#dfir-a1)" />
          <line x1="530" y1="105" x2="546" y2="105" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="180" y="95" textAnchor="middle" fontSize="9" fontWeight="800" fill="#0f1c2e" className="fig-halo">same IP</text>
        <text x="360" y="95" textAnchor="middle" fontSize="9" fontWeight="800" fill="#0f1c2e" className="fig-halo">same host</text>
        <text x="540" y="95" textAnchor="middle" fontSize="9" fontWeight="800" fill="#0f1c2e" className="fig-halo">same host</text>
        <text x="360" y="185" textAnchor="middle" fontSize="11" fill="#64748b">Rule logic: sequence(H1→H2→H3→H4) ∧ entity-match ∧ window ≤ 30 min → page Tier 2</text>
        <text x="360" y="205" textAnchor="middle" fontSize="11" fontWeight="700" fill="#be123c">Any single hop alone = hunt lead · all four = incident</text>
      </svg>
    </Figure>
    <h4>11.4 Analytical query languages: KQL, SPL, Lucene</h4>
    <p>
      Hunt fluency means thinking in <b>entity × time</b> regardless of dialect. <b>KQL</b> (Elastic) filters with{" "}
      <span className="mono text-sm">field : value AND NOT ...</span> plus EQL sequences for ordered chains;{" "}
      <b>SPL</b> (Splunk) pipes <span className="mono text-sm">stats dc() by</span> aggregations with{" "}
      <span className="mono text-sm">transaction</span> for session stitching; <b>Lucene</b> underpins both plus
      OpenSearch. Learn the <i>patterns</i>, not just syntax: rare-value (first-seen per entity), volume-spike
      (count vs. baseline), join-across-sources (shared entity + window), and allowlist-subtraction (remove the known
      before judging the unknown).
    </p>
    <div className="not-serif">
      <CodeBlock
        title="KQL / EQL — the four hunt patterns (Elastic)"
        code={`// 1) rare process per host (first-seen = suspicious until proven routine)\nprocess.name : * AND NOT process.name : (svchost.exe OR explorer.exe OR chrome.exe)\n// 2) volume spike: top DNS clients by TXT queries, last 24h\nbase-query: dns.question.type : TXT | stats count by source.ip, sort desc\n// 3) EQL sequence: web POST then child process on same host within 10m\nsequence by host.name with maxspan=10m\n  [http where http.request.method == "POST" and url.path : "*.php"]\n  [process where process.parent.name == "w3wp.exe"]\n// 4) allowlist subtraction: RDP successes minus known admin sources\n(source.ip : * AND event.code : 4624 AND winlog.logon.type : 10) AND NOT source.ip : (10.1.0.0/24)`}
      />
    </div>
    <h4>11.5 Threshold &amp; anomaly detections</h4>
    <p>
      Static thresholds ("&gt; 50 failed logons") catch spray-and-pray; <b>baselined anomalies</b> ("3σ above this
      user's 30-day egress mean") catch the careful adversary. Build baselines per <i>entity class</i> (service
      accounts differ from humans; DCs differ from laptops), prefer <b>rate and ratio features</b> over raw counts
      (bytes-per-flow, NXDOMAIN ratio, off-hours fraction), and always ship a <b>business-hours/weekend split</b> —
      most "anomalies" are just Monday. Machine-learning jobs (rare-process, unusual-login-time) supplement but never
      replace explainable rules: every ML alert needs a one-line human-readable reason, or Tier 1 will ignore it.
    </p>
    <DataTable
      head={["Detection", "Type", "Baseline entity", "Why it works"]}
      rows={[
        ["Off-hours admin logon", "Threshold + time", "Per admin account", "Attackers work while defenders sleep"],
        ["Rare process per host role", "First-seen", "Per host role (DC/web/laptop)", "Novelty on stable fleets is precious"],
        ["Egress bytes 3σ spike", "Statistical", "Per host, 30-day", "Exfil moves bulk; ratios beat counts"],
        ["Impossible travel", "Velocity", "Per user", "Humans cannot cross oceans in minutes"],
        ["New service + first C2", "Sequence (Fig. 17)", "Per host", "Chains defeat single-signal evasion"],
      ]}
    />
    <h4>11.6 SOC triage dashboards</h4>
    <p>
      Dashboards are <b>decision instruments</b>, not wall art. Tier 1 needs three views: <b>queue health</b> (alerts
      by severity/age, SLA burn-down), <b>service health</b> (agent coverage %, pipeline lag seconds, parse-failure
      %, per-source EPS vs. baseline), and <b>threat overview</b> (top attacker IPs/domains/hashes with pivots to
      raw events). Design rules: every panel links to its underlying query, every number shows its baseline
      comparison, and red means <i>act now</i> — decorative red trains analysts to ignore red.
    </p>
    <Callout color="amber">
      <b>Coverage honesty.</b> Publish the agent-coverage % and pipeline-lag on the SOC wall. An alert for an
      unmonitored host range is impossible — leadership must see the blind fraction every single day.
    </Callout>
    <h4>11.7 ★ NEW · SOAR, honest metrics, and the ECS core</h4>
    <p>
      <b>SOAR</b> (orchestration + automation + response) multiplies analysts when layered correctly: <b>L0</b> notify
      (page with context), <b>L1</b> enrich-and-ticket (auto-attach VirusTotal, WHOIS, asset owner, related alerts),{" "}
      <b>L2</b> contain-on-approval (one-click isolate/block from the ticket), <b>L3</b> auto-contain narrow,
      reversible scopes only (phish-URL block, attachment detonation hold) — always with a kill-switch and full audit
      trail. Rule: <i>automate enrichment first, action last</i>; every auto-action needs a blast-radius cap and a
      human override faster than the damage. Measure what matters: <b>MTTD/MTTR/MTTC</b> (detect/respond/contain),
      alert precision (% true positive — below 20% breeds ignore-everything culture), coverage %, pipeline lag, and
      detection debt from Ch. 12. Beware perverse incentives: MTTR drops when analysts close tickets faster, not
      better — pair every speed metric with a quality metric (reopen rate, escaped-dwell sampling).
    </p>
    <DataTable
      head={["ECS field", "Holds", "Why hunters live here"]}
      rows={[
        ["@timestamp", "Event time (UTC, normalized)", "Every join and window keys on it"],
        ["host.name / host.id", "Endpoint identity", "Pivot: IP → host → user → process"],
        ["user.name", "Normalized account", "Cross-source account timelines (AD + cloud + VPN)"],
        ["source.ip / destination.ip", "Flow endpoints", "Beacon, spray, and exfil screens"],
        ["process.name / process.parent.name", "Execution + parentage", "LotL and injection hunts (Ch. 6)"],
        ["file.path + file.hash.sha256", "File identity", "Allowlist subtraction + malware pivots"],
        ["dns.question.name / url.full", "Requested names", "C2, tunnel, and phish-kit hunts"],
        ["event.action / event.code / rule.name", "What + which detection", "Precision measurement per rule"],
      ]}
    />
    <p>
      A syntax honesty note for §11.4's patterns: <b>KQL</b> filters, <b>ES|QL</b> aggregates (
      <span className="mono text-sm">FROM logs-* | WHERE … | STATS count BY source.ip</span>), and <b>EQL</b> sequences
      join on a <i>single key per sequence</i> — multi-entity chains like Fig. 17 are built from nested sequences or
      entity-pivot queries, not a one-liner. Learn all three shapes; production rules almost always need EQL or
      ES|QL, not bare KQL. Defender shops get the same patterns in <b>Advanced Hunting (KQL)</b> over Device* tables —
      the query below is the §12.2 Sigma rule's cloud-native twin.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="KQL — Advanced Hunting: encoded PowerShell from Office (M365 Defender)"
        code={`DeviceProcessEvents\n| where Timestamp > ago(1d)\n| where FileName =~ "powershell.exe" and ProcessCommandLine has_any ("-enc", "FromBase64String")\n| where InitiatingProcessFileName in~ ("winword.exe", "excel.exe")\n| project Timestamp, DeviceName, InitiatingProcessFileName, FileName, ProcessCommandLine`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 11.1 · Agent deployment plan (60 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Given a 500-host network map, place agents/collectors per §11.1; justify every exception (there should be none).</li>
      <li>Specify the ECS/CIM field map for three custom sources; define parse-failure alerts.</li>
      <li>Write the agent-health SLA: silence threshold, upgrade policy, and coverage report.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 11.2 · Correlation hunt (90 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Execute the four hunt patterns (§11.4) against a day of lab SIEM data; rank all hits.</li>
      <li>Build the Fig. 17 chain for the top campaign; document each hop's query + evidence.</li>
      <li>Convert the chain into a correlation rule with window, entities, and threshold; estimate FP rate.</li>
    </ol>
  </>
);

export const ch11: Chapter = {
  id: "ch11",
  num: 11,
  title: "Enterprise SIEM Architecture, Agent Deployment, and Correlation",
  subtitle: "Agents · ECS/CIM · Four-hop chains · KQL/SPL · Baselines · Dashboards",
  badge: "Tier 4 · SIEM + correlation",
  time: "10–12 h · ~44 pages equiv.",
  outcomes:
    "Deploy full-coverage agent estates; normalize to ECS/CIM; write cross-source sequence rules; hunt fluently in KQL/SPL; baseline anomaly detections; design decision-grade dashboards.",
  body,
  labTitle: "Hands-on Lab 11.1 · Agent deployment plan + Lab 11.2 · Correlation hunt",
  labsBody,
  workshop: {
    title: "Correlation engineering: from hunt queries to paging rules",
    env: ["Elastic/OpenSearch lab", "Day of multi-source data", "Kibana + alerting"],
    tabs: [
      {
        id: "hunt",
        label: "Hunt queries",
        steps: [
          {
            n: "1",
            title: "Run the rare + spike screens",
            desc: "First-seen processes and TXT-volume spikes surface the campaign's edges.",
            code: [
              {
                title: "KQL — rare + spike",
                text: `// rare child of web server (last 24h)\nprocess.parent.name : w3wp.exe\n// TXT volume by client\n(dns.question.type : TXT) | top source.ip by count`,
              },
            ],
          },
          {
            n: "2",
            title: "Pivot by shared entity",
            desc: "One suspicious IP → all its events → the host set → their processes. Entities, not alerts.",
            code: [
              {
                title: "KQL — entity pivot",
                text: `source.ip : 45.9.148.7 OR destination.ip : 45.9.148.7\n// then: which hosts? which users? which processes? (aggregate each)`,
              },
            ],
          },
        ],
      },
      {
        id: "chain",
        label: "Build the chain",
        steps: [
          {
            n: "3",
            title: "Assemble the four hops in EQL",
            desc: "Sequence with entity joins and a 30-minute maxspan — Fig. 17 as executable logic.",
            code: [
              {
                title: "EQL — four-hop chain",
                text: `sequence by source.ip, host.name with maxspan=30m\n  [network where event.action == "allowed" and destination.port == 443]\n  [http where http.request.method == "POST"]\n  [process where process.parent.name == "w3wp.exe"]\n  [dns where dns.question.type == "TXT"]`,
              },
            ],
            expected: "one sequence result binding firewall → web → process → DNS to a single campaign",
          },
        ],
      },
      {
        id: "rule",
        label: "Rule + dashboard",
        steps: [
          {
            n: "4",
            title: "Promote the chain to an alert",
            desc: "Threshold 1 chain/30 min pages Tier 2; attach runbook + entity pivots to the alert.",
            code: [
              {
                title: "Alert spec (pseudocode)",
                text: `name: WEB-TO-C2-CHAIN\nseverity: high | window: 30m | threshold: >=1 chain\nentities: source.ip, host.name, user.name\nactions: page Tier2 + open ticket + attach EQL + link dashboard\ntuning-review: 14 days (FP check)`,
              },
            ],
          },
          {
            n: "5",
            title: "Dashboard the inputs",
            note: "Deliverable: hunt queries + EQL chain + alert spec + dashboard panels for queue, coverage, and threat overview. Every panel links to its query.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> agents (§11.1) · normalization (§11.2) · chains (§11.3) → Detection-as-Code (Ch. 12) →
        containment triggers (Ch. 13). Deliverable: a production-grade correlation rule with provenance.
      </>
    ),
  },
  quiz: [
    { q: "The agent-placement doctrine is:", o: ["DCs only", "Every DC, server, and endpoint — no exceptions", "Laptops only", "Only during incidents"], a: 1, e: "Attackers seek unmonitored hosts; exceptions become targets." },
    { q: "ECS/CIM normalization exists so that:", o: ["Logs look pretty", "One query hunts across heterogeneous sources via canonical fields", "Disks fill slower", "Agents run faster"], a: 1, e: "Common schema = cross-source correlation becomes possible." },
    { q: "The canonical four-hop chain joins sensors via:", o: ["Random sampling", "Shared entities (IP/host/user) within a time window", "Alphabetical order", "File size"], a: 1, e: "Entity-match + sequence + window = campaign, not coincidence." },
    { q: "Alert-on-chains, hunt-on-links means:", o: ["Never hunt", "Multi-link sequences earn paging; single signals stay in notebooks", "Page on everything", "Delete single-signal data"], a: 1, e: "Paging precision comes from corroborated chains." },
    { q: "Anomaly baselines should be computed per:", o: ["Whole planet", "Entity class (role/account/host type)", "Vendor", "Alphabet"], a: 1, e: "Service accounts, DCs, and laptops have incomparable normals." },
    { q: "A SOC coverage metric belongs on the wall because:", o: ["It looks technical", "Leadership must see the unmonitorable blind fraction daily", "Auditors like colors", "It replaces analysts"], a: 1, e: "Honest coverage drives budget; hidden gaps drive breaches." },
  ],
};
