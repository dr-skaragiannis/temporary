import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>2.1 RFC 3227 order of volatility</h4>
    <p>
      <b>RFC 3227</b> orders evidence by perishability: collect the most ephemeral first (Fig. 3). CPU registers,
      cache, and routing tables vanish in nanoseconds; <b>RAM</b> (process state, keys, injected code) survives only
      while powered; swap, disk, and finally archival logs persist longest. The operational consequence is a
      collection sequence — <i>memory → system state → disk → logs</i> — that this book repeats in every live-response
      chapter. Shutting down a host before RAM capture permanently forfeits everything above the disk line, which is
      precisely where fileless tradecraft (Ch. 7) hides.
    </p>
    <Figure
      id="fig-volatility"
      label="Fig. 3 · Order of volatility pyramid (RFC 3227, vector)"
      caption={
        <>
          <b>Fig. 3.</b> Collect top-down: registers/cache first, archival media last. The dashed line marks the
          power boundary — everything above it is lost on shutdown. Timeouts in minutes annotate typical enterprise
          triage budgets.
        </>
      }
    >
      <svg viewBox="0 0 720 300" className="w-full h-auto" role="img" aria-label="Order of volatility">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <polygon points="360,12 470,70 250,70" fill="#be123c" />
          <text x="360" y="48" fill="#fff" fontSize="10">REGISTERS · CACHE</text>
          <polygon points="250,70 470,70 510,112 210,112" fill="#b45309" />
          <text x="360" y="98" fill="#fff">RAM · PROCESS STATE · KEYS</text>
          <polygon points="210,112 510,112 550,154 170,154" fill="#0e7490" />
          <text x="360" y="140" fill="#fff">NETWORK STATE · SWAP · HANDLES</text>
          <polygon points="170,154 550,154 590,196 130,196" fill="#7c3aed" />
          <text x="360" y="182" fill="#fff">DISK · MFT · REGISTRY · VSC</text>
          <polygon points="130,196 590,196 630,238 90,238" fill="#166534" />
          <text x="360" y="224" fill="#fff">LOGS · SIEM · BACKUPS · ARCHIVE</text>
        </g>
        <line x1="60" y1="154" x2="660" y2="154" stroke="#0f1c2e" strokeWidth="2" strokeDasharray="8 5" />
        <text x="360" y="146" textAnchor="middle" fontSize="10" fontWeight="800" fill="#0f1c2e" className="fig-halo">— POWER / REBOOT BOUNDARY —</text>
        <g fontSize="10" fontWeight="700" fill="#64748b" textAnchor="start">
          <text x="478" y="55">seconds</text>
          <text x="516" y="98">minutes</text>
          <text x="556" y="140">minutes–hours</text>
          <text x="596" y="182">days–years</text>
          <text x="60" y="224">years</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="40" y1="250" x2="40" y2="40" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="24" y="150" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e" className="fig-halo" transform="rotate(-90 24 150)">COLLECT FIRST ↑</text>
        <text x="360" y="268" textAnchor="middle" fontSize="11" fill="#64748b">Fig. 3 · RFC 3227 collection order; fileless tradecraft lives above the power boundary</text>
      </svg>
    </Figure>
    <h4>2.2 Write-blocking technology</h4>
    <p>
      Forensic imaging must not alter the source. <b>Hardware write-blockers</b> (Tableau, WiebeTech) sit on the bus
      between suspect media and the examiner workstation, intercepting and refusing write-class commands (ATA
      WRITE DMA, SCSI WRITE) at firmware level while passing reads. <b>Software write-blocking</b> (Linux{" "}
      <span className="mono text-sm">blockdev --setro</span>, Windows registry USB write-protect,{" "}
      <span className="mono text-sm">mount -o ro,loop</span>) is cheaper but weaker: kernel bugs or examiner error can
      still issue writes, so it is acceptable for triage but not for evidence destined for court. The verification
      ritual is identical either way: hash the source <i>before and after</i> imaging and confirm equality.
    </p>
    <DataTable
      head={["Method", "Mechanism", "Strength", "Use when"]}
      rows={[
        ["Hardware blocker", "Firmware drops write opcodes on the bus", "Court-grade; OS-independent", "Seized media; any case that may litigate"],
        ["Linux read-only blockdev", "Kernel marks device read-only", "Good for triage", "Dead-box lab imaging with hash verification"],
        ["Windows USB write-protect", "Registry StorageDevicePolicies", "Weak; bypassable", "Never for evidence; transport convenience only"],
        ["Forensic live distro (PALADIN/CAINE)", "Auto-mounts read-only by default", "Good", "Field preview before full acquisition"],
      ]}
    />
    <h4>2.3 Bit-stream disk acquisition: dd, E01, AFF</h4>
    <p>
      A <b>bit-stream (physical) image</b> copies every sector — allocated files, slack, unallocated space, and
      partition gaps — unlike logical copies that capture only live files. <b>Raw (dd)</b> images are simple
      sector-for-sector streams: universally readable but metadata-poor. <b>Expert Witness (E01)</b> wraps compressed
      sectors with case metadata, per-chunk CRCs, and an MD5/SHA-1 of the whole image, and remains the interchange
      standard. <b>Advanced Forensic Format (AFF)</b> offers segmented, extensible storage with strong provenance
      metadata. Size rule: provision destination capacity at least 1.2× source for raw, and always image <i>to</i> a
      wiped, hashed destination drive.
    </p>
    <h4>2.4 Cryptographic verification: MD5, SHA-1, SHA-256</h4>
    <p>
      Hashing proves <b>integrity</b> (the image equals the source) and <b>immutability</b> (the image never changed
      afterward). Legacy practice paired <b>MD5 + SHA-1</b> because E01 tooling computed both; both are now broken for
      collision resistance, though still useful for file <i>identification</i> (NSRL lookups). Modern acquisition
      anchors on <b>SHA-256</b>: hash the source device, hash the image, compare; re-hash on every access and log the
      result (Fig. 4). A single mismatched nibble invalidates the exhibit — there is no "close enough" in evidence
      integrity.
    </p>
    <Figure
      id="fig-hash-chain"
      label="Fig. 4 · Acquisition integrity chain (vector)"
      caption={
        <>
          <b>Fig. 4.</b> The four-hash ritual. Source and image hashes must match at acquisition; working-copy hashes
          must match on every subsequent access. Mismatch at any gate quarantines the exhibit.
        </>
      }
    >
      <svg viewBox="0 0 720 170" className="w-full h-auto" role="img" aria-label="Hash verification chain">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="150" height="80" rx="10" fill="#0f1c2e" />
          <text x="85" y="66" fill="#fbbf24">1 · HASH SOURCE</text>
          <text x="85" y="84" fill="#cbd5e1" fontWeight="400" fontSize="10">sha256(/dev/sdb)</text>
          <text x="85" y="100" fill="#cbd5e1" fontWeight="400" fontSize="10">write-blocked</text>
          <rect x="190" y="40" width="150" height="80" rx="10" fill="#0e7490" />
          <text x="265" y="66" fill="#fff">2 · IMAGE</text>
          <text x="265" y="84" fill="#e0f2fe" fontWeight="400" fontSize="10">dc3dd / E01</text>
          <text x="265" y="100" fill="#e0f2fe" fontWeight="400" fontSize="10">+ per-chunk CRC</text>
          <rect x="370" y="40" width="150" height="80" rx="10" fill="#b45309" />
          <text x="445" y="66" fill="#fff">3 · HASH IMAGE</text>
          <text x="445" y="84" fill="#fef3c7" fontWeight="400" fontSize="10">compare ≡ gate 1</text>
          <text x="445" y="100" fill="#fef3c7" fontWeight="400" fontSize="10">mismatch → redo</text>
          <rect x="550" y="40" width="160" height="80" rx="10" fill="#166534" />
          <text x="630" y="66" fill="#fff">4 · WORKING COPY</text>
          <text x="630" y="84" fill="#dcfce7" fontWeight="400" fontSize="10">analyze the copy</text>
          <text x="630" y="100" fill="#dcfce7" fontWeight="400" fontSize="10">re-hash each open</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="160" y1="80" x2="186" y2="80" markerEnd="url(#dfir-a1)" />
          <line x1="340" y1="80" x2="366" y2="80" markerEnd="url(#dfir-a1)" />
          <line x1="520" y1="80" x2="546" y2="80" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="145" textAnchor="middle" fontSize="11" fill="#64748b">Golden rule: original is sealed after gate 3 — all analysis touches working copies only</text>
      </svg>
    </Figure>
    <h4>2.5 Chain of custody tracking</h4>
    <p>
      Following <b>ISO/IEC 27037</b>, each exhibit carries an intake record: unique ID, description, source system,
      collector identity, date-time (UTC), acquisition method and tool versions, hashes, and storage location. Every
      subsequent handler signs the item out and back in with purpose and timestamps; transport uses tamper-evident
      bags and encrypted containers. Digitally, the register from Workshop 1 plus signed hash logs forms the custody
      spine. Audit yourself with one question: <i>could a stranger reconstruct unbroken possession from seizure to
      courtroom using only these records?</i>
    </p>
    <h4>2.6 Live vs. dead-box acquisition</h4>
    <p>
      <b>Dead-box</b> (powered-off, remove media, image via blocker) maximizes disk integrity and is preferred when
      volatile state is expendable or the host is already off. <b>Live acquisition</b> (capture RAM and system state
      from the running host, then disk) preserves volatile evidence at the cost of small, documented footprint changes
      — acceptable under RFC 3227 when justified and logged. Decision rule: if the host is <b>on and the case involves
      intrusion, encryption keys, or fileless tradecraft → go live first</b> (Ch. 7); if it is off, keep it off and go
      dead-box. Never "just boot it to take a look" — a boot writes thousands of artifacts over evidence.
    </p>
    <Callout color="rose">
      <b>Cardinal sin.</b> Booting a suspect drive in its native OS, browsing files on original media, or imaging
      without write protection each independently compromise admissibility. When in doubt, photograph the screen,
      pull network (not power, if live capture is planned), and call the forensic lead.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — forensically sound dd acquisition with dual hashing"
        code={`# Identify source (NEVER guess): list, then confirm serial/size
lsblk -o NAME,SIZE,SERIAL,MODEL
sudo blockdev --setro /dev/sdb   # software RO (triage-grade)

# Acquire with progress + on-the-fly hashing
sudo dc3dd if=/dev/sdb of=/mnt/evidence/case041-sdb.dd hash=sha256 log=/mnt/evidence/case041-sdb.log

# Independently verify: re-hash source and image, compare
sudo sha256sum /dev/sdb | tee /mnt/evidence/source.sha256
sha256sum /mnt/evidence/case041-sdb.dd | tee /mnt/evidence/image.sha256
diff <(cut -d' ' -f1 /mnt/evidence/source.sha256) <(cut -d' ' -f1 /mnt/evidence/image.sha256) && echo MATCH`}
      />
    </div>
    <h4>2.7 ★ NEW · Encryption, SSDs, and virtual disks: acquisition edge cases</h4>
    <p>
      Three realities complicate textbook imaging. <b>Full-disk encryption</b> (BitLocker, FileVault, LUKS): a powered-off
      encrypted drive is cryptographically sealed — so a <i>running</i> encrypted host is a gift, not a problem. Before
      any shutdown, capture RAM (keys live in memory, Ch. 7), record <span className="mono text-sm">manage-bde -status</span>{" "}
      output and recovery-key escrow (AD/MDM), and image the <i>unlocked</i> volume live. Shutting down first and asking
      for the PIN later is how evidence becomes a brick. <b>SSDs and TRIM</b>: garbage collection permanently erases
      deleted blocks, often within minutes — deleted-file recovery that works on spinning disks silently fails on SSDs.
      Image fast, record TRIM status (<span className="mono text-sm">fsutil behavior query DisableDeleteNotify</span>),
      and never promise deleted-data recovery on flash without attempting it first. <b>Virtual disks</b> (VMDK/VHDX):
      snapshot first, then copy base + delta files together and hash both; hypervisor-level memory files (.vmem) give
      the lowest-footprint RAM capture available (Ch. 7).
    </p>
    <h4>2.8 ★ NEW · Similarity hashing, carving, and the seizure ritual</h4>
    <p>
      Cryptographic hashes prove identity; <b>similarity hashes</b> (ssdeep, TLSH) measure <i>resemblance</i> — the
      malware-variant problem ("is this sample related to last month's dropper?"). A ssdeep score around 70+ warrants
      manual comparison; lower scores suggest unrelated code. Similarity never convicts alone — it prioritizes
      reverse-engineering queues. <b>File carving</b> recovers files from unallocated space by header/footer signatures
      (JPEG <span className="mono text-sm">FF D8 … FF D9</span>, PDF <span className="mono text-sm">%PDF … %%EOF</span>):
      verify type with <span className="mono text-sm">file</span> (magic bytes beat extensions — adversaries rename),
      then carve with foremost/photorec/scalpel, expecting fragmentation losses on large files.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="Bash — similarity, identification, and carving triage"
        code={`ssdeep -b new-sample.bin > new.ssdeep && ssdeep -m known-bad.ssdeep new.ssdeep  # variant match?\nfile -b suspect.xlsx                      # magic bytes vs extension (zip? OLE? exe?)\nforemost -t jpg,pdf,exe -i case041-sdb.dd -o carve-out/   # carve working copy only`}
      />
    </div>
    <p>
      Physical seizure follows a ritual: <b>photograph</b> the scene and screen before touching anything; decide{" "}
      <b>power</b> (on + intrusion/encryption → live-capture per Ch. 7; off → keep off); bag mobile devices in{" "}
      <b>Faraday</b> enclosures to block remote wipe; <b>label</b> every item (ID, date, collector, plus a port/cable
      map for multi-drive systems); and open the custody record <i>at the scene</i>, not back at the lab. The scene is
      the one place evidence is created or destroyed in seconds — slowness there is professionalism.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 2.1 · USB imaging drill (60 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Prepare a sacrificial USB with known files; record its serial and size from <span className="mono text-xs">lsblk</span>.</li>
      <li>Image it with <span className="mono text-xs">dc3dd</span> to a wiped destination; capture the tool log.</li>
      <li>Independently hash source and image; demonstrate MATCH and file both hashes plus the log in the register.</li>
      <li>Mount the image read-only via loop device and carve one deleted file to prove bit-stream completeness.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 2.2 · E01 + custody package (45 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Acquire the same media to E01 with case metadata (<span className="mono text-xs">ewfacquire</span>); verify with <span className="mono text-xs">ewfverify</span>.</li>
      <li>Complete the full custody form: intake, hashes, storage, and two mock transfer signatures.</li>
      <li>Write a 1-page acquisition report a prosecutor could read: method, tools/versions, hashes, deviations.</li>
    </ol>
  </>
);

export const ch02: Chapter = {
  id: "ch2",
  num: 2,
  title: "Evidence Handling, Acquisition, and Chain of Custody",
  subtitle: "RFC 3227 volatility · Write-blockers · dd/E01/AFF · Hash verification · Custody · Live vs. dead-box",
  badge: "Foundations · Evidence integrity",
  time: "7–9 h · ~34 pages equiv.",
  outcomes:
    "Sequence collection by volatility; select blocking and imaging methods; prove integrity with hashes; maintain ISO 27037 custody; choose live vs. dead-box acquisition correctly.",
  body,
  labTitle: "Hands-on Lab 2.1 · USB imaging drill + Lab 2.2 · E01 + custody package",
  labsBody,
  workshop: {
    title: "Forensic imaging pipeline: block, acquire, hash, verify",
    env: ["Linux examiner VM", "dc3dd + ewf-tools", "Sacrificial USB media"],
    tabs: [
      {
        id: "prep",
        label: "Prepare + block",
        steps: [
          {
            n: "1",
            title: "Identify and freeze the source",
            desc: "Positive identification by serial/size prevents imaging the examiner drive by mistake.",
            code: [
              {
                title: "Bash — identify source",
                text: `lsblk -o NAME,SIZE,SERIAL,MODEL\nread -p "source device (e.g. /dev/sdb): " SRC; echo "SOURCE=$SRC" | tee /mnt/evidence/source.id\nsudo blockdev --setro "$SRC" && echo "read-only flag set"`,
              },
            ],
          },
          {
            n: "2",
            title: "Wipe and hash the destination",
            desc: "A clean destination with a known-zero baseline proves no cross-case contamination.",
            code: [
              {
                title: "Bash — destination hygiene",
                text: `sudo dd if=/dev/zero of=/mnt/evidence/case041-sdb.dd bs=1M count=1 conv=fsync 2>/dev/null\nrm /mnt/evidence/case041-sdb.dd\ndf -h /mnt/evidence   # confirm free space >= 1.2x source`,
              },
            ],
          },
        ],
      },
      {
        id: "acquire",
        label: "Acquire + hash",
        steps: [
          {
            n: "3",
            title: "Acquire with dc3dd and SHA-256",
            desc: "dc3dd hashes during acquisition and writes a court-friendly log.",
            code: [
              {
                title: "Bash — acquire",
                text: `sudo dc3dd if="$SRC" of=/mnt/evidence/case041-sdb.dd hash=sha256 log=/mnt/evidence/case041-sdb.log\ntail -n 5 /mnt/evidence/case041-sdb.log`,
              },
            ],
            expected: "log footer shows matching input/output hash lines and sector counts",
          },
          {
            n: "4",
            title: "Independent verification hashes",
            desc: "A second tool re-hashes both sides; the acquisition tool never grades its own homework.",
            code: [
              {
                title: "Bash — verify",
                text: `sudo sha256sum "$SRC" | tee /mnt/evidence/source.sha256\nsha256sum /mnt/evidence/case041-sdb.dd | tee /mnt/evidence/image.sha256\ndiff <(cut -d' ' -f1 /mnt/evidence/source.sha256) <(cut -d' ' -f1 /mnt/evidence/image.sha256) && echo "INTEGRITY MATCH"`,
              },
            ],
            expected: "INTEGRITY MATCH",
          },
        ],
      },
      {
        id: "e01",
        label: "E01 + custody",
        steps: [
          {
            n: "5",
            title: "Produce the E01 exchange copy",
            desc: "E01 embeds case metadata and per-sector CRCs for handoff to other examiners.",
            code: [
              {
                title: "Bash — E01",
                text: `sudo ewfacquire -t /mnt/evidence/case041-sdb -d sha256 -c best -C CASE-041 -e "K. Osei" -N "FIN-WS-114 USB" "$SRC"\newfverify /mnt/evidence/case041-sdb.E01`,
              },
            ],
            expected: "ewfverify: SUCCESS — hash sections match",
          },
          {
            n: "6",
            title: "Register the exhibit",
            desc: "Custody entries reference hash files, never bare hash strings alone.",
            note: "Deliverable: .dd + .E01 + .log + both .sha256 files + register.csv row + custody form, all in the case directory.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> volatility order (§2.1) · blockers (§2.2) · formats (§2.3) · hash ritual (§2.4) → live RAM
        capture (Ch 7). Deliverable: verified image set with a complete custody package.
      </>
    ),
  },
  quiz: [
    { q: "Per RFC 3227, the FIRST evidence to collect from a running host is:", o: ["Archival backup tapes", "Registers, cache, and RAM", "Disk image", "Printed firewall rules"], a: 1, e: "Most volatile first — registers/cache/RAM vanish fastest." },
    { q: "Hardware write-blockers work by:", o: ["Encrypting the suspect drive", "Refusing write-class opcodes at firmware/bus level", "Deleting malware on contact", "Speeding up imaging"], a: 1, e: "They pass reads and drop writes independent of the host OS." },
    { q: "A bit-stream image is superior to a logical copy because it captures:", o: ["Only filenames", "Every sector including slack and unallocated space", "Only the registry", "Only encrypted files"], a: 1, e: "Deleted and hidden data lives outside allocated files." },
    { q: "Modern acquisition integrity should anchor on:", o: ["MD5 alone", "SHA-1 alone", "SHA-256 (MD5/SHA-1 legacy only)", "CRC32"], a: 2, e: "MD5/SHA-1 are collision-broken; SHA-256 is the current anchor." },
    { q: "A host involved in an active intrusion is powered ON. Correct first move:", o: ["Pull power immediately", "Boot into BIOS", "Live-capture RAM and state before any shutdown", "Browse files to assess"], a: 2, e: "Volatile evidence dies on shutdown; capture it first, with logging." },
    { q: "Under ISO/IEC 27037, every exhibit record must include:", o: ["Adversary attribution", "Unique ID, source, collector, UTC time, method, hashes, storage", "Malware family name", "Insurance policy number"], a: 1, e: "Custody = identity + provenance + integrity + possession, gap-free." },
  ],
};
