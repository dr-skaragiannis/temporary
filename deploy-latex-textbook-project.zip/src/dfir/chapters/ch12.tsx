import { Callout, CodeBlock, DataTable, Figure, type Chapter } from "../ui";

const body = (
  <>
    <h4>12.1 Detection as Code (DaC)</h4>
    <p>
      <b>Detection as Code</b> treats every detection like software: versioned in Git, peer-reviewed, unit-tested
      against sample events, deployed through CI/CD, and deprecated on schedule. The payoff is forensic-grade
      provenance — <i>which rule version fired, authored from which incident, tested against what</i> — and safe
      change velocity: no more Friday-afternoon SIEM edits that page the SOC all weekend. Repository layout mirrors
      the lifecycle (Fig. 18): <span className="mono text-sm">detections/</span> (Sigma/YAML sources),{" "}
      <span className="mono text-sm">tests/</span> (positive/negative event fixtures),{" "}
      <span className="mono text-sm">deploy/</span> (transpiled per-platform queries), and{" "}
      <span className="mono text-sm">docs/</span> (runbooks linked from every alert).
    </p>
    <Figure
      id="fig-dac-pipe"
      label="Fig. 18 · Detection-as-Code lifecycle (vector)"
      caption={
        <>
          <b>Fig. 18.</b> Detections are software: incidents and intel become Sigma, CI transpiles and tests, deploy
          is staged, tuning feeds back to source. No step is optional — untested rules are unshipped rules.
        </>
      }
    >
      <svg viewBox="0 0 720 220" className="w-full h-auto" role="img" aria-label="Detection pipeline">
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="50" width="120" height="90" rx="8" fill="#0f1c2e" />
          <text x="70" y="72" fill="#fbbf24">1 · AUTHOR</text>
          <text x="70" y="88" fill="#cbd5e1" fontWeight="400">Sigma YAML</text>
          <text x="70" y="103" fill="#cbd5e1" fontWeight="400">+ runbook</text>
          <text x="70" y="122" fill="#fbbf24" fontSize="9">from incident/intel</text>
          <rect x="148" y="50" width="120" height="90" rx="8" fill="#0e7490" />
          <text x="208" y="72" fill="#fff">2 · TEST</text>
          <text x="208" y="88" fill="#e0f2fe" fontWeight="400">fixtures ±</text>
          <text x="208" y="103" fill="#e0f2fe" fontWeight="400">atomic replay</text>
          <text x="208" y="122" fill="#fef08a" fontSize="9">CI must pass</text>
          <rect x="286" y="50" width="120" height="90" rx="8" fill="#b45309" />
          <text x="346" y="72" fill="#fff">3 · TRANSPILE</text>
          <text x="346" y="88" fill="#fef3c7" fontWeight="400">pySigma →</text>
          <text x="346" y="103" fill="#fef3c7" fontWeight="400">SPL/KQL/etc.</text>
          <text x="346" y="122" fill="#fff" fontSize="9">per platform</text>
          <rect x="424" y="50" width="120" height="90" rx="8" fill="#166534" />
          <text x="484" y="72" fill="#fff">4 · DEPLOY</text>
          <text x="484" y="88" fill="#dcfce7" fontWeight="400">stage → canary</text>
          <text x="484" y="103" fill="#dcfce7" fontWeight="400">→ production</text>
          <text x="484" y="122" fill="#fff" fontSize="9">rollback ready</text>
          <rect x="562" y="50" width="148" height="90" rx="8" fill="#7c3aed" />
          <text x="636" y="72" fill="#fff">5 · TUNE / RETIRE</text>
          <text x="636" y="88" fill="#ede9fe" fontWeight="400">FP review 14/90 d</text>
          <text x="636" y="103" fill="#ede9fe" fontWeight="400">deprecate stale</text>
          <text x="636" y="122" fill="#fff" fontSize="9">feeds back to 1</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="130" y1="95" x2="144" y2="95" markerEnd="url(#dfir-a1)" />
          <line x1="268" y1="95" x2="282" y2="95" markerEnd="url(#dfir-a1)" />
          <line x1="406" y1="95" x2="420" y2="95" markerEnd="url(#dfir-a1)" />
          <line x1="544" y1="95" x2="558" y2="95" markerEnd="url(#dfir-a1)" />
        </g>
        <g stroke="#64748b" strokeWidth="2" fill="none">
          <polyline points="636,140 636,170 70,170 70,144" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="192" textAnchor="middle" fontSize="11" fill="#64748b">Tuning feedback: FP analysis and emulation results rewrite the Sigma source — never the deployed query alone</text>
      </svg>
    </Figure>
    <h4>12.2 Sigma rule architecture</h4>
    <p>
      <b>Sigma</b> is the vendor-agnostic detection interchange format: one YAML rule transpiles to Splunk, Elastic,
      QRadar, and 40+ backends. Anatomy: <b>title/id/status/author/date</b> (identity + lifecycle),{" "}
      <b>logsource</b> (product/service/category — the routing contract), <b>detection</b> (named{" "}
      <span className="mono text-sm">selection</span> blocks plus a <span className="mono text-sm">condition</span>{" "}
      combining them), <b>falsepositives</b> (documented, honest), <b>level</b> (severity), and{" "}
      <b>tags</b> (ATT&amp;CK technique IDs binding detection to threat model). Quality bar: every rule names its
      ATT&amp;CK technique, its tested log source, and its known FPs — rules missing any of the three fail review.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="YAML — Sigma: encoded PowerShell via WinWord parent (T1059.001 + T1566.001)"
        code={`title: Encoded PowerShell Spawned by Office App\nid: dfir-2026-0041\nstatus: experimental\nauthor: SOC Detection Eng.\ndate: 2026/09/26\nlogsource:\n  product: windows\n  service: sysmon\n  definition: 'EventID 1 required (Sysmon)'\ndetection:\n  selection_parent:\n    ParentImage|endswith:\n      - '\\WINWORD.EXE'\n      - '\\EXCEL.EXE'\n  selection_encoded:\n    CommandLine|contains:\n      - ' -enc '\n      - ' -EncodedCommand '\n      - 'FromBase64String'\n  condition: selection_parent and selection_encoded\nfalsepositives:\n  - Developer macros invoking encoded helpers (rare; allowlist by hash)\nlevel: high\ntags:\n  - attack.execution\n  - attack.t1059.001\n  - attack.t1566.001`}
      />
    </div>
    <h4>12.3 Rule transpilation via pySigma</h4>
    <p>
      <b>pySigma</b> compiles generic rules into native queries through backend plugins (
      <span className="mono text-sm">pySigma-backend-splunk</span>, <span className="mono text-sm">-elasticsearch</span>,{" "}
      <span className="mono text-sm">-qradar</span>) plus <b>processing pipelines</b> that adapt field names to local
      schemas (e.g., ECS vs. CIM mappings from Ch. 11). CI runs every rule through every deployed backend on each
      commit: transpile errors fail the build, and rendered queries are diffed so reviewers see exactly what ships.
      Golden rule: <mark className="hl">engineers edit Sigma; machines edit SPL/KQL</mark> — hand-edited deployed
      queries drift from source within weeks and become undebuggable.
    </p>
    <h4>12.4 MISP platform operations</h4>
    <p>
      <b>MISP</b> (Malware Information Sharing Platform) is the open CTI hub: <b>events</b> bundle <b>attributes</b>{" "}
      (IoCs: hashes, IPs, domains, YARA, Sigma) with <b>objects</b> (structured file/URL/vulnerability records),{" "}
      <b>galaxies</b> (threat-actor, tool, TTP clusters), and <b>tags</b> (TLP, confidence, ATT&amp;CK). DFIR workflows:
      publish incident-derived attributes with sightings, correlate new alerts against stored attributes
      automatically, and sync selectively with trusted communities (sector ISACs). Hygiene: expire IoCs (30/90-day
      defaults per type), record <b>first-seen/last-seen + sightings</b>, and never ingest a feed you have not
      measured for FP rate — MISP amplifies both signal and noise.
    </p>
    <DataTable
      head={["MISP construct", "Holds", "DFIR use"]}
      rows={[
        ["Event", "One incident/campaign bundle", "Case-041: all attributes + galaxies + reports in one place"],
        ["Attribute", "Single IoC (type+value+context)", "Auto-correlate SIEM hits; push to blocklists by type"],
        ["Galaxy/Cluster", "Actor/tool/TTP knowledge", "Tag events with APT/tool; pivot to related campaigns"],
        ["Sighting", "Observed-in-the-wild confirmation", "Weight attributes by confirmation; expire the unseen"],
        ["Sharing group + TLP", "Distribution boundary", "Enforce need-to-know; TLP:RED stays inside"],
      ]}
    />
    <h4>12.5 Automated threat enrichment: STIX/TAXII feeds</h4>
    <p>
      <b>STIX 2.1</b> (structured objects: indicators, malware, relationships) over <b>TAXII 2.1</b> (collection
      polling/push) automates intel flow from producers into MISP and SIEM. Enrichment architecture: TAXII pollers
      ingest into MISP → correlation + expiration policies curate → export jobs push SIEM-ready lists (high-confidence
      block, medium-confidence alert, low-confidence hunt-only). The critical control is <b>feedback</b>: sightings
      and FP reports flow back to producers, and locally-derived intel (case-041's C2 domain within the hour) outranks
      any commercial feed in both freshness and relevance.
    </p>
    <h4>12.6 Adversary emulation testing: Atomic Red Team</h4>
    <p>
      Detections prove themselves only against <b>executed adversary behavior</b>. <b>Atomic Red Team</b> provides
      small, mapped, cross-platform test "atomics" per ATT&amp;CK technique — execute T1059.001's encoded-PowerShell
      atomic, confirm the Sigma rule fires end-to-end (telemetry → SIEM → alert → ticket), then clean up. CI
      integration runs atomics nightly in a sacrificial lab: <b>detection coverage becomes a measured metric</b>{" "}
      (% techniques with passing end-to-end tests), and every new rule ships with its proving atomic. Safety: atomics
      run in isolated VMs on snapshots, scheduled off-hours, with lab-only credentials — emulation that escapes
      containment is an incident, not a test.
    </p>
    <Callout color="violet">
      <b>Coverage metric (adopt it).</b> <i>Detection coverage = techniques with passing end-to-end emulation tests ÷
      techniques in your threat profile.</i> Report it monthly; every incident must raise it or explain why it could
      not.
    </Callout>
    <h4>12.7 ★ NEW · YARA: content hunting for files and memory</h4>
    <p>
      Where Sigma queries <i>events</i>, <b>YARA</b> queries <i>content</i> — files at rest and bytes in memory. Rule
      anatomy (Fig. 23) is three blocks: <b>meta</b> (name, description, author, date, TLP, ATT&amp;CK reference),{" "}
      <b>strings</b> (text with <span className="mono text-sm">nocase wide ascii</span>, hex{" "}
      <span className="mono text-sm">{`{ 4D 5A 90 }`}</span>, regex, plus <span className="mono text-sm">private</span>{" "}
      helper strings), and <b>condition</b> (Boolean logic: <span className="mono text-sm">any of them</span>,{" "}
      <span className="mono text-sm">2 of ($a*)</span>, <span className="mono text-sm">$mz at 0</span>,{" "}
      <span className="mono text-sm">filesize &lt; 5MB</span>). Scan disk images and mounts with{" "}
      <span className="mono text-sm">yara -r</span>, memory with Volatility's{" "}
      <span className="mono text-sm">vadyarascan</span>, and fleets with sweepers (LOKI/THOR-style). Manage rules like
      Sigma: version in Git, test against benign + malicious corpora, measure FP rate, and exchange via MISP objects.
      Beginner trap: over-broad strings (single common API names) match half the OS — anchor on rare constants,
      distinctive PDB paths, C2 strings, and multi-string conditions.
    </p>
    <Figure
      id="fig-yara"
      label="Fig. 23 · YARA rule anatomy pipeline (vector) ★ NEW"
      caption={
        <>
          <b>Fig. 23.</b> Meta rides along so every match explains itself; strings define the evidence; the condition
          sets the burden of proof. Matches flow to triage with rule identity attached — detections that document
          themselves.
        </>
      }
    >
      <svg viewBox="0 0 720 190" className="w-full h-auto" role="img" aria-label="YARA anatomy">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="160" height="100" rx="10" fill="#0f1c2e" />
          <text x="90" y="62" fill="#fbbf24">META</text>
          <text x="90" y="79" fill="#cbd5e1" fontWeight="400" fontSize="10">name · author</text>
          <text x="90" y="95" fill="#cbd5e1" fontWeight="400" fontSize="10">date · TLP</text>
          <text x="90" y="114" fill="#fbbf24" fontSize="9">travels with hit</text>
          <rect x="190" y="40" width="180" height="100" rx="10" fill="#0e7490" />
          <text x="280" y="62" fill="#fff">STRINGS</text>
          <text x="280" y="79" fill="#e0f2fe" fontWeight="400" fontSize="10">text / hex / regex</text>
          <text x="280" y="95" fill="#e0f2fe" fontWeight="400" fontSize="10">nocase · wide · private</text>
          <text x="280" y="114" fill="#fef08a" fontSize="9">the evidence</text>
          <rect x="390" y="40" width="160" height="100" rx="10" fill="#b45309" />
          <text x="470" y="62" fill="#fff">CONDITION</text>
          <text x="470" y="79" fill="#fef3c7" fontWeight="400" fontSize="10">any / all / N of</text>
          <text x="470" y="95" fill="#fef3c7" fontWeight="400" fontSize="10">at / in / filesize</text>
          <text x="470" y="114" fill="#fff" fontSize="9">burden of proof</text>
          <rect x="570" y="40" width="140" height="100" rx="10" fill="#166534" />
          <text x="640" y="62" fill="#fff">MATCH →</text>
          <text x="640" y="79" fill="#dcfce7" fontWeight="400" fontSize="10">rule + strings</text>
          <text x="640" y="95" fill="#dcfce7" fontWeight="400" fontSize="10">+ offsets</text>
          <text x="640" y="114" fill="#fff" fontSize="9">self-explaining</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="90" x2="186" y2="90" markerEnd="url(#dfir-a1)" />
          <line x1="370" y1="90" x2="386" y2="90" markerEnd="url(#dfir-a1)" />
          <line x1="550" y1="90" x2="566" y2="90" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="164" textAnchor="middle" fontSize="11" fill="#64748b">Test every rule against benign corpora before fleet deployment — untested YARA is a false-positive cannon</text>
      </svg>
    </Figure>
    <div className="not-serif">
      <CodeBlock
        title="YARA — macro-dropper rule + scan commands"
        code={`rule Office_Macro_Dropper {\n  meta:\n    description = "Office doc spawning encoded PowerShell patterns"\n    author = "DFIR lab"\n    date = "2026-09-26"\n    tlp = "amber"\n  strings:\n    $ps = "powershell" nocase wide ascii\n    $enc1 = "-EncodedCommand" nocase\n    $enc2 = "-enc " nocase\n    $b64 = "FromBase64String" nocase\n    $auto = "AutoOpen" nocase\n  condition:\n    $auto and 2 of ($ps, $enc1, $enc2, $b64)\n}\n\n// scan a mounted image + memory image\n// yara -r macro-dropper.yar /mnt/image/\n// vol -f mem.raw windows.vadyarascan --yara-file macro-dropper.yar`}
      />
    </div>
    <p>
      Two companion practices close the loop. <b>D3FEND mapping</b>: for every incident TTP, look up its defensive
      countermeasures in MITRE D3FEND and cite them in the report's recommendations — TTP-driven justification turns
      "buy EDR" into "T1003.001 observed → credential-hardening + LSASS protection + EID 10 alerting," which budgets
      approve. <b>Sigma aggregation</b> handles threshold logic the §12.2 rule didn't need:{" "}
      <span className="mono text-sm">condition: selection | count() by srcip &gt; 20</span> (spray),{" "}
      <span className="mono text-sm">near</span> correlations across selections, and windowed counts — the bridge from
      single-event rules to the behavioral detections of Ch. 11.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Lab 12.1 · Sigma authoring + transpile (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Author two Sigma rules from case-041 TTPs (encoded Office macro + LSASS access) with full metadata.</li>
      <li>Transpile to your lab SIEM backend via pySigma; diff and review the rendered queries.</li>
      <li>Peer-review another team's rules against the §12.2 quality bar; reject any missing ATT&amp;CK/FP/logsource.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Lab 12.2 · MISP + emulation loop (75 min)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Publish case-041 attributes to MISP with galaxies, TLP, and sightings; configure expiration.</li>
      <li>Execute matching Atomic Red Team atomics; verify end-to-end alerting for both rules.</li>
      <li>Record the coverage delta: which threat-profile techniques moved from untested to passing.</li>
    </ol>
  </>
);

export const ch12: Chapter = {
  id: "ch12",
  num: 12,
  title: "Detection Engineering, Sigma Rules, and Threat Intelligence Integration (MISP)",
  subtitle: "Detection-as-Code · Sigma · pySigma · MISP · STIX/TAXII · Atomic Red Team",
  badge: "Tier 4 · Detection engineering",
  time: "9–11 h · ~40 pages equiv.",
  outcomes:
    "Run detection lifecycles as code; author review-grade Sigma; transpile with pySigma pipelines; operate MISP events/galaxies; automate STIX/TAXII enrichment; prove rules with emulation.",
  body,
  labTitle: "Hands-on Lab 12.1 · Sigma authoring + transpile + Lab 12.2 · MISP + emulation loop",
  labsBody,
  workshop: {
    title: "Ship a detection: Sigma to alert to emulation proof",
    env: ["Detection repo (Git)", "pySigma + lab SIEM", "Atomic Red Team VM (snapshot)"],
    tabs: [
      {
        id: "author",
        label: "Author + test",
        steps: [
          {
            n: "1",
            title: "Author Sigma from the incident TTP",
            desc: "Start from the proven technique (T1059.001), not from a hash — Pyramid of Pain discipline.",
            code: [
              {
                title: "Bash — rule scaffold",
                text: `mkdir -p detections/windows/sysmon tests/fixtures\ncat > detections/windows/sysmon/office-encoded-ps.yml <<'EOF'\ntitle: Encoded PowerShell Spawned by Office App\nid: dfir-2026-0041\nstatus: experimental\nlogsource: {product: windows, service: sysmon}\ndetection:\n  selection_parent:\n    ParentImage|endswith: ['\\\\WINWORD.EXE', '\\\\EXCEL.EXE']\n  selection_encoded:\n    CommandLine|contains: [' -enc ', 'FromBase64String']\n  condition: selection_parent and selection_encoded\nlevel: high\ntags: [attack.t1059.001, attack.t1566.001]\nEOF\ngit add detections && git commit -m "add office-encoded-ps (case-041)"`,
              },
            ],
          },
          {
            n: "2",
            title: "Add positive + negative fixtures",
            desc: "Untested rules don't ship: one event that must fire, two that must not.",
            code: [
              {
                title: "Bash — fixtures",
                text: `cat > tests/fixtures/office-encoded-ps-positive.json <<'EOF'\n{"EventID": 1, "ParentImage": "C:\\\\Program Files\\\\Office\\\\WINWORD.EXE",\n "Image": "C:\\\\Windows\\\\System32\\\\WindowsPowerShell\\\\powershell.exe",\n "CommandLine": "powershell -enc UwB0AGEAcgB0AC0AUwBsAGUAZQBw"}\nEOF\ncat > tests/fixtures/office-encoded-ps-negative.json <<'EOF'\n{"EventID": 1, "ParentImage": "C:\\\\Windows\\\\explorer.exe",\n "Image": "C:\\\\Windows\\\\System32\\\\WindowsPowerShell\\\\powershell.exe",\n "CommandLine": "powershell -File .\\\\build.ps1"}\nEOF\nls tests/fixtures/`,
              },
            ],
          },
        ],
      },
      {
        id: "ship",
        label: "Transpile + deploy",
        steps: [
          {
            n: "3",
            title: "Transpile to the lab backend",
            desc: "pySigma renders the native query; reviewers inspect the diff, never hand-edit it.",
            code: [
              {
                title: "Bash — pySigma",
                text: `pip install pysigma-backend-elasticsearch 2>/dev/null | tail -n 1\nsigma convert -t elasticsearch -p ecs_windows detections/windows/sysmon/office-encoded-ps.yml \\\n  | tee deploy/office-encoded-ps.kql\ncat deploy/office-encoded-ps.kql`,
              },
            ],
            expected: "KQL/Lucene query encoding both selections ANDed, deployed to staging index first",
          },
          {
            n: "4",
            title: "Publish intel to MISP",
            desc: "Case attributes with context outlive the incident and arm the community.",
            code: [
              {
                title: "Bash — MISP event sketch (API)",
                text: `# event: case-041 phishing+C2 | TLP:AMBER\n# attributes: sha256(svc.exe), cdn-x7.ru, 45.9.148.7, YARA-office-macro\n# galaxies: tool=custom-dropper, ttp=T1566.001/T1059.001/T1071.004\n# sightings: 3 hosts | expires: 90d (domain/IP), 365d (TTP note)`,
              },
            ],
          },
        ],
      },
      {
        id: "prove",
        label: "Emulate + prove",
        steps: [
          {
            n: "5",
            title: "Execute the proving atomic",
            desc: "Atomic T1059.001 in the sacrificial VM; expect alert → ticket within the SLA.",
            code: [
              {
                title: "PowerShell — Atomic Red Team (ISOLATED VM)",
                text: `Invoke-AtomicTest T1059.001 -TestNumbers 1 -GetPrereqs\nInvoke-AtomicTest T1059.001 -TestNumbers 1\n# verify: SIEM alert office-encoded-ps fired with correct entities\nInvoke-AtomicTest T1059.001 -TestNumbers 1 -Cleanup`,
              },
            ],
            expected: "alert fires with host/user/process entities; cleanup restores the snapshot state",
          },
          {
            n: "6",
            title: "Record coverage and promote",
            note: "Deliverable: merged Sigma + fixtures + transpiled query + MISP event + passing emulation proof + coverage-delta note. Status experimental → stable only after 14 clean days.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Concept map:</b> Sigma anatomy (§12.2) · pySigma (§12.3) · MISP (§12.4) → emulation proof (§12.6) → capstone
        detections (Ch. 13). Deliverable: a shipped, proven, intelligence-linked detection.
      </>
    ),
  },
  quiz: [
    { q: "Detection as Code's core requirement is:", o: ["Expensive tools", "Versioned, tested, reviewed, CI-deployed detection lifecycle", "No documentation", "Vendor lock-in"], a: 1, e: "Detections get the full software-engineering discipline." },
    { q: "A Sigma rule's logsource block defines:", o: ["The severity", "The product/service/category routing contract", "The author", "The price"], a: 1, e: "Logsource declares which telemetry the rule requires." },
    { q: "pySigma processing pipelines adapt rules to:", o: ["Local field schemas (ECS/CIM variants)", "Weather", "CPU arch", "Screen size"], a: 0, e: "Pipelines map generic fields to each SIEM's reality." },
    { q: "MISP galaxies provide:", o: ["Encryption", "Threat-actor/tool/TTP clustering for pivots", "Backups", "VPN"], a: 1, e: "Galaxies link attributes to campaigns and tradecraft." },
    { q: "Locally-derived incident intel outranks commercial feeds in:", o: ["Volume", "Freshness and case relevance", "Price", "Color"], a: 1, e: "Your C2 domain, this hour, beats any feed's yesterday." },
    { q: "Atomic Red Team proves detections by:", o: ["Reading docs", "Executing mapped adversary behaviors and verifying end-to-end alerting", "Guessing", "Disabling logging"], a: 1, e: "Executed technique → telemetry → alert → ticket is the proof chain." },
  ],
};
