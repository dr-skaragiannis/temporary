import { DataTable } from "./ui";

export function PlaybooksAppendix() {
  return (
    <section id="playbooks" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-amber-600 dark:text-amber-400">Appendix C ★ NEW · Print for the war room</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Incident Playbooks (One-Page Each)</h2>
      <p className="text-sm text-slate-500 mt-1">Condensed from Ch. 1, 8, 11–13. Each playbook assumes the case directory, severity, and custody discipline of Ch. 1–2 are already running.</p>

      <h4 className="font-extrabold mt-4">C.1 Ransomware detonation</h4>
      <DataTable
        head={["Phase", "Actions"]}
        rows={[
          ["First 30 min", "Declare SEV-1; page commander; isolate affected segments (Fig. 19); preserve ONE host powered for forensics; photograph ransom notes; stop backups from being overwritten"],
          ["Scope (h 1–4)", "Identify variant (ID Ransomware); enumerate encrypted + beaconing hosts (EDR + sinkhole, §10.8); determine initial vector; assess data-theft (DLP/proxy/§13.7)"],
          ["Decide", "Counsel + law enforcement engaged; sanctions check; default NO-PAY with documented exceptions; start §13.8 disclosure clocks from awareness"],
          ["Eradicate + restore", "Evict per Ch. 13 (krbtgt×2 if AD touched); restore AD → backups → tools → business → endpoints; verify each tier before the next"],
          ["Report", "Technical report + executive brief + post-mortem actions; leak-site monitoring 90 days; detection-coverage delta recorded"],
        ]}
      />
      <h4 className="font-extrabold mt-4">C.2 Business email compromise / mailbox intrusion</h4>
      <DataTable
        head={["Phase", "Actions"]}
        rows={[
          ["First hour", "Force sign-out + revoke sessions; reset creds + phishing-resistant MFA review; preserve mailbox (litigation hold) BEFORE remediation deletes evidence"],
          ["Scope", "UAL: inbox rules, forwarding, eDiscovery abuse, app-consent grants; Entra/Okta sign-ins (impossible travel, AiTM markers, Fig. 22); sent-items + deleted-items review"],
          ["Contain", "Remove rules/forwards; revoke OAuth grants + refresh tokens; block attacker infrastructure (domains, IPs, transport rules); purge malicious mail tenant-wide if propagated"],
          ["Eradicate + recover", "Verify no lingering grants/rules 72 h; re-enable with CA hardening; notify recipients of attacker-sent mail per counsel"],
          ["Report", "Financial-fraud notices (bank recall windows are hours); disclosure clocks if PII exfiltrated; BEC process fix (payment-change verification)"],
        ]}
      />
      <h4 className="font-extrabold mt-4">C.3 Webshell / public-app compromise</h4>
      <DataTable
        head={["Phase", "Actions"]}
        rows={[
          ["First hour", "Snapshot + isolate web host (keep logs!); WAF emergency rule for the exploited URI; rotate app secrets/DB creds the host could read"],
          ["Scope", "Access logs: upload vector + all webshell POSTs (Ch. 8); Sysmon EID 1 children of w3wp; DB query review; lateral pivots (Ch. 5 constellations)"],
          ["Contain", "Take host out of rotation; block attacker IPs/URLs at edge + proxy; preserve image + memory for forensics"],
          ["Eradicate + recover", "Patch the exploited vector FIRST; rebuild from clean image (never 'clean' a rooted web host); redeploy with WAF + FIM; verify with rescan + hunts"],
          ["Report", "Customer-notification analysis if app data touched; root cause (patch SLA? WAF gap? input validation?) with owner + date"],
        ]}
      />
      <h4 className="font-extrabold mt-4">C.4 Insider threat (malicious or compromised-privilege)</h4>
      <DataTable
        head={["Phase", "Actions"]}
        rows={[
          ["First moves", "HR + Legal engaged BEFORE any subject contact; no tipping (tipping destroys cases and creates liability); litigation hold on custodial data"],
          ["Preserve", "Quiet evidence preservation: mailbox hold, EDR data, DLP/file-access logs, badge/VPN records; chain of custody from minute one"],
          ["Scope", "Data-access review (what, when, volume vs. baseline); exfil channels (email/USB/cloud/print); accomplice/collusion check"],
          ["Contain", "Least-visible controls first (DLP block, silent alerting); access changes coordinated with HR timing; coordinated device collection if authorized"],
          ["Report", "Fact-only findings to counsel; employment/legal outcomes are NOT the analyst's call; access-review + DLP-tuning actions owned"],
        ]}
      />
    </section>
  );
}

export function TemplatesAppendix() {
  return (
    <section id="templates" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-amber-600 dark:text-amber-400">Appendix D ★ NEW · Copy, print, use</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Field Templates</h2>

      <h4 className="font-extrabold mt-4">D.1 Chain-of-custody form (per exhibit)</h4>
      <DataTable
        head={["Field", "Example entry"]}
        rows={[
          ["Item ID", "EVID-2026-041"],
          ["Description", "RAM capture, FIN-WS-114, 16 GB DDR4, WinPmem raw"],
          ["Source system / location", "FIN-WS-114 (10.4.17.88), Finance floor, desk 114"],
          ["Collector / date-time (UTC)", "K. Osei / 2026-09-26T14:11:47Z"],
          ["Method + tool versions", "WinPmem 4.0 (build 2024.11) to examiner USB, hash on capture"],
          ["SHA-256", "9f2c…(64 hex) — see attached .sha256 file"],
          ["Storage", "Safe-3 / shelf-B, tamper-bag #TB-1188"],
          ["Transfer log", "2026-09-26 15:02Z K.Osei → J.Mensah (analysis) sig:____; returned 18:40Z sig:____"],
        ]}
      />
      <h4 className="font-extrabold mt-4">D.2 Forensic report skeleton</h4>
      <div className="prose-book serif text-[15px]">
        <ol className="list-decimal ml-5 space-y-1">
          <li><b>Executive summary</b> (1 page): scope, impact, cause, status — no jargon.</li>
          <li><b>Methodology</b>: tools + versions, hashes, custody manifest, deviations.</li>
          <li><b>Timeline</b> (UTC): one row per event with exhibit citation.</li>
          <li><b>Findings per system</b>: evidence → analysis → verdict → confidence (observed / inferred / unknown).</li>
          <li><b>Appendices</b>: IoCs, TTP map, YARA, Sigma, figures.</li>
          <li><b>Recommendations</b>: prioritized, owned, dated.</li>
        </ol>
      </div>
      <h4 className="font-extrabold mt-4">D.3 First-responder triage card (15 minutes)</h4>
      <DataTable
        head={["Min", "Action", "Done"]}
        rows={[
          ["0–2", "Photo screen + scene; isolate NETWORK (keep power); open case log (UTC)", "☐"],
          ["2–7", "RAM capture to external media; hash immediately; record tool version", "☐"],
          ["7–10", "Process + socket + user snapshot to external media", "☐"],
          ["10–13", "Targeted log/prefetch/MFT copy; note what you touched", "☐"],
          ["13–15", "Hash everything; set severity; escalate with enrichment attached", "☐"],
        ]}
      />
      <h4 className="font-extrabold mt-4">D.4 Log-source inventory (per service row)</h4>
      <DataTable
        head={["Service", "Log", "Retention", "Collector", "Parsed?", "Owner"]}
        rows={[
          ["AD (DCs)", "Security 4768/69/71/4662", "400 d hot", "Winlogbeat → SIEM", "ECS ✓", "Identity team"],
          ["DNS resolvers", "Debug / query.log", "180 d", "Filebeat/syslog TLS", "ECS ✓", "NetOps"],
          ["Web fleet", "Access + error", "180 d", "Filebeat", "ECS ✓", "App team"],
          ["Proxy", "URI + verdict + bytes", "400 d", "Syslog TLS", "ECS ✓", "NetSec"],
          ["Endpoints", "Sysmon + Security + PS", "90 d hot / 1 y warm", "Elastic Agent", "ECS ✓", "SOC"],
        ]}
      />
    </section>
  );
}

export function AttckMapAppendix() {
  const rows: [string, string, string][] = [
    ["T1566.001", "Spearphishing Attachment", "§§3.2, 8.5, 12.2; capstone hop 1"],
    ["T1059.001", "PowerShell", "§§3.2, 6.2, 12.2; Fig. 10"],
    ["T1071.004", "DNS C2", "§§3.2, 6.3, 8.2, 9.3–9.4"],
    ["T1003.001", "LSASS Memory", "§§3.2, 6.4, 7.6, 8.8"],
    ["T1021.001/.004/.006", "RDP / SSH / WinRM", "§§5.4, 5.8, 8.6, 13.6"],
    ["T1048", "Exfiltration Over C2", "§§3.2, 9.3, 11.5"],
    ["T1547.001/.004/.005", "Run keys / Winlogon / SSP", "§§4.4, 5.7; Fig. 8"],
    ["T1053", "Scheduled Task/Job", "§§4.4, 5.3, B.4"],
    ["T1543", "System Services", "§§4.4, 5.8, B.4"],
    ["T1546", "Event-Triggered Execution", "§4.4; Fig. 8 (WMI/Winlogon)"],
    ["T1137 / T1176", "Office / Browser Extensions", "§4.4; Fig. 8"],
    ["T1564.004", "NTFS ADS", "§§4.2, 6.7 (EID 15)"],
    ["T1490", "Inhibit System Recovery", "§§4.6, 13.7"],
    ["T1486", "Data Encrypted for Impact", "§13.7; Playbook C.1"],
    ["T1070", "Indicator Removal", "§§3.2, 4.8, 5.6"],
    ["T1027", "Obfuscated Files/Info", "§§3.2, 6.2, 12.7"],
    ["T1068 / T1134", "Exploit / Token Manipulation", "§§3.2, 5.5"],
    ["T1018 / T1087", "Remote Discovery / Account Discovery", "§§3.2, 8.1"],
    ["T1055", "Process Injection", "§§6.4, 7.5; Fig. 12"],
    ["T1047 / T1218", "WMI / Signed-Binary Proxy Exec", "§§3.6, 5.8, 6.2"],
    ["T1558", "Steal/Forged Kerberos Tickets", "§§8.1, 8.8, 13.2"],
    ["T1078", "Valid Accounts", "§§3.2, 5.4, 8.7"],
    ["T1204", "User Execution", "§§3.2, 5.2"],
    ["T1505.003", "Web Shell", "§§8.4, 10.2; Playbook C.3"],
    ["T1110", "Brute Force / Spray", "§§8.1, 8.6, 11.5"],
    ["T1197", "BITS Jobs", "§5.7"],
    ["T1574", "Hijack Execution Flow (DLL)", "§6.7 (EID 7)"],
  ];
  return (
    <section id="attck-map" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300">Appendix E ★ NEW · Cross-reference</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">ATT&amp;CK-to-Chapter Map</h2>
      <p className="text-sm text-slate-500 mt-1">Every technique cited in the book, mapped to the sections that detect, hunt, or evict it. Use it to scope hunts (Ch. 3), write Sigma (Ch. 12), and prove coverage (Ch. 13).</p>
      <DataTable head={["Technique", "Name", "Detect / hunt / evict in"]} rows={rows} />
    </section>
  );
}

export function ToolsAppendix() {
  return (
    <section id="tools" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300">Appendix F ★ NEW · Bench reference</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Tools, Practice Datasets &amp; Glossary</h2>

      <h4 className="font-extrabold mt-4">F.1 Tool inventory by phase</h4>
      <DataTable
        head={["Phase", "Tool", "Use"]}
        rows={[
          ["Acquire", "dc3dd / dd", "Hashed bit-stream imaging with logs"],
          ["Acquire", "ewf-tools", "E01 create/verify for exchange"],
          ["Acquire", "WinPmem / DumpIt / LiME / AVML", "Windows/Linux RAM capture"],
          ["Acquire", "PALADIN / CAINE", "Field triage without writes"],
          ["Dead-box", "MFTECmd / PECmd / EvtxECmd / AmcacheParser", "Eric Zimmerman artifact parsers (the core kit)"],
          ["Dead-box", "Registry Explorer", "Hive + deleted-key analysis"],
          ["Dead-box", "Timeline Explorer", "CSV timeline review"],
          ["Dead-box", "Autopsy / Sleuth Kit", "Open full-disk examination suites"],
          ["Dead-box", "foremost / photorec / scalpel", "Header carving from unallocated"],
          ["Dead-box", "ssdeep / TLSH", "Similarity matching for variants"],
          ["Memory", "Volatility 3", "Process/injection/network/credential analysis"],
          ["Memory", "WinDbg", "Crash-dump + kernel debugging"],
          ["Network", "Wireshark / tshark / capinfos", "Interactive + scripted packet analysis"],
          ["Network", "Zeek + zeek-cut", "Transaction logs + intel framework"],
          ["Network", "Arkime", "Indexed PCAP retrieval"],
          ["Network", "SiLK / nfdump / ElastiFlow", "Long-retention flow analysis"],
          ["Network", "Suricata", "NIDS + eve.json + filestore"],
          ["Network", "tcpflow / NetworkMiner", "Payload/file extraction from PCAP"],
          ["Endpoint", "Sysmon + SwiftOnSecurity config", "Process/network/registry telemetry"],
          ["Endpoint", "Autoruns / Process Explorer", "Persistence + live-process review"],
          ["Endpoint", "LOKI / THOR Lite", "YARA fleet sweepers"],
          ["Detect", "Sigma CLI + pySigma", "Author once, transpile everywhere"],
          ["Detect", "YARA", "Content rules for files + memory"],
          ["Detect", "MISP + PyMISP", "Intel hub + automation"],
          ["Detect", "Atomic Red Team", "Emulation proof per technique"],
          ["SIEM", "Elastic / OpenSearch / Splunk", "Ingest, hunt (KQL/SPL/EQL/ES|QL), alert"],
          ["SIEM", "Wazuh", "Agent + FIM + manager-tier SIEM"],
          ["AD", "BloodHound / SharpHound / PingCastle", "Attack paths + hygiene scoring"],
          ["AD", "Impacket secretsdump (lab only)", "Understand DCSync-shaped theft"],
        ]}
      />

      <h4 className="font-extrabold mt-4">F.2 Practice datasets &amp; ranges</h4>
      <DataTable
        head={["Resource", "Gives you", "Use for"]}
        rows={[
          ["NIST CFReDS", "Reference disk/memory images + hashes", "Acquisition + dead-box labs (Ch. 2, 4–5)"],
          ["OTRF Mordor + EVTX-ATTACK-SAMPLES", "Pre-recorded attack telemetry", "Sigma testing + hunt replay (Ch. 11–12)"],
          ["Splunk BOSS/BOTS datasets", "Full-fidelity IR scenarios", "Capstone rehearsal (Ch. 13)"],
          ["CyberDefenders / Blue Team Labs / LetsDefend", "Guided DFIR challenges", "Weekly reps with scoring"],
          ["abuse.ch (MalwareBazaar/URLhaus)", "Live malware + C2 feeds", "Intel + YARA practice (Ch. 12)"],
          ["SANS DFIR posters", "Evidence + artifact cheat sheets", "Bench reference next to Appendix A"],
          ["13Cubed / DFIR Diva (video)", "Tool walkthroughs", "Pre-lab primers for Zimmerman/Volatility/Zeek"],
        ]}
      />

      <h4 className="font-extrabold mt-4">F.3 Beyond this book (pointers, not chapters)</h4>
      <DataTable
        head={["Domain", "Start with", "Note"]}
        rows={[
          ["Mobile", "ALEAPP/iLEAPP on device backups", "Logical-first; chip-off is a specialty lab"],
          ["macOS", "Unified log + APFS snapshots + TCC.db", "Time Machine + FSEvents complete timelines"],
          ["Cloud-native", "CloudTrail / Activity / Audit logs + snapshots", "Acquire via provider APIs under counsel"],
          ["Containers/K8s", "K8s audit log + image digests + docker diff", "Escalate deliberately (§B.6)"],
          ["ICS/OT", "Passive taps + historian exports", "Never scan OT actively without owner sign-off"],
        ]}
      />

      <h4 className="font-extrabold mt-4">F.4 Glossary (exam terms)</h4>
      <DataTable
        head={["Term", "Meaning"]}
        rows={[
          ["Admissibility", "Evidence quality bar: relevant, authentic, integrity-proven, repeatably obtained."],
          ["AiTM", "Adversary-in-the-middle: live relay proxy defeating passwords + weak MFA; steals sessions."],
          ["Allowlist subtraction", "Removing known-good before judging the unknown — the hunt noise filter."],
          ["Beaconing", "Implant check-ins on sleep+jitter schedules; hunt via interval regularity."],
          ["BYOVD", "Bring-your-own-vulnerable-driver: signed-but-buggy drivers used to kill EDR."],
          ["Chain of custody", "Gap-free possession record from seizure to courtroom."],
          ["Constellation", "Multi-event signature (e.g., PsExec's 4 events) — hunt shapes, not singletons."],
          ["D3FEND", "MITRE defensive-countermeasure graph mirroring ATT&CK."],
          ["DCSync", "Mimicked DC replication pulling hashes; 4662 from non-DC."],
          ["Dwell time", "Intrusion duration before detection; readiness aims to shrink it."],
          ["E01", "Expert Witness image format with metadata + CRCs + hashes."],
          ["ECS / CIM", "Elastic Common Schema / Splunk CIM: normalization dialects."],
          ["EID", "Event ID: Sysmon/Windows event type number."],
          ["Golden / Silver Ticket", "Forged Kerberos TGT / service ticket; hunt lifetimes + missing 4768."],
          ["IMPHASH", "Import-table hash clustering related malware builds."],
          ["IoC vs. TTP", "Atomic indicators (block) vs. behaviors (detect) — Pyramid of Pain."],
          ["JA3/JA4", "TLS ClientHello fingerprints identifying client stacks."],
          ["Jitter", "Randomized beacon skew defeating fixed-interval detectors."],
          ["Kerberoasting", "Offline cracking of RC4 service tickets; 4769 floods."],
          ["Kovel", "Counsel-engaged consultant arrangement preserving privilege."],
          ["Litigation hold", "Preservation order suspending deletion; violation = spoliation."],
          ["LotL", "Living-off-the-land: abusing legitimate binaries/services."],
          ["MTTD/MTTR/MTTC", "Mean time to detect/respond/contain — paired always with quality metrics."],
          ["ProcessGuid", "Sysmon's unique process key — join on it, never PID."],
          ["Resident (MFT)", "File content stored inside the MFT record itself."],
          ["SEV-1–4", "Severity bands driving SLAs and paging."],
          ["Sigma", "Vendor-agnostic detection YAML; transpiled by pySigma."],
          ["Spoliation", "Destruction of held evidence; invites adverse inference."],
          ["Timestomping", "$SI timestamp forgery; $FN divergence exposes it."],
          ["TTP", "Tactics, techniques, procedures — the durable detection layer."],
          ["UEBA", "User/entity behavior analytics — baselined anomaly detection."],
          ["WEF", "Windows Event Forwarding — agentless .evtx collection via WinRM."],
          ["YARA", "Content-matching rules for files and memory."],
          ["Zeek uid", "Per-connection key joining all Zeek logs."],
        ]}
      />
    </section>
  );
}
