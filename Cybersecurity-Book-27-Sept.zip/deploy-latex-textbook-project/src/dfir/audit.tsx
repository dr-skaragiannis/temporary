import { DataTable } from "./ui";

export function AuditBanner() {
  return (
    <section id="audit" className="mt-6 rounded-2xl p-6 lg:p-8 shadow-sm print-block text-white border border-cyan-800" style={{ background: "linear-gradient(135deg,#0f1c2e 0%,#134e4a 60%,#0e7490 100%)" }}>
      <div className="badge bg-emerald-400 text-slate-900 px-3 py-1 rounded-full">Έλεγχος ειδικού κυβερνοασφάλειας · Έλεγχος πληρότητας · Κάλυψη κενών</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-2">Έλεγχος ειδικού: Είναι πλήρες το βιβλίο για έναν εκπαιδευόμενο στο DFIR;</h2>
      <p className="text-sm text-cyan-50/90 mt-2 leading-relaxed max-w-4xl">
        Το χειρόγραφο ελέγχθηκε με βάση την πραγματική επαγγελματική πρακτική: εταιρικές διερευνήσεις περιστατικών,
        απαιτήσεις στελέχωσης SOC και το εύρος δεξιοτήτων GCFA, GCIA και BTL1. Εξετάστηκαν η πληρότητα, το τεχνικό
        βάθος, οι μηχανισμοί που έλειπαν και η οπτική τεκμηρίωση. Ο βασικός κορμός των 13 κεφαλαίων είναι συνεκτικός
        και προσιτός, εντοπίστηκαν όμως <b>14 κενά</b>, από την περιορισμένη κάλυψη της μεθοδολογίας threat hunting και
        της πλευρικής κίνησης έως την απουσία Linux forensics, YARA, WEF και cloud identity. Όλα έχουν πλέον
        <b>καλυφθεί στις κατάλληλες θέσεις</b> με 20 νέες ενότητες, 5 νέα σχήματα και 5 νέα παραρτήματα. Δεν αφαιρέθηκε
        υλικό· οι προσθήκες επισημαίνονται ως <b>★ ΝΕΟ</b> μέσα στη φυσική σειρά των κεφαλαίων.
      </p>
      <div className="grid md:grid-cols-3 gap-3 mt-4 text-[13px] leading-relaxed">
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <b className="text-emerald-300">✔ Κάλυψη: 13/13 κεφάλαια και 20 πρόσθετες ενότητες.</b><br />
          Καλύπτονται πλέον σε επιχειρησιακό βάθος όλα τα θέματα Tier 1–4: νομική ετοιμότητα, κρυπτογράφηση και SSD,
          file carving, κύκλοι threat hunting, KEV/EPSS και D3FEND, τεκμήρια LNK/bin/cache, Defender και SRUM,
          πλευρική κίνηση, πλήρης κατάλογος EID, προστασία από παραποίηση EDR, hiberfil/pagefile, Linux /proc,
          Entra/M365/AiTM, NTDS.dit, Zeek Intel, Arkime, DoH, WEF, τεχνικές παραπλάνησης, SOAR, ECS, YARA,
          ransomware και κανονιστικές προθεσμίες γνωστοποίησης.
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <b className="text-emerald-300">✔ Παιδαγωγική δομή: συνεπής μορφή για εκπαιδευόμενους.</b><br />
          Οι νέες ενότητες ακολουθούν το ίδιο διδακτικό σχήμα: εξήγηση → παράδειγμα → έρευνα → τεκμηρίωση.
          Προστέθηκαν μελέτες περίπτωσης, διορθώθηκαν ανακριβείς εντολές και επισημάνθηκαν οι διαφορές σύνταξης
          ανά έκδοση εργαλείου. Η αξιολόγηση παραμένει συνεκτική: το νέο υλικό εφαρμόζεται στα εργαστήρια και στην
          τελική συνθετική εργασία, χωρίς να αλλοιώνονται τα βασικά κουίζ.
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <b className="text-emerald-300">✔ Σκόπιμα εκτός εύρους, με σαφείς παραπομπές.</b><br />
          Η πλήρης εγκληματολογία κινητών, macOS, ICS/OT και container απαιτεί αυτοτελές μάθημα. Το Παράρτημα F
          παρέχει εργαλεία, σημειώσεις και σύνολα εξάσκησης αντί για επιφανειακά κεφάλαια. Το βιβλίο εμβαθύνει στα
          περιβάλλοντα όπου εργάζονται συχνότερα τα νεότερα στελέχη DFIR: Windows, διακομιστές Linux, AD/Entra,
          δίκτυα και SIEM.
        </div>
      </div>
      <div className="mt-4 not-serif overflow-x-auto rounded-xl">
        <DataTable head={["Κενό που εντοπίστηκε", "Τι προστέθηκε", "Θέση"]} rows={[
          ["Απουσία ετοιμότητας και νομικής καθοδήγησης", "Έλεγχοι ετοιμότητας, litigation hold, Kovel και ασκήσεις tabletop", "§1.7"],
          ["Ελλιπής κάλυψη κρυπτογράφησης, SSD, VM και carving", "BitLocker, TRIM, VMDK, ssdeep, carving και ασφαλής κατάσχεση", "§§2.7–2.8"],
          ["Άτυπη μεθοδολογία hunting, χωρίς UKC/KEV/D3FEND", "Κύκλος TaHiTI/PEAK, UKC, KEV/EPSS και D3FEND", "§§3.7–3.8"],
          ["Ανεπαρκής κάλυψη LNK/bin/cache και USN", "Ίχνη link/bin/cache, DPAPI και έρευνες καταστροφής journal", "§§4.7–4.8"],
          ["Περιορισμένη κάλυψη Defender/SRUM/RDP και πλευρικής κίνησης", "AV/ASR/WDAC/SRUM/BITS και μοτίβα PsExec/WMI/WinRM/RDP", "§§5.7–5.8"],
          ["Μερική κάλυψη EID και απουσία άμυνας EDR", "Πλήρης κατάλογος EID 1–29, έρευνες BYOVD και ροή EDR-first", "§6.7"],
          ["Απουσία hiberfil/pagefile/dump και ζωντανής ανάλυσης Linux", "Μνήμη στον δίσκο, λήψη hypervisor και διαλογή /proc", "§7.7"],
          ["Απουσία cloud identity και NTDS.dit", "Entra/M365/Okta, AiTM, NTDS.dit, εισιτήρια και BloodHound", "§§8.7–8.8"],
          ["Απουσία Zeek Intel, Arkime, ροών και DoH", "Zeek Intel, Arkime, NetFlow/IPFIX, εξαγωγή αρχείων, DoH και δεοντολογία υποκλοπής", "§9.7"],
          ["Απουσία WEF και τεχνικών παραπλάνησης", "Αρχιτεκτονική WEF, honeytoken, sinkholing, datasets και filestore", "§§10.7–10.8"],
          ["Απουσία SOAR, μετρήσεων και πυρήνα ECS", "Επίπεδα αυτοματισμού, MTTx, ECS και διάκριση ES|QL/KQL/EQL", "§11.7"],
          ["Πλήρης απουσία YARA", "Ανατομία κανόνων, σάρωση, διαχείριση, D3FEND και συναθροίσεις Sigma", "§12.7"],
          ["Απουσία δόγματος ransomware και γνωστοποιήσεων", "Δέντρο αποφάσεων, σειρά επαναφοράς και προθεσμίες GDPR/NIS2/SEC/CIRCIA", "§§13.7–13.8"],
          ["Απουσία Linux και επιχειρησιακών παραρτημάτων", "Παραρτήματα Linux, playbook, πρότυπα, χάρτης ATT&CK και εργαλεία/γλωσσάρι", "Παρ. B–F"],
        ]} />
      </div>
      <p className="text-[12px] text-cyan-100/80 mt-3">
        Τρόπος μελέτης του νέου υλικού: διαβάστε κάθε ενότητα ★ ΝΕΟ στη σειρά του κεφαλαίου, εκτελέστε τις εντολές
        της στο εργαστήριο και ενσωματώστε τα τεκμήρια στην τελική αναφορά. Για τους διδάσκοντες, το πλάνο εξαμήνου
        απορροφά τις προσθήκες χωρίς αναδιάταξη· υπολογίστε περίπου μία επιπλέον ώρα ανά κεφάλαιο και έξι ώρες για το Παράρτημα B.
      </p>
    </section>
  );
}
