import { useMemo, useState } from "react";
import { ExternalLink, Images, ScrollText, X } from "lucide-react";
import { figIndex, REFS, type FigEntry } from "./book";
import { CodeBlock, DataTable } from "./ui";

export function FiguresGallery() {
  const [q, setQ] = useState("");
  const [ch, setCh] = useState("");
  const [open, setOpen] = useState<FigEntry | null>(null);
  const chs = useMemo(() => [...new Set(figIndex.map((f) => f.ch))], []);
  const list = figIndex.filter(
    (f) =>
      (!ch || f.ch === ch) &&
      (!q || (f.n + " " + f.t + " " + f.cap).toLowerCase().includes(q.toLowerCase()))
  );
  return (
    <section id="figures" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300 inline-flex items-center gap-1.5">
        <Images size={13} /> Συλλογή σχημάτων · <span id="figCount">{list.length}</span> / {figIndex.length} εμφανίζονται
      </div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Ευρετήριο Σχημάτων (Σχ. 1–25)</h2>
      <p className="text-sm text-slate-500 mt-1">Όλα τα σχήματα είναι ενσωματωμένα διανυσματικά διαγράμματα στη θέση του αντίστοιχου κεφαλαίου. Αναζητήστε ή φιλτράρετε και επιλέξτε μια κάρτα για να δείτε τη διδακτική λεζάντα.</p>
      <div className="flex flex-col sm:flex-row gap-2 mt-3 no-print">
        <input
          id="figSearch"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Αναζήτηση σχημάτων, π.χ. beacon, MFT, Sigma…"
          className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none placeholder:text-slate-400"
        />
        <select
          id="figChFilter"
          value={ch}
          onChange={(e) => setCh(e.target.value)}
          className="bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none"
        >
          <option value="">Όλα τα κεφάλαια</option>
          {chs.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>
      <div id="figGrid" className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3 mt-4">
        {list.map((f) => (
          <button
            key={f.n}
            onClick={() => setOpen(f)}
            className="text-left p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:border-cyan-400 hover:shadow-md transition group"
          >
            <div className="fig-thumb mb-2 relative">
              <svg viewBox="0 0 200 90" className="w-full h-full">
                <rect x="8" y="10" width="184" height="70" rx="8" fill="none" stroke="#94a3b8" strokeDasharray="5 4" strokeWidth="1.5" />
                <text x="100" y="42" textAnchor="middle" fontSize="15" fontWeight="800" fill="#0e7490">Σχ. {f.n}</text>
                <text x="100" y="60" textAnchor="middle" fontSize="8" fill="#64748b">{f.ch} · ενσωματωμένο διάνυσμα</text>
              </svg>
              <span className="absolute top-2 right-2 text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500 text-white">ΔΙΑΝΥΣΜΑΤΙΚΟ</span>
            </div>
            <div className="text-[13px] font-bold leading-snug group-hover:text-cyan-700 dark:group-hover:text-cyan-300">Σχ. {f.n} · {f.t}</div>
            <div className="text-[11px] text-slate-500 mt-1">{f.ch} — επιλογή για τη διδακτική λεζάντα</div>
          </button>
        ))}
        {list.length === 0 && <div className="text-sm text-slate-500 p-4">Δεν βρέθηκαν σχήματα.</div>}
      </div>
      {open && (
        <div className="fixed inset-0 z-[80] bg-black/60 flex items-center justify-center p-4" onClick={() => setOpen(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 relative" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setOpen(null)} className="absolute top-3 right-3 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Κλείσιμο">
              <X size={16} />
            </button>
            <div className="badge text-cyan-700 dark:text-cyan-300">{open.ch} · Αναδημιουργημένο ως ενσωματωμένο διανυσματικό διάγραμμα</div>
            <h3 className="font-black text-lg mt-1">Σχ. {open.n} · {open.t}</h3>
            <p className="text-sm mt-2 leading-relaxed text-slate-600 dark:text-slate-300">{open.cap}</p>
            <div className="mt-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs leading-relaxed">
              <b>Διδακτική αξιοποίηση.</b> Προβάλετε το ενσωματωμένο διανυσματικό σχήμα και ζητήστε από τους εκπαιδευόμενους: (1) να περιγράψουν τον μηχανισμό σε
              μία πρόταση, (2) να αναφέρουν έναν έλεγχο ή μία έρευνα που υποστηρίζει και (3) να τον αντιστοιχίσουν στο ATT&amp;CK και στον κύκλο ζωής NIST.
            </div>
            <a href={`#${open.anchor}`} onClick={() => setOpen(null)} className="mt-3 inline-flex items-center gap-1 text-sm font-bold text-cyan-700 dark:text-cyan-300">
              <ExternalLink size={14} /> Μετάβαση στο Σχ. {open.n} του {open.ch}
            </a>
          </div>
        </div>
      )}
    </section>
  );
}

export function ReferencesSection() {
  return (
    <section id="references" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-cyan-700 dark:text-cyan-300 inline-flex items-center gap-1.5">
        <ScrollText size={13} /> APA 7η έκδοση · Πρότυπα και αξιολογημένες επιστημονικές πηγές
      </div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Βιβλιογραφικές αναφορές</h2>
      <ol id="refList" className="mt-3 space-y-2 text-[13.5px] leading-relaxed list-none">
        {REFS.map((r, i) => (
          <li key={i} className="pl-1" dangerouslySetInnerHTML={{ __html: `<span class="font-black text-slate-900 dark:text-white">[${i + 1}]</span> ${r}` }} />
        ))}
      </ol>
    </section>
  );
}

export function AppendixSection() {
  return (
    <section id="appendix" className="mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 lg:p-8 shadow-sm print-block">
      <div className="badge text-amber-600 dark:text-amber-400">Παράρτημα · Εκτυπώστε το για το εργαστήριο</div>
      <h2 className="text-2xl lg:text-3xl font-black tracking-tight mt-1">Σύντομοι οδηγοί πεδίου</h2>

      <h4 className="font-extrabold mt-4">Α.1 Σύντομος οδηγός Windows Event ID</h4>
      <DataTable
        head={["ID", "Κανάλι", "Σημασία", "Έρευνα"]}
        rows={[
          ["4624 / 4625", "Security", "Επιτυχής/αποτυχημένη σύνδεση και τύπος", "Τύπος 3/10 από πηγές που εμφανίζονται πρώτη φορά"],
          ["4672", "Security", "Ειδικά προνόμια κατά τη σύνδεση", "Νέοι λογαριασμοί/συστήματα στη ροή 4672"],
          ["4688", "Security", "Δημιουργία διεργασίας", "Συσχέτιση με Sysmon EID 1· απαιτεί πολιτική καταγραφής γραμμής εντολών"],
          ["4720 / 4732", "Security", "Δημιουργία λογαριασμού / προσθήκη σε ομάδα", "Λογαριασμοί κερκόπορτας και διεργασία που εκτέλεσε την ενέργεια"],
          ["1102", "Security", "Εκκαθάριση αρχείου ελέγχου", "Άμεσο SEV-1· έλεγχος αντιγράφου στο SIEM"],
          ["7045", "System", "Εγκατάσταση υπηρεσίας", "Εγκατάσταση παραμονής· έλεγχος ImagePath"],
          ["4768 / 4769 / 4771", "Security (DC)", "TGT / εισιτήριο υπηρεσίας / αποτυχία pre-auth", "Kerberoasting, αναγνώριση DCSync και password spraying"],
          ["4662", "Security (DC)", "Πρόσβαση σε αντικείμενο DS", "Μη DC και GUID αναπαραγωγής = DCSync"],
          ["4104", "PowerShell", "Κείμενο ScriptBlock", "Αποσυσκοτισμένα payload, μαζί με -enc"],
          ["Sysmon 1/3/10/22", "Sysmon", "Διεργασίες / δίκτυο / πρόσβαση / DNS", "Δέντρα, sockets→διεργασίες, LSASS και τομείς C2"],
        ]}
      />

      <h4 className="font-extrabold mt-4">Α.2 Σειρά αρχικής διαλογής με Volatility 3</h4>
      <div className="not-serif">
        <CodeBlock
          title="Bash — απομνημονεύστε αυτή τη σειρά"
          code={`vol -f mem.raw windows.info && vol -f mem.raw windows.pstree\nvol -f mem.raw windows.psscan        # vs pslist: hidden hunt\nvol -f mem.raw windows.malfind        # injected code\nvol -f mem.raw windows.netscan        # sockets at capture\nvol -f mem.raw windows.hashdump       # credential scope`}
        />
      </div>

      <h4 className="font-extrabold mt-4">Α.3 Σύντομες εντολές δικτυακής διαλογής</h4>
      <div className="not-serif">
        <CodeBlock
          title="Bash — tshark + Zeek"
          code={`tshark -r c.pcap -q -z conv,ip | head -n 25\ntshark -r c.pcap -Y "dns.flags.response==0" -T fields -e dns.qry.name | sort | uniq -c | sort -rn | head\ncat conn.log | zeek-cut id.orig_h id.resp_h id.resp_p duration orig_bytes resp_bytes | awk '$4>300' | head\ncat ssl.log | zeek-cut id.orig_h ja3 SNI | sort | uniq -c | sort -n | head`}
        />
      </div>

      <h4 className="font-extrabold mt-4">Α.4 Κατάλογος ελέγχου απομάκρυνσης κατά την ώρα Τ</h4>
      <DataTable
        head={["Χρόνος", "Ενέργεια", "Επαλήθευση"]}
        rows={[
          ["T-60", "Οριστικοποίηση έκτασης (συστήματα/χρήστες/IP) και δοκιμαστική εκτέλεση όλων των σεναρίων", "Καταγραφή hash της έκτασης"],
          ["T-0", "Ταυτόχρονη απομόνωση, αποκλεισμοί firewall/proxy και απενεργοποίηση λογαριασμών", "Ημερολόγιο απομάκρυνσης με UTC ανά ενέργεια"],
          ["T+30", "Πρώτη επαναφορά krbtgt, ανάκληση OAuth και αλλαγή SPN", "Ενεργό helpdesk και σχέδιο επικοινωνίας"],
          ["T+36h", "Δεύτερη επαναφορά krbtgt μετά από 2× διάρκεια ζωής και αναπαραγωγή", "Όλα τα εισιτήρια έχουν ακυρωθεί"],
          ["T+72h", "Έρευνες επαλήθευσης (4768/69/4624, beacon και παραμονή)", "Απουσία σημάτων = επιτυχία· ευρήματα = νέα οριοθέτηση"],
          ["T+5d", "Αναδρομική εξέταση, τεχνική/διοικητική αναφορά και διάθεση ανιχνεύσεων", "Κάθε ενέργεια έχει υπεύθυνο και προθεσμία"],
        ]}
      />
    </section>
  );
}
