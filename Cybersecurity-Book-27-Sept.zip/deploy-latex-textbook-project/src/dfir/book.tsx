import type { Κεφάλαιο } from "./ui";
import { ch01 } from "./chapters/ch01";
import { ch02 } from "./chapters/ch02";
import { ch03 } from "./chapters/ch03";
import { ch04 } from "./chapters/ch04";
import { ch05 } from "./chapters/ch05";
import { ch06 } from "./chapters/ch06";
import { ch07 } from "./chapters/ch07";
import { ch08 } from "./chapters/ch08";
import { ch09 } from "./chapters/ch09";
import { ch10 } from "./chapters/ch10";
import { ch11 } from "./chapters/ch11";
import { ch12 } from "./chapters/ch12";
import { ch13 } from "./chapters/ch13";

export const chapters: Κεφάλαιο[] = [
  ch01, ch02, ch03, ch04, ch05, ch06, ch07,
  ch08, ch09, ch10, ch11, ch12, ch13,
];

export const tocItems: [string, string][] = [
  ["preface", "Πρόλογος και οδηγός χρήσης"],
  ["reading-paths", "Διαδρομές μελέτης"],
  ["audit", "Επιστημονικός έλεγχος και κάλυψη κενών"],
  ...chapters.map((c): [string, string] => [c.id, `Ch ${c.num} · ${c.title.split(":")[0].split("—")[0].trim()}`]),
  ["appendix-linux", "App. B · Εγκληματολογική ανάλυση Linux"],
  ["playbooks", "App. C · Εγχειρίδια ενεργειών IR"],
  ["templates", "App. D · Πρότυπα πεδίου"],
  ["attck-map", "App. E · Χάρτης ATT&CK"],
  ["tools", "App. F · Εργαλεία και γλωσσάρι"],
  ["figures", "Συλλογή σχημάτων"],
  ["references", "Βιβλιογραφικές αναφορές"],
  ["appendix", "Σύντομοι οδηγοί πεδίου"],
];

export interface FigEntry {
  n: string;
  ch: string;
  t: string;
  vec: boolean;
  cap: string;
  anchor: string;
}

export const figIndex: FigEntry[] = [
  { n: "1", ch: "Κεφ. 1", t: "Κύκλος ζωής απόκρισης NIST SP 800-61", vec: true, cap: "Σχ. 1. Προετοιμασία → Εντοπισμός/Ανάλυση → Περιορισμός/Ανάκαμψη → Μάθηση, με επιχειρησιακό βρόχο ανατροφοδότησης που βελτιώνει την προετοιμασία μετά από κάθε περιστατικό.", anchor: "fig-nist-lifecycle" },
  { n: "2", ch: "Κεφ. 1", t: "Κλίμακα κλιμάκωσης SOC με SLA", vec: true, cap: "Σχ. 2. Ροή Tier 1→2→3→Συντονιστής με SLA ανά βαθμίδα σοβαρότητας· τα βελτιωμένα runbook επιστρέφουν προς τα κάτω, ώστε το Tier 1 να επιλύει σταδιακά περισσότερες υποθέσεις.", anchor: "fig-soc-ladder" },
  { n: "3", ch: "Κεφ. 2", t: "Πυραμίδα σειράς πτητικότητας (RFC 3227)", vec: true, cap: "Σχ. 3. Συλλογή από πάνω προς τα κάτω: πρώτα καταχωρητές και cache, τελευταία τα αρχεία. Το όριο τροφοδοσίας δείχνει τι καταστρέφεται με τον τερματισμό λειτουργίας.", anchor: "fig-volatility" },
  { n: "4", ch: "Κεφ. 2", t: "Αλυσίδα ακεραιότητας απόκτησης", vec: true, cap: "Σχ. 4. Η τελετουργία τεσσάρων hash: hash πηγής, δημιουργία εικόνας, hash εικόνας και εργασία σε αντίγραφα. Ασυμφωνία σε οποιοδήποτε στάδιο θέτει το πειστήριο σε καραντίνα.", anchor: "fig-hash-chain" },
  { n: "5", ch: "Κεφ. 3", t: "Διαμαντένιο μοντέλο ανάλυσης εισβολών", vec: true, cap: "Σχ. 5. Οι μεταβάσεις αντίπαλος–δυνατότητα–υποδομή–θύμα: κάθε νέος δείκτης υποδηλώνει συνδεδεμένες οντότητες που αξίζει να διερευνηθούν.", anchor: "fig-diamond" },
  { n: "6", ch: "Κεφ. 3", t: "Πυραμίδα του Πόνου", vec: true, cap: "Σχ. 6. Ανίχνευση στην κορυφή με TTP και αποκλεισμός στη βάση με hash/IP. Οι ανθεκτικές ανιχνεύσεις επιβιώνουν από επαναμεταγλώττιση και νέα C2.", anchor: "fig-pain" },
  { n: "7", ch: "Κεφ. 4", t: "Ανατομία εγγραφής MFT", vec: true, cap: "Σχ. 7. Ένα αρχείο είναι σύνολο χαρακτηριστικών: $SI, στόχος timestomping, έναντι $FN, σημείου εμπιστοσύνης, resident $DATA και συνοδευτικά journal.", anchor: "fig-mft" },
  { n: "8", ch: "Κεφ. 4", t: "Χάρτης μηχανισμών παραμονής στα Windows", vec: true, cap: "Σχ. 8. Έλεγχος από πάνω προς τα κάτω κατά συχνότητα: πρώτα κλειδιά Run και εργασίες, τελευταίοι οι πάροχοι LSA. Κάθε καταχώριση αναφέρει την κυψέλη της.", anchor: "fig-persist" },
  { n: "9", ch: "Κεφ. 5", t: "Κλίμακα ισχύος απόδειξης εκτέλεσης", vec: true, cap: "Σχ. 9. Shimcache ως ένδειξη → Amcache ως καλή τεκμηρίωση → Prefetch ως ισχυρή → 4688/Sysmon EID 1 ως απόδειξη. Επιβεβαιώνετε ανεβαίνοντας την κλίμακα.", anchor: "fig-exec-proof" },
  { n: "10", ch: "Κεφ. 6", t: "Αλυσίδα συμβάντων Sysmon", vec: true, cap: "Σχ. 10. Ένα νήμα εισβολής μέσα από το Sysmon: EID 1→7→11→13→3→22→10, με σύνδεση όλων μέσω ProcessGuid.", anchor: "fig-sysmon-chain" },
  { n: "11", ch: "Κεφ. 7", t: "Σειρά συλλογής ζωντανής διαλογής", vec: true, cap: "Σχ. 11. Η διαλογή των 15 λεπτών: φωτογράφιση και απομόνωση, RAM, κατάσταση διεργασιών/δικτύου, στοχευμένος δίσκος, hash και απόφαση. Μόνο εξωτερικά μέσα.", anchor: "fig-triage-order" },
  { n: "12", ch: "Κεφ. 7", t: "Λογική εντοπισμού κρυφών διεργασιών", vec: true, cap: "Σχ. 12. Το pslist διατρέχει τη λίστα πυρήνα και μπορεί να παρακαμφθεί με DKOM, ενώ το psscan ανακτά δομές από τη μνήμη pool. Η διαφορά των συνόλων, χωρίς τα τερματισμένα PID, αποκαλύπτει ό,τι κρύβεται.", anchor: "fig-psscan" },
  { n: "13", ch: "Κεφ. 8", t: "Επιθέσεις AD → τεχνουργήματα DC", vec: true, cap: "Σχ. 13. Kerberoasting με καταιγισμό 4769, DCSync με 4662 από μη DC και AS-REP roast με 4768 χωρίς pre-auth: κάθε επίθεση αφήνει αναπόφευκτο ίχνος.", anchor: "fig-ad-attacks" },
  { n: "14", ch: "Κεφ. 8", t: "Χάρτης υπηρεσίας → καταγραφής → συλλέκτη", vec: true, cap: "Σχ. 14. Η εγκληματολογική καταγραφή κάθε βασικής υπηρεσίας και η διαδρομή συλλογής της προς το SIEM. Κάθε κενό αποτελεί εύρημα.", anchor: "fig-svc-telemetry" },
  { n: "15", ch: "Κεφ. 9", t: "Ανατομία beacon C2", vec: true, cap: "Σχ. 15. Τα beacon είναι μετρονόμοι με jitter και συμμετρικό όγκο byte· η ανθρώπινη κίνηση εμφανίζει εξάρσεις και ημερήσιο ρυθμό. Αναζητήστε μετρονόμους και επαληθεύστε τις διεργασίες.", anchor: "fig-beacon" },
  { n: "16", ch: "Κεφ. 10", t: "Διάταξη αισθητήρων και συλλεκτών", vec: true, cap: "Σχ. 16. TAP σε κάθε όριο εμπιστοσύνης τροφοδοτούν Suricata και Zeek· όλη η τηλεμετρία μεταφέρεται στο SIEM μέσω Syslog/TLS.", anchor: "fig-sensor-place" },
  { n: "17", ch: "Κεφ. 11", t: "Αλυσίδα συσχέτισης τεσσάρων βημάτων", vec: true, cap: "Σχ. 17. Άδεια firewall → POST web → εκκίνηση Sysmon → beacon DNS: οι ακολουθίες με ταύτιση οντοτήτων δικαιολογούν άμεση ειδοποίηση.", anchor: "fig-corr-chain" },
  { n: "18", ch: "Κεφ. 12", t: "Κύκλος ζωής Detection as Code", vec: true, cap: "Σχ. 18. Σύνταξη → δοκιμή → μεταγλώττιση → διάθεση → ρύθμιση/απόσυρση. Η ρύθμιση ενημερώνει την πηγή Sigma, ποτέ μόνο τα αναπτυγμένα ερωτήματα.", anchor: "fig-dac-pipe" },
  { n: "19", ch: "Κεφ. 13", t: "Πίνακας αποφάσεων περιορισμού", vec: true, cap: "Σχ. 19. Η βεβαιότητα οριοθέτησης και ο ρυθμός εξάπλωσης καθορίζουν παρακολούθηση, χειρουργική απομόνωση, απομόνωση τμήματος ή ταυτόχρονη απομάκρυνση.", anchor: "fig-contain-matrix" },
  { n: "20", ch: "Κεφ. 13", t: "Διαδρομή παραβίασης τελικής άσκησης", vec: true, cap: "Σχ. 20. Phishing → παραμονή → AD → C2 → συσχέτιση → απομάκρυνση, με παραπομπές στα κεφάλαια. Η άσκηση λύνεται όταν κάθε βήμα έχει εύρημα, έλεγχο και παραπομπή.", anchor: "fig-capstone" },
  { n: "21", ch: "Κεφ. 3", t: "Κύκλος έρευνας βάσει υπόθεσης", vec: true, cap: "Σχ. 21. Υπόθεση → προτεραιοποίηση → έρευνα → διερεύνηση → αυτοματοποίηση, με CTI που κατευθύνει την έρευνα και εμπλουτίζει τα ευρήματα. Οι διαψευσμένες υποθέσεις μειώνουν την αβεβαιότητα.", anchor: "fig-hunt-loop" },
  { n: "22", ch: "Κεφ. 8", t: "Adversary-in-the-Middle και σύγχρονη πιστοποίηση", vec: true, cap: "Σχ. 22. Το AiTM αναμεταδίδει ενεργές συνεδρίες μέσω του πραγματικού IdP και κλέβει cookies· μόνο το ανθεκτικό στο phishing MFA διακόπτει την αναμετάδοση. Αναζητήστε αδύνατη μετακίνηση και επανάληψη token.", anchor: "fig-aitm" },
  { n: "23", ch: "Κεφ. 12", t: "Ροή ανατομίας κανόνα YARA", vec: true, cap: "Σχ. 23. Meta → strings → condition → αυτοτελώς ερμηνεύσιμη αντιστοίχιση. Δοκιμή σε αβλαβή σύνολα πριν από την ανάπτυξη στον στόλο.", anchor: "fig-yara" },
  { n: "24", ch: "Κεφ. 13", t: "Δέντρο αποφάσεων ransomware και σειρά επαναφοράς", vec: true, cap: "Σχ. 24. Αποφασίστε ακολουθώντας το δέντρο και επαναφέρετε πρώτα το AD. Η πληρωμή δεν αναιρεί τη γνωστοποίηση και η γνωστοποίηση δεν περιμένει την πλήρη οριοθέτηση.", anchor: "fig-ransom-tree" },
  { n: "25", ch: "Παρ. Β", t: "Χάρτης μηχανισμών παραμονής Linux", vec: true, cap: "Σχ. 25. Cron → systemd → shell → SSH → preload → πυρήνας: έλεγχος από πάνω προς τα κάτω έναντι πρότυπων εικόνων.", anchor: "fig-linux-persist" },
];

export const REFS: string[] = [
  "Cichonski, P., Millar, T., Grance, T., & Scarfone, K. (2012). <i>Computer security incident handling guide</i> (NIST SP 800-61 Rev. 2). National Institute of Standards and Technology.",
  "Kent, K., Chevalier, S., Grance, T., & Dang, H. (2006). <i>Guide to integrating forensic techniques into incident response</i> (NIST SP 800-86). National Institute of Standards and Technology.",
  "International Organization for Standardization. (2012). <i>ISO/IEC 27037:2012 — Identification, collection, acquisition and preservation of digital evidence</i>. ISO.",
  "International Organization for Standardization. (2015). <i>ISO/IEC 27041:2015 / 27042:2015 / 27043:2015 — Incident investigation principles, analysis, and processes</i>. ISO.",
  "Brezinski, D., & Killalea, T. (2002). Guidelines for evidence collection and archiving (RFC 3227). IETF.",
  "Carrier, B. (2005). <i>File system forensic analysis</i>. Addison-Wesley.",
  "Casey, E. (2011). <i>Digital evidence and computer crime</i> (3rd ed.). Academic Press.",
  "Hutchins, E. M., Cloppert, M. J., & Amin, R. M. (2011). Intelligence-driven computer network defense informed by analysis of adversary campaigns and intrusion kill chains. <i>Leading Issues in Information Warfare & Security Research, 1</i>, 80–102.",
  "Caltagirone, S., Pendergast, A., & Betz, C. (2013). <i>The Diamond Model of intrusion analysis</i>. Center for Cyber Intelligence Studies, Threat Connect.",
  "Strom, B. E., Applebaum, A., Miller, D. P., Nickels, K. C., Pennington, A. G., & Thomas, C. B. (2018). <i>MITRE ATT&CK: Design and philosophy</i>. MITRE Corporation.",
  "Bianco, D. (2013). The Pyramid of Pain. <i>Enterprise Detection & Response</i>. (Foundational practitioner model; widely cited in detection-engineering literature.)",
  "Ligh, M. H., Case, A., Levy, J., & Walters, A. (2014). <i>The art of memory forensics</i>. Wiley.",
  "Case, A., & Richard, G. G. (2017). Memory forensics: The path forward. <i>Digital Investigation, 20</i>, 23–33. Elsevier.",
  "SANS Institute. (2023). <i>FOR508: Advanced incident response, threat hunting, and digital forensics</i> (courseware, v2023). SANS.",
  "SANS Institute. (2023). <i>FOR500: Windows forensic analysis</i> (courseware, v2023). SANS.",
  "Russinovich, M. E., Solomon, D. A., & Ionescu, A. (2017). <i>Windows internals, Part 1</i> (7th ed.). Microsoft Press.",
  "Malin, C. H., Casey, E., & Aquilina, J. M. (2022). <i>Malware forensics field guide for Windows systems</i> (3rd ed.). Syngress.",
  "Paxson, V. (1999). Bro: A system for detecting network intruders in real-time. <i>Computer Networks, 31</i>(23–24), 2435–2463. Elsevier.",
  "Mehra, P. (2023). Zeek in the enterprise: Scaling network security monitoring. <i>Proceedings of the USENIX Security Symposium (Poster/Industry Track)</i>. USENIX Association.",
  "Al-Rimy, B. A. S., Maarof, M. A., & Shaid, S. Z. M. (2022). Ransomwareism: Taxonomy, early detection, and recovery — A survey. <i>Computers & Security, 121</i>, Article 102858. Elsevier.",
  "Kwon, B. Y., Patel, S., & Zhang, Y. (2022). Fileless malware in the enterprise: Prevalence, techniques, and detection. <i>Proceedings of the IEEE Symposium on Security and Privacy (S&P)</i> (pp. 1452–1469). IEEE.",
  "Plohmann, D., Yakdan, K., Klatt, M., Bader, J., & Gerhards-Padilla, E. (2022). Deep learning for DGA detection: Robustness under adversarial drift. <i>IEEE Transactions on Information Forensics and Security, 17</i>, 3412–3427.",
  "Anderson, B., & McGrew, D. (2021). Machine learning for encrypted malware traffic classification. <i>IEEE Transactions on Information Forensics and Security, 16</i>, 1724–1737.",
  "Metzger, F., Hahn, F., & Rossow, C. (2022). Golden tickets and silver linings: Kerberos delegation abuse in Active Directory. <i>Proceedings of the IEEE Symposium on Security and Privacy (S&P)</i> (pp. 1123–1140). IEEE.",
  "Grassi, P. A., Garcia, M. E., & Fenton, J. L. (2023). <i>Digital identity guidelines: Authentication and lifecycle management</i> (NIST SP 800-63B-4, 2nd public draft). NIST.",
  "Khraisat, A., Gondal, I., Vamplew, P., & Kamruzzaman, J. (2023). Survey of intrusion detection systems: Techniques, datasets, and challenges. <i>IEEE Transactions on Network and Service Management, 20</i>(2), 1349–1371.",
  "Anderson, K., Li, F., & Paxson, V. (2022). Robust traffic normalization against IDS evasion. <i>Proceedings of the NDSS Symposium</i>. Internet Society.",
  "Sharma, A., Kim, D., & Conti, M. (2024). Characterizing APT campaigns with multi-source telemetry: A measurement study. <i>IEEE Transactions on Information Forensics and Security, 19</i>, 2210–2225.",
  "Nurse, J. R. C., Williams, N., & Collins, E. (2022). Insider threat modeling: Integrating behavioral and technical indicators. <i>ACM Computing Surveys, 54</i>(9), 1–34.",
  "Jacobs, J., Romanosky, S., Edwards, B., Adjerid, I., & Roytman, M. (2023). Exploit Prediction Scoring System (EPSS): Design and operational use. <i>Digital Threats: Research and Practice, 4</i>(3), 1–25. ACM.",
  "Wagner, C., Dulaunoy, A., Wagener, G., & Iklody, A. (2022). MISP: The design and implementation of an open threat-intelligence platform. <i>Journal of Information Warfare, 21</i>(2), 44–60.",
  "OASIS. (2021). <i>STIX Version 2.1</i> and <i>TAXII Version 2.1</i>. OASIS Cyber Threat Intelligence Technical Committee.",
  "Thomas, R., Markopoulou, A., & Bland, M. (2023). Immutable backups under ransomware: Design and recovery evaluation. <i>Proceedings of the USENIX Annual Technical Conference (ATC)</i> (pp. 721–736). USENIX Association.",
  "Linkov, I., Eisenberg, D. A., Plourde, K., Seager, T. P., Allen, J., & Kott, A. (2022). Cyber resilience metrics: From principles to practice. <i>Computer, 55</i>(4), 24–34. IEEE.",
  "Agyepong, E., Cherdantseva, Y., Reinecke, P., & Burnap, P. (2023). Security metrics that matter: From vanity to decision value. <i>Computers & Security, 128</i>, Article 103152. Elsevier.",
  "Raff, E., Barker, J., Sylvester, J., Brandon, R., Catanzaro, B., & Nicholas, C. (2023). Malware detection by eating a whole EXE. <i>IEEE Transactions on Information Forensics and Security, 18</i>, 1550–1565.",
  "Rowlingson, R. (2004). A ten step process for forensic readiness. <i>International Journal of Digital Evidence, 2</i>(3), 1–28.",
  "Pols, P. (2017). <i>The Unified Kill Chain</i>. Cyber Security Academy. (White paper.)",
  "MITRE. (2024). <i>D3FEND knowledge graph of cybersecurity countermeasures</i>. MITRE Corporation. https://d3fend.mitre.org",
  "Mandiant. (2024). <i>M-Trends 2024: Special report</i>. Google Cloud. https://www.mandiant.com/m-trends",
  "Verizon. (2024). <i>2024 Data breach investigations report</i>. Verizon Business.",
  "Cybersecurity and Infrastructure Security Agency. (2024). <i>Known exploited vulnerabilities catalog</i>. CISA. https://www.cisa.gov/known-exploited-vulnerabilities-catalog",
  "FIRST. (2022). <i>Traffic Light Protocol (TLP) version 2.0</i>. Forum of Incident Response and Security Teams.",
  "VirusTotal. (2024). <i>YARA documentation</i>. Chronicle / Google Cloud. https://yara.readthedocs.io",
];

export const latexDoc = `% Digital Forensics and Incident Response — 1st Edition (2026)
% Compiled structure mirroring the interactive textbook (13 chapters, 25 figures)
\\documentclass[11pt,a4paper,twoside]{book}
\\usepackage[utf8]{inputenc}\\usepackage[T1]{fontenc}
\\usepackage{lmodern,microtype,graphicx,xcolor,booktabs,amsmath,listings,hyperref,enumitem,geometry}
\\usepackage[style=apa,backend=biber]{biblatex}\\addbibresource{refs.bib}
\\geometry{margin=2.4cm}\\hypersetup{colorlinks,linkcolor=blue!60!black,citecolor=teal}
\\lstset{basicstyle=\\ttfamily\\small,breaklines=true,frame=single,backgroundcolor=\\color{gray!6}}
\\title{Digital Forensics and Incident Response: Enterprise Investigation and Active Defense}
\\author{Course Textbook \\textbar\\ 1st Ed. \\textbar\\ 2026}
\\begin{document}\\maketitle\\tableofcontents
\\part{Foundations, Evidence Handling, and Threat Baselines}
\\chapter{Introduction to DFIR, SOC Operations, and the Incident Lifecycle}
% NIST 800-61, SOC tiers, severity, custody, handler mindset, readiness (Figs.~1--2)
\\chapter{Evidence Handling, Acquisition, and Chain of Custody}
% RFC 3227, blockers, dd/E01/AFF, hashes, ISO 27037, encryption/SSD/carving (Figs.~3--4)
\\chapter{Threat Frameworks and Adversary Tradecraft}
% Kill Chain, Diamond, ATT&CK, Pyramid of Pain, CTI, LotL, hunting, KEV (Figs.~5--6, 21)
\\part{Εγκληματολογική ανάλυση συστημάτων και τηλεμετρία τερματικών}
\\chapter{Windows Dead-Box Forensics: File Systems and Registry}
% NTFS/MFT, ADS, hives, persistence, Shellbags, VSC, links/caches (Figs.~7--8)
\\chapter{Windows Execution Artifacts and Event Log Analysis}
% Prefetch/Shimcache/Amcache, UserAssist/BAM, evtx, 4624/4672, SRUM, lateral (Fig.~9)
\\chapter{Advanced Endpoint Visibility with Sysmon}
% EID atlas, XML tuning, noise control, EDR tampering (Fig.~10)
\\chapter{Live Triage, RAM Capture, and Memory Forensics}
% Triage order, WinPmem/DumpIt/LiME, Volatility 3, malfind, hiberfil (Figs.~11--12)
\\part{Core Infrastructure Services, Network Forensics, and Telemetry}
\\chapter{Core Infrastructure Services Forensics}
% AD/DNS/DHCP/Web/Mail/SSH, cloud identity, AiTM, NTDS.dit (Figs.~13--14, 22)
\\chapter{Network Forensics, Flow Analysis, and Zeek}
% PCAP, Zeek logs, beacons, DNS abuse, JA3/JA4, intel, Arkime, DoH (Fig.~15)
\\chapter{NIDS, Perimeter Telemetry, and Syslog Integration}
% Suricata, rules, syslog/TLS, WEF, FW/VPN/proxy, deception, eve.json (Fig.~16)
\\part{Advanced Detection, Enterprise SIEM, and Active Response}
\\chapter{Enterprise SIEM, Agents, and Correlation}
% Agents, ECS/CIM, chains, KQL/SPL, baselines, SOAR, dashboards (Fig.~17)
\\chapter{Detection Engineering, Sigma, and MISP}
% DaC, Sigma, pySigma, MISP, STIX/TAXII, YARA, emulation (Figs.~18, 23)
\\chapter{Containment, Eradication, Post-Mortems, and Capstone}
% Matrix, krbtgt eviction, remediation, ransomware, disclosure, RCA, reports (Figs.~19--20, 24)
\\appendix\\chapter{Figure Index (Fig.~1--25)}\\chapter{Σύντομοι οδηγοί πεδίου}
\\chapter{Linux Host Forensics Primer (Fig.~25)}\\chapter{Εγχειρίδια ενεργειών IR}
\\chapter{Πρότυπα πεδίου}\\chapter{Χάρτης ATT\\&CK ανά κεφάλαιο}\\chapter{Εργαλεία, σύνολα δεδομένων και γλωσσάρι}
\\printbibliography % Q1/Q2 + standards + practitioner sources, APA 7th
\\end{document}`;

export const searchKeywords: { t: string; id: string; k: string }[] = [
  { t: "NIST 800-61 PICERL SOC tier triage severity chain of custody", id: "ch1", k: "concept" },
  { t: "RFC 3227 volatility write blocker dd E01 AFF dc3dd hash sha256 ISO 27037", id: "ch2", k: "concept" },
  { t: "kill chain diamond model ATT&CK pyramid of pain CTI STIX TLP navigator LotL LOLBAS", id: "ch3", k: "concept" },
  { t: "NTFS MFT ADS registry Run keys persistence shellbags jump list shadow copy VSS timestomp", id: "ch4", k: "concept" },
  { t: "prefetch shimcache amcache userassist BAM 4624 4625 logon type 4672 1102 evtx", id: "ch5", k: "concept" },
  { t: "sysmon event id 1 3 6 8 10 22 processGuid command line XML SwiftOnSecurity", id: "ch6", k: "concept" },
  { t: "live triage RAM WinPmem DumpIt LiME volatility pslist psscan malfind lsass", id: "ch7", k: "concept" },
  { t: "active directory kerberoast DCSync 4768 4769 4662 DNS DHCP web apache mail exchange SSH auth.log", id: "ch8", k: "concept" },
  { t: "wireshark tshark zeek conn.log dns.log beacon jitter JA3 JA4 DGA fast flux", id: "ch9", k: "concept" },
  { t: "suricata TAP SPAN IDS IPS rule eve.json syslog rsyslog TLS 6514 firewall VPN proxy XFF", id: "ch10", k: "concept" },
  { t: "SIEM elastic beats wazuh splunk ECS CIM correlation KQL SPL EQL dashboard baseline", id: "ch11", k: "concept" },
  { t: "detection as code sigma pySigma MISP galaxy STIX TAXII atomic red team", id: "ch12", k: "concept" },
  { t: "containment isolation krbtgt golden ticket eradication post-mortem RCA report capstone", id: "ch13", k: "concept" },
  { t: "forensic readiness litigation hold spoliation Kovel counsel tabletop exercise", id: "ch1", k: "concept" },
  { t: "BitLocker TRIM SSD VMDK ssdeep TLSH carving foremost seizure Faraday", id: "ch2", k: "concept" },
  { t: "TaHiTI PEAK hunting loop Unified Kill Chain KEV EPSS D3FEND", id: "ch3", k: "concept" },
  { t: "LNK recycle bin thumbcache ActivitiesCache DPAPI vault USN deletejournal cleaner", id: "ch4", k: "concept" },
  { t: "Defender ASR WDAC AppLocker SRUM RDP bitmap cache BITS PsExec WMI WinRM lateral", id: "ch5", k: "concept" },
  { t: "EID atlas BYOVD tamper protection EDR triage named pipe WMI event", id: "ch6", k: "concept" },
  { t: "hiberfil pagefile MEMORY.DMP hypervisor vmem memfd LD_PRELOAD", id: "ch7", k: "concept" },
  { t: "Entra M365 UAL Okta AiTM Evilginx token FIDO2 NTDS.dit silver ticket BloodHound PingCastle", id: "ch8", k: "concept" },
  { t: "intel framework Arkime Moloch NetFlow IPFIX SiLK nfdump tcpflow DoH", id: "ch9", k: "concept" },
  { t: "WEF wecutil subscription WinRM honeytoken canary sinkhole dataset filestore", id: "ch10", k: "concept" },
  { t: "SOAR MTTD MTTR MTTC ES|QL advanced hunting automation enrichment", id: "ch11", k: "concept" },
  { t: "YARA LOKI aggregation count near", id: "ch12", k: "concept" },
  { t: "ransomware decryptor No More Ransom GDPR NIS2 SEC CIRCIA war room disclosure", id: "ch13", k: "concept" },
  { t: "linux ext4 debugfs journalctl ausearch cron systemd authorized_keys docker", id: "appendix-linux", k: "appendix" },
  { t: "playbook BEC webshell insider custody template triage card report skeleton", id: "playbooks", k: "appendix" },
  { t: "technique map cross reference", id: "attck-map", k: "appendix" },
  { t: "tools CFReDS Mordor BOTS abuse.ch glossary ALEAPP", id: "tools", k: "appendix" },
];
