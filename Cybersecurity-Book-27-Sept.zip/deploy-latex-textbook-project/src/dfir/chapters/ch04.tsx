import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>4.1 Εσωτερική δομή NTFS: MFT, $LogFile και $UsnJrnl</h4>
    <p>
      Στο NTFS, κάθε αρχείο αντιστοιχεί σε μια εγγραφή του <b>Master File Table ($MFT)</b>: μια δομή 1.024 byte με χαρακτηριστικά όπως $STANDARD_INFORMATION —χρονικές σημάνσεις και σημαίες—, $FILE_NAME —όνομα, γονική εγγραφή και χρονικές σημάνσεις— και $DATA —ενσωματωμένο περιεχόμενο ή λίστα περιοχών δίσκου— μαζί με στοιχεία ασφάλειας και ευρετηρίου (Σχ. 7). Οι λεπτομέρειες έχουν μεγάλη εγκληματολογική αξία. Αρχεία μικρότερα περίπου από 700 byte μπορεί να αποθηκεύονται μέσα στην ίδια την MFT και να ανακτώνται μετά τη «διαγραφή» τους, έως ότου επαναχρησιμοποιηθεί η εγγραφή. Επιπλέον, οι χρονικές σημάνσεις $FILE_NAME αλλάζουν κυρίως κατά τη μετονομασία ή μετακίνηση. Έτσι, εργαλεία αλλοίωσης χρόνου που επεμβαίνουν μόνο στο $STANDARD_INFORMATION αφήνουν εμφανή ασυνέπεια. Το $LogFile καταγράφει συναλλαγές μεταδεδομένων για ανάκαμψη από σφάλματα, ενώ το $UsnJrnl αποθηκεύει τους λόγους αλλαγής ανά αρχείο και λειτουργεί ως ενσωματωμένη ροή δραστηριότητας.
    </p>
    <Figure
      id="fig-mft"
      label="Fig. 7 · MFT record anatomy (1024 bytes, vector)"
      caption={
        <>
          <b>Fig. 7.</b> A file is a bag of attributes, not a blob. Timestomp detection: compare $SI against $FN
          created times — divergence proves tampering. Deleted ≠ gone: unallocated MFT entries retain attributes
          until reallocated.
        </>
      }
    >
      <svg viewBox="0 0 720 220" className="w-full h-auto" role="img" aria-label="MFT record">
        <text x="10" y="20" fontSize="11" fontWeight="800" fill="#0f1c2e">MFT RECORD #48210 · 1024 bytes · IN-USE / DELETED flag @ offset 0x16</text>
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="110" height="90" rx="8" fill="#0f1c2e" />
          <text x="65" y="52" fill="#fbbf24">HEADER 42B</text>
          <text x="65" y="68" fill="#cbd5e1" fontWeight="400">LSN · seq · links</text>
          <text x="65" y="84" fill="#cbd5e1" fontWeight="400">flags: in-use?</text>
          <text x="65" y="100" fill="#fbbf24" fontSize="9">deleted ≠ wiped</text>
          <rect x="128" y="30" width="140" height="90" rx="8" fill="#0e7490" />
          <text x="198" y="52" fill="#fff">$STANDARD_INFO</text>
          <text x="198" y="68" fill="#e0f2fe" fontWeight="400">C · M · E · A times</text>
          <text x="198" y="84" fill="#e0f2fe" fontWeight="400">timestomp target</text>
          <text x="198" y="100" fill="#fef08a" fontSize="9">trust: LOW</text>
          <rect x="276" y="30" width="140" height="90" rx="8" fill="#166534" />
          <text x="346" y="52" fill="#fff">$FILE_NAME ×n</text>
          <text x="346" y="68" fill="#dcfce7" fontWeight="400">name + parent MFR</text>
          <text x="346" y="84" fill="#dcfce7" fontWeight="400">own C/M/E/A</text>
          <text x="346" y="100" fill="#bbf7d0" fontSize="9">trust: HIGH</text>
          <rect x="424" y="30" width="150" height="90" rx="8" fill="#b45309" />
          <text x="499" y="52" fill="#fff">$DATA</text>
          <text x="499" y="68" fill="#fef3c7" fontWeight="400">resident (&lt;~700B)</text>
          <text x="499" y="84" fill="#fef3c7" fontWeight="400">or run-list extents</text>
          <text x="499" y="100" fill="#fff" fontSize="9">+ ADS names here</text>
          <rect x="582" y="30" width="128" height="90" rx="8" fill="#7c3aed" />
          <text x="646" y="52" fill="#fff">OTHERS</text>
          <text x="646" y="68" fill="#ede9fe" fontWeight="400">$SECURITY</text>
          <text x="646" y="84" fill="#ede9fe" fontWeight="400">$OBJECT_ID</text>
          <text x="646" y="100" fill="#ede9fe" fontWeight="400">$REPARSE…</text>
        </g>
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="132" width="345" height="52" rx="8" fill="#f1f5f9" stroke="#0e7490" strokeWidth="1.5" />
          <text x="182" y="152" fill="#0e7490">$LogFile — metadata transaction journal</text>
          <text x="182" y="168" fill="#475569" fontWeight="400">replay recent create/delete/rename ops</text>
          <rect x="365" y="132" width="345" height="52" rx="8" fill="#f1f5f9" stroke="#166534" strokeWidth="1.5" />
          <text x="537" y="152" fill="#166534">$UsnJrnl — per-file change reasons</text>
          <text x="537" y="168" fill="#475569" fontWeight="400">DATA_EXTEND · RENAME · CLOSE …</text>
        </g>
        <text x="360" y="204" textAnchor="middle" fontSize="11" fill="#64748b">MFT + $LogFile + $UsnJrnl triangulate file activity even after deletion</text>
      </svg>
    </Figure>
    <h4>4.2 Εναλλακτικές ροές δεδομένων (Alternate Data Streams — ADS)</h4>
    <p>
      Τα αρχεία NTFS μπορούν να περιέχουν περισσότερα από ένα χαρακτηριστικά $DATA: την προεπιλεγμένη ανώνυμη ροή και πρόσθετες <b>εναλλακτικές ροές δεδομένων</b>, όπως <span className="mono text-sm">file.txt:hidden.exe</span>. Το περιεχόμενο ADS δεν εμφανίζεται στην Εξερεύνηση ούτε στις περισσότερες απλές λίστες καταλόγων, δεν αυξάνει το αναφερόμενο μέγεθος του αρχείου και διατηρείται κατά την αντιγραφή εντός NTFS. Γι’ αυτό αποτελεί κλασική τεχνική απόκρυψης T1564.004. Ο εντοπισμός είναι απλός όταν γνωρίζουμε τι αναζητούμε: <span className="mono text-sm">dir /r</span>, PowerShell <span className="mono text-sm">Get-Item -Stream *</span> ή αναλυτές MFT που απαριθμούν όλα τα $DATA. Υπάρχουν και νόμιμες χρήσεις, όπως το Zone.Identifier για ληφθέντα αρχεία. Επομένως, εύρημα δεν είναι απλώς η ύπαρξη ADS, αλλά το ύποπτο περιεχόμενο —για παράδειγμα, εκτελέσιμο κρυμμένο μέσα στη ροή ενός εγγράφου.
    </p>
    <h4>4.3 Αρχιτεκτονική Μητρώου: οι κρίσιμες κυψέλες</h4>
    <p>
      Το Μητρώο των Windows αποτελείται από αρχεία κυψελών, καθένα με διαφορετική εγκληματολογική αξία. Η <b>SYSTEM</b> περιέχει υπηρεσίες, ιστορικό συσκευών USB μέσω USBSTOR και στοιχεία τερματισμού, όπως ShutdownTime. Η <b>SOFTWARE</b> καταγράφει εγκατεστημένα προγράμματα, προφίλ δικτύου και σημεία αυτόματης εκκίνησης. Η <b>SAM</b> περιέχει αποτυπώματα τοπικών λογαριασμών και απαιτεί αυξημένη προστασία. Το <b>NTUSER.DAT</b> κάθε χρήστη καταγράφει Run keys, RecentDocs, πληκτρολογημένες διαδρομές και ιστορικό κοινών παραθύρων διαλόγου. Συναφείς κυψέλες Amcache και Shimcache τεκμηριώνουν εκτέλεση, όπως αναλύεται στο Κεφάλαιο 5. Οι κυψέλες είναι συναλλακτικές, άρα τα LOG1/LOG2 πρέπει να συλλέγονται μαζί τους για σωστή ανάλυση μη ολοκληρωμένων αλλαγών. Διαγραμμένα κλειδιά μπορεί επίσης να παραμένουν σε μη εκχωρημένα κελιά μέχρι να αντικατασταθούν.
    </p>
    <DataTable
      head={["Hive (file)", "Location", "Highest-value keys"]}
      rows={[
        ["SYSTEM", "Windows\\System32\\config\\SYSTEM", "Services, USBSTOR, ControlSet\\ShutdownTime, AppCompatCache"],
        ["SOFTWARE", "Windows\\System32\\config\\SOFTWARE", "Run/RunOnce, Uninstall, NetworkList profiles"],
        ["SAM", "Windows\\System32\\config\\SAM", "Local users, groups, cached hashes (V)"],
        ["NTUSER.DAT", "Users\\<u>\\NTUSER.DAT", "Run, RecentDocs, TypedPaths, UserAssist (ROT13)"],
        ["UsrClass.dat", "Users\\<u>\\AppData\\Local\\Microsoft\\Windows", "Shellbags, Jump List AppIDs, file associations"],
      ]}
    />
    <h4>4.4 Έλεγχος μηχανισμών παραμονής: Run keys, εργασίες και υπηρεσίες</h4>
    <p>
      Οι αντίπαλοι επιδιώκουν παραμονή στα σημεία όπου τα Windows εκκινούν αυτόματα κώδικα, όπως T1547, T1053 και T1543. Ο έλεγχος πρέπει να γίνεται κατά προτεραιότητα: Run/RunOnce σε HKLM και HKCU, προγραμματισμένες εργασίες μέσω XML και Μητρώου, υπηρεσίες στη SYSTEM\Services με ασυνήθιστο ImagePath, συνδρομές WMI, βοηθήματα Winlogon, πρόσθετα Office και, σε μεγαλύτερο βάθος, πάροχοι LSA. Η συστηματική απαρίθμηση με Sysinternals Autoruns, VirusTotal και σύγκριση hash με γνωστές βασικές γραμμές παραμένει ο ταχύτερος αρχικός έλεγχος σε εταιρικό περιβάλλον. Κάθε ανυπόγραφη καταχώριση ή σπάνια διαδρομή αποτελεί αφετηρία διερεύνησης. Το Σχήμα 8 συνδέει τα συνηθέστερα σημεία παραμονής με τις αντίστοιχες κυψέλες.
    </p>
    <Figure
      id="fig-persist"
      label="Fig. 8 · Windows persistence map"
      caption={
        <>
          <b>Fig. 8.</b> Audit top-down by prevalence: Run keys and tasks catch ~80% of commodity persistence; the
          lower tier catches APT-grade mechanisms. Each entry names its hive so dead-box examiners know which file to
          parse.
        </>
      }
    >
      <svg viewBox="0 0 720 240" className="w-full h-auto" role="img" aria-label="Persistence map">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="10" width="225" height="96" rx="8" fill="#be123c" />
          <text x="122" y="30" fill="#fff">RUN / RUNONCE KEYS</text>
          <text x="122" y="47" fill="#ffe4e6" fontWeight="400">HKLM + HKCU …\Run</text>
          <text x="122" y="63" fill="#ffe4e6" fontWeight="400">SOFTWARE + NTUSER.DAT</text>
          <text x="122" y="82" fill="#fff" fontSize="9">T1547.001 · check FIRST</text>
          <rect x="247" y="10" width="226" height="96" rx="8" fill="#b45309" />
          <text x="360" y="30" fill="#fff">SCHEDULED TASKS</text>
          <text x="360" y="47" fill="#fef3c7" fontWeight="400">Tasks XML + registry</text>
          <text x="360" y="63" fill="#fef3c7" fontWeight="400">SOFTWARE\Microsoft\…\TaskCache</text>
          <text x="360" y="82" fill="#fff" fontSize="9">T1053 · hidden + COM hijack</text>
          <rect x="485" y="10" width="225" height="96" rx="8" fill="#0e7490" />
          <text x="597" y="30" fill="#fff">SERVICES + DRIVERS</text>
          <text x="597" y="47" fill="#e0f2fe" fontWeight="400">SYSTEM\CurrentControlSet\Services</text>
          <text x="597" y="63" fill="#e0f2fe" fontWeight="400">ImagePath + Start type</text>
          <text x="597" y="82" fill="#fff" fontSize="9">T1543 · Type=kernel?</text>
          <rect x="10" y="114" width="225" height="88" rx="8" fill="#7c3aed" />
          <text x="122" y="134" fill="#fff">WMI + WINLOGON</text>
          <text x="122" y="151" fill="#ede9fe" fontWeight="400">Event subscriptions</text>
          <text x="122" y="167" fill="#ede9fe" fontWeight="400">Userinit / Shell / Notify</text>
          <text x="122" y="186" fill="#fff" fontSize="9">T1546 · fileless-friendly</text>
          <rect x="247" y="114" width="226" height="88" rx="8" fill="#166534" />
          <text x="360" y="134" fill="#fff">OFFICE / BROWSER</text>
          <text x="360" y="151" fill="#dcfce7" fontWeight="400">Add-ins · extensions</text>
          <text x="360" y="167" fill="#dcfce7" fontWeight="400">NTUSER + UsrClass</text>
          <text x="360" y="186" fill="#fff" fontSize="9">T1137 · T1176</text>
          <rect x="485" y="114" width="225" height="88" rx="8" fill="#0f1c2e" />
          <text x="597" y="134" fill="#fbbf24">LSA / SSP / NETSH</text>
          <text x="597" y="151" fill="#cbd5e1" fontWeight="400">Security Packages</text>
          <text x="597" y="167" fill="#cbd5e1" fontWeight="400">SYSTEM · admin-only</text>
          <text x="597" y="186" fill="#fbbf24" fontSize="9">T1547.005 · credential theft</text>
        </g>
        <text x="360" y="224" textAnchor="middle" fontSize="11" fill="#64748b">Καταγράψτε πρώτα τη γνωστή ορθή γραμμή βάσης· διερευνήστε ανυπόγραφες, πρόσφατες εγγραφές και εκτελέσιμα σε ασυνήθιστες διαδρομές</text>
      </svg>
    </Figure>
    <h4>4.5 Ανασύνθεση δραστηριότητας χρήστη: Shellbags, Jump Lists και RecentDocs</h4>
    <p>
      Ακόμη και όταν λείπει το περιεχόμενο ενός αρχείου, τα Windows αποτυπώνουν τη συμπεριφορά του χρήστη. Τα <b>Shellbags</b> στο UsrClass.dat καταγράφουν φακέλους που προβλήθηκαν στην Εξερεύνηση, ακόμη και αν βρίσκονταν σε USB που έχει αφαιρεθεί ή σε διαδρομή που διαγράφηκε. Τα <b>Jump Lists</b> στο AutomaticDestinations διατηρούν πρόσφατα αρχεία ανά εφαρμογή, πλήθος ανοίγματος και χρονικές σημάνσεις. Το <b>RecentDocs</b> στο NTUSER.DAT καταγράφει πρόσφατα έγγραφα ανά επέκταση. Μαζί απαντούν στο ερώτημα «άνοιξε ο χρήστης το ωφέλιμο φορτίο και τι περιηγήθηκε στη συνέχεια;», δημιουργώντας μια ανθρώπινη χρονογραμμή που επιβεβαιώνει ή αντικρούει τα τεχνουργήματα εκτέλεσης του Κεφαλαίου 5.
    </p>
    <h4>4.6 Σκιώδη αντίγραφα τόμου: ιστορική αναδρομή για τον αναλυτή</h4>
    <p>
      Τα στιγμιότυπα <b>Volume Shadow Copy Service (VSS)</b> αποθηκεύουν προηγούμενες καταστάσεις του τόμου σε επίπεδο μπλοκ: παλαιότερες κυψέλες Μητρώου, αρχεία πριν από τη διαγραφή και πρωτότυπα πριν από την κρυπτογράφηση. Προσαρτήστε τα σκιώδη αντίγραφα μόνο για ανάγνωση και συγκρίνετέ τα με τον ενεργό τόμο. Σε περιστατικά ransomware συχνά αποκαλύπτουν ανακτήσιμα πρωτότυπα, ενώ Run keys που «καθαρίστηκαν» μπορεί να επανεμφανιστούν σε παλαιότερες κυψέλες. Οι αντίπαλοι γνωρίζουν την αξία τους: η εντολή <span className="mono text-sm">vssadmin delete shadows</span> αποτελεί ένδειξη υψηλής αξιοπιστίας για κακόβουλη ενέργεια T1490 και συχνά είναι από τις πρώτες καταστροφικές πράξεις που πρέπει να αναζητηθούν.
    </p>
    <Callout color="emerald">
      <b>Dead-box workflow (memorize).</b> Image → verify hashes → working copy → Χρονογραμμή MFT → persistence audit →
      user-activity corroboration → VSC diff → execution artifacts (Ch. 5). Never skip straight to "suspicious files"
      — timelines first, conclusions last.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — rapid persistence + ADS screen (live triage or mounted image)"
        code={`# Έλεγχος ADS (T1564.004): any executable stream on a document is a finding
Get-ChildItem C:\\Users -Recurse -File -ErrorAction SilentlyContinue |
  ForEach-Object { Get-Item $_.FullName -Stream * -ErrorAction SilentlyContinue |
    Where-Object { $_.Stream -ne ':$DATA' -and $_.Stream -ne 'Zone.Identifier' } |
    Select-Object @{n='File';e={$_.PSParentPath}}, Stream, Length }

# Run-key audit (HKLM + all loaded HKCU)
'Registry::HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run',
'Registry::HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run' |
  ForEach-Object { Get-ItemProperty $_ -ErrorAction SilentlyContinue }

# Shadow copies present? (absence after incident = T1490 hunt)
vssadmin list shadows`}
      />
    </div>
    <h4>4.7 Συντομεύσεις, Κάδος, προσωρινές μνήμες και χρονογραμμές: απόδειξη γνώσης αρχείου</h4>
    <p>
      Τέσσερα τεχνουργήματα μπορούν να αποδείξουν ότι ένας χρήστης γνώριζε την ύπαρξη αρχείου —κρίσιμο στοιχείο σε διαρροές και υποθέσεις εσωτερικής απειλής. Οι συντομεύσεις <b>.lnk</b> καταγράφουν πλήρη διαδρομή στόχου, σειριακό αριθμό τόμου, χρονικές σημάνσεις και αναγνωριστικό συστήματος, ακόμη και για αποσυνδεδεμένο USB ή κοινόχρηστο πόρο. Ο <b>Κάδος Ανακύκλωσης</b> συνδυάζει μεταδεδομένα $I —αρχική διαδρομή και χρόνο διαγραφής— με περιεχόμενο $R. Η <b>προσωρινή μνήμη μικρογραφιών</b> διατηρεί εικόνες προεπισκόπησης μετά τη διαγραφή των πρωτοτύπων, ενώ το <b>Windows Timeline</b> στο ActivitiesCache.db προσθέτει δραστηριότητα εφαρμογής, αρχείου και διάρκειας μεταξύ συσκευών. Συναφώς, κωδικοί περιηγητή και θυρίδες Credential Manager προστατεύονται με DPAPI και συνήθως ανακτώνται μόνο με το κύριο κλειδί του χρήστη ή από ενεργή, συνδεδεμένη συνεδρία.
    </p>
    <DataTable
      head={["Artifact", "Proves", "Location"]}
      rows={[
        [".lnk shortcuts", "File opened; target path + volume + machine", "Recent, Start Menu, per-user link dirs"],
        ["$I / $R pairs", "What was deleted, from where, when", "$Recycle.Bin\\<SID> per volume"],
        ["Thumbcache", "Images viewed (post-deletion)", "Explorer\\ThumbCacheToDelete / thumbcache_*.db"],
        ["ActivitiesCache.db", "App/file engagement across devices", "ConnectedDevicesPlatform\\ActivitiesCache.db"],
        ["DPAPI blobs + Vault", "Stored secrets existed (needs masterkey)", "Protect\\<SID>, AppData\\Local\\Microsoft\\Vault"],
      ]}
    />
    <h4>4.8 Καταστροφή ημερολογίων και εργαλεία καθαρισμού: όταν η χρονογραμμή αντιστέκεται</h4>
    <p>
      Οι αντίπαλοι επιτίθενται και στην ίδια τη χρονογραμμή. Η εντολή <span className="mono text-sm">fsutil usn deletejournal</span> διαγράφει το $UsnJrnl, όμως τα Windows δημιουργούν νέο ημερολόγιο με διαφορετικό αναγνωριστικό και χρόνο δημιουργίας. Αυτή η ασυνέχεια είναι το ίχνος: συγκρίνετε το ενεργό αναγνωριστικό με αντίγραφα μέσα σε VSS και αντιμετωπίστε ημερολόγιο νεότερο από την εγκατάσταση του λειτουργικού ως πιθανή καταστροφή μέχρι να αποδειχθεί το αντίθετο. Η επαναφορά του $LogFile, η διαγραφή Prefetch και εργαλεία όπως CCleaner ή BleachBit αφήνουν δικά τους ίχνη εκτέλεσης και αφύσικα ομοιόμορφα κενά στις χρονικές σημάνσεις. Εξετάστε πρώτα το ημερολόγιο, καταγράψτε το αναγνωριστικό του και συγκρίνετε τα σκιώδη αντίγραφα πριν εμπιστευθείτε οποιαδήποτε χρονογραμμή αρχείων.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — έλεγχος ακεραιότητας USN journal σε ενεργό σύστημα ή προσαρτημένη εικόνα"
        code={`fsutil usn queryjournal C:   # record UsnJournalID + lowest/highest USN\n# Compare UsnJournalID across shadow copies: differing IDs = journal was deleted & recreated\n# Rule: journal creation newer than OS install date + incident window = T1070 tamper lead`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 4.1 · Χρονογραμμή MFT και εντοπισμός timestomp (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Αναλύστε την παρεχόμενη MFT σε CSV και δημιουργήστε χρονογραμμή περιορισμένη στο παράθυρο του περιστατικού, με περιθώριο δύο ωρών.</li>
      <li>Επισημάνετε αποκλίσεις χρονικών σημάνσεων $SI/$FN μεγαλύτερες από ένα δευτερόλεπτο και καταγράψτε κάθε αποτέλεσμα ως ύποπτο timestomp μαζί με τον αριθμό MFR.</li>
      <li>Συσχετίστε τα σημαντικότερα αποτελέσματα με τους λόγους του $UsnJrnl και συντάξτε την παράγραφο δραστηριότητας αρχείων της αναφοράς.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 4.2 · Έλεγχος μηχανισμών παραμονής και VSC (60 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Ελέγξτε όλες τις θέσεις του Σχήματος 8 στην εργαστηριακή εικόνα και ταξινομήστε κάθε εγγραφή ως γνωστή νόμιμη, άγνωστη ή κακόβουλη.</li>
      <li>Καταγράψτε τα σκιώδη αντίγραφα, προσαρτήστε το παλαιότερο και συγκρίνετε τα Run keys και μία διαδρομή ωφέλιμου φορτίου με την ενεργή κατάσταση.</li>
      <li>Δημιουργήστε πίνακα ευρημάτων παραμονής με θέση, τιμή, πρώτη εμφάνιση, συμπέρασμα και πειστήριο.</li>
    </ol>
  </>
);

export const ch04: Κεφάλαιο = {
  id: "ch4",
  num: 4,
  title: "Στατική Εγκληματολογική Ανάλυση Windows — Συστήματα Αρχείων και Μητρώο",
  subtitle: "NTFS/MFT · ADS · Κυψέλες Μητρώου · Μηχανισμοί παραμονής · Shellbags · Σκιώδη αντίγραφα",
  badge: "Tier 2 · Εγκληματολογία συστημάτων",
  time: "9–11 ώρες · περίπου 40 σελίδες",
  outcomes:
    "Αναλύετε χαρακτηριστικά και ημερολόγια MFT· εντοπίζετε απόκρυψη ADS και αλλοίωση χρονικών σημάνσεων· εξετάζετε τις βασικές κυψέλες του Μητρώου· ελέγχετε συστηματικά μηχανισμούς παραμονής· ανασυνθέτετε δραστηριότητα χρήστη· και αξιοποιείτε σκιώδη αντίγραφα.",
  body,
  labTitle: "Πρακτική Άσκηση 4.1 · Χρονογραμμή MFT και εντοπισμός timestomp + Άσκηση 4.2 · Έλεγχος παραμονής και VSC",
  labsBody,
  workshop: {
    title: "Ροή στατικής ανάλυσης: χρονογραμμή MFT, έλεγχος ADS και αρχική εξέταση κυψελών",
    env: ["Εικονική μηχανή Windows για τον εξεταστή", "MFTECmd και Registry Explorer", "Εργαστηριακή εικόνα προσαρτημένη μόνο για ανάγνωση"],
    tabs: [
      {
        id: "mft",
        label: "Χρονογραμμή MFT",
        steps: [
          {
            n: "1",
            title: "Αναλύστε την $MFT σε CSV",
            desc: "Το MFTECmd εξάγει κάθε χαρακτηριστικό, μαζί με τις χρονικές σημάνσεις $FN και τα ονόματα ADS.",
            code: [
              {
                title: "PowerShell — MFTECmd",
                text: `E:\\Tools\\MFTECmd.exe -f "F:\\$MFT" --csv E:\\cases\\041 --csvf mft.csv\nImport-Csv E:\\cases\\041\\mft.csv | Measure-Object | Select-Object Count`,
              },
            ],
          },
          {
            n: "2",
            title: "Περιορίστε το χρονικό παράθυρο και αναζητήστε timestomp",
            desc: "Η απόκλιση μεταξύ $SI Created και $FN Created ελέγχεται αυτοματοποιημένα· ο απλός οπτικός έλεγχος δεν αποτελεί επαρκή επαγγελματική πρακτική.",
            code: [
              {
                title: "PowerShell — timestomp screen",
                text: `$m = Import-Csv E:\\cases\\041\\mft.csv\n# incident window filter (adjust to case)\n$m | Where-Object { $_.Created0 -ge '2026-09-20' -and $_.Created0 -le '2026-09-22' } |\n  Export-Csv E:\\cases\\041\\mft-window.csv -NoTypeInformation\n# $SI/$FN divergence\n$m | Where-Object { $_.Created0 -ne $_.FNCreated0 } |\n  Select-Object EntryNumber, FileName, Created0, FNCreated0 | Format-Table -AutoSize`,
              },
            ],
            expected: "σύντομη λίστα αποκλινόντων MFR· κάθε εγγραφή αποτελεί ένδειξη προς διερεύνηση και όχι ακόμη τελικό συμπέρασμα",
          },
        ],
      },
      {
        id: "ads",
        label: "Έλεγχος ADS",
        steps: [
          {
            n: "3",
            title: "Καταγράψτε όλες τις επώνυμες ροές",
            desc: "Αφαιρέστε τον αναμενόμενο θόρυβο του Zone.Identifier. Το ουσιαστικό σήμα είναι τα εκτελέσιμα μέσα σε ροές.",
            code: [
              {
                title: "PowerShell — απογραφή ροών",
                text: `$m | Where-Object { $_.ADS -eq 'True' } | Select-Object EntryNumber, FileName | Format-Table -AutoSize\n# targeted confirmation on disk (mounted image F:)\nGet-Item 'F:\\Users\\*' -Stream * -ErrorAction SilentlyContinue | Where-Object { $_.Stream -notmatch 'DATA|Zone' }`,
              },
            ],
          },
        ],
      },
      {
        id: "reg",
        label: "Αρχική εξέταση κυψελών",
        steps: [
          {
            n: "4",
            title: "Εξαγάγετε τις κυψέλες και τα transaction logs",
            desc: "Οι μη καθαρά κλεισμένες κυψέλες αναλύονται ελλιπώς χωρίς LOG1/LOG2. Αντιγράφετε πάντοτε και τα τρία αρχεία.",
            code: [
              {
                title: "PowerShell — συλλογή κυψελών",
                text: `mkdir E:\\cases\\041\\hives\nCopy-Item 'F:\\Windows\\System32\\config\\SYSTEM*' E:\\cases\\041\\hives\\\nCopy-Item 'F:\\Windows\\System32\\config\\SOFTWARE*' E:\\cases\\041\\hives\\\nCopy-Item 'F:\\Users\\*\\NTUSER.DAT*' E:\\cases\\041\\hives\\ -Force\nGet-FileHash E:\\cases\\041\\hives\\* -Algorithm SHA256 | Export-Csv E:\\cases\\041\\hives\\hashes.csv`,
              },
            ],
          },
          {
            n: "5",
            title: "Εξετάστε Run keys, USBSTOR και ShutdownTime",
            desc: "Απαντήστε σε τρία ερωτήματα: τι διατηρεί παραμονή, ποιο USB συνδέθηκε και πότε τερματίστηκε τελευταία φορά ομαλά το σύστημα.",
            note: "Παραδοτέο: mft-window.csv, αποτελέσματα timestomp, απογραφή ADS, hash κυψελών και σημειώσεις διαλογής. Ανοίξτε τις εξαγόμενες κυψέλες στο Registry Explorer για τη λεπτομερή ανάλυση της Άσκησης 4.2.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> χαρακτηριστικά MFT (§4.1) · ADS (§4.2) · κυψέλες (§4.3) → χάρτης παραμονής (§4.4) → απόδειξη εκτέλεσης (Κεφ. 5). Παραδοτέο: χρονογραμμή περιορισμένη στο κρίσιμο παράθυρο και σύνολο κυψελών με hash, έτοιμο για αναλυτική επεξεργασία.
      </>
    ),
  },
  quiz: [
    { q: "Τι σημαίνει ότι το $DATA είναι resident;", o: ["Το περιεχόμενο είναι κρυπτογραφημένο", "Το περιεχόμενο βρίσκεται μέσα στην ίδια την εγγραφή MFT των 1.024 byte", "Το περιεχόμενο αποθηκεύεται στο cloud", "Το αρχείο δεν μπορεί να ανακτηθεί"], a: 1, e: "Μικρά αρχεία, συνήθως κάτω από περίπου 700 byte, μπορούν να χωρέσουν εξ ολοκλήρου στην εγγραφή MFT." },
    { q: "Γιατί οι χρονικές σημάνσεις $FILE_NAME θεωρούνται συχνά πιο αξιόπιστες από τις $STANDARD_INFORMATION;", o: ["Είναι κρυπτογραφημένες", "Αλλάζουν κυρίως σε μετονομασία ή μετακίνηση, κάτι που παραλείπουν πολλά εργαλεία timestomp", "Αποθηκεύονται εκτός δίσκου", "Δεν μπορούν να διαβαστούν"], a: 1, e: "Η απόκλιση μεταξύ $SI και $FN αποτελεί χαρακτηριστική ένδειξη αλλοίωσης χρονικών σημάνσεων." },
    { q: "Τι υποδηλώνει συνήθως ένα εκτελέσιμο ADS συνδεδεμένο με έγγραφο Word;", o: ["Φυσιολογική λειτουργία του Office", "Απόκρυψη T1564.004 που απαιτεί διερεύνηση", "Βλάβη δίσκου", "Ενημέρωση Windows"], a: 1, e: "Το Zone.Identifier είναι συνήθως νόμιμο ADS· ένα εκτελέσιμο μέσα σε εναλλακτική ροή εγγράφου δεν είναι." },
    { q: "Πού βρίσκεται το ιστορικό συσκευών USB στα Windows;", o: ["Στο RecentDocs του NTUSER.DAT", "Στο USBSTOR της κυψέλης SYSTEM", "Στο bitmap της MFT", "Στο pagefile"], a: 1, e: "Η διαδρομή SYSTEM\ControlSet\Enum\USBSTOR καταγράφει συσκευές αποθήκευσης που συνδέθηκαν." },
    { q: "Τι υποδηλώνει η εκτέλεση vssadmin delete shadows μέσα στο χρονικό παράθυρο ενός περιστατικού;", o: ["Συνήθη συντήρηση", "Καταστροφή σκιωδών αντιγράφων T1490 που απαιτεί άμεση έρευνα", "Επιτυχημένη λήψη αντιγράφου", "Ανασυγκρότηση δίσκου"], a: 1, e: "Οι επιτιθέμενοι διαγράφουν σκιώδη αντίγραφα για να εμποδίσουν την ανάκαμψη· οι διαχειριστές το κάνουν σπάνια κατά τη διάρκεια περιστατικού." },
    { q: "Σε ποιο ερώτημα απαντούν κυρίως τα Shellbags;", o: ["Ποιοι φάκελοι προβλήθηκαν, ακόμη και αν διαγράφηκαν ή αφαιρέθηκαν", "Ποιο είναι το PIN του BitLocker", "Ποιοι είναι οι κωδικοί Wi-Fi", "Ποια είναι η θερμοκρασία της CPU"], a: 0, e: "Τα Shellbags διατηρούν στο UsrClass.dat το ιστορικό περιήγησης φακέλων της Εξερεύνησης." },
  ],
};
