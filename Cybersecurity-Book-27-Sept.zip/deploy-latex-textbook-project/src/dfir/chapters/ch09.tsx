import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>9.1 Βασικές αρχές ανάλυσης πακέτων: Wireshark και tshark</h4>
    <p>
      Η καταγραφή πακέτων <b>PCAP</b> αποτελεί την πληρέστερη πηγή για όσα διέρχονται από το δίκτυο: περιέχει ολόκληρα πλαίσια με χρονικές σημάνσεις υψηλής ακρίβειας, υποστηρίζει φίλτρα εμφάνισης και επιτρέπει ανάλυση σε επίπεδο πεδίου. Το <b>Wireshark</b> προσφέρει διαδραστική αποκωδικοποίηση, στατιστικά συνομιλιών και αποκρυπτογράφηση TLS όταν παρέχονται τα κατάλληλα κλειδιά. Το <b>tshark</b> είναι το αντίστοιχο εργαλείο γραμμής εντολών για αυτοματοποιημένη εξαγωγή μεγάλου όγκου, όπως <span className="mono text-sm">-T fields -e dns.qry.name</span>. Η ορθή συλλογή απαιτεί καταγραφή διεπαφής, snaplen, φίλτρου και hash κατά τη λήψη. Όπου η πιστότητα έχει αποδεικτική σημασία, προτιμώνται TAP αντί SPAN. Τα PCAP με κακόβουλη κίνηση αναλύονται πάντοτε σε απομονωμένο, μη δρομολογούμενο περιβάλλον.
    </p>
    <h4>9.2 Μεταδεδομένα δικτύου με Zeek: conn, dns, http και ssl</h4>
    <p>
      Η πλήρης καταγραφή PCAP είναι υπερβολικά ογκώδης για πολύμηνη διατήρηση. Το <b>Zeek</b> συμπυκνώνει την κίνηση σε μικρά και εύκολα αναζητήσιμα αρχεία συναλλαγών. Το <b>conn.log</b> καταγράφει κάθε ροή —άκρα, θύρες, πρωτόκολλο, εκτιμώμενη υπηρεσία, διάρκεια, όγκο και κατάσταση— και λειτουργεί ως κεντρικός κορμός συσχέτισης. Το <b>dns.log</b> περιέχει ερωτήματα και απαντήσεις μαζί με TTL και πλήθος απαντήσεων. Το <b>http.log</b> καταγράφει μεθόδους, URI, User-Agent και κωδικούς κατάστασης, ενώ τα <b>ssl.log/x509.log</b> περιγράφουν τη χειραψία και την αλυσίδα πιστοποιητικών. Βασικό κλειδί σύνδεσης είναι το <b>uid</b>, το μοναδικό αναγνωριστικό ανά σύνδεση, μαζί με τη χρονική σήμανση —η δικτυακή αντιστοιχία της πειθαρχίας ProcessGuid του Sysmon.
    </p>
    <DataTable
      head={["Zeek log", "Records", "Signature DFIR uses"]}
      rows={[
        ["conn.log", "5-tuple + duration + bytes + history flags", "Beacon intervals, data volumes, rare ports/services"],
        ["dns.log", "query + qtype + answers + TTL", "Tunnels, DGA, fast-flux, C2 domains"],
        ["http.log", "method + URI + UA + status + lengths", "Webshell POSTs, staged downloads, scan sweeps"],
        ["ssl.log", "version + cipher + SNI + JA3/JA4", "Malware TLS clients, cert anomalies, SNI lies"],
        ["x509.log", "cert subject/issuer/validity/SAN", "Self-signed C2 certs, short-lived impostors"],
        ["files.log / weird.log", "Transferred files / protocol anomalies", "Payload hashes, Heartbleed-style violations"],
      ]}
    />
    <h4>9.3 Εντοπισμός διοίκησης και ελέγχου: beacons και jitter</h4>
    <p>
      Τα εμφυτεύματα επικοινωνούν με την υποδομή διοίκησης και ελέγχου βάσει προγράμματος beacon: σταθερά διαστήματα αναμονής με <b>jitter</b>, δηλαδή τυχαία απόκλιση που δυσκολεύει τους απλούς ανιχνευτές περιοδικότητας. Η ανίχνευση πρέπει επομένως να μετρά την κανονικότητα μέσα στον θόρυβο (Σχ. 15): κατανομές χρόνου μεταξύ αφίξεων με μικρή διακύμανση σε σχέση με τον μέσο όρο, μικρό και συμμετρικό όγκο byte για λήψη εργασιών και επιμονή επί ημέρες. Η ανθρώπινη κίνηση είναι συνήθως εκρηκτική, ακολουθεί ημερήσιο κύκλο και παρουσιάζει μεγάλες αποκλίσεις. Πρακτικά, μετρήστε συνδέσεις ανά συνδυασμό πηγής, προορισμού και θύρας, διάμεσο διάστημα, συμμετρία byte και μακρές ροές χαμηλού όγκου. Στη συνέχεια, συνδέστε τους υποψηφίους που απομένουν με δεδομένα διεργασιών του τερματικού.
    </p>
    <Figure
      id="fig-beacon"
      label="Fig. 15 · C2 beacon anatomy vs. human traffic"
      caption={
        <>
          <b>Fig. 15.</b> Beacons are metronomes with jitter: tight interval clustering and small symmetric payloads.
          Human browsing is bursty and diurnal. Hunt the metronomes, then identify the owning process via Sysmon EID
          3 / Zeek uid joins.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="Beacon pattern">
        <text x="20" y="24" fontSize="11" fontWeight="800" fill="#be123c">C2 BEACON · 60 s sleep + 15% jitter · 400 B ⇄</text>
        <g stroke="#be123c" strokeWidth="3">
          {[40, 100, 158, 222, 280, 342, 400, 462, 520, 582, 640].map((x, i) => (
            <line key={i} x1={x} y1={34} x2={x} y2={86} />
          ))}
        </g>
        <line x1="20" y1="88" x2="700" y2="88" stroke="#94a3b8" strokeWidth="1" />
        <g fontSize="10" fill="#64748b" fontWeight="700">
          <text x="40" y="102">t+0</text><text x="222" y="102">t+180 s</text><text x="400" y="102">t+360 s</text><text x="582" y="102">t+540 s</text>
        </g>
        <text x="20" y="130" fontSize="11" fontWeight="800" fill="#0e7490">HUMAN BROWSING · bursty · diurnal · heavy-tailed</text>
        <g stroke="#0e7490" strokeWidth="3">
          <line x1="50" y1={140} x2={50} y2={120} /><line x1="58" y1={140} x2={58} y2={104} /><line x1="66" y1={140} x2={66} y2={126} />
          <line x1="230" y1={140} x2={230} y2={98} /><line x1="238" y1={140} x2={238} y2={130} />
          <line x1="470" y1={140} x2={470} y2={110} /><line x1="480" y1={140} x2={480} y2={88} /><line x1="489" y1={140} x2={489} y2={122} /><line x1="500" y1={140} x2={500} y2={132} />
          <line x1="660" y1={140} x2={660} y2={118} />
        </g>
        <line x1="20" y1="142" x2="700" y2="142" stroke="#94a3b8" strokeWidth="1" />
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="20" y="160" width="330" height="56" rx="8" fill="#fef2f2" stroke="#be123c" strokeWidth="1.5" />
          <text x="185" y="181" fill="#be123c">BEACON METRICS → hunt</text>
          <text x="185" y="198" fill="#475569" fontWeight="400" fontSize="10">interval CV &lt; 0.3 · bytes symmetric · 24×7 persistence</text>
          <rect x="370" y="160" width="330" height="56" rx="8" fill="#ecfeff" stroke="#0e7490" strokeWidth="1.5" />
          <text x="535" y="181" fill="#0e7490">HUMAN METRICS → baseline</text>
          <text x="535" y="198" fill="#475569" fontWeight="400" fontSize="10">bursts + nights silent · bytes asymmetric (down ≫ up)</text>
        </g>
        <text x="360" y="236" textAnchor="middle" fontSize="11" fill="#64748b">Προσοχή: περιοδική επικοινωνία εμφανίζουν και οι υπηρεσίες cloud sync ή ενημερώσεων· πριν από συμπέρασμα, ταυτοποιήστε πάντοτε τη διεργασία που κατέχει τη σύνδεση</text>
      </svg>
    </Figure>
    <h4>9.4 Ανάλυση κατάχρησης DNS: tunnels, εξαγωγή δεδομένων και DGA</h4>
    <p>
      Στο δίκτυο, η κατάχρηση DNS αποκαλύπτεται από τον τύπο ερωτήματος, τη μορφή των ετικετών και τον όγκο. Τα tunnels προτιμούν TXT, NULL ή CNAME με μεγάλες ετικέτες υψηλής εντροπίας και σταθερό ρυθμό. Η εξαγωγή δεδομένων παρουσιάζει έντονη ασυμμετρία: πολλά ερωτήματα προς τα έξω και πολύ μικρές απαντήσεις. Οι <b>DGA</b> παράγουν καταιγισμό NXDOMAIN, καθώς ένας πελάτης δοκιμάζει δεκάδες αλγοριθμικά ονόματα μέχρι να βρει ενεργό τομέα. Το <b>fast-flux</b> εμφανίζεται ως ένας τομέας που επιλύεται σε μεγάλο και συνεχώς μεταβαλλόμενο σύνολο διευθύνσεων χαμηλού TTL, συχνά σε διαφορετικά ASN. Το dns.log του Zeek επιτρέπει ποσοτική αξιολόγηση μέσω πλήθους ερωτημάτων ανά πελάτη, κατανομής εντροπίας και μεγέθους του συνόλου απαντήσεων, χωρίς ανάγκη διατήρησης όλων των πακέτων.
    </p>
    <h4>9.5 Εγκληματολογία κρυπτογραφημένης κίνησης: JA3/JA4 και πιστοποιητικά</h4>
    <p>
      Το TLS κρύβει το περιεχόμενο, όχι όμως τη συμπεριφορά της χειραψίας. Τα αποτυπώματα <b>JA3/JA4</b> συνοψίζουν την έκδοση ClientHello, τη λίστα κρυπτοσουιτών, τις επεκτάσεις και τις καμπύλες σε αναγνωριστικό πελάτη. Οικογένειες κακόβουλου λογισμικού συχνά επαναχρησιμοποιούν διακριτές στοίβες που διαφέρουν από τους περιηγητές, άρα ένα σπάνιο JA3 σε έναν σταθμό αποτελεί άμεση ένδειξη προς διερεύνηση. Συμπληρωματικά σήματα είναι η ασυμφωνία SNI, πιστοποιητικού και προορισμού, τα αυτοϋπογεγραμμένα ή βραχύβια πιστοποιητικά C2 στο x509.log και η υποβάθμιση έκδοσης ή κρυπτοσουίτας. Το JA3 μπορεί να συγκρούεται μεταξύ εργαλείων και να παρακάμπτεται μέσω GREASE ή τυχαιοποίησης. Χρησιμοποιείται λοιπόν ως σημείο μετάβασης και επιβεβαιώνεται με χρόνο, άκρα σύνδεσης και δεδομένα διεργασιών.
    </p>
    <DataTable
      head={["Encrypted-traffic signal", "Zeek source", "Interpretation"]}
      rows={[
        ["Rare JA3/JA4 for the host role", "ssl.log ja3/ja4", "Non-browser TLS stack — malware, tooling, or updater; identify process"],
        ["SNI ≠ cert CN/SAN", "ssl.log + x509.log", "SNI lie / fronting; inspect destination + cert history"],
        ["Self-signed + long-lived flow", "x509.log + conn.log", "C2-grade cert hygiene; check first-seen + beacon metrics"],
        ["TLS 1.0/weak cipher, 2026", "ssl.log version/cipher", "Legacy malware stack or downgrade; rare = suspicious"],
      ]}
    />
    <h4>9.6 Συγχρονισμός δεδομένων συστήματος και δικτύου</h4>
    <p>
      Η απόδοση μιας σύνδεσης ολοκληρώνεται όταν τα ρολόγια συστήματος και δικτύου συμφωνούν. Η πεντάδα σύνδεσης και ο χρόνος UTC του Sysmon EID 3 πρέπει να αντιστοιχούν στο uid, την πεντάδα και το ts του Zeek conn.log με απόκλιση χιλιοστών του δευτερολέπτου. Οι προϋποθέσεις είναι απλές αλλά καθοριστικές: σωστό NTP σε αισθητήρες και τερματικά, UTC παντού και τεκμηριωμένη καθυστέρηση καταγραφής από SPAN ή ουρές αισθητήρων. Επαληθεύστε τις αποκλίσεις πριν από κάθε σύνθεση· λανθασμένο ρολόι μπορεί να αθωώσει φαινομενικά μια πραγματική εισβολή. Η τυπική σύνδεση είναι: Zeek conn.log uid → IP, θύρα και χρόνος τερματικού → Sysmon EID 3 ProcessGuid → γονική αλυσίδα EID 1. Αυτή η διαδρομή τεσσάρων βημάτων αποτελεί τον αποδεικτικό κορμό κάθε ευρήματος C2.
    </p>
    <Callout color="cyan">
      <b>Fusion rule.</b> A network-only C2 verdict is a hypothesis; a host-only verdict is a suspicion. The finding
      exists only where beacon metrics (network) meet owning-process identity (host) on synchronized clocks.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — tshark + Zeek triage one-liners"
        code={`# Top talkers + rare ports (tshark on capture.pcap)\ntshark -r capture.pcap -T fields -e ip.src -e tcp.dstport | sort | uniq -c | sort -rn | head\n# DNS query names + types, NXDOMAIN-heavy clients\ntshark -r capture.pcap -Y dns.flags.response==0 -T fields -e ip.src -e dns.qry.name -e dns.qry.type | head -n 40\n# Zeek: beacon candidates — high-count, low-byte, long-lived flows\ncat conn.log | zeek-cut id.orig_h id.resp_h id.resp_p duration orig_bytes resp_bytes missed_bytes \\\n | awk '$4>300 && $5<5000' | sort | uniq -c | sort -rn | head\n# Zeek: rare JA3s\ncat ssl.log | zeek-cut id.orig_h ja3 SNI | sort | uniq -c | sort -n | head`}
      />
    </div>
    <h4>9.7 Εταιρική καταγραφή, πληροφορίες απειλών και το πρόβλημα DoH</h4>
    <p>
      Τα ώριμα προγράμματα χρησιμοποιούν πολλαπλά επίπεδα καταγραφής. Το <b>Zeek Intel Framework</b> εφαρμόζει πληροφορίες απειλών απευθείας στο δίκτυο: λαμβάνει δείκτες, για παράδειγμα από MISP, και γράφει κάθε αντιστοίχιση στο intel.log μαζί με πηγή και πλαίσιο, χωρίς καθυστέρηση επιστροφής μέσω SIEM. Το <b>Arkime</b> ευρετηριάζει πλήρη πακέτα για αναλυτική διερεύνηση: μεταδεδομένα συνεδρίας για αναζήτηση και άμεση μετάβαση στα πακέτα για απόδειξη. Τα <b>NetFlow/IPFIX</b>, με εργαλεία όπως SiLK, nfdump και ElastiFlow, διατηρούν μήνες ιστορικού ροών με χαμηλό κόστος, επιτρέποντας ανάλυση beacon αφού το PCAP έχει λήξει. Για ανάκτηση φορτίου, τα tcpflow, NetworkMiner και Wireshark export objects εξάγουν αρχεία από τις καταγραφές για hash και ασφαλή ανάλυση. Το DNS over HTTPS περιορίζει την ορατότητα DNS στο δίκτυο, γι’ αυτό απαιτούνται καταγραφές resolver, proxy και τερματικού μαζί με έλεγχο των επιτρεπόμενων παρόχων DoH.
    </p>
    <DataTable
      head={["Tier", "Retains", "Answers (months later?)"]}
      rows={[
        ["Full PCAP / Arkime", "Every byte, hours–days", "Exact payloads, exfil content, court-grade proof"],
        ["Zeek logs + intel.log", "Transactions + IoC hits, months", "Who talked to what, when, how much"],
        ["NetFlow / IPFIX", "5-tuple + bytes, 6–12 mo", "Beacon history, lateral paths, volume anomalies"],
        ["Alert summaries", "Verdicts only, years", "That something fired — never why"],
      ]}
    />
    <p>
      <b>DNS-over-HTTPS/TLS (DoH/DoT)</b> encrypts the resolver channel this book leans on: endpoints speaking DoH to
      Οι δημόσιοι resolvers παρακάμπτουν πλήρως την εταιρική καταγραφή DNS, δημιουργώντας ένα θεσμικά επιτρεπόμενο τυφλό σημείο που μπορεί να αξιοποιηθεί και για C2. Αντιμετωπίστε το με πολυεπίπεδη ορατότητα: <b>Sysmon EID 22</b>, που βλέπει τα ερωτήματα στο τερματικό πριν κρυπτογραφηθούν, παρακολούθηση SNI για γνωστούς παρόχους DoH, πολιτική DNS στα τερματικά με διαχειριζόμενους resolvers ή agents φιλτραρίσματος και επιθεώρηση TLS στον proxy μόνο όπου υπάρχει σαφής νομική έγκριση. Η υποκλοπή τύπου <b>break-and-inspect</b> έχει κόστος για την ιδιωτικότητα, τη νομιμότητα και την εμπιστοσύνη και μπορεί να διακόψει το certificate pinning. Προτιμήστε ορατότητα τερματικού και μεταδεδομένων και εφαρμόστε υποκλοπή μόνο με τεκμηριωμένη νομική βάση, στενό πεδίο και ενημέρωση των χρηστών.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 9.1 · Ανατομία εισβολής σε PCAP (90 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Δημιουργήστε προφίλ της καταγραφής: διάρκεια, κύριοι συνομιλητές, κατανομή πρωτοκόλλων και απογραφή ερωτημάτων DNS.</li>
      <li>Απομονώστε το κανάλι C2 χρησιμοποιώντας μετρήσεις beacon, πειστήρια DNS και ανάλυση JA3/SNI.</li>
      <li>Εξαγάγετε τα τεχνουργήματα φορτίου μέσω files.log ή export objects και υπολογίστε τα hash για τον φάκελο IoC.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 9.2 · Έρευνα Zeek και σύνθεση με δεδομένα συστήματος (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Εκτελέστε ελέγχους beacon, DGA και σπάνιων JA3 σε μία ημέρα καταγραφών Zeek και ιεραρχήστε τους υποψηφίους.</li>
      <li>Συνδέστε τον σημαντικότερο υποψήφιο με Sysmon EID 3 και 1 και προσδιορίστε τη διεργασία που κατέχει τη σύνδεση και τη γονική αλυσίδα.</li>
      <li>Παραδώστε το εύρημα C2 με δικτυακή απόδειξη, απόδειξη συστήματος και βεβαίωση συγχρονισμού ρολογιών.</li>
    </ol>
  </>
);

export const ch09: Κεφάλαιο = {
  id: "ch9",
  num: 9,
  title: "Δικτυακή Εγκληματολογία, Ανάλυση Ροών και Τηλεμετρία Zeek",
  subtitle: "Wireshark/tshark · Καταγραφές Zeek · Εντοπισμός beacon · Κατάχρηση DNS · JA3/JA4 · Σύνθεση με δεδομένα συστήματος",
  badge: "Tier 3 · Δικτυακή εγκληματολογία",
  time: "10–12 ώρες · περίπου 44 σελίδες",
  outcomes:
    "Αναλύετε PCAP με φίλτρα εμφάνισης· αξιοποιείτε τα βασικά αρχεία Zeek· μετράτε τη συμπεριφορά beacon· εντοπίζετε tunnels, DGA και fast-flux· δημιουργείτε αποτυπώματα πελατών TLS· και συνδυάζετε δικτυακά ευρήματα με δεδομένα συστήματος μέσω συγχρονισμένων ρολογιών.",
  body,
  labTitle: "Πρακτική Άσκηση 9.1 · Ανατομία εισβολής σε PCAP + Άσκηση 9.2 · Έρευνα Zeek και σύνθεση με δεδομένα συστήματος",
  labsBody,
  workshop: {
    title: "Ροή από το δίκτυο στο σύστημα: σύνθεση PCAP, Zeek και Sysmon",
    env: ["Εικονική μηχανή Security Onion ή Zeek", "Δείγμα PCAP εισβολής", "tshark, zeek-cut και jq"],
    tabs: [
      {
        id: "pcap",
        label: "Προφίλ PCAP",
        steps: [
          {
            n: "1",
            title: "Δημιουργήστε προφίλ πριν από τη λεπτομερή ανάλυση",
            desc: "Ξεκινήστε με στατιστικά: χρονικό εύρος, άκρα και πρωτόκολλα. Μην αρχίζετε διαβάζοντας μεμονωμένα πακέτα.",
            code: [
              {
                title: "Bash — capinfos και συνομιλίες",
                text: `capinfos capture.pcap | grep -E "Duration|packets|Data size"\ntshark -r capture.pcap -q -z conv,ip | head -n 25\ntshark -r capture.pcap -q -z dns,tree | head -n 30`,
              },
            ],
          },
          {
            n: "2",
            title: "Εξαγάγετε απογραφές DNS και HTTP",
            desc: "Τα ονόματα ερωτημάτων και τα URI αποτελούν τον ταχύτερο δρόμο προς το κακόβουλο νήμα.",
            code: [
              {
                title: "Bash — απογραφές",
                text: `tshark -r capture.pcap -Y "dns.flags.response==0" -T fields -e dns.qry.name | sort | uniq -c | sort -rn | head -n 25\ntshark -r capture.pcap -Y http.request -T fields -e ip.src -e http.request.method -e http.request.uri | head -n 25`,
              },
            ],
          },
        ],
      },
      {
        id: "zeek",
        label: "Έρευνα Zeek",
        steps: [
          {
            n: "3",
            title: "Δημιουργήστε καταγραφές Zeek από το PCAP",
            desc: "Ένα τοπικό Zeek μετατρέπει κάθε καταγραφή σε έξι βασικές πηγές έρευνας.",
            code: [
              {
                title: "Bash — εκτέλεση Zeek σε PCAP",
                text: `mkdir -p zeek-out && cd zeek-out\nzeek -r ../capture.pcap\nls -la *.log | awk '{print $9, $5}'`,
              },
            ],
          },
          {
            n: "4",
            title: "Εκτελέστε ελέγχους beacon και JA3",
            desc: "Συνδυάστε σε μία ροή τις μετρήσεις του Σχήματος 15: επιμονή, συμμετρία και σπανιότητα.",
            code: [
              {
                title: "Bash — beacon και JA3",
                text: `cat conn.log | zeek-cut id.orig_h id.resp_h id.resp_p duration orig_bytes resp_bytes | awk '$4>300' | sort | uniq -c | sort -rn | head\ncat ssl.log | zeek-cut id.orig_h ja3 SNI | sort | uniq -c | sort -n | head\ncat dns.log | zeek-cut id.orig_h query qtype_name answers | grep -E "TXT|NULL" | head`,
              },
            ],
            expected: "ένα εσωτερικό σύστημα προς μία εξωτερική IP:443, ροές άνω των 300 δευτερολέπτων, μικρός συμμετρικός όγκος και σπάνιο JA3",
          },
        ],
      },
      {
        id: "fuse",
        label: "Σύνδεση με το σύστημα",
        steps: [
          {
            n: "5",
            title: "Συνδέστε το Zeek uid με το Sysmon",
            desc: "Πεντάδα σύνδεσης και χρονική σήμανση με ανοχή δύο δευτερολέπτων → EID 3 → ProcessGuid → γονική αλυσίδα EID 1.",
            code: [
              {
                title: "Bash — υπόδειγμα σύνδεσης δεδομένων",
                text: `# 1) candidate flow: 10.4.17.88:51xxx -> 45.9.148.7:443 @ 02:14:33Z (conn.log uid C8...)\n# 2) Sysmon EID 3 same 5-tuple/time -> ProcessGuid {A1..}\n# 3) EID 1 Guid {A1..}: svc.exe parented by powershell -enc (WINWORD grandparent)\n# 4) verdict: C2 owned by injected svc.exe; beacon confirmed host+network`,
              },
            ],
          },
          {
            n: "6",
            title: "Βεβαιώστε τον συγχρονισμό ρολογιών και συντάξτε το εύρημα",
            note: "Παραδοτέο: προφίλ καταγραφής, έλεγχοι Zeek και ενοποιημένο εύρημα C2 με uid, GUID, μετρήσεις beacon και βεβαίωση NTP. Χωρίς σύνθεση πηγών δεν υπάρχει τεκμηριωμένο εύρημα.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> καταγραφές Zeek (§9.2) · μετρήσεις beacon (§9.3) · JA3 (§9.5) → ειδοποιήσεις Suricata (Κεφ. 10) → συσχέτιση SIEM (Κεφ. 11). Παραδοτέο: ενοποιημένος φάκελος ευρήματος C2 από το δίκτυο έως το σύστημα.
      </>
    ),
  },
  quiz: [
    { q: "Με ποιο στοιχείο συνδέεται κυρίως το conn.log με τα υπόλοιπα αρχεία του Zeek;", o: ["Με το όνομα αρχείου", "Με το uid και τις χρονικές σημάνσεις", "Με τη διεύθυνση MAC", "Με το όνομα χρήστη"], a: 1, e: "Το uid είναι το μοναδικό αναγνωριστικό σύνδεσης που χρησιμοποιείται σε όλα τα σχετικά αρχεία Zeek." },
    { q: "Γιατί χρησιμοποιείται jitter στα C2 beacons;", o: ["Για ταχύτερη μεταφορά", "Για παράκαμψη απλών ανιχνευτών σταθερού χρονικού διαστήματος", "Για κρυπτογράφηση του φορτίου", "Για συμπίεση δεδομένων"], a: 1, e: "Η τυχαία χρονική απόκλιση αποκρύπτει την περιοδικότητα από απλά στατικά όρια." },
    { q: "Ένας πελάτης δημιουργεί 200 απαντήσεις NXDOMAIN σε πέντε λεπτά. Τι υποδηλώνει πιθανότερα;", o: ["Συνήθη περιήγηση", "Μαζική δοκιμή τομέων από DGA", "Μετάδοση βίντεο", "Εκτύπωση"], a: 1, e: "Οι περισσότεροι αλγοριθμικά παραγόμενοι τομείς αποτυγχάνουν μέχρι να βρεθεί ο ενεργός C2." },
    { q: "Από ποια στοιχεία αναγνωρίζουν οι υπογραφές JA3 έναν πελάτη TLS;", o: ["Από αποκρυπτογραφημένο περιεχόμενο", "Από παραμέτρους ClientHello, όπως έκδοση, κρυπτοσουίτες, επεκτάσεις και καμπύλες", "Από τη φήμη της IP", "Από το ιστορικό DNS"], a: 1, e: "Η συμπεριφορά της χειραψίας χαρακτηρίζει τη στοίβα TLS και όχι το κρυπτογραφημένο περιεχόμενο." },
    { q: "Τι μπορεί να υποδηλώνει ασυμφωνία του SNI με το CN/SAN του πιστοποιητικού;", o: ["Πάντοτε φυσιολογική συμπεριφορά CDN", "Πιθανό domain fronting ή ψευδές SNI που απαιτεί διερεύνηση", "Ταχύτερο TLS", "Χρήση IPv6"], a: 1, e: "Η ασυμφωνία ταυτότητας στη χειραψία αποτελεί ένδειξη απόκρυψης ή παράκαμψης." },
    { q: "Τι απαιτεί οπωσδήποτε η σύνθεση δεδομένων συστήματος και δικτύου;", o: ["Εργαλεία του ίδιου προμηθευτή", "Συγχρονισμένα μέσω NTP ρολόγια UTC με τεκμηριωμένες αποκλίσεις", "Αποκρυπτογραφημένη κίνηση", "Φυσική πρόσβαση"], a: 1, e: "Οι συσχετίσεις χιλιοστών του δευτερολέπτου καταρρέουν όταν υπάρχει απόκλιση ρολογιού." },
  ],
};
