import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>6.1 Αρχιτεκτονική Sysmon: οδηγός πυρήνα και υπηρεσία</h4>
    <p>
      Το <b>Microsoft System Monitor (Sysmon)</b> συνδυάζει έναν οδηγό λειτουργίας πυρήνα —ο οποίος συλλέγει συμβάντα μέσω επανακλήσεων διεργασιών, φόρτωσης εικόνων, δικτύου και Μητρώου— με μια υπηρεσία χώρου χρήστη. Η υπηρεσία εφαρμόζει φίλτρα από αρχείο XML και γράφει τα επιλεγμένα συμβάντα στο κανάλι Microsoft-Windows-Sysmon/Operational. Ο προεπιλεγμένος έλεγχος των Windows καταγράφει ότι ξεκίνησε μια διεργασία, συνήθως μέσω 4688 και συχνά χωρίς πλήρη γραμμή εντολών. Το Sysmon καταγράφει και τον τρόπο: πλήρη εντολή, γονική εικόνα και PID, hash αρχείων και GUID συνεδρίας, ώστε να συνδέονται δέντρα διεργασιών ακόμη και όταν οι αριθμοί PID επαναχρησιμοποιούνται. Η εγκατάσταση γίνεται μέσω GPO, SCCM ή Intune με ρύθμιση υπό έλεγχο εκδόσεων. Ο οδηγός ενεργοποιείται νωρίς κατά την εκκίνηση, περιορίζοντας τα χρονικά κενά ορατότητας.
    </p>
    <DataTable
      head={["Component", "Role", "Forensic relevance"]}
      rows={[
        ["SysmonDrv (kernel)", "Registers process/image/network/registry callbacks", "Sees events user-mode malware tries to hide"],
        ["Sysmon64.exe (service)", "Applies XML filters, writes .evtx", "Config version determines exactly what is (not) logged"],
        ["Sysmon/Operational channel", "Structured event store", "Forward to SIEM; local retention is finite"],
        ["Config XML (e.g., SwiftOnSecurity)", "Include/exclude rules per Event ID", "Tuning = detection quality; audit it like code"],
      ]}
    />
    <h4>6.2 Τηλεμετρία δημιουργίας διεργασίας (Event ID 1)</h4>
    <p>
      Το <b>EID 1</b> είναι ένα από τα πολυτιμότερα συμβάντα στην εγκληματολογία Windows. Περιλαμβάνει χρόνο UTC, υπολογιστή, χρήστη, εικόνα, γραμμή εντολών, ParentImage και ParentCommandLine, ProcessId και ProcessGuid, hash αρχείου —όπως SHA-256 ή IMPHASH— και επίπεδο ακεραιότητας. Η ανάλυση σχέσεων γονικής και θυγατρικής διεργασίας αποκαλύπτει κατάχρηση νόμιμων εργαλείων. Ένα powershell.exe με γονέα explorer.exe στις 09:00 μπορεί να είναι νόμιμη διαχείριση· η ίδια διεργασία με γονέα wmiprvse.exe, ορίσματα base64 και ώρα 03:00 αποτελεί ισχυρή ένδειξη T1059. Οι συσχετίσεις πρέπει να βασίζονται πάντοτε στο <b>ProcessGuid</b> και όχι στο PID: οι αριθμοί PID ανακυκλώνονται, τα GUID όχι.
    </p>
    <h4>6.3 Ορατότητα δικτύου και οδηγών (EID 3, EID 6 και EID 22)</h4>
    <p>
      Το <b>EID 3</b> καταγράφει συνδέσεις TCP/UDP με εικόνα διεργασίας, διεύθυνση και θύρα προέλευσης και προορισμού, καθώς και τον χρήστη που ξεκίνησε τη σύνδεση. Έτσι συνδέει κάθε socket με τη διεργασία που το κατέχει, κάτι που δεν μπορούν να προσφέρουν τα αρχεία ενός τείχους προστασίας. Το <b>EID 6</b> καταγράφει φορτώσεις οδηγών και την κατάσταση υπογραφής τους, βοηθώντας στον εντοπισμό rootkit και τεχνικών <b>BYOVD</b>, δηλαδή κατάχρησης νόμιμου αλλά ευάλωτου οδηγού. Το <b>EID 22</b> καταγράφει ερωτήματα DNS και τη διεργασία που τα υπέβαλε, αποκαλύπτοντας τομείς C2 ακόμη και χωρίς κεντρικές καταγραφές DNS. Μαζί απαντούν στο ερώτημα «ποια διεργασία επικοινώνησε με τον αντίπαλο και ποια επίλυσε το όνομα τομέα;», καλύπτοντας την πλευρά του τερματικού σε κάθε διερεύνηση C2.
    </p>
    <Figure
      id="fig-sysmon-chain"
      label="Fig. 10 · Sysmon event chain for one intrusion thread"
      caption={
        <>
          <b>Fig. 10.</b> One phishing payload narrated end-to-end by Sysmon: process creation (1) → image loads (7)
          → file drop (11) → registry persistence (13) → C2 (3) → DNS (22). Join all nodes on ProcessGuid; the parent
          chain (dashed) proves the infection vector.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="Sysmon event chain">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="160" height="70" rx="8" fill="#0f1c2e" />
          <text x="90" y="50" fill="#fbbf24">EID 1 · PROC CREATE</text>
          <text x="90" y="66" fill="#cbd5e1" fontWeight="400">WINWORD → powershell</text>
          <text x="90" y="82" fill="#fbbf24" fontSize="9">Guid .A1 · -enc …</text>
          <rect x="190" y="30" width="150" height="70" rx="8" fill="#7c3aed" />
          <text x="265" y="50" fill="#fff">EID 7 · IMAGE</text>
          <text x="265" y="66" fill="#ede9fe" fontWeight="400">unsigned DLL</text>
          <text x="265" y="82" fill="#fff" fontSize="9">Signed=false!</text>
          <rect x="360" y="30" width="150" height="70" rx="8" fill="#b45309" />
          <text x="435" y="50" fill="#fff">EID 11 · FILE</text>
          <text x="435" y="66" fill="#fef3c7" fontWeight="400">drop: \Temp\svc.exe</text>
          <text x="435" y="82" fill="#fff" fontSize="9">SHA256: 9f2c…</text>
          <rect x="530" y="30" width="180" height="70" rx="8" fill="#be123c" />
          <text x="620" y="50" fill="#fff">EID 13 · REGISTRY</text>
          <text x="620" y="66" fill="#ffe4e6" fontWeight="400">HKCU\…\Run = svc.exe</text>
          <text x="620" y="82" fill="#fff" fontSize="9">T1547.001</text>
          <rect x="100" y="140" width="200" height="70" rx="8" fill="#0e7490" />
          <text x="200" y="160" fill="#fff">EID 3 · NETWORK</text>
          <text x="200" y="176" fill="#e0f2fe" fontWeight="400">svc.exe → 45.9.148.7:443</text>
          <text x="200" y="192" fill="#fef08a" fontSize="9">5-min beacon</text>
          <rect x="330" y="140" width="200" height="70" rx="8" fill="#166534" />
          <text x="430" y="160" fill="#fff">EID 22 · DNS QUERY</text>
          <text x="430" y="176" fill="#dcfce7" fontWeight="400">svc.exe ? cdn-x7.ru</text>
          <text x="430" y="192" fill="#fff" fontSize="9">low-reputation TLD</text>
          <rect x="560" y="140" width="150" height="70" rx="8" fill="#0f1c2e" />
          <text x="635" y="160" fill="#fbbf24">EID 10 · ACCESS</text>
          <text x="635" y="176" fill="#cbd5e1" fontWeight="400">svc → lsass.exe</text>
          <text x="635" y="192" fill="#fbbf24" fontSize="9">T1003.001!</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="65" x2="186" y2="65" markerEnd="url(#dfir-a1)" />
          <line x1="340" y1="65" x2="356" y2="65" markerEnd="url(#dfir-a1)" />
          <line x1="510" y1="65" x2="526" y2="65" markerEnd="url(#dfir-a1)" />
          <line x1="200" y1="100" x2="200" y2="136" markerEnd="url(#dfir-a1)" />
          <line x1="300" y1="175" x2="326" y2="175" markerEnd="url(#dfir-a1)" />
          <line x1="530" y1="175" x2="556" y2="175" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="234" textAnchor="middle" fontSize="11" fill="#64748b">Κλειδί συσχέτισης: ProcessGuid · Η αλυσίδα γονικών διεργασιών τεκμηριώνει το διάνυσμα · EID 10 προς lsass: κλιμάκωση ως περιστατικό πρόσβασης σε διαπιστευτήρια</text>
      </svg>
    </Figure>
    <h4>6.4 Αλλοίωση και έγχυση διεργασιών (EID 8 και EID 10)</h4>
    <p>
      Το <b>EID 8 (CreateRemoteThread)</b> ενεργοποιείται όταν μια διεργασία δημιουργεί νήμα μέσα σε άλλη, χαρακτηριστικό γνώρισμα κλασικής έγχυσης DLL T1055. Το <b>EID 10 (ProcessAccess)</b> καταγράφει την απόκτηση λαβής και τα ζητούμενα δικαιώματα. Τιμές 0x1010 ή 0x1410 προς το lsass.exe αποτελούν γνωστή υπογραφή απόπειρας εξαγωγής LSASS T1003.001, ενώ ευρείες άδειες 0x1FFFFF μπορεί να προαναγγέλλουν process hollowing. Και τα δύο συμβάντα παράγουν σημαντικό θόρυβο, επειδή ενεργοποιούνται συχνά από antivirus, EDR και περιηγητές. Στην παραγωγή, περιορίζουμε το EID 10 σε ευαίσθητους στόχους, όπως lsass, csrss και services, και το EID 8 σε πηγές εκτός των αναμενόμενων περιηγητών. Προτιμούμε την ακρίβεια από την άκριτη πληρότητα, διατηρώντας πλήρη συλλογή μόνο σε συστήματα υπό διερεύνηση.
    </p>
    <h4>6.5 Βελτιστοποίηση της ρύθμισης XML του Sysmon</h4>
    <p>
      Το σχήμα XML οργανώνει κανόνες <span className="mono text-sm">&lt;EventFiltering&gt;</span> ανά Event ID με σημασιολογία <span className="mono text-sm">onmatch="include|exclude"</span>. Ορίζουμε τι πρέπει να διατηρείται —σπάνια και υψηλής αξίας συμβάντα— και τι μπορεί να απορρίπτεται ως γνωστός, νόμιμος θόρυβος μεγάλου όγκου. Καθιερωμένα πρότυπα, όπως το σχολιασμένο sysmon-config του SwiftOnSecurity και η αρθρωτή έκδοση του Olaf Hartong, προσφέρουν αφετηρία και όχι τελική λύση. Κάθε οργανισμός πρέπει να δημιουργεί δικό του κλάδο, να τον διατηρεί στο Git και να δοκιμάζει τις αλλαγές σε λειτουργία ελέγχου πριν από τη μαζική διάθεση. Αντιμετωπίστε τη ρύθμιση ως κώδικα ανίχνευσης: κάθε αλλαγή χρειάζεται αξιολόγηση από δεύτερο άτομο, ιστορικό μεταβολών και σχέδιο επαναφοράς.
    </p>
    <h4>6.6 Περιορισμός θορύβου χωρίς απώλεια ορατότητας</h4>
    <p>
      Μια αφιλτράριστη εγκατάσταση του <b>Sysmon</b> μπορεί να παραγάγει εξαιρετικά μεγάλο όγκο συμβάντων ανά σύστημα, οδηγώντας σε κορεσμό της αποθήκευσης και υπέρβαση των ορίων κατάποσης δεδομένων (<b>ingestion limits</b>) του <b>SIEM</b>. Η μείωση θορύβου (<b>noise reduction</b>) πρέπει να εφαρμόζεται ιεραρχικά και να τεκμηριώνεται με βάση τις απαιτήσεις ανίχνευσης και εγκληματολογικής ορατότητας (<b>telemetry visibility</b>).
    </p>
    <ul>
      <li><b>EID 10 — ProcessAccess:</b> εφαρμόστε κανόνες <b>include</b> για διεργασίες-στόχους υψηλής ευαισθησίας, όπως η <span className="mono text-sm">lsass.exe</span>, αντί να συλλέγετε αδιακρίτως κάθε πρόσβαση μεταξύ διεργασιών.</li>
      <li><b>EID 7 — ImageLoad:</b> περιορίστε τη συλλογή σε φορτώσεις υψηλής αναλυτικής αξίας, όπως ανυπόγραφα αρχεία, μη έγκυρες υπογραφές ή βιβλιοθήκες από ασυνήθιστες διαδρομές. Η ιδιότητα «μη Microsoft» δεν αποτελεί από μόνη της ένδειξη κακόβουλης δραστηριότητας.</li>
      <li><b>EID 3 — NetworkConnect:</b> εξαιρέστε μόνο επαληθευμένη, επαναλαμβανόμενη κίνηση από περιηγητές, υπηρεσίες ενημέρωσης και γνωστές υποδομές <b>CDN</b>. Διατηρήστε τις συνδέσεις από ασυνήθιστες διεργασίες, προς σπάνιους προορισμούς ή μη τυπικές θύρες.</li>
      <li><b>EID 1 — ProcessCreate:</b> μην εξαιρείτε συμβάντα μόνο βάσει του ονόματος του εκτελέσιμου. Απαιτείται συσχέτιση των πεδίων <b>Image</b>, <b>ParentImage</b>, <b>CommandLine</b>, ψηφιακής υπογραφής και <b>hash</b>, ώστε να περιορίζεται ο κίνδυνος παράκαμψης μέσω μεταμφίεσης (<b>masquerading</b>).</li>
    </ul>
    <h5>Υπολειπόμενος κίνδυνος και αντισταθμιστικοί έλεγχοι</h5>
    <p>
      Κάθε εξαίρεση πρέπει να συνοδεύεται από αιτιολόγηση, υπεύθυνο, ημερομηνία λήξης, υπολειπόμενο κίνδυνο (<b>residual risk</b>) και αντισταθμιστικό έλεγχο (<b>compensating control</b>). Παράδειγμα: «Η συνήθης κίνηση περιηγητών εξαιρείται από το <b>EID 3</b>, ενώ η ορατότητα σε <b>URL</b>, κατηγορία προορισμού και πλήρη διαδρομή διατηρείται μέσω του εταιρικού <b>web proxy</b>». Οι εξαιρέσεις επανεξετάζονται τουλάχιστον ανά τρίμηνο και μετά από ουσιώδη μεταβολή της υποδομής ή των πληροφοριών απειλών (<b>Threat Intelligence</b>). Η επικύρωση πρέπει να περιλαμβάνει μετρήσεις όγκου ανά <b>Event ID</b> και ελεγχόμενες δοκιμές που αποδεικνύουν ότι οι απαιτούμενες αλυσίδες συμβάντων εξακολουθούν να ανιχνεύονται.
    </p>
    <Callout color="cyan">
      <b>Βασικά ερωτήματα διερεύνησης.</b> Αναζητήστε σπάνιους συνδυασμούς γονικής και θυγατρικής διεργασίας, κωδικοποιημένες γραμμές εντολών, φορτώσεις ανυπόγραφων βιβλιοθηκών, πρόσβαση στη <span className="mono text-sm">lsass.exe</span> και εξερχόμενους προορισμούς που εμφανίζονται για πρώτη φορά ανά διεργασία. Τα ευρήματα αξιολογούνται ως συσχετισμένες αλυσίδες συμπεριφοράς και όχι ως μεμονωμένα συμβάντα.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="XML — minimal high-value Sysmon filter skeleton (adapted from SwiftOnSecurity pattern)"
        code={`<Sysmon schemaversion="4.90">
  <HashAlgorithms>sha256,IMPHASH</HashAlgorithms>
  <EventFiltering>
    <!-- EID 1: keep everything EXCEPT known-benign triples -->
    <ProcessCreate onmatch="exclude">
      <ParentImage condition="is">C:\\Windows\\System32\\services.exe</ParentImage>
      <Image condition="is">C:\\Windows\\System32\\svchost.exe</Image>
    </ProcessCreate>
    <!-- EID 10: keep ONLY sensitive-target access -->
    <ProcessAccess onmatch="include">
      <TargetImage condition="is">C:\\Windows\\System32\\lsass.exe</TargetImage>
      <TargetImage condition="is">C:\\Windows\\System32\\csrss.exe</TargetImage>
    </ProcessAccess>
    <!-- EID 22: keep all DNS (cheap, high-value); exclude nothing initially -->
    <DnsQuery onmatch="exclude"></DnsQuery>
  </EventFiltering>
</Sysmon>`}
      />
    </div>
    <h4>6.7 Άτλαντας EID, παρεμβάσεις σε EDR και ροή εργασίας με προτεραιότητα στο EDR</h4>
    <p>
      Οι αναλυτές πρέπει να γνωρίζουν τον πλήρη χάρτη συμβάντων Sysmon και όχι μόνο τα πιο γνωστά Event ID. Ο παρακάτω άτλαντας ομαδοποιεί τα συμβάντα παραγωγικής αξίας ανά ρόλο στην αλυσίδα επίθεσης: διεργασίες, κώδικας, δίκτυο, αρχεία, Μητρώο, WMI και αυτοπροστασία. Δύο συχνά υποτιμημένες εγγραφές αξίζουν ιδιαίτερη προσοχή. Το <b>EID 15 (CreateStreamHash)</b> καταγράφει τη δημιουργία ADS μαζί με hash, εντοπίζοντας την τεχνική απόκρυψης του §4.2 τη στιγμή που εφαρμόζεται. Το <b>EID 25 (ProcessTampering)</b> ενεργοποιείται όταν μια εικόνα διεργασίας τροποποιείται στη μνήμη και αποτελεί άμεση ένδειξη hollowing ή masquerading. Κατά την οριοθέτηση περιστατικού, εξετάστε τον άτλαντα από πάνω προς τα κάτω και ρωτήστε για κάθε ομάδα: «το καταγράψαμε και το ερευνήσαμε;».
    </p>
    <DataTable
      head={["EID", "Event", "Hunt value"]}
      rows={[
        ["1 / 5 / 25", "ProcessCreate / Ended / Tampering", "Trees, lifetimes, in-memory image modification"],
        ["6 / 7", "DriverLoad / ImageLoad", "Rootkits, BYOVD, unsigned/phantom DLLs (T1574)"],
        ["8 / 10", "CreateRemoteThread / ProcessAccess", "Injection; LSASS handle grants (T1055/T1003)"],
        ["9", "RawAccessRead", "Direct disk reads (MFT/SAM theft bypassing APIs)"],
        ["3 / 22", "NetworkConnect / DnsQuery", "Sockets→process bind; per-image C2 domains"],
        ["11 / 15 / 23–24", "FileCreate / StreamHash / Delete / Clipboard", "Drops, ADS births,wiper deletes, staged secrets"],
        ["12–14", "RegistryObject add/delete/value", "Persistence writes with before/after values"],
        ["17–18", "PipeEvent create/connect", "C2 IPC (Cobalt-Strike-class named pipes), lateral meld"],
        ["19–21 / 29", "WMI filter/consumer/binding / Summary", "Fileless persistence + execution via WMI"],
        ["4 / 16", "ServiceState / ConfigChange", "Sysmon's own health + config-hash drift (tamper alarm)"],
      ]}
    />
    <p>
      Οι αντίπαλοι επιχειρούν πλέον να απενεργοποιήσουν πρώτα τους μηχανισμούς παρακολούθησης. Η τεχνική <b>BYOVD</b> φορτώνει έναν νόμιμα υπογεγραμμένο αλλά εκμεταλλεύσιμο οδηγό, ώστε να τερματίσει το EDR ή το antivirus από τον πυρήνα. Αποτελεί συχνό στοιχείο εργαλείων συνεργατών ransomware. Η άμυνα σε βάθος απαιτεί ενεργή <b>προστασία από αλλοίωση</b>, κωδικούς για απεγκατάσταση ή διακοπή υπηρεσίας, ειδοποίηση EID 6 για hash γνωστών ευάλωτων οδηγών, συσχετισμό 7045 με διακοπή υπηρεσιών ασφάλειας και παρακολούθηση αποκλίσεων EID 16. Η ροή διαλογής με προτεραιότητα στο EDR είναι: απομόνωση του συστήματος με διατήρηση τροφοδοσίας → εξέταση του δέντρου διεργασιών EDR δύο ώρες πριν και μετά → οριοθέτηση χρηστών και συστημάτων → λήψη μνήμης αν εμφανιστούν ενδείξεις fileless τεχνικών → δελτίο με δέντρο, hash και έκταση. Το Sysmon καλύπτει κενά διατήρησης ή ορατότητας του EDR· τα δύο εργαλεία συμπληρώνουν το ένα το άλλο και δεν είναι υποκατάστατα.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — έρευνα παρεμβάσεων EDR και BYOVD σε Sysmon και System"
        code={`# Known-abused driver loads (maintain hash list from vendor advisories + LOTLDrivers)\nGet-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=6} -MaxEvents 500 |\n  Where-Object { $_.Message -match 'Signed.*false|gdbnt|mhyprot|procexp' }\n# Security-service stops and Sysmon config drift in the window\nGet-WinEvent -FilterHashtable @{LogName='System'; Id=7036,7040} |\n  Where-Object { $_.Message -match 'Sysmon|WinDefend|Sense|CrowdStrike|Carbon' }\nGet-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=16} -MaxEvents 5`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 6.1 · Έρευνα δέντρου διεργασιών (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Εισαγάγετε σύνολο δεδομένων Sysmon EID 1–3–11–13 και ανακατασκευάστε το πλήρες δέντρο του συστήματος βάσει ProcessGuid.</li>
      <li>Επισημάνετε ασυνήθιστα ζεύγη γονικής και θυγατρικής διεργασίας, κωδικοποιημένες γραμμές εντολών και πρωτοεμφανιζόμενους δικτυακούς προορισμούς.</li>
      <li>Συντάξτε την αφήγηση της εισβολής: διάνυσμα → εκτέλεση → παραμονή → C2, με μία παράγραφο ανά στάδιο.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 6.2 · Βελτιστοποίηση ρύθμισης με περιορισμένο όγκο (45 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Μετρήστε τα ημερήσια συμβάντα ανά EID σε μια θορυβώδη ρύθμιση και εντοπίστε τις τρεις μεγαλύτερες πηγές όγκου.</li>
      <li>Συντάξτε εξαιρέσεις που μειώνουν τον όγκο τουλάχιστον κατά 70%, διατηρώντας και τα πέντε κρίσιμα σήματα έρευνας.</li>
      <li>Τεκμηριώστε τον υπολειπόμενο κίνδυνο και τον αντισταθμιστικό έλεγχο κάθε εξαίρεσης και ζητήστε έλεγχο από δεύτερο αναλυτή για κενά ορατότητας.</li>
    </ol>
  </>
);

export const ch06: Κεφάλαιο = {
  id: "ch6",
  num: 6,
  title: "Προηγμένη Ορατότητα Τερματικών με το Microsoft Sysmon",
  subtitle: "Αρχιτεκτονική οδηγού · EID 1/3/6/7/8/10/11/13/22 · Ρύθμιση XML · Έλεγχος θορύβου",
  badge: "Tier 2 · Τηλεμετρία τερματικών",
  time: "9–11 ώρες · περίπου 38 σελίδες",
  outcomes:
    "Εγκαθιστάτε και διαχειρίζεστε εκδόσεις ρυθμίσεων Sysmon· αξιοποιείτε την τηλεμετρία γονικής και θυγατρικής διεργασίας του EID 1· συνδέετε sockets και ερωτήματα DNS με διεργασίες· εντοπίζετε έγχυση και πρόσβαση στο LSASS· και βελτιστοποιείτε φίλτρα χωρίς να χάνετε κρίσιμη ορατότητα.",
  body,
  labTitle: "Πρακτική Άσκηση 6.1 · Έρευνα δέντρου διεργασιών + Άσκηση 6.2 · Βελτιστοποίηση ρύθμισης με περιορισμένο όγκο",
  labsBody,
  workshop: {
    title: "Εγκατάσταση Sysmon, ασφαλής προσομοίωση και αναζήτηση στην αλυσίδα συμβάντων",
    env: ["Εργαστηριακή εικονική μηχανή Windows με στιγμιότυπο", "Sysmon και ρύθμιση SwiftOnSecurity", "PowerShell και Timeline Explorer"],
    tabs: [
      {
        id: "deploy",
        label: "Εγκατάσταση και επαλήθευση",
        steps: [
          {
            n: "1",
            title: "Εγκαταστήστε με ρύθμιση υπό έλεγχο εκδόσεων",
            desc: "Δημιουργήστε πρώτα στιγμιότυπο και καταγράψτε το hash της ρύθμισης, ώστε να εντοπίζεται κάθε μεταγενέστερη απόκλιση.",
            code: [
              {
                title: "PowerShell ως διαχειριστής — εγκατάσταση",
                text: `Checkpoint-VM -Name LAB-WIN11 -SnapshotName "pre-sysmon"\n.\\Sysmon64.exe -accepteula -i .\\sysmonconfig-v28.xml\nGet-FileHash .\\sysmonconfig-v28.xml -Algorithm SHA256\nGet-WinEvent -LogName Microsoft-Windows-Sysmon/Operational -MaxEvents 3 |
  Select-Object TimeCreated, Id`,
              },
            ],
            expected: "τα EID 4 για κατάσταση υπηρεσίας και EID 16 για hash ρύθμισης επιβεβαιώνουν ότι ο οδηγός λειτουργεί",
          },
          {
            n: "2",
            title: "Επαληθεύστε τη ροή συμβάντων",
            desc: "Το EID 16 καταγράφει το ενεργό hash ρύθμισης· μια ασυμφωνία υποδηλώνει αλλοίωση ή μη ελεγχόμενη απόκλιση.",
            code: [
              {
                title: "PowerShell — έλεγχος υγείας",
                text: `Get-Service Sysmon64 | Select-Object Status\nGet-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=16} -MaxEvents 1 |\n  Select-Object -ExpandProperty Message`,
              },
            ],
          },
        ],
      },
      {
        id: "detonate",
        label: "Ασφαλής προσομοίωση",
        steps: [
          {
            n: "3",
            title: "Δημιουργήστε ελεγχόμενα ύποπτα σήματα",
            desc: "Εκτελέστε μικροδοκιμές τύπου Atomic: κωδικοποιημένο PowerShell, δημιουργία διεργασίας μέσω WMI και δοκιμαστική σύνδεση C2, αποκλειστικά μέσα στο εργαστήριο.",
            code: [
              {
                title: "PowerShell — μικροδοκιμές ΜΟΝΟ ΣΕ ΑΠΟΜΟΝΩΜΕΝΗ VM",
                text: `# encoded execution (T1059.001 pattern, harmless payload)\npowershell -enc UwB0AGEAcgB0AC0AUwBsAGUAZQBwACAALQBzACAAMQAK\n# WMI-spawned process (T1047 pattern)\nwmic process call create "calc.exe"\n# test egress (documents EID 3 shape)\nTest-NetConnection -ComputerName 192.0.2.1 -Port 443 -WarningAction SilentlyContinue`,
              },
            ],
          },
          {
            n: "4",
            title: "Αναζητήστε την αλυσίδα",
            desc: "Φιλτράρετε το EID 1 με ParentImage και CommandLine και συνδέστε το EID 3 μέσω ProcessGuid.",
            code: [
              {
                title: "PowerShell — ερωτήματα έρευνας",
                text: `Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'; Id=1} -MaxEvents 200 |\n  Where-Object { $_.Message -match '-enc|wmic|calc' } |\n  Select-Object TimeCreated, @{n='Proc';e={($_.Message | Select-String 'Image: (.+)').Matches.Groups[1].Value}}`,
              },
            ],
            expected: "το κωδικοποιημένο PowerShell και το calc που δημιουργήθηκε μέσω wmic εμφανίζονται με πλήρη γονική αλυσίδα",
          },
        ],
      },
      {
        id: "tune",
        label: "Βελτιστοποίηση και θωράκιση",
        steps: [
          {
            n: "5",
            title: "Μετρήστε και μειώστε τον θόρυβο",
            desc: "Μετρήστε τα συμβάντα ανά ID για μία ώρα. Εξαιρείτε μόνο τεκμηριωμένους νόμιμους τριπλούς συνδυασμούς, ποτέ μόνο ένα όνομα εικόνας.",
            code: [
              {
                title: "PowerShell — έλεγχος όγκου",
                text: `Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Sysmon/Operational'} -MaxEvents 5000 |\n  Group-Object Id | Sort-Object Count -Descending | Format-Table Count, Name -AutoSize`,
              },
            ],
          },
          {
            n: "6",
            title: "Προστατεύστε τη ρύθμιση",
            desc: "Περιορίστε τα ACL του αρχείου ρύθμισης και δημιουργήστε ειδοποιήσεις για αλλαγές EID 16 και διακοπή της υπηρεσίας Sysmon.",
            note: "Παραδοτέο: εγκατεστημένο Sysmon, καταγραφή hash ρύθμισης, αποτελέσματα ερωτημάτων έρευνας, έλεγχος όγκου και σημείωση παρακολούθησης EID 16.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> δέντρα EID 1 (§6.2) · σύνδεση συστήματος και δικτύου μέσω EID 3/22 (§6.3) · έγχυση EID 8/10 (§6.4) → επιβεβαίωση με Zeek (Κεφ. 9) → κανόνες Sigma (Κεφ. 12). Παραδοτέο: εγκατάσταση Sysmon βελτιστοποιημένη, μετρημένη και υπό συνεχή παρακολούθηση.
      </>
    ),
  },
  quiz: [
    { q: "Γιατί το Sysmon χωρίζει τη λειτουργία του σε οδηγό πυρήνα και υπηρεσία χρήστη;", o: ["Για εξοικονόμηση χώρου", "Για συλλογή μέσω callbacks του πυρήνα, φιλτράρισμα σε χώρο χρήστη και δομημένη καταγραφή", "Για να αντικαταστήσει το antivirus", "Για να κρυπτογραφεί καταγραφές"], a: 1, e: "Ο πυρήνας παρέχει ευρεία ορατότητα, ενώ η υπηρεσία εφαρμόζει τα φίλτρα ρύθμισης και γράφει τα συμβάντα .evtx." },
    { q: "Γιατί τα δέντρα διεργασιών πρέπει να συνδέονται με ProcessGuid και όχι με PID;", o: ["Τα GUID είναι συντομότερα", "Τα PID επαναχρησιμοποιούνται, ενώ το GUID είναι μοναδικό ανά διεργασία", "Τα PID είναι κρυπτογραφημένα", "Τα GUID περιέχουν hash"], a: 1, e: "Η επαναχρησιμοποίηση PID αλλοιώνει το δέντρο, ενώ το ProcessGuid επιτρέπει αξιόπιστη συσχέτιση." },
    { q: "Ποια πρόσθετη αξία προσφέρει το EID 3 σε σχέση με τα αρχεία firewall;", o: ["Μεγαλύτερη ταχύτητα", "Συνδέει κάθε socket με τη διεργασία, τον χρήστη και το GUID που το κατέχουν", "Αποκλείει την κίνηση", "Αποκρυπτογραφεί TLS"], a: 1, e: "Το firewall βλέπει ροές, ενώ το Sysmon αποκαλύπτει ποια διεργασία τις δημιούργησε." },
    { q: "Τι υποδηλώνουν δικαιώματα 0x1010/0x1410 του EID 10 προς το lsass.exe;", o: ["Windows Update", "Πιθανή εξαγωγή διαπιστευτηρίων από LSASS T1003.001", "Εκτύπωση", "Επίλυση DNS"], a: 1, e: "Τα δικαιώματα ανάγνωσης μνήμης του LSASS αποτελούν χαρακτηριστική ένδειξη απόπειρας dump." },
    { q: "Ποια είναι η ασφαλέστερη πρακτική εξαιρέσεων;", o: ["Καθολικός αποκλεισμός ονόματος εικόνας", "Εξαίρεση συνδυασμού εικόνας, γονέα και ορισμάτων με τεκμηριωμένο υπολειπόμενο κίνδυνο", "Αποκλεισμός ολόκληρου του EID 1", "Αποκλεισμός όλων των στοιχείων Microsoft"], a: 1, e: "Οι εξαιρέσεις με τριπλό περιορισμό διατηρούν την ανίχνευση κατάχρησης νόμιμων εκτελέσιμων." },
    { q: "Τι καταγράφει το EID 16 στο κανάλι Sysmon;", o: ["Ερωτήματα DNS", "Αλλαγές κατάστασης ή ρύθμισης, μαζί με το hash της ρύθμισης", "Δημιουργία αρχείων", "Διαγραφή κλειδιών Μητρώου"], a: 1, e: "Το EID 16 επιτρέπει την παρακολούθηση αλλοίωσης και απόκλισης της ίδιας της ρύθμισης Sysmon." },
  ],
};
