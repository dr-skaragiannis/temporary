import { Callout, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>3.1 Μοντελοποίηση αντιπάλου: Kill Chain, Diamond Model και ATT&amp;CK</h4>
    <p>
      Τρία μοντέλα οργανώνουν τη μελέτη του αντιπάλου σε διαφορετικό επίπεδο λεπτομέρειας. Το <b>Cyber Kill Chain</b> της Lockheed Martin χωρίζει μια εισβολή σε επτά στάδια —αναγνώριση, οπλοποίηση, παράδοση, εκμετάλλευση, εγκατάσταση, C2 και ενέργειες επί των στόχων— και αναδεικνύει την αξία της έγκαιρης διακοπής. Το <b>Diamond Model</b> (Σχ. 5) συνδέει κάθε συμβάν με τέσσερις κορυφές: <i>αντίπαλο, δυνατότητα, υποδομή και θύμα</i>. Έτσι ωθεί τον αναλυτή να μετακινείται από το ένα στοιχείο στο άλλο: ένας νέος τομέας C2 υποδηλώνει συγκεκριμένη δυνατότητα και πιθανό σύνολο θυμάτων. Το <b>MITRE ATT&amp;CK</b> καταγράφει τις πραγματικές συμπεριφορές και TTP που έχουν παρατηρηθεί, χωρίς να τις περιορίζει σε γραμμική ακολουθία. Οι επαγγελματίες χρησιμοποιούν και τα τρία: το Kill Chain για να προσδιορίσουν <i>σε ποιο στάδιο βρίσκεται ο αντίπαλος</i>, το Diamond Model για να εντοπίσουν <i>τι συνδέεται με τι</i> και το ATT&amp;CK για να περιγράψουν <i>τι ακριβώς έκανε</i>.
    </p>
    <Figure
      id="fig-diamond"
      label="Fig. 5 · Diamond Model of intrusion analysis"
      caption={
        <>
          <b>Fig. 5.</b> Every event connects adversary, capability, infrastructure, and victim. Pivoting means
          traversing edges: infrastructure → capability (what else does this tooling do?), capability → victim (who
          else is targeted?). Meta-features (timestamp, phase) annotate each edge.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="Diamond model">
        <polygon points="360,30 560,140 360,250 160,140" fill="none" stroke="#0f1c2e" strokeWidth="2.5" className="fig-line" />
        <g fontSize="11" fontWeight="800" textAnchor="middle">
          <rect x="280" y="8" width="160" height="44" rx="8" fill="#be123c" />
          <text x="360" y="26" fill="#fff">ADVERSARY</text>
          <text x="360" y="42" fill="#ffe4e6" fontWeight="400" fontSize="10">operator / customer</text>
          <rect x="510" y="118" width="170" height="44" rx="8" fill="#0e7490" />
          <text x="595" y="136" fill="#fff">CAPABILITY</text>
          <text x="595" y="152" fill="#e0f2fe" fontWeight="400" fontSize="10">malware / technique</text>
          <rect x="280" y="208" width="160" height="44" rx="8" fill="#166534" />
          <text x="360" y="226" fill="#fff">VICTIM</text>
          <text x="360" y="242" fill="#dcfce7" fontWeight="400" fontSize="10">persona / asset</text>
          <rect x="40" y="118" width="170" height="44" rx="8" fill="#b45309" />
          <text x="125" y="136" fill="#fff">INFRASTRUCTURE</text>
          <text x="125" y="152" fill="#fef3c7" fontWeight="400" fontSize="10">domain / IP / relay</text>
        </g>
        <text x="360" y="140" textAnchor="middle" fontSize="12" fontWeight="800" fill="#0f1c2e" className="fig-halo">EVENT</text>
        <g fontSize="10" fontWeight="700" fill="#475569" textAnchor="middle" className="fig-edge">
          <text x="270" y="95">uses</text>
          <text x="450" y="95">hosts</text>
          <text x="450" y="195">targets</text>
          <text x="270" y="195">compromises</text>
        </g>
      </svg>
    </Figure>
    <h4>3.2 Δομή του MITRE ATT&amp;CK: τακτικές, τεχνικές και διαδικασίες</h4>
    <p>
      Το ATT&amp;CK οργανώνει τη συμπεριφορά του αντιπάλου σε <b>τακτικές</b> —το <i>γιατί</i>, με 14 εταιρικές τακτικές από την Αναγνώριση έως τον Αντίκτυπο—, <b>τεχνικές και υποτεχνικές</b> —το <i>πώς</i>, όπως T1566 Phishing και T1059.001 PowerShell— και <b>διαδικασίες</b>, δηλαδή συγκεκριμένες εφαρμογές από γνωστές ομάδες ή κακόβουλο λογισμικό. Κάθε τεχνική συνοδεύεται από οδηγίες ανίχνευσης, πηγές δεδομένων και μέτρα μετριασμού. Επομένως, το ATT&amp;CK λειτουργεί όχι μόνο ως ταξινομία αλλά και ως κατάλογος εργασιών για τη μηχανική ανίχνευσης. Στο DFIR, κρίσιμη δεξιότητα είναι η <b>χαρτογράφηση τεχνικών</b>: η μετατροπή ακατέργαστων ευρημάτων, όπως «Run key + PowerShell base64 + σήμα DNS», σε T1547.001 + T1059.001 + T1071.004, ώστε να προκύψουν άμεσα συναφείς τεχνικές προς διερεύνηση.
    </p>
    <DataTable
      head={["Tactic (why)", "Example techniques (how)", "Forensic artifacts to pull"]}
      rows={[
        ["Initial Access", "T1566 Phishing, T1190 Exploit Public App", "Mail gateway logs, web access logs (Ch. 8)"],
        ["Execution", "T1059 CLI/Scripting, T1204 User Execution", "Prefetch, Shimcache, Sysmon EID 1 (Ch. 5–6)"],
        ["Persistence", "T1547 Boot/Logon Autostart, T1053 Tasks", "Registry Run keys, scheduled tasks (Ch. 4)"],
        ["Privilege Escalation", "T1068 Exploit, T1134 Token Manipulation", "Security EID 4672/4673, Sysmon EID 10"],
        ["Defense Evasion", "T1070 Indicator Removal, T1027 Obfuscation", "EID 1102 log-clear, Sysmon config gaps"],
        ["Credential Access", "T1003 LSASS Dump, T1558 Kerberoast", "Sysmon EID 10 on lsass, DC EID 4769 (Ch. 8)"],
        ["Discovery / Lateral Movement", "T1018 Remote Discovery, T1021 RDP/SMB", "Zeek conn.log, firewall allows (Ch. 9–10)"],
        ["C2 / Exfiltration / Impact", "T1071 App-Layer C2, T1486 Ransomware", "DNS/proxy logs, MFT timelines (Ch. 9, Ch. 4)"],
      ]}
    />
    <h4>3.3 Η Πυραμίδα του Κόστους για τον Αντίπαλο</h4>
    <p>
      Η <b>Πυραμίδα του Κόστους (Pyramid of Pain)</b> του David Bianco (Σχ. 6) κατατάσσει τους δείκτες ανάλογα με το κόστος που προκαλεί στον αντίπαλο η ανάγκη αλλαγής εργαλείων και μεθόδων. Ο αποκλεισμός ενός <b>hash</b> απαιτεί απλώς νέα μεταγλώττιση, ενώ ο αποκλεισμός μιας <b>διεύθυνσης IP ή ενός ονόματος τομέα</b> απαιτεί νέα καταχώριση. Αντίθετα, η ανίχνευση των <b>TTP</b> —των συμπεριφορών που απαιτούνται για την αποστολή του— τον αναγκάζει να επανασχεδιάσει δαπανηρές τεχνικές. Στο DFIR, οι δείκτες παραβίασης, όπως hash και IP, χρησιμοποιούνται κυρίως για αποκλεισμό και αρχική διαλογή, ενώ τα TTP τροφοδοτούν ανιχνεύσεις και έρευνες απειλών. Μια αναφορά που παραθέτει μόνο hash καταγράφει το περιστατικό· μια αναφορά που χαρτογραφεί TTP ενισχύει ουσιαστικά την άμυνα του οργανισμού.
    </p>
    <Figure
      id="fig-pain"
      label="Fig. 6 · Pyramid of Pain"
      caption={
        <>
          <b>Fig. 6.</b> Higher levels = more adversary pain when denied. Mature programs detect at the top (TTPs,
          tools) and block at the bottom (hashes, IPs). Color encodes recommended use: green = detect/hunt, amber =
          block/triage.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="Pyramid of pain">
        <g fontSize="11" fontWeight="800" textAnchor="middle">
          <polygon points="360,10 420,52 300,52" fill="#166534" />
          <text x="360" y="40" fill="#fff" fontSize="9">TTPs</text>
          <polygon points="300,52 420,52 455,94 265,94" fill="#16a34a" />
          <text x="360" y="80" fill="#fff" fontSize="10">TOOLS</text>
          <polygon points="265,94 455,94 490,136 230,136" fill="#0e7490" />
          <text x="360" y="122" fill="#fff" fontSize="10">NETWORK / HOST ARTIFACTS</text>
          <polygon points="230,136 490,136 525,178 195,178" fill="#b45309" />
          <text x="360" y="164" fill="#fff" fontSize="10">DOMAIN NAMES</text>
          <polygon points="195,178 525,178 560,220 160,220" fill="#be123c" />
          <text x="360" y="206" fill="#fff" fontSize="10">IP ADDRESSES · HASHES</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="120" y1="215" x2="120" y2="40" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="100" y="130" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e" className="fig-halo" transform="rotate(-90 100 130)">ADVERSARY PAIN ↑</text>
        <g fontSize="10" fontWeight="700" fill="#64748b" textAnchor="start">
          <text x="570" y="45">detect + hunt</text>
          <text x="570" y="85">detect + hunt</text>
          <text x="570" y="125">hunt pivots</text>
          <text x="570" y="168">block 30–90 d</text>
          <text x="570" y="210">block, expires fast</text>
        </g>
        <text x="360" y="244" textAnchor="middle" fontSize="11" fill="#64748b">Κανόνας: μην σχεδιάζετε ανίχνευση που ενεργοποιείται αποκλειστικά από ένα hash</text>
      </svg>
    </Figure>
    <h4>3.4 Βασικές αρχές πληροφοριών κυβερνοαπειλών</h4>
    <p>
      Οι <b>πληροφορίες κυβερνοαπειλών (Cyber Threat Intelligence — CTI)</b> μετατρέπουν τα ακατέργαστα δεδομένα σε πλεονέκτημα λήψης αποφάσεων σε τρία επίπεδα. Η <b>στρατηγική</b> πληροφόρηση —ποιοι στοχεύουν τον κλάδο και με ποια πρόθεση— υποστηρίζει τη διοίκηση και τον προϋπολογισμό. Η <b>τακτική και επιχειρησιακή</b> πληροφόρηση —TTP, κακόβουλο λογισμικό και εκστρατείες— καθοδηγεί τη μηχανική ανίχνευσης και το κυνήγι απειλών. Η <b>τεχνική</b> πληροφόρηση —IoC, YARA και Sigma— τροφοδοτεί τους μηχανισμούς αποκλεισμού και ειδοποίησης. Ο κύκλος CTI περιλαμβάνει κατεύθυνση, συλλογή, επεξεργασία, ανάλυση, διάθεση και ανατροφοδότηση, ώστε οι ροές να ανταποκρίνονται στις πραγματικές ανάγκες. Η άκριτη συσσώρευση δεδομένων προκαλεί κόπωση από ειδοποιήσεις, όχι καλύτερη ασφάλεια. Για την ανταλλαγή χρησιμοποιούνται STIX/TAXII και σημάνσεις χειρισμού TLP.
    </p>
    <DataTable
      head={["Level", "Consumer", "Question answered", "Example product"]}
      rows={[
        ["Strategic", "Executives, board", "Who threatens us and why?", "Sector threat landscape brief"],
        ["Tactical", "Hunters, detection engineers", "How do they operate?", "TTP profile + hunt hypotheses"],
        ["Operational", "SOC analysts, IR", "What is happening now?", "Campaign alert with scope guidance"],
        ["Technical", "Controls, SIEM", "What exactly to block/detect?", "IoCs, YARA, Sigma (TLP-marked)"],
      ]}
    />
    <h4>3.5 ATT&amp;CK Navigator: χαρτογράφηση κάλυψης</h4>
    <p>
      Το <b>ATT&amp;CK Navigator</b> απεικονίζει τεχνικές σε χάρτες θερμότητας και αποθηκεύει τα αποτελέσματα ως κοινόχρηστα επίπεδα JSON. Οι τεχνικές βαθμολογούνται ανάλογα με την κάλυψη ανίχνευσης, τη συνάφεια της απειλής ή τα ευρήματα μιας αξιολόγησης. Με την επικάλυψη διαφορετικών επιπέδων —για παράδειγμα, προφίλ απειλής έναντι κάλυψης ελέγχων— αποκαλύπτονται τα κενά. Στο DFIR χρησιμοποιείται για την οριοθέτηση περιστατικών, τον σχεδιασμό ασκήσεων purple team και τη μέτρηση της βελτίωσης μετά από ένα συμβάν. Τα επίπεδα πρέπει να διατηρούνται υπό έλεγχο εκδόσεων, λειτουργώντας ως μητρώο «χρέους ανίχνευσης».
    </p>
    <h4>3.6 Κατάχρηση νόμιμων εργαλείων συστήματος (Living-off-the-Land)</h4>
    <p>
      Οι τεχνικές <b>Living-off-the-Land (LotL)</b> καταχρώνται νόμιμα εκτελέσιμα και υπηρεσίες —PowerShell, WMI, PsExec, RDP, BITS και certutil— με αποτέλεσμα να μην εμφανίζεται ποτέ hash κακόβουλου λογισμικού. Η διάκριση ανάμεσα στη διαχείριση και την επίθεση απαιτεί <b>βασικές γραμμές συμπεριφοράς</b>: ποιος εκτέλεσε την εντολή, από πού, με ποια γονική διεργασία και ορίσματα, ποια ώρα και σε σχέση με ποιον συνήθη όγκο. Η καταγραφή γραμμής εντολών με Sysmon, η ανίχνευση ασυνήθιστων σχέσεων γονικής και θυγατρικής διεργασίας και η ανάλυση σπάνιων διεργασιών αποτελούν βασικά αντίμετρα. Οι κατάλογοι LOLBAS και LOLDrivers καταγράφουν εργαλεία που μπορούν να καταχραστούν, αλλά το ουσιαστικό συμπέρασμα είναι αρχιτεκτονικό: κάθε διοικητική δυνατότητα του οργανισμού γίνεται δυνατότητα του αντιπάλου μετά την παραβίαση.
    </p>
    <Callout color="amber">
      <b>Συχνή παγίδα.</b> Τα εκτελέσιμα LotL είναι υπογεγραμμένα από τη Microsoft και συχνά επιτρέπονται βάσει hash. Μια στρατηγική που σταματά στον «έμπιστο εκδότη» αποτυγχάνει απέναντι στις T1059, T1047 και T1218. Η γονική διεργασία, η γραμμή εντολών και η δικτυακή συμπεριφορά αποτελούν την ελάχιστη αξιόπιστη τριάδα ανίχνευσης.
    </Callout>
    <h4>3.7 Κυνήγι απειλών βάσει υπόθεσης: ο κύκλος TaHiTI/PEAK</h4>
    <p>
      Το <b>κυνήγι απειλών (threat hunting)</b> είναι η συστηματική αναζήτηση αντιπάλων που δεν έχουν εντοπιστεί, με αφετηρία την παραδοχή ότι η παραβίαση είναι πιθανή μέχρι να αποδειχθεί το αντίθετο. Ο κύκλος <b>TaHiTI/PEAK</b> (Σχ. 21) διατηρεί την έρευνα επιστημονική: διατυπώνουμε μια διαψεύσιμη υπόθεση για συγκεκριμένο TTP στο δικό μας περιβάλλον, την <b>ιεραρχούμε</b> βάσει κινδύνου και εφικτότητας, τη <b>δοκιμάζουμε</b> σε δεδομένα με γνωστή βασική γραμμή, <b>διερευνούμε</b> πλήρως τα αποτελέσματα, <b>αυτοματοποιούμε</b> όσα επιβεβαιώνονται σε κανόνες Sigma και καταγράφουμε τα <b>διδάγματα</b>. Μια υπόθεση που διαψεύδεται είναι επίσης επιτυχία, επειδή μειώνει την αβεβαιότητα. Η CTI τροφοδοτεί τόσο τη δημιουργία υποθέσεων όσο και τον εμπλουτισμό των ευρημάτων. Έρευνα χωρίς γραπτή υπόθεση είναι άσκοπη αναζήτηση· εύρημα που δεν οδηγεί σε αυτοματοποίηση αφήνει ανεκμετάλλευτη αξία.
    </p>
    <Figure
      id="fig-hunt-loop"
      label="Fig. 21 · Hypothesis-driven hunting loop ★ NEW"
      caption={
        <>
          <b>Fig. 21.</b> Every hunt enters at Hypothesis with a falsifiable claim and exits at Automate with a
          detection or at Lessons with retired uncertainty. CTI enters twice: to aim the hunt and to judge its catch.
          Loops that skip Automate leak value — the same adversary returns unopposed.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="Hunting loop">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="270" y="10" width="180" height="52" rx="10" fill="#0f1c2e" />
          <text x="360" y="31" fill="#fbbf24">1 · HYPOTHESIZE</text>
          <text x="360" y="47" fill="#cbd5e1" fontWeight="400" fontSize="10">TTP + where + signal</text>
          <rect x="490" y="80" width="180" height="52" rx="10" fill="#0e7490" />
          <text x="580" y="101" fill="#fff">2 · PRIORITIZE</text>
          <text x="580" y="117" fill="#e0f2fe" fontWeight="400" fontSize="10">risk × feasibility</text>
          <rect x="490" y="160" width="180" height="52" rx="10" fill="#b45309" />
          <text x="580" y="181" fill="#fff">3 · HUNT</text>
          <text x="580" y="197" fill="#fef3c7" fontWeight="400" fontSize="10">baseline vs. anomaly</text>
          <rect x="270" y="160" width="180" height="52" rx="10" fill="#be123c" />
          <text x="360" y="181" fill="#fff">4 · INVESTIGATE</text>
          <text x="360" y="197" fill="#ffe4e6" fontWeight="400" fontSize="10">scope every hit</text>
          <rect x="50" y="160" width="180" height="52" rx="10" fill="#166534" />
          <text x="140" y="181" fill="#fff">5 · AUTOMATE</text>
          <text x="140" y="197" fill="#dcfce7" fontWeight="400" fontSize="10">Sigma + close loop</text>
          <rect x="50" y="80" width="180" height="52" rx="10" fill="#7c3aed" />
          <text x="140" y="101" fill="#fff">CTI FEED (×2)</text>
          <text x="140" y="117" fill="#ede9fe" fontWeight="400" fontSize="10">aim + enrich</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2" fill="none">
          <polyline points="450,36 490,36 490,80" markerEnd="url(#dfir-a1)" />
          <line x1="580" y1="132" x2="580" y2="156" markerEnd="url(#dfir-a1)" />
          <line x1="490" y1="186" x2="454" y2="186" markerEnd="url(#dfir-a1)" />
          <line x1="270" y1="186" x2="234" y2="186" markerEnd="url(#dfir-a1)" />
          <polyline points="140,160 140,62 266,62" markerEnd="url(#dfir-a1)" />
        </g>
        <g stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="5 4">
          <line x1="230" y1="106" x2="266" y2="106" />
          <line x1="230" y1="186" x2="266" y2="186" />
        </g>
        <text x="360" y="234" textAnchor="middle" fontSize="11" fill="#64748b">Διαψευσμένη υπόθεση = επιτυχία, επειδή μειώνεται η αβεβαιότητα · Μη αυτοματοποιημένο εύρημα = χρέος</text>
      </svg>
    </Figure>
    <h4>3.8 Πέρα από τα βασικά: Unified Kill Chain, KEV και D3FEND</h4>
    <p>
      Τρεις επεκτάσεις ολοκληρώνουν το σύνολο εργαλείων μοντελοποίησης. Το <b>Unified Kill Chain</b> του Pols επεκτείνει τα επτά στάδια της Lockheed σε δεκαοκτώ, προσθέτοντας ως διακριτές φάσεις την πλευρική μετακίνηση, την κλιμάκωση προνομίων, την αποφυγή άμυνας και τους τελικούς στόχους. Έτσι αποτυπώνει πιστότερα τις διαδρομές ATT&amp;CK και τις αναφορές red team. Ο κατάλογος <b>Known Exploited Vulnerabilities (KEV)</b> της CISA περιλαμβάνει ευπάθειες με επιβεβαιωμένη εκμετάλλευση: σε ένα περιστατικό, η παρουσία στον KEV σε συνδυασμό με τη βαθμολογία πιθανότητας <b>EPSS</b> καθορίζει ποια ευάλωτα συστήματα εξετάζονται πρώτα. Το <b>MITRE D3FEND</b> λειτουργεί αμυντικά απέναντι στο ATT&amp;CK, αντιστοιχίζοντας επιθετικές τεχνικές με τεχνικές αντιμέτρων. Οι επιπλέον πίνακες ATT&amp;CK —<b>PRE</b>, <b>Mobile</b> και <b>ICS</b>— επιτρέπουν σε εταιρικές, βιομηχανικές και κινητές έρευνες να χρησιμοποιούν κοινή γλώσσα.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 3.1 · Χαρτογράφηση Kill Chain και ATT&amp;CK (60 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Με βάση ένα δισέλιδο σενάριο εισβολής —phishing → macro → C2 → LSASS → RDP → εξαγωγή— αντιστοιχίστε κάθε βήμα σε στάδιο του Kill Chain.</li>
      <li>Αντιστοιχίστε κάθε βήμα σε αναγνωριστικά τεχνικών ATT&amp;CK. Στόχος είναι τουλάχιστον οκτώ αντιστοιχίσεις, με υποτεχνικές όπου χρειάζεται.</li>
      <li>Για κάθε τεχνική, προσδιορίστε το ισχυρότερο εγκληματολογικό τεχνούργημα που την αποδεικνύει ή τη διαψεύδει, μαζί με το κεφάλαιο και την πηγή καταγραφής.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 3.2 · Αναδιατύπωση βάσει Πυραμίδας Κόστους (30 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Πάρτε μια αναφορά προμηθευτή που περιέχει μόνο hash και IP και αναδιατυπώστε τις συστάσεις της σε επίπεδο TTP.</li>
      <li>Συντάξτε μία υπόθεση έρευνας ανά TTP, ορίζοντας πηγή δεδομένων, βασική γραμμή και κριτήριο ανωμαλίας.</li>
      <li>Αξιολογήστε ο ένας την εργασία του άλλου: θα παρέμενε αποτελεσματική η ανίχνευση μετά από νέα μεταγλώττιση και αλλαγή τομέα C2; Αν όχι, ανεβείτε ψηλότερα στην πυραμίδα.</li>
    </ol>
  </>
);

export const ch03: Κεφάλαιο = {
  id: "ch3",
  num: 3,
  title: "Πλαίσια Απειλών και Τεχνικές Αντιπάλου (MITRE ATT&CK και CTI)",
  subtitle: "Kill Chain · Diamond Model · ATT&CK · Πυραμίδα Κόστους · CTI · Navigator · LotL",
  badge: "Θεμελιώδεις αρχές · Βασικές γραμμές απειλών",
  time: "7–9 ώρες · περίπου 34 σελίδες",
  outcomes:
    "Μοντελοποιείτε εισβολές με Kill Chain, Diamond Model και ATT&CK· ιεραρχείτε ελέγχους με την Πυραμίδα του Κόστους· αξιοποιείτε CTI ανά επίπεδο· δημιουργείτε επίπεδα κάλυψης στο Navigator· και ανιχνεύετε τεχνικές LotL βάσει συμπεριφοράς.",
  body,
  labTitle: "Πρακτική Άσκηση 3.1 · Χαρτογράφηση Kill Chain και ATT&CK + Άσκηση 3.2 · Αναδιατύπωση βάσει Πυραμίδας Κόστους",
  labsBody,
  workshop: {
    title: "Οριοθέτηση βάσει απειλής: χαρτογράφηση περιστατικού στο ATT&CK και αξιολόγηση κάλυψης",
    env: ["ATT&CK Navigator (τοπικά)", "Φύλλο σεναρίου περιστατικού", "jq και python3"],
    tabs: [
      {
        id: "map",
        label: "Χαρτογράφηση τεχνικών",
        steps: [
          {
            n: "1",
            title: "Εξαγάγετε τον βασικό κορμό τεχνικών",
            desc: "Διαβάστε το σενά μία φορά για τη συνολική εικόνα και δεύτερη φορά εστιάζοντας στα ρήματα. Κάθε ενέργεια του αντιπάλου αντιστοιχεί σε τεχνική.",
            code: [
              {
                title: "Bash — απογραφή τεχνικών",
                text: `cat > incident-techniques.txt <<'EOF'\nT1566.001 Spearphishing Attachment   # malicious xlsm\nT1059.001 PowerShell                 # base64 -enc payload\nT1071.004 DNS C2                     # TXT beacons\nT1003.001 LSASS Memory               # credential dump\nT1021.004 SSH / T1021.001 RDP        # lateral movement\nT1048 Exfiltration Over C2           # staged rar to C2\nEOF\ncat incident-techniques.txt`,
              },
            ],
          },
          {
            n: "2",
            title: "Συνδέστε κάθε τεχνική με τις πηγές δεδομένων",
            desc: "Τεχνική χωρίς αντιστοίχιση παραμένει εκτός οριοθέτησης. Κάθε τεχνική χρειάζεται πηγή καταγραφής που θα μπορούσε να την έχει παρατηρήσει.",
            code: [
              {
                title: "Bash — πίνακας πηγών",
                text: `cat > technique-sources.tsv <<'EOF'\nT1566.001\tmail gateway + attachment detonation logs\nT1059.001\tSysmon EID 1 (command line) + ScriptBlock logging\nT1071.004\tDNS query logs + Zeek dns.log\nT1003.001\tSysmon EID 10 (lsass access) + EDR telemetry\nT1021.004\tsshd auth.log + firewall allows\nT1048\tproxy bytes-out + Zeek conn.log orig_bytes\nEOF\ncolumn -s$'\\t' -t technique-sources.tsv`,
              },
            ],
          },
        ],
      },
      {
        id: "nav",
        label: "Επίπεδο Navigator",
        steps: [
          {
            n: "3",
            title: "Δημιουργήστε επίπεδο κάλυψης",
            desc: "Βαθμολογήστε από 0 —πλήρες κενό— έως 3 —ενεργή ειδοποίηση— και αφήστε το Navigator να δημιουργήσει τον χάρτη θερμότητας από το JSON.",
            code: [
              {
                title: "Bash — Επίπεδο Navigator JSON",
                text: `cat > coverage-layer.json <<'EOF'\n{\n  "name": "INC-2026-0117 coverage", "version": "4.5", "domain": "enterprise-attack",\n  "techniques": [\n    {"techniqueID": "T1566.001", "score": 2, "comment": "gateway blocks known; macro detonation partial"},\n    {"techniqueID": "T1059.001", "score": 1, "comment": "Sysmon deployed 60% fleet; no alerting"},\n    {"techniqueID": "T1071.004", "score": 0, "comment": "no DNS logging — BLIND"},\n    {"techniqueID": "T1003.001", "score": 2, "comment": "EDR blocks known dumpers"},\n    {"techniqueID": "T1021.004", "score": 1, "comment": "auth.log collected, no correlation"},\n    {"techniqueID": "T1048", "score": 0, "comment": "no egress anomaly detection — BLIND"}\n  ],\n  "gradient": {"colors": ["#ff6666", "#ffe766", "#8ec843"], "minValue": 0, "maxValue": 3}\n}\nEOF\njq '.techniques | map(select(.score==0) | .techniqueID)' coverage-layer.json`,
              },
            ],
            expected: '["T1071.004", "T1048"] — τα κενά ορατότητας που πρέπει να καθορίσουν το σχέδιο έρευνας',
          },
        ],
      },
      {
        id: "hunt",
        label: "Σχέδιο έρευνας",
        steps: [
          {
            n: "4",
            title: "Μετατρέψτε τα κενά ορατότητας σε έρευνες",
            desc: "Κάθε τεχνική με βαθμολογία 0 μετατρέπεται σε υπόθεση έρευνας με πηγή δεδομένων και κριτήρια επιτυχίας.",
            code: [
              {
                title: "Bash — κάρτες έρευνας",
                text: `cat > hunt-plan.md <<'EOF'\n## H-1 DNS C2 (T1071.004) — BLIND\n- Hypothesis: beacons hide in TXT queries to newly-registered domains\n- Data: enable DNS debug log + Zeek dns.log (Ch. 8-9); baseline query entropy\n- Hit criteria: periodic TXT to low-reputation domain from >1 host\n## H-2 Exfil over C2 (T1048) — BLIND\n- Hypothesis: staged archives egress in off-hours bursts\n- Data: proxy bytes-out + conn.log; baseline per-host egress\n- Hit criteria: >500MB off-hours egress to non-CDN host\nEOF\ncat hunt-plan.md`,
              },
            ],
          },
          {
            n: "5",
            title: "Καταγράψτε το χρέος ανίχνευσης",
            note: "Παραδοτέο: incident-techniques.txt, technique-sources.tsv, coverage-layer.json και hunt-plan.md. Κανόνας χρέους: κανένα περιστατικό δεν κλείνει όσο υπάρχει τεχνική βαθμολογίας 0 χωρίς υπεύθυνο.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> τακτικές ATT&amp;CK (§3.2) · Pyramid of Pain (§3.3) → δεδομένα Sysmon (§3.6, Κεφ. 6) →
        ανιχνεύσεις Sigma (Κεφ. 12). Παραδοτέο: επίπεδο Navigator που λειτουργεί παράλληλα ως μητρώο χρέους
        ανίχνευσης του περιστατικού.
      </>
    ),
  },
  quiz: [
    { q: "Ποιες είναι οι τέσσερις κορυφές του Diamond Model;", o: ["Αντίπαλος, δυνατότητα, υποδομή και θύμα", "Προετοιμασία, εντοπισμός, περιορισμός και ανάκαμψη", "Hash, IP, domain και URL", "Εμπιστευτικότητα, ακεραιότητα, διαθεσιμότητα και χρησιμότητα"], a: 0, e: "Η διερεύνηση μετακινείται κατά μήκος των σχέσεων αντιπάλου, δυνατότητας, υποδομής και θύματος." },
    { q: "Πώς περιγράφεται καλύτερα η T1059.001 (PowerShell);", o: ["Τακτική", "Τεχνική και ειδικότερα υποτεχνική", "Διαδικασία που αφορά αποκλειστικά μία ομάδα", "Μέτρο μετριασμού"], a: 1, e: "Οι τεχνικές απαντούν στο «πώς», ενώ η κατάληξη .001 δηλώνει υποτεχνική." },
    { q: "Σύμφωνα με την Pyramid of Pain, ποιο επίπεδο προσφέρει την ανθεκτικότερη ανίχνευση;", o: ["Hash αρχείων", "Διευθύνσεις IP", "Ονόματα τομέα", "TTP"], a: 3, e: "Οι συμπεριφορές είναι απαραίτητες για την αποστολή του αντιπάλου και η αλλαγή τους έχει υψηλό κόστος." },
    { q: "Μια κλαδική επισκόπηση απειλών για στελέχη αποτελεί:", o: ["Τεχνική πληροφόρηση", "Στρατηγική πληροφόρηση", "Κανόνα firewall", "Ροή hash"], a: 1, e: "Η στρατηγική CTI απαντά ποιος απειλεί τον οργανισμό και γιατί, υποστηρίζοντας τη λήψη αποφάσεων." },
    { q: "Σε τι χρησιμοποιούνται κυρίως τα επίπεδα ATT&CK Navigator;", o: ["Στην κρυπτογράφηση κίνησης C2", "Στην απεικόνιση και σύγκριση κάλυψης τεχνικών με βαθμολογημένους χάρτες", "Στην απεικόνιση δίσκων", "Στη δημιουργία κωδικών"], a: 1, e: "Τα βαθμολογημένα επίπεδα αποκαλύπτουν άμεσα τα κενά ανίχνευσης." },
    { q: "Ποια είναι η ελάχιστη αξιόπιστη τριάδα για ανίχνευση κατάχρησης LotL;", o: ["Hash, IP και domain", "Γονική διεργασία, γραμμή εντολών και δικτυακή συμπεριφορά", "Όνομα χρήστη, κωδικός και MFA", "Κατασκευαστής, μοντέλο και σειριακός αριθμός"], a: 1, e: "Τα υπογεγραμμένα εκτελέσιμα παρακάμπτουν τις allowlists βάσει hash. Το ουσιαστικό σήμα είναι η συμπεριφορά." },
  ],
};
