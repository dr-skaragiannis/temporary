import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>12.1 Ανίχνευση ως Κώδικας (Detection as Code — DaC)</h4>
    <p>
      Η προσέγγιση <b>Detection as Code</b> αντιμετωπίζει κάθε ανίχνευση όπως το λογισμικό: διατηρείται σε Git, αξιολογείται από δεύτερο μηχανικό, δοκιμάζεται με συμβάντα αναφοράς, διατίθεται μέσω CI/CD και αποσύρεται βάσει προγράμματος. Το όφελος είναι προέλευση εγκληματολογικού επιπέδου —ποια έκδοση κανόνα ενεργοποιήθηκε, από ποιο περιστατικό προέκυψε και με ποια δεδομένα δοκιμάστηκε— μαζί με ασφαλή ταχύτητα αλλαγών. Έτσι αποφεύγονται πρόχειρες τροποποιήσεις στο SIEM που κατακλύζουν το SOC με ειδοποιήσεις. Η δομή του αποθετηρίου ακολουθεί τον κύκλο ζωής (Σχ. 18): <span className="mono text-sm">detections/</span> για πηγές Sigma/YAML, <span className="mono text-sm">tests/</span> για θετικά και αρνητικά δείγματα, <span className="mono text-sm">deploy/</span> για μεταγλωττισμένα ερωτήματα ανά πλατφόρμα και <span className="mono text-sm">docs/</span> για σχέδια ενεργειών συνδεδεμένα με κάθε ειδοποίηση.
    </p>
    <Figure
      id="fig-dac-pipe"
      label="Σχ. 18 · Κύκλος ζωής Detection as Code"
      caption={
        <>
          <b>Σχ. 18.</b> Οι ανιχνεύσεις αντιμετωπίζονται ως λογισμικό: τα περιστατικά και οι πληροφορίες απειλών μετατρέπονται σε Sigma, το CI μεταγλωττίζει και δοκιμάζει τους κανόνες,
          η διάθεση γίνεται σταδιακά και τα αποτελέσματα της ρύθμισης επιστρέφουν στην πηγή. Κανένα στάδιο δεν είναι προαιρετικό — κανόνας που δεν έχει δοκιμαστεί δεν διατίθεται.
        </>
      }
    >
      <svg viewBox="0 0 720 220" className="w-full h-auto" role="img" aria-label="Ροή ανάπτυξης ανιχνεύσεων">
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="50" width="120" height="90" rx="8" fill="#0f1c2e" />
          <text x="70" y="72" fill="#fbbf24">1 · AUTHOR</text>
          <text x="70" y="88" fill="#cbd5e1" fontWeight="400">Sigma YAML</text>
          <text x="70" y="103" fill="#cbd5e1" fontWeight="400">+ runbook</text>
          <text x="70" y="122" fill="#fbbf24" fontSize="9">από περιστατικό/πληροφορίες</text>
          <rect x="148" y="50" width="120" height="90" rx="8" fill="#0e7490" />
          <text x="208" y="72" fill="#fff">2 · TEST</text>
          <text x="208" y="88" fill="#e0f2fe" fontWeight="400">δείγματα ±</text>
          <text x="208" y="103" fill="#e0f2fe" fontWeight="400">αναπαραγωγή atomic</text>
          <text x="208" y="122" fill="#fef08a" fontSize="9">το CI πρέπει να περάσει</text>
          <rect x="286" y="50" width="120" height="90" rx="8" fill="#b45309" />
          <text x="346" y="72" fill="#fff">3 · TRANSPILE</text>
          <text x="346" y="88" fill="#fef3c7" fontWeight="400">pySigma →</text>
          <text x="346" y="103" fill="#fef3c7" fontWeight="400">SPL/KQL/etc.</text>
          <text x="346" y="122" fill="#fff" fontSize="9">ανά πλατφόρμα</text>
          <rect x="424" y="50" width="120" height="90" rx="8" fill="#166534" />
          <text x="484" y="72" fill="#fff">4 · DEPLOY</text>
          <text x="484" y="88" fill="#dcfce7" fontWeight="400">staging → canary</text>
          <text x="484" y="103" fill="#dcfce7" fontWeight="400">→ production</text>
          <text x="484" y="122" fill="#fff" fontSize="9">έτοιμο για επαναφορά</text>
          <rect x="562" y="50" width="148" height="90" rx="8" fill="#7c3aed" />
          <text x="636" y="72" fill="#fff">5 · TUNE / RETIRE</text>
          <text x="636" y="88" fill="#ede9fe" fontWeight="400">έλεγχος FP στις 14/90 ημέρες</text>
          <text x="636" y="103" fill="#ede9fe" fontWeight="400">απόσυρση παρωχημένων</text>
          <text x="636" y="122" fill="#fff" fontSize="9">ανατροφοδότηση στο 1</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="130" y1="95" x2="144" y2="95" markerEnd="url(#dfir-a1)" />
          <line x1="268" y1="95" x2="282" y2="95" markerEnd="url(#dfir-a1)" />
          <line x1="406" y1="95" x2="420" y2="95" markerEnd="url(#dfir-a1)" />
          <line x1="544" y1="95" x2="558" y2="95" markerEnd="url(#dfir-a1)" />
        </g>
        <g stroke="#64748b" strokeWidth="2" fill="none">
          <polyline points="636,140 636,170 70,170 70,144" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="192" textAnchor="middle" fontSize="11" fill="#64748b">Ανατροφοδότηση ρύθμισης: η ανάλυση ψευδώς θετικών και τα αποτελέσματα προσομοίωσης ενημερώνουν την πηγή Sigma — ποτέ μόνο το αναπτυγμένο ερώτημα</text>
      </svg>
    </Figure>
    <h4>12.2 Αρχιτεκτονική κανόνων Sigma</h4>
    <p>
      Το <b>Sigma</b> είναι ανεξάρτητη από προμηθευτή μορφή ανταλλαγής ανιχνεύσεων: ένας κανόνας YAML μπορεί να μεταγλωττιστεί σε Splunk, Elastic, QRadar και δεκάδες άλλα συστήματα. Η δομή περιλαμβάνει title, id, status, author και date για ταυτότητα και κύκλο ζωής· <b>logsource</b> για προϊόν, υπηρεσία και κατηγορία· <b>detection</b> με ονομασμένα σύνολα επιλογής και condition που τα συνδυάζει· <b>falsepositives</b> για ειλικρινή καταγραφή γνωστών εξαιρέσεων· <b>level</b> για σοβαρότητα· και <b>tags</b> με αναγνωριστικά τεχνικών ATT&amp;CK. Το ελάχιστο επίπεδο ποιότητας απαιτεί από κάθε κανόνα να ορίζει την τεχνική ATT&amp;CK, τη δοκιμασμένη πηγή καταγραφής και τα γνωστά ψευδώς θετικά. Αν λείπει ένα από τα τρία, ο κανόνας δεν εγκρίνεται.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="YAML — Sigma: encoded PowerShell via WinWord parent (T1059.001 + T1566.001)"
        code={`title: Encoded PowerShell Spawned by Office App\nid: dfir-2026-0041\nstatus: experimental\nauthor: SOC Detection Eng.\ndate: 2026/09/26\nlogsource:\n  product: windows\n  service: sysmon\n  definition: 'EventID 1 required (Sysmon)'\ndetection:\n  selection_parent:\n    ParentImage|endswith:\n      - '\\WINWORD.EXE'\n      - '\\EXCEL.EXE'\n  selection_encoded:\n    CommandLine|contains:\n      - ' -enc '\n      - ' -EncodedCommand '\n      - 'FromBase64String'\n  condition: selection_parent and selection_encoded\nfalsepositives:\n  - Developer macros invoking encoded helpers (rare; allowlist by hash)\nlevel: high\ntags:\n  - attack.execution\n  - attack.t1059.001\n  - attack.t1566.001`}
      />
    </div>
    <h4>12.3 Μεταγλώττιση κανόνων με pySigma</h4>
    <p>
      Το <b>pySigma</b> μετατρέπει γενικούς κανόνες σε εγγενή ερωτήματα μέσω πρόσθετων backend για Splunk, Elasticsearch, QRadar και άλλα συστήματα. Οι γραμμές επεξεργασίας προσαρμόζουν τα ονόματα πεδίων στο τοπικό σχήμα, όπως οι αντιστοιχίσεις ECS και CIM του Κεφαλαίου 11. Σε κάθε commit, το CI μεταγλωττίζει όλους τους κανόνες για κάθε ενεργό backend. Τα σφάλματα σταματούν το build και οι διαφορές των παραγόμενων ερωτημάτων εμφανίζονται στους αξιολογητές, ώστε να γνωρίζουν ακριβώς τι θα διατεθεί. Ο βασικός κανόνας είναι: οι μηχανικοί επεξεργάζονται το Sigma και οι μηχανές παράγουν SPL ή KQL. Χειροκίνητες αλλαγές στα αναπτυγμένα ερωτήματα αποκλίνουν γρήγορα από την πηγή και γίνονται δύσκολο να ελεγχθούν.
    </p>
    <h4>12.4 Λειτουργία της πλατφόρμας MISP</h4>
    <p>
      Το <b>MISP (Malware Information Sharing Platform)</b> είναι ανοικτός κόμβος CTI. Τα συμβάντα συνδυάζουν χαρακτηριστικά —hash, IP, domains, YARA και Sigma— με δομημένα αντικείμενα αρχείων, URL και ευπαθειών, galaxies για ομάδες απειλών, εργαλεία και TTP, και ετικέτες TLP, βεβαιότητας και ATT&amp;CK. Στις ροές DFIR, δημοσιεύουμε χαρακτηριστικά που προέκυψαν από περιστατικό μαζί με sightings, συσχετίζουμε αυτόματα νέες ειδοποιήσεις με αποθηκευμένους δείκτες και συγχρονίζουμε επιλεκτικά με έμπιστες κοινότητες, όπως κλαδικά ISAC. Η υγιεινή δεδομένων είναι κρίσιμη: οι IoC λήγουν ανάλογα με τον τύπο τους, διατηρούν first-seen, last-seen και sightings και καμία ροή δεν εισάγεται πριν μετρηθεί το ποσοστό ψευδώς θετικών. Το MISP ενισχύει τόσο το χρήσιμο σήμα όσο και τον θόρυβο.
    </p>
    <DataTable
      head={["Δομή MISP", "Περιεχόμενο", "Χρήση στο DFIR"]}
      rows={[
        ["Συμβάν", "Ενιαίο σύνολο περιστατικού/εκστρατείας", "Case-041: χαρακτηριστικά, galaxies και αναφορές σε ένα σημείο"],
        ["Χαρακτηριστικό", "Μεμονωμένο IoC (τύπος, τιμή και πλαίσιο)", "Αυτόματη συσχέτιση ευρημάτων SIEM και προώθηση σε λίστες αποκλεισμού ανά τύπο"],
        ["Galaxy/Cluster", "Γνώση για δράστες, εργαλεία και TTP", "Επισήμανση συμβάντων και μετάβαση σε συναφείς εκστρατείες"],
        ["Sighting", "Επιβεβαίωση παρατήρησης στο πραγματικό περιβάλλον", "Στάθμιση βάσει επιβεβαίωσης και λήξη όσων δεν παρατηρούνται"],
        ["Ομάδα διαμοιρασμού και TLP", "Όριο διάδοσης", "Επιβολή της αρχής need-to-know· το TLP:RED παραμένει εσωτερικό"],
      ]}
    />
    <h4>12.5 Αυτοματοποιημένος εμπλουτισμός απειλών: ροές STIX/TAXII</h4>
    <p>
      Το <b>STIX 2.1</b> περιγράφει δομημένα αντικείμενα —δείκτες, κακόβουλο λογισμικό και σχέσεις— ενώ το <b>TAXII 2.1</b> μεταφέρει συλλογές μέσω polling ή push. Η αρχιτεκτονική εμπλουτισμού λειτουργεί ως εξής: οι TAXII pollers εισάγουν δεδομένα στο MISP, οι πολιτικές συσχέτισης και λήξης τα επιμελούνται και οι εργασίες εξαγωγής προωθούν λίστες κατάλληλες για SIEM. Δείκτες υψηλής βεβαιότητας μπορούν να αποκλείονται, μεσαίας να παράγουν ειδοποίηση και χαμηλής να χρησιμοποιούνται μόνο σε έρευνα. Κρίσιμος έλεγχος είναι η ανατροφοδότηση: sightings και αναφορές ψευδώς θετικών επιστρέφουν στους παραγωγούς. Η τοπική πληροφορία που προκύπτει από ενεργό περιστατικό υπερέχει συχνά μιας εμπορικής ροής ως προς τη φρεσκάδα και τη συνάφεια.
    </p>
    <h4>12.6 Δοκιμές προσομοίωσης αντιπάλου: Atomic Red Team</h4>
    <p>
      Μια ανίχνευση αποδεικνύει την αξία της μόνο όταν δοκιμαστεί απέναντι σε πραγματική εκτέλεση συμπεριφοράς αντιπάλου. Το <b>Atomic Red Team</b> παρέχει μικρές, αντιστοιχισμένες στο ATT&amp;CK δοκιμές πολλαπλών πλατφορμών. Εκτελέστε, για παράδειγμα, το atomic κωδικοποιημένου PowerShell για T1059.001, επιβεβαιώστε ότι ο κανόνας Sigma ενεργοποιείται σε ολόκληρη την αλυσίδα —τηλεμετρία, SIEM, ειδοποίηση και δελτίο— και στη συνέχεια καθαρίστε το περιβάλλον. Η ενσωμάτωση στο CI μπορεί να εκτελεί τις δοκιμές κάθε βράδυ σε αναλώσιμο εργαστήριο, μετατρέποντας την κάλυψη σε μετρήσιμο ποσοστό τεχνικών με επιτυχή έλεγχο άκρου προς άκρο. Κάθε νέος κανόνας πρέπει να συνοδεύεται από δοκιμή που τον αποδεικνύει. Τα atomics εκτελούνται μόνο σε απομονωμένες εικονικές μηχανές με στιγμιότυπα και εργαστηριακά διαπιστευτήρια.
    </p>
    <Callout color="violet">
      <b>Δείκτης κάλυψης — υιοθετήστε τον.</b> <i>Detection coverage = techniques with passing end-to-end emulation tests ÷
      techniques in your threat profile.</i> Report it monthly; every incident must raise it or explain why it could
      not.
    </Callout>
    <h4>12.7 YARA: αναζήτηση περιεχομένου σε αρχεία και μνήμη</h4>
    <p>
      Ενώ το Sigma αναζητά συμβάντα, το <b>YARA</b> αναζητά περιεχόμενο σε αρχεία και bytes μνήμης. Ένας κανόνας (Σχ. 23) έχει τρία μέρη: <b>meta</b> με όνομα, περιγραφή, δημιουργό, ημερομηνία, TLP και ATT&amp;CK· <b>strings</b> με κείμενο και τροποποιητές nocase, wide και ascii, δεκαεξαδικά μοτίβα, κανονικές εκφράσεις και ιδιωτικές βοηθητικές συμβολοσειρές· και <b>condition</b> με λογική όπως any of them, 2 of ($a*), $mz at 0 ή filesize κάτω από όριο. Σαρώστε εικόνες και προσαρτημένους δίσκους με <span className="mono text-sm">yara -r</span>, μνήμη με το <span className="mono text-sm">vadyarascan</span> του Volatility και στόλους με εργαλεία τύπου LOKI/THOR. Οι κανόνες διαχειρίζονται όπως το Sigma: Git, δοκιμές σε νόμιμα και κακόβουλα σύνολα, μέτρηση ψευδώς θετικών και ανταλλαγή μέσω MISP. Αποφύγετε κοινές μεμονωμένες συμβολοσειρές· βασιστείτε σε σπάνιες σταθερές, χαρακτηριστικές διαδρομές PDB, στοιχεία C2 και συνθήκες πολλαπλών μοτίβων.
    </p>
    <Figure
      id="fig-yara"
      label="Σχ. 23 · Ανατομία κανόνα YARA pipeline ★ NEW"
      caption={
        <>
          <b>Fig. 23.</b> Meta rides along so every match explains itself; strings define the evidence; the condition
          sets the burden of proof. Matches flow to triage with rule identity attached — detections that document
          themselves.
        </>
      }
    >
      <svg viewBox="0 0 720 190" className="w-full h-auto" role="img" aria-label="Ανατομία κανόνα YARA">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="160" height="100" rx="10" fill="#0f1c2e" />
          <text x="90" y="62" fill="#fbbf24">META</text>
          <text x="90" y="79" fill="#cbd5e1" fontWeight="400" fontSize="10">όνομα · δημιουργός</text>
          <text x="90" y="95" fill="#cbd5e1" fontWeight="400" fontSize="10">ημερομηνία · TLP</text>
          <text x="90" y="114" fill="#fbbf24" fontSize="9">συνοδεύει το εύρημα</text>
          <rect x="190" y="40" width="180" height="100" rx="10" fill="#0e7490" />
          <text x="280" y="62" fill="#fff">ΣΥΜΒΟΛΟΣΕΙΡΕΣ</text>
          <text x="280" y="79" fill="#e0f2fe" fontWeight="400" fontSize="10">text / hex / regex</text>
          <text x="280" y="95" fill="#e0f2fe" fontWeight="400" fontSize="10">nocase · wide · private</text>
          <text x="280" y="114" fill="#fef08a" fontSize="9">τα πειστήρια</text>
          <rect x="390" y="40" width="160" height="100" rx="10" fill="#b45309" />
          <text x="470" y="62" fill="#fff">ΣΥΝΘΗΚΗ</text>
          <text x="470" y="79" fill="#fef3c7" fontWeight="400" fontSize="10">any / all / N of</text>
          <text x="470" y="95" fill="#fef3c7" fontWeight="400" fontSize="10">at / in / filesize</text>
          <text x="470" y="114" fill="#fff" fontSize="9">βάρος απόδειξης</text>
          <rect x="570" y="40" width="140" height="100" rx="10" fill="#166534" />
          <text x="640" y="62" fill="#fff">ΑΝΤΙΣΤΟΙΧΙΣΗ →</text>
          <text x="640" y="79" fill="#dcfce7" fontWeight="400" fontSize="10">κανόνας + συμβολοσειρές</text>
          <text x="640" y="95" fill="#dcfce7" fontWeight="400" fontSize="10">+ offsets</text>
          <text x="640" y="114" fill="#fff" fontSize="9">αυτοτελής ερμηνεία</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="170" y1="90" x2="186" y2="90" markerEnd="url(#dfir-a1)" />
          <line x1="370" y1="90" x2="386" y2="90" markerEnd="url(#dfir-a1)" />
          <line x1="550" y1="90" x2="566" y2="90" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="164" textAnchor="middle" fontSize="11" fill="#64748b">Δοκιμάστε κάθε κανόνα σε αβλαβή σύνολα πριν από την ανάπτυξη στον στόλο — ένας αδοκίμαστος κανόνας YARA παράγει καταιγισμό ψευδώς θετικών</text>
      </svg>
    </Figure>
    <div className="not-serif">
      <CodeBlock
        title="YARA — κανόνας macro-dropper και εντολές σάρωσης"
        code={`rule Office_Macro_Dropper {\n  meta:\n    description = "Office doc spawning encoded PowerShell patterns"\n    author = "DFIR lab"\n    date = "2026-09-26"\n    tlp = "amber"\n  strings:\n    $ps = "powershell" nocase wide ascii\n    $enc1 = "-EncodedCommand" nocase\n    $enc2 = "-enc " nocase\n    $b64 = "FromBase64String" nocase\n    $auto = "AutoOpen" nocase\n  condition:\n    $auto and 2 of ($ps, $enc1, $enc2, $b64)\n}\n\n// scan a mounted image + memory image\n// yara -r macro-dropper.yar /mnt/image/\n// vol -f mem.raw windows.vadyarascan --yara-file macro-dropper.yar`}
      />
    </div>
    <p>
      Δύο συμπληρωματικές πρακτικές ολοκληρώνουν τον κύκλο. <b>Αντιστοίχιση D3FEND:</b> για κάθε TTP ενός περιστατικού, εντοπίστε τα αντίστοιχα
      αμυντικά αντίμετρα στο MITRE D3FEND και παραπέμψτε σε αυτά στις συστάσεις της αναφοράς. Η τεκμηρίωση βάσει TTP μετατρέπει τη γενική πρόταση
      «αγοράστε EDR» σε «παρατηρήθηκε T1003.001 → ενίσχυση διαπιστευτηρίων, προστασία LSASS και ειδοποίηση για EID 10», μια διατύπωση που μπορεί να στηρίξει
      συγκεκριμένο προϋπολογισμό. Η <b>συνάθροιση Sigma</b> καλύπτει τη λογική ορίων που δεν χρειαζόταν ο κανόνας της §12.2:{" "}
      <span className="mono text-sm">condition: selection | count() by srcip &gt; 20</span> για password spraying,{" "}
      συσχετίσεις <span className="mono text-sm">near</span> μεταξύ επιλογών και μετρήσεις σε χρονικά παράθυρα — τη γέφυρα από
      κανόνες μεμονωμένων συμβάντων προς τις συμπεριφορικές ανιχνεύσεις του Κεφαλαίου 11.
    </p>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 12.1 · Σύνταξη και μεταγλώττιση Sigma (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Συντάξτε δύο κανόνες Sigma από τα TTP της υπόθεσης 041 (κωδικοποιημένη μακροεντολή Office και πρόσβαση στο LSASS), με πλήρη μεταδεδομένα.</li>
      <li>Μεταγλωττίστε τους κανόνες για το backend του εργαστηριακού SIEM μέσω pySigma· συγκρίνετε και αξιολογήστε τα παραγόμενα ερωτήματα.</li>
      <li>Αξιολογήστε τους κανόνες άλλης ομάδας με βάση τα κριτήρια της §12.2· απορρίψτε όσους δεν περιλαμβάνουν ATT&amp;CK, ψευδώς θετικά ή logsource.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 12.2 · MISP και κύκλος προσομοίωσης (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Δημοσιεύστε τα χαρακτηριστικά της υπόθεσης 041 στο MISP με galaxies, TLP και sightings· ρυθμίστε τη λήξη τους.</li>
      <li>Εκτελέστε τις αντίστοιχες δοκιμές Atomic Red Team και επαληθεύστε από άκρο σε άκρο την ενεργοποίηση και των δύο κανόνων.</li>
      <li>Καταγράψτε τη μεταβολή κάλυψης: ποιες τεχνικές του προφίλ απειλής πέρασαν από αδοκίμαστες σε επιτυχώς επαληθευμένες.</li>
    </ol>
  </>
);

export const ch12: Κεφάλαιο = {
  id: "ch12",
  num: 12,
  title: "Μηχανική Ανίχνευσης, Κανόνες Sigma και Ενσωμάτωση Πληροφοριών Απειλών (MISP)",
  subtitle: "Detection as Code · Sigma · pySigma · MISP · STIX/TAXII · Atomic Red Team",
  badge: "Tier 4 · Μηχανική ανίχνευσης",
  time: "9–11 h · ~40 pages equiv.",
  outcomes:
    "Διαχειρίζεστε τον κύκλο ζωής ανιχνεύσεων ως κώδικα· συντάσσετε κανόνες Sigma κατάλληλους για αξιολόγηση· τους μεταγλωττίζετε με ροές pySigma· χειρίζεστε συμβάντα και galaxies στο MISP· αυτοματοποιείτε εμπλουτισμό STIX/TAXII· και αποδεικνύετε κανόνες μέσω προσομοίωσης αντιπάλου.",
  body,
  labTitle: "Πρακτική Άσκηση 12.1 · Σύνταξη και μεταγλώττιση Sigma + Άσκηση 12.2 · MISP και κύκλος προσομοίωσης",
  labsBody,
  workshop: {
    title: "Διάθεση ανίχνευσης: από το Sigma στην ειδοποίηση και την απόδειξη μέσω προσομοίωσης",
    env: ["Αποθετήριο ανιχνεύσεων (Git)", "pySigma και εργαστηριακό SIEM", "VM Atomic Red Team (στιγμιότυπο)"],
    tabs: [
      {
        id: "author",
        label: "Σύνταξη και δοκιμή",
        steps: [
          {
            n: "1",
            title: "Σύνταξη Sigma από το TTP του περιστατικού",
            desc: "Ξεκινήστε από την επιβεβαιωμένη τεχνική (T1059.001), όχι από ένα hash, ακολουθώντας την Πυραμίδα του Πόνου.",
            code: [
              {
                title: "Bash — βασικός σκελετός κανόνα",
                text: `mkdir -p detections/windows/sysmon tests/fixtures\ncat > detections/windows/sysmon/office-encoded-ps.yml <<'EOF'\ntitle: Encoded PowerShell Spawned by Office App\nid: dfir-2026-0041\nstatus: experimental\nlogsource: {product: windows, service: sysmon}\ndetection:\n  selection_parent:\n    ParentImage|endswith: ['\\\\WINWORD.EXE', '\\\\EXCEL.EXE']\n  selection_encoded:\n    CommandLine|contains: [' -enc ', 'FromBase64String']\n  condition: selection_parent and selection_encoded\nlevel: high\ntags: [attack.t1059.001, attack.t1566.001]\nEOF\ngit add detections && git commit -m "add office-encoded-ps (case-041)"`,
              },
            ],
          },
          {
            n: "2",
            title: "Προσθήκη θετικών και αρνητικών δειγμάτων",
            desc: "Οι αδοκίμαστοι κανόνες δεν διατίθενται: απαιτείται ένα συμβάν που πρέπει να ενεργοποιεί τον κανόνα και δύο που δεν πρέπει.",
            code: [
              {
                title: "Bash — δείγματα δοκιμής",
                text: `cat > tests/fixtures/office-encoded-ps-positive.json <<'EOF'\n{"EventID": 1, "ParentImage": "C:\\\\Program Files\\\\Office\\\\WINWORD.EXE",\n "Image": "C:\\\\Windows\\\\System32\\\\WindowsPowerShell\\\\powershell.exe",\n "CommandLine": "powershell -enc UwB0AGEAcgB0AC0AUwBsAGUAZQBw"}\nEOF\ncat > tests/fixtures/office-encoded-ps-negative.json <<'EOF'\n{"EventID": 1, "ParentImage": "C:\\\\Windows\\\\explorer.exe",\n "Image": "C:\\\\Windows\\\\System32\\\\WindowsPowerShell\\\\powershell.exe",\n "CommandLine": "powershell -File .\\\\build.ps1"}\nEOF\nls tests/fixtures/`,
              },
            ],
          },
        ],
      },
      {
        id: "ship",
        label: "Μεταγλώττιση και διάθεση",
        steps: [
          {
            n: "3",
            title: "Μεταγλώττιση για το εργαστηριακό backend",
            desc: "Το pySigma παράγει το εγγενές ερώτημα· οι αξιολογητές εξετάζουν τις διαφορές και δεν το τροποποιούν ποτέ χειροκίνητα.",
            code: [
              {
                title: "Bash — pySigma",
                text: `pip install pysigma-backend-elasticsearch 2>/dev/null | tail -n 1\nsigma convert -t elasticsearch -p ecs_windows detections/windows/sysmon/office-encoded-ps.yml \\\n  | tee deploy/office-encoded-ps.kql\ncat deploy/office-encoded-ps.kql`,
              },
            ],
            expected: "ερώτημα KQL/Lucene που συνδυάζει και τις δύο επιλογές με AND και αναπτύσσεται πρώτα σε δείκτη staging",
          },
          {
            n: "4",
            title: "Δημοσίευση πληροφοριών στο MISP",
            desc: "Τα χαρακτηριστικά της υπόθεσης, μαζί με το πλαίσιό τους, παραμένουν χρήσιμα μετά το περιστατικό και ενισχύουν την κοινότητα.",
            code: [
              {
                title: "Bash — προσχέδιο συμβάντος MISP (API)",
                text: `# event: case-041 phishing+C2 | TLP:AMBER\n# attributes: sha256(svc.exe), cdn-x7.ru, 45.9.148.7, YARA-office-macro\n# galaxies: tool=custom-dropper, ttp=T1566.001/T1059.001/T1071.004\n# sightings: 3 hosts | expires: 90d (domain/IP), 365d (TTP note)`,
              },
            ],
          },
        ],
      },
      {
        id: "prove",
        label: "Προσομοίωση και απόδειξη",
        steps: [
          {
            n: "5",
            title: "Εκτέλεση της δοκιμής atomic που αποδεικνύει τον κανόνα",
            desc: "Εκτελέστε το atomic T1059.001 στην αναλώσιμη VM· η ειδοποίηση και το δελτίο πρέπει να δημιουργηθούν εντός του SLA.",
            code: [
              {
                title: "PowerShell — Atomic Red Team (ΑΠΟΜΟΝΩΜΕΝΗ VM)",
                text: `Invoke-AtomicTest T1059.001 -TestNumbers 1 -GetPrereqs\nInvoke-AtomicTest T1059.001 -TestNumbers 1\n# verify: SIEM alert office-encoded-ps fired with correct entities\nInvoke-AtomicTest T1059.001 -TestNumbers 1 -Cleanup`,
              },
            ],
            expected: "η ειδοποίηση ενεργοποιείται με τις οντότητες συστήματος, χρήστη και διεργασίας· η εκκαθάριση επαναφέρει την κατάσταση του στιγμιοτύπου",
          },
          {
            n: "6",
            title: "Καταγραφή κάλυψης και προαγωγή του κανόνα",
            note: "Παραδοτέο: συγχωνευμένος κανόνας Sigma, δείγματα δοκιμής, μεταγλωττισμένο ερώτημα, συμβάν MISP, επιτυχής απόδειξη μέσω προσομοίωσης και σημείωση μεταβολής κάλυψης. Η κατάσταση αλλάζει από experimental σε stable μόνο μετά από 14 ημέρες χωρίς προβλήματα.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Εννοιολογικός χάρτης:</b> ανατομία Sigma (§12.2) · pySigma (§12.3) · MISP (§12.4) → απόδειξη μέσω προσομοίωσης (§12.6) → τελικές
        ανιχνεύσεις (Κεφ. 13). Παραδοτέο: ανίχνευση που έχει διατεθεί, αποδειχθεί και συνδεθεί με πληροφορίες απειλών.
      </>
    ),
  },
  quiz: [
    { q: "Ποια είναι η βασική απαίτηση της προσέγγισης Detection as Code;", o: ["Ακριβά εργαλεία", "Κύκλος ζωής ανίχνευσης με εκδόσεις, δοκιμές, αξιολόγηση και διάθεση μέσω CI", "Καμία τεκμηρίωση", "Εξάρτηση από έναν προμηθευτή"], a: 1, e: "Οι ανιχνεύσεις εφαρμόζουν την ίδια πειθαρχία που απαιτεί η μηχανική λογισμικού." },
    { q: "Τι ορίζει το τμήμα logsource ενός κανόνα Sigma;", o: ["Τη σοβαρότητα", "Το συμβόλαιο δρομολόγησης προϊόντος, υπηρεσίας και κατηγορίας", "Τον δημιουργό", "Το κόστος"], a: 1, e: "Το logsource δηλώνει ποια τηλεμετρία απαιτεί ο κανόνας." },
    { q: "Σε τι προσαρμόζουν τους κανόνες οι γραμμές επεξεργασίας pySigma;", o: ["Στα τοπικά σχήματα πεδίων, όπως παραλλαγές ECS ή CIM", "Στον καιρό", "Στην αρχιτεκτονική CPU", "Στο μέγεθος οθόνης"], a: 0, e: "Οι γραμμές επεξεργασίας αντιστοιχίζουν τα γενικά πεδία στην πραγματική δομή κάθε SIEM." },
    { q: "Τι προσφέρουν τα MISP galaxies;", o: ["Κρυπτογράφηση", "Ομαδοποίηση δραστών, εργαλείων και TTP για συσχετίσεις", "Αντίγραφα ασφαλείας", "VPN"], a: 1, e: "Τα galaxies συνδέουν δείκτες με εκστρατείες, εργαλεία και τεχνικές." },
    { q: "Σε ποια χαρακτηριστικά υπερέχει συνήθως η πληροφορία που προκύπτει από τοπικό περιστατικό έναντι εμπορικών ροών;", o: ["Στον όγκο", "Στη φρεσκάδα και τη συνάφεια με τη συγκεκριμένη υπόθεση", "Στην τιμή", "Στο χρώμα"], a: 1, e: "Ο τομέας C2 της δικής σας υπόθεσης, αυτή την ώρα, είναι χρησιμότερος από μια γενική πληροφορία της προηγούμενης ημέρας." },
    { q: "Πώς αποδεικνύει μια ανίχνευση το Atomic Red Team;", o: ["Με ανάγνωση τεκμηρίωσης", "Με εκτέλεση αντιστοιχισμένης συμπεριφοράς αντιπάλου και επαλήθευση της ειδοποίησης από άκρο σε άκρο", "Με εικασία", "Με απενεργοποίηση καταγραφών"], a: 1, e: "Η αλυσίδα εκτελεσμένη τεχνική → τηλεμετρία → ειδοποίηση → δελτίο αποτελεί την απόδειξη." },
  ],
};
