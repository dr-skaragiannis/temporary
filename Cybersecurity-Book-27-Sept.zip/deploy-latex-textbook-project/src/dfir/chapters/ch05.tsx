import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>5.1 Τεχνουργήματα εκτέλεσης: Prefetch, Shimcache και Amcache</h4>
    <p>
      Η απόδειξη της εκτέλεσης —και όχι απλώς της παρουσίας ενός αρχείου— αποτελεί βασικό στόχο της στατικής ανάλυσης. Τρία τεχνουργήματα συνδυάζονται για ισχυρή τεκμηρίωση (Σχ. 9). Το <b>Prefetch</b> στο <span className="mono text-sm">C:\Windows\Prefetch\*.pf</span> καταγράφει έως και τις οκτώ τελευταίες εκτελέσεις κάθε προγράμματος, το πλήθος και τον χρόνο εκτέλεσης, καθώς και αρχεία ή συσκευές που χρησιμοποιήθηκαν στα πρώτα δευτερόλεπτα. Το <b>Shimcache/AppCompatCache</b> στην κυψέλη SYSTEM καταγράφει εκτελέσιμα που αξιολογήθηκαν για συμβατότητα. Η παρουσία εκεί αποτελεί ένδειξη διαδρομής εκτέλεσης, όχι από μόνη της απόδειξη, αλλά συχνά επιβιώνει μετά τη διαγραφή του αρχείου. Το <b>Amcache</b> στο Amcache.hve διατηρεί χρόνο πρώτης εκτέλεσης, SHA-1 και πλήρη διαδρομή, ακόμη και για αφαιρούμενα μέσα. Ο πρακτικός κανόνας είναι σαφής: Prefetch και Amcache μαζί με καταγραφή δημιουργίας διεργασίας συνιστούν ισχυρή απόδειξη· το Shimcache μόνο αποτελεί αφετηρία έρευνας.
    </p>
    <Figure
      id="fig-exec-proof"
      label="Fig. 9 · Execution-proof strength ladder"
      caption={
        <>
          <b>Fig. 9.</b> Strength of execution evidence, weakest at bottom. Climb by corroboration: Shimcache
          (evaluated) + Amcache (first run) + Prefetch (run count/times) + EID 4688/Sysmon EID 1 (process creation) =
          proof beyond reasonable doubt.
        </>
      }
    >
      <svg viewBox="0 0 720 250" className="w-full h-auto" role="img" aria-label="Execution proof ladder">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="150" y="10" width="420" height="44" rx="8" fill="#166534" />
          <text x="360" y="28" fill="#fff">PROOF · EID 4688 / SYSMON EID 1</text>
          <text x="360" y="44" fill="#dcfce7" fontWeight="400" fontSize="10">process created: image + PID + parent + cmdline + hash</text>
          <rect x="150" y="62" width="420" height="44" rx="8" fill="#0e7490" />
          <text x="360" y="80" fill="#fff">STRONG · PREFETCH (.pf)</text>
          <text x="360" y="96" fill="#e0f2fe" fontWeight="400" fontSize="10">run count + last 8 runs + files touched in first 10 s</text>
          <rect x="150" y="114" width="420" height="44" rx="8" fill="#b45309" />
          <text x="360" y="132" fill="#fff">GOOD · AMCACHE.HVE</text>
          <text x="360" y="148" fill="#fef3c7" fontWeight="400" fontSize="10">first-run time + SHA-1 + full path incl. USB volume</text>
          <rect x="150" y="166" width="420" height="40" rx="8" fill="#7c3aed" />
          <text x="360" y="184" fill="#fff">LEAD · SHIMCACHE (AppCompatCache)</text>
          <text x="360" y="199" fill="#ede9fe" fontWeight="400" fontSize="10">evaluated for compat — execution path, not proof of run</text>
        </g>
        <g fontSize="10" fontWeight="700" fill="#64748b" textAnchor="start">
          <text x="582" y="37">needs logging ON</text>
          <text x="582" y="89">needs prefetch kept</text>
          <text x="582" y="141">needs hive</text>
          <text x="582" y="192">survives deletion</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="120" y1="200" x2="120" y2="40" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="100" y="125" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0f1c2e" className="fig-halo" transform="rotate(-90 100 125)">EVIDENTIARY STRENGTH ↑</text>
        <text x="360" y="228" textAnchor="middle" fontSize="11" fill="#64748b">Επιβεβαιώνετε κάθε ένδειξη με τεκμήρια υψηλότερης αποδεικτικής ισχύος· ο συνδυασμός είναι ισχυρότερος από οποιοδήποτε μεμονωμένο artifact</text>
      </svg>
    </Figure>
    <h4>5.2 Ίχνη χρήσης προγραμμάτων: UserAssist και BAM/DAM</h4>
    <p>
      Το <b>UserAssist</b> στο NTUSER.DAT, κωδικοποιημένο με ROT13, καταγράφει ανά χρήστη το πλήθος εκκινήσεων εφαρμογών γραφικού περιβάλλοντος, τον τελευταίο χρόνο εκτέλεσης και τη διάρκεια εστίασης. Είναι ιδιαίτερα χρήσιμο για το ερώτημα «άνοιξε ο χρήστης το ωφέλιμο φορτίο με διπλό κλικ;». Τα <b>BAM/DAM</b> —Background Activity Moderator και Desktop Activity Moderator— στην κυψέλη SYSTEM καταγράφουν τον τελευταίο χρόνο εκτέλεσης δυαδικών αρχείων, συμπεριλαμβανομένων διεργασιών παρασκηνίου, και εμφανίζουν λιγότερα κενά σε σύγχρονες εκδόσεις Windows. Και τα δύο συνδέουν την εκτέλεση με συγκεκριμένο προφίλ χρήστη, κάτι που δεν μπορεί να κάνει το Prefetch. Αποκωδικοποιήστε μηχανικά το ROT13 και χρησιμοποιήστε τις μεταβολές του μετρητή μεταξύ στιγμιοτύπων VSS για να σχηματίσετε χρονογραμμή εκτέλεσης.
    </p>
    <h4>5.3 Αρχιτεκτονική αρχείων καταγραφής συμβάντων Windows</h4>
    <p>
      Τα Windows αποθηκεύουν δυαδικά κανάλια <b>.evtx</b> στον κατάλογο <span className="mono text-sm">C:\Windows\System32\winevt\Logs</span>. Ο βασικός εγκληματολογικός πυρήνας περιλαμβάνει τρία κανάλια: <b>Security</b> για πιστοποίηση, χρήση προνομίων και πρόσβαση σε αντικείμενα —εφόσον έχει ενεργοποιηθεί η κατάλληλη πολιτική ελέγχου—, <b>System</b> για υπηρεσίες, οδηγούς και τερματισμούς, και <b>Application</b> για σφάλματα εφαρμογών και εγκαταστάσεις MSI. Πρόσθετη ορατότητα παρέχουν τα Sysmon/Operational, PowerShell/Operational με ScriptBlock EID 4104, TaskScheduler/Operational και TerminalServices για RDP. Το μέγεθος και η διατήρηση αποτελούν επιλογές πολιτικής: ένα προεπιλεγμένο αρχείο Security 20 MB σε πολυάσχολο ελεγκτή τομέα μπορεί να ανακυκλωθεί μέσα σε ώρες. Επαληθεύστε λοιπόν τη διατήρηση πριν εξαγάγετε συμπέρασμα για την έκταση και προωθείτε τα συμβάντα σε SIEM ώστε η τοπική ανακύκλωση να μη σημαίνει απώλεια.
    </p>
    <DataTable
      head={["Channel (.evtx)", "Key Event IDs", "Answers"]}
      rows={[
        ["Security", "4624/4625 logon, 4672 special logon, 4688 process, 4720 account created, 1102 cleared", "Who authenticated, what ran, what changed"],
        ["System", "7045 service installed, 7036 state, 6005/6006 start/stop, 1/12 time change", "Persistence installs, reboots, clock tampering"],
        ["Sysmon/Operational", "EID 1/3/7/8/10/11/13/22", "Full process/network/registry narrative (Ch. 6)"],
        ["PowerShell/Operational", "4103/4104 module + scriptblock", "Deobfuscated script content incl. encoded payloads"],
        ["TerminalServices-*/RDP", "21/22/23/24/25 session lifecycle", "RDP lateral movement corroboration"],
        ["TaskScheduler/Operational", "106/140/141 task registered/updated", "T1053 persistence with author + payload path"],
      ]}
    />
    <h4>5.4 Έλεγχος πιστοποίησης: 4624/4625 και τύποι σύνδεσης</h4>
    <p>
      Κάθε προσπάθεια σύνδεσης παράγει συμβάν 4624 για επιτυχία ή 4625 για αποτυχία, μαζί με έναν <b>τύπο σύνδεσης (Logon Type)</b> που αποκαλύπτει τον τρόπο πρόσβασης —ένα από τα συχνότερα παρερμηνευμένα πεδία στην εγκληματολογία Windows. Ο Τύπος 3 αφορά δικτυακή σύνδεση και εμφανίζεται συχνά σε πλευρική μετακίνηση. Ο Τύπος 10 δηλώνει διαδραστική απομακρυσμένη συνεδρία RDP, οι Τύποι 4 και 5 αντιστοιχούν σε μαζική εργασία και υπηρεσία, ενώ ο Τύπος 9 για RunAs και οι αποθηκευμένοι Τύποι 11/13 αποκαλύπτουν μοτίβα επαναχρησιμοποίησης διαπιστευτηρίων. Συσχετίστε πάντα την τριάδα <b>λογαριασμός + IP ή σταθμός προέλευσης + τύπος σύνδεσης</b>. Εύρημα αποτελεί ένας λογαριασμός υπηρεσίας που συνδέεται διαδραστικά ή ένας λογαριασμός που εμφανίζεται από δύο γεωγραφικές περιοχές μέσα σε λίγα λεπτά, όχι ο ακατέργαστος αριθμός συμβάντων 4624.
    </p>
    <DataTable
      head={["Logon Type", "Meaning", "Forensic reading"]}
      rows={[
        ["2 Interactive", "Local console logon", "Physical or VM-console access; rare for service accounts"],
        ["3 Network", "SMB/remote resource access", "Lateral-movement workhorse; pair with source IP"],
        ["4 Batch / 5 Service", "Scheduled task / service start", "Check parent task; attackers schedule as SYSTEM"],
        ["7 Unlock / 8 NetworkCleartext", "Workstation unlock / basic-auth network", "8 in cleartext = legacy app or downgrade attack"],
        ["9 RunAs / 10 RemoteInteractive", "Alternate creds / RDP", "10 + odd hour + new source = RDP intrusion pattern"],
        ["11 Cached / 12/13 Cached variants", "Offline cached-credential logon", "Stolen laptop scenario; compare against DC logs"],
      ]}
    />
    <h4>5.5 Ίχνη κλιμάκωσης προνομίων: 4672, 4720 και αλλαγές ομάδων</h4>
    <p>
      Το συμβάν <b>4672</b> —εκχώρηση ειδικών προνομίων κατά τη σύνδεση— εμφανίζεται όταν ξεκινά συνεδρία με δικαιώματα αντίστοιχα διαχειριστή. Καταγράψτε τον φυσιολογικό όγκο και αναζητήστε αποκλίσεις, όπως νέους λογαριασμούς, ασυνήθιστους σταθμούς ή λογαριασμούς υπηρεσίας που αποκτούν ξαφνικά προνόμια. Τα συμβάντα κύκλου ζωής λογαριασμών 4720 για δημιουργία, 4728/4732/4756 για προσθήκη σε ομάδα και 4738 για τροποποίηση αφηγούνται τη δημιουργία κρυφού λογαριασμού πρόσβασης. Συνδέστε τα με τα πεδία του καλούντος για να εντοπίσετε ποια διεργασία προκάλεσε την αλλαγή. Τα συμβάντα χρήσης προνομίων 4673/4674, όπως SeDebugPrivilege και SeBackupPrivilege, απαιτούν ενεργοποιημένο έλεγχο ευαίσθητων προνομίων. Ελέγξτε πρώτα την πολιτική, διαφορετικά η απουσία καταγραφής μπορεί να εκληφθεί λανθασμένα ως απουσία δραστηριότητας.
    </p>
    <h4>5.6 Εντοπισμός αντιεγκληματολογικών παρεμβάσεων στις καταγραφές</h4>
    <p>
      Οι αντίπαλοι διαγράφουν, περιορίζουν ή διακόπτουν την καταγραφή για να μειώσουν την ορατότητα των αμυνόμενων. Το <b>1102</b>, που δηλώνει εκκαθάριση του αρχείου ελέγχου, αποτελεί κλασική ισχυρή ένδειξη. Πιο έμπειροι δράστες μπορεί να διακόψουν την υπηρεσία EventLog —System 7036/7040—, να αναστείλουν το Sysmon, να μειώσουν το μέγεθος καναλιών ώστε να επιταχύνουν την ανακύκλωση ή να διαγράψουν επιλεκτικά εγγραφές με εργαλεία που διορθώνουν τα checksums. Αναζητήστε μετα-ενδείξεις: κενά στους αριθμούς εγγραφών, ασυμφωνία μεταξύ χρόνου λειτουργίας και κάλυψης καταγραφών, αλλαγές ρύθμισης Sysmon EID 16 και εγκαταστάσεις ύποπτων υπηρεσιών EID 7045. Η πραγματική άμυνα είναι αρχιτεκτονική: η προώθηση σε πραγματικό χρόνο μέσω WEF ή Syslog διατηρεί κεντρικά όσα διαγράφονται τοπικά. Η παρουσία ενός συμβάντος στο SIEM αλλά όχι στο σύστημα αποτελεί από μόνη της απόδειξη παρέμβασης.
    </p>
    <Callout color="rose">
      <b>Absence-of-evidence rule.</b> Before concluding "no logon occurred" or "no process ran," verify: (1) the
      channel existed and was enabled, (2) retention covers the window, (3) no 1102/gap/service-stop precedes the
      gap. Unverified absence is not a finding — it is an unknown.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — logon-timeline triage (Security.evtx on a mounted image or live host)"
        code={`# RDP + network logons in the incident window, grouped by account/source/type
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624,4625; StartTime='2026-09-20'} |
  Select-Object TimeCreated,
    @{n='Acct';e={$_.Properties[5].Value}}, @{n='SrcIP';e={$_.Properties[18].Value}},
    @{n='Type';e={$_.Properties[8].Value}}, @{n='ID';e={$_.Id}} |
  Sort-Object TimeCreated | Format-Table -AutoSize

# Anti-forensics screen: clears, service stops, Sysmon changes
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=1102} -ErrorAction SilentlyContinue
Get-WinEvent -FilterHashtable @{LogName='System'; Id=7045,7036} |
  Where-Object { $_.Message -match 'EventLog|Sysmon|WinDefend' }`}
      />
    </div>
    <h4>5.7 Τηλεμετρία προϊόντων ασφάλειας και χρήσης: Defender, ASR, WDAC, SRUM και BITS</h4>
    <p>
      Οι ενσωματωμένοι μηχανισμοί ασφάλειας λειτουργούν και ως εγκληματολογικοί αισθητήρες. Οι λειτουργικές καταγραφές του <b>Defender</b> —1006/1008 για εντοπισμούς, 1015 για αποκλεισμούς, 1116 για κατάσταση κακόβουλου λογισμικού και 5001/5007 για αλλαγές προστασίας— δημιουργούν χρονογραμμή και καταγράφουν απόπειρες απενεργοποίησης. Οι κανόνες <b>Attack Surface Reduction (ASR)</b> παράγουν συμβάντα αποκλεισμού ή ελέγχου ανά αναγνωριστικό, όπως Office που δημιουργεί διεργασία ή προσπάθεια πρόσβασης στο LSASS. Τα <b>WDAC/AppLocker 8003/8004</b> αποτελούν ενδείξεις παραβίασης λίστας επιτρεπόμενων εφαρμογών με χαμηλό ποσοστό ψευδώς θετικών. Το <b>SRUM</b> στο SRUDB.dat καταγράφει ανά εφαρμογή τον ωριαίο όγκο δικτύου και βοηθά να απαντηθεί ποια διεργασία μετέφερε ασυνήθιστα πολλά δεδομένα. Η προσωρινή μνήμη bitmap του RDP μπορεί να διατηρεί τμήματα οθόνης απομακρυσμένων συνεδριών. Τέλος, οι εργασίες <b>BITS</b> χρησιμοποιούνται συχνά ως νόμιμο εργαλείο λήψης και μηχανισμός παραμονής T1197.
    </p>
    <DataTable
      head={["Source", "Key IDs / store", "Signature use"]}
      rows={[
        ["Defender AV/Operational", "1006/1008/1015/1116, 5001/5007", "Malware timeline + protection-tamper proof"],
        ["ASR rules", "Per-rule block/audit events", "Behavior blocked even for unknown payloads"],
        ["WDAC / AppLocker", "8003/8004 (+ MSI/script channels)", "Allowlist trips — investigate every one"],
        ["SRUM (SRUDB.dat)", "Hourly per-app bytes + network", "Exfil attribution + volume for impact statements"],
        ["RDP bitmap cache", "Cache000*.bin tiles", "Attacker screen reconstruction (opportunistic)"],
        ["BITS jobs DB", "bitsadmin /list /allusers", "Covert download + persistence jobs"],
      ]}
    />
    <h4>5.8 Υπογραφές πλευρικής μετακίνησης: συσχετισμοί PsExec, WMI, WinRM και RDP</h4>
    <p>
      Η πλευρική μετακίνηση δεν αφήνει ένα μοναδικό συμβάν αλλά έναν <b>συσχετισμό συμβάντων</b> σε πολλά κανάλια. Η αναγνώριση αυτού του σχήματος διαχωρίζει την ουσιαστική ανάλυση από την απλή ανάγνωση ειδοποιήσεων. Για PsExec εμφανίζονται συνήθως 4624 Τύπου 3 από την πηγή, 7045 για εγκατάσταση υπηρεσίας, 4688 για θυγατρική διεργασία στον στόχο και 7036/7040 για διακοπή ή καθαρισμό υπηρεσίας. Για WMI, ακολουθούν 4624 μέσω DCOM, συμβάντα WMI-Activity 5857/5858/5860/5861 και το wmiprvse.exe που δημιουργεί το ωφέλιμο φορτίο. Για WinRM/PSRemoting, αναζητήστε Operational 91 και 168 μαζί με 4624 και ScriptBlock 4104 στον στόχο. Για RDP, συσχετίστε 4624 Τύπου 10 με TerminalServices 21–25 και εγγραφές bitmap cache. Ο κανόνας έρευνας είναι να αναζητούμε ολόκληρο τον σχηματισμό μέσα σε λίγα λεπτά, όχι ένα μεμονωμένο «άστρο»: κάθε συμβάν μπορεί να έχει νόμιμη εξήγηση, ο πλήρης συνδυασμός πολύ σπανιότερα.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="PowerShell — έρευνα συσχετισμού PsExec σε Security και System για το χρονικό παράθυρο του περιστατικού"
        code={`# All four stars within the window on the TARGET host = lateral movement, not coincidence\nGet-WinEvent -FilterHashtable @{LogName='Security'; Id=4624; StartTime='2026-09-20'} |\n  Where-Object { $_.Properties[8].Value -eq 3 }          # network logon from source\nGet-WinEvent -FilterHashtable @{LogName='System'; Id=7045} | Where-Object { $_.Message -match 'PSEXESVC|remotsvc' }\nGet-WinEvent -FilterHashtable @{LogName='Security'; Id=4688} | Where-Object { $_.Message -match 'PSEXESVC' }\nGet-WinEvent -FilterHashtable @{LogName='System'; Id=7036} | Where-Object { $_.Message -match 'PSEXESVC.*stopped' }`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 5.1 · Φάκελος απόδειξης εκτέλεσης (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Για τρία ύποπτα εκτελέσιμα, συλλέξτε τις αντίστοιχες εγγραφές Prefetch, Amcache, Shimcache, UserAssist και BAM.</li>
      <li>Αξιολογήστε κάθε εκτελέσιμο με βάση την κλίμακα του Σχήματος 9 και συντάξτε σε μία παράγραφο την απόδειξη ή το τεκμηριωμένο κενό.</li>
      <li>Επιβεβαιώστε την ισχυρότερη περίπτωση με EID 4688, Sysmon EID 1 και καταγραφές ScriptBlock, εφόσον υπάρχουν.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 5.2 · Ανάλυση συνδέσεων και αντιεγκληματολογικών ενεργειών (60 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Δημιουργήστε πίνακα λογαριασμού × πηγής × τύπου σύνδεσης για το χρονικό παράθυρο του περιστατικού και αιτιολογήστε κάθε ανωμαλία.</li>
      <li>Ελέγξτε για συμβάν 1102, παρεμβάσεις στις υπηρεσίες EventLog ή Sysmon και κενά στην αρίθμηση εγγραφών.</li>
      <li>Παραδώστε τα ευρήματα πιστοποίησης: χρονογραμμή, ασυνήθιστες συνεδρίες και συμπέρασμα για πιθανή αλλοίωση.</li>
    </ol>
  </>
);

export const ch05: Κεφάλαιο = {
  id: "ch5",
  num: 5,
  title: "Τεχνουργήματα Εκτέλεσης Windows και Ανάλυση Αρχείων Συμβάντων",
  subtitle: "Prefetch · Shimcache · Amcache · UserAssist/BAM · .evtx · 4624/4625 · 4672 · Αντιεγκληματολογικές τεχνικές",
  badge: "Tier 2 · Εγκληματολογία συστημάτων",
  time: "9–11 ώρες · περίπου 40 σελίδες",
  outcomes:
    "Αποδεικνύετε εκτέλεση μέσω συνδυασμού τεχνουργημάτων· αποδίδετε εκτελέσεις σε συγκεκριμένους χρήστες· αναλύετε κανάλια .evtx και τύπους σύνδεσης· παρακολουθείτε κλιμάκωση προνομίων· και εντοπίζετε αλλοιώσεις ή κενά στις καταγραφές.",
  body,
  labTitle: "Πρακτική Άσκηση 5.1 · Φάκελος απόδειξης εκτέλεσης + Άσκηση 5.2 · Ανάλυση συνδέσεων και έρευνα αντιεγκληματολογικών ενεργειών",
  labsBody,
  workshop: {
    title: "Ροή ανάλυσης εκτέλεσης και συνδέσεων: PECmd, EvtxECmd και ενοποίηση χρονογραμμής",
    env: ["Εικονική μηχανή Windows για τον εξεταστή", "PECmd, EvtxECmd και Timeline Explorer", "Εργαστηριακή εικόνα και εξαγόμενα αρχεία .evtx"],
    tabs: [
      {
        id: "prefetch",
        label: "Prefetch και Amcache",
        steps: [
          {
            n: "1",
            title: "Αναλύστε τον κατάλογο Prefetch",
            desc: "Το PECmd αποκωδικοποιεί ανά εκτελέσιμο το πλήθος εκτελέσεων, τους τελευταίους χρόνους και τα αρχεία αναφοράς.",
            code: [
              {
                title: "PowerShell — PECmd",
                text: `E:\\Tools\\PECmd.exe -d "F:\\Windows\\Prefetch" --csv E:\\cases\\041 --csvf prefetch.csv\nImport-Csv E:\\cases\\041\\prefetch.csv |\n  Where-Object { $_.ExecutableName -match 'powershell|mimikatz|rundll32|mshta|wmic' } |\n  Select-Object ExecutableName, RunCount, LastRun | Format-Table -AutoSize`,
              },
            ],
          },
          {
            n: "2",
            title: "Αναλύστε το Amcache για πρώτη εκτέλεση και SHA-1",
            desc: "Το Amcache συνδέει την πρώτη εκτέλεση με hash και πλήρη διαδρομή, παρέχοντας ισχυρό σημείο ταυτοποίησης.",
            code: [
              {
                title: "PowerShell — AmcacheParser",
                text: `E:\\Tools\\AmcacheParser.exe -f "F:\\Windows\\AppCompat\\Programs\\Amcache.hve" --csv E:\\cases\\041\nImport-Csv E:\\cases\\041\\Amcache*.csv | Where-Object { $_.SHA1 -ne '' } |\n  Select-Object -First 5 Name, SHA1, FirstRun`,
              },
            ],
            expected: "το ύποπτο εκτελέσιμο εμφανίζεται με ταυτόσημο SHA-1 στις σχετικές εγγραφές Amcache και Prefetch",
          },
        ],
      },
      {
        id: "evtx",
        label: "Security.evtx",
        steps: [
          {
            n: "3",
            title: "Αναλύστε μαζικά το Security.evtx",
            desc: "Το EvtxECmd μετατρέπει το .evtx σε CSV, ώστε να αναλυθεί σε συγκεκριμένο χρονικό παράθυρο με το Timeline Explorer.",
            code: [
              {
                title: "PowerShell — EvtxECmd",
                text: `E:\\Tools\\EvtxECmd.exe -f "F:\\Windows\\System32\\winevt\\Logs\\Security.evtx" --csv E:\\cases\\041 --csvf sec.csv\nImport-Csv E:\\cases\\041\\sec.csv | Group-Object EventId | Sort-Object Count -Descending | Select-Object -First 8 Count, Name`,
              },
            ],
          },
          {
            n: "4",
            title: "Εξαγάγετε τον πίνακα συνδέσεων",
            desc: "Ο συνδυασμός λογαριασμού, πηγής και τύπου σύνδεσης είναι η ομαδοποίηση που αποκαλύπτει την πλευρική μετακίνηση.",
            code: [
              {
                title: "PowerShell — πίνακας συνδέσεων",
                text: `Import-Csv E:\\cases\\041\\sec.csv | Where-Object { $_.EventId -in 4624,4625 } |\n  Select-Object TimeCreated, EventId,\n    TargetUserName, TargetDomainName,\n    @{n='Type';e={$_.LogonType}}, @{n='Src';e={$_.IpAddress}} |\n  Sort-Object TimeCreated | Export-Csv E:\\cases\\041\\logons.csv -NoTypeInformation`,
              },
            ],
          },
        ],
      },
      {
        id: "fuse",
        label: "Σύνθεση και επαλήθευση",
        steps: [
          {
            n: "5",
            title: "Συνδυάστε την εκτέλεση με τις συνδέσεις",
            desc: "Εκτέλεση μέσα σε λίγα λεπτά από την πρώτη εμφάνιση σύνδεσης Τύπου 3 ή 10 αποτελεί ισχυρή υπογραφή πλευρικής μετακίνησης.",
            code: [
              {
                title: "PowerShell — έλεγχος σύνθεσης",
                text: `# Eyeball in Timeline Explorer: load prefetch.csv + logons.csv, sort by time,\n# filter window to incident ±2h. Flag: new source IP -> 4624 T3 -> EID 4688\n# rundll32/powershell within 10 min on the same host.`,
              },
            ],
          },
          {
            n: "6",
            title: "Συμπέρασμα για αντιεγκληματολογικές ενέργειες",
            desc: "Ελέγξτε το 1102, τα συμβάντα υπηρεσιών και τη συνέχεια των εγγραφών πριν διατυπώσετε συμπεράσματα.",
            note: "Παραδοτέο: prefetch.csv, ευρήματα Amcache, sec.csv, logons.csv, ενοποιημένη χρονογραμμή και παράγραφος συμπεράσματος για πιθανή αλλοίωση.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> κλίμακα απόδειξης (§5.1–5.2) · κανάλια (§5.3) · τύποι σύνδεσης (§5.4) → λεπτομερής ορατότητα Sysmon (Κεφ. 6). Παραδοτέο: φάκελος απόδειξης εκτέλεσης ενοποιημένος με τη χρονογραμμή πιστοποίησης.
      </>
    ),
  },
  quiz: [
    { q: "Γιατί το Prefetch αποτελεί ισχυρότερη απόδειξη εκτέλεσης από το Shimcache;", o: ["Καταγράφει μόνο ονόματα αρχείων", "Καταγράφει πλήθος εκτελέσεων, τελευταίους χρόνους και αρχεία που χρησιμοποιήθηκαν", "Καταγράφει μόνο κλειδιά Μητρώου", "Καταγράφει δικτυακά πακέτα"], a: 1, e: "Το Prefetch περιέχει πραγματική τηλεμετρία εκτέλεσης, ενώ το Shimcache καταγράφει αξιολόγηση συμβατότητας." },
    { q: "Πού αποθηκεύεται το UserAssist, το οποίο χρησιμοποιεί κωδικοποίηση ROT13;", o: ["Στην κυψέλη SYSTEM", "Στο NTUSER.DAT κάθε χρήστη", "Στο pagefile", "Στο bitmap της MFT"], a: 1, e: "Το UserAssist συνδέει την εκκίνηση εφαρμογών γραφικού περιβάλλοντος με συγκεκριμένο προφίλ χρήστη." },
    { q: "Τι υποδηλώνει σύνδεση Τύπου 10 από πρωτοεμφανιζόμενη IP στις 03:00;", o: ["Συνήθη εγκατάσταση ενημερώσεων", "Πιθανό μοτίβο εισβολής μέσω RDP που απαιτεί διερεύνηση", "Χρήση τοπικής κονσόλας", "Κοινή χρήση εκτυπωτή"], a: 1, e: "Ο Τύπος 10 σημαίνει RemoteInteractive μέσω RDP. Νέα πηγή και ασυνήθιστη ώρα συνθέτουν ισχυρή ένδειξη." },
    { q: "Τι μπορεί να σημαίνει η πρώτη εμφάνιση συμβάντος 4672 για έναν λογαριασμό υπηρεσίας;", o: ["Φυσιολογική λειτουργία", "Πιθανή κλιμάκωση προνομίων ή κατάχρηση προνομιούχας συνεδρίας", "Βλάβη δίσκου", "Διακοπή DNS"], a: 1, e: "Το 4672 δηλώνει ειδικά προνόμια κατά τη σύνδεση. Η νέα και μη αναμενόμενη εμφάνισή του αποτελεί το σήμα." },
    { q: "Τι σημαίνει το Event ID 1102 στο αρχείο Security;", o: ["Επιτυχημένη σύνδεση", "Εκκαθάριση του αρχείου καταγραφής ελέγχου", "Εκκίνηση υπηρεσίας", "Αλλαγή κωδικού"], a: 1, e: "Το 1102 αποτελεί την καθιερωμένη ένδειξη εκκαθάρισης καταγραφών ασφαλείας." },
    { q: "Πριν καταλήξει ότι «δεν πραγματοποιήθηκε σύνδεση», τι πρέπει να επαληθεύσει ΠΡΩΤΑ ο αναλυτής;", o: ["Την άδεια χρήσης του SIEM", "Ότι το κανάλι ήταν ενεργό, η διατήρηση καλύπτει το χρονικό παράθυρο και δεν προηγήθηκε αλλοίωση ή κενό", "Τον προϊστάμενο του χρήστη", "Την έκδοση του antivirus"], a: 1, e: "Μια απουσία που δεν έχει επαληθευτεί αποτελεί άγνωστο στοιχείο και όχι τεκμηριωμένο εύρημα." },
  ],
};
