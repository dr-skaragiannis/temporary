import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>8.1 Active Directory και ταυτότητα: στόχος είναι ολόκληρο το forest</h4>
    <p>
      Το <b>Active Directory</b> αποτελεί ταυτόχρονα το επίπεδο ταυτότητας του οργανισμού και την πολυτιμότερη επιφάνεια εγκληματολογικής διερεύνησης. Τα αρχεία Security των Domain Controllers καταγράφουν την πιστοποίηση σε μεγάλη κλίμακα: 4768 για αίτημα TGT, 4769 για αίτημα service ticket —ένδειξη Kerberoasting όταν ένας λογαριασμός ζητά πολλά εισιτήρια RC4—, 4771 για αποτυχία προπιστοποίησης, όπως password spraying ή αναγνώριση AS-REP roasting, και 4662 για πρόσβαση αναπαραγωγής ή υπηρεσιών καταλόγου, χαρακτηριστική ένδειξη DCSync όταν προέρχεται από λογαριασμό εκτός DC. Το NTLM relay αφήνει 4624 Τύπου 3 από απρόσμεσους ενδιάμεσους σταθμούς και ίχνη υποβάθμισης SMB signing. Καταγράψτε τη συνήθη ποσότητα εισιτηρίων ανά λογαριασμό, ειδοποιείτε για 4662 από μη DC και αντιμετωπίζετε κάθε ανωμαλία του krbtgt ως περιστατικό επιπέδου forest μέχρι να αποδειχθεί το αντίθετο.
    </p>
    <Figure
      id="fig-ad-attacks"
      label="Fig. 13 · AD attacks → DC artifacts"
      caption={
        <>
          <b>Fig. 13.</b> Three identity attacks and their unavoidable DC traces. Attackers choose the technique;
          defenders choose whether the log that catches it is collected. DCSync is the highest-severity single event
          in this chapter.
        </>
      }
    >
      <svg viewBox="0 0 720 230" className="w-full h-auto" role="img" aria-label="AD attacks">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="20" width="225" height="160" rx="10" fill="#b45309" />
          <text x="122" y="42" fill="#fff">KERBEROASTING</text>
          <text x="122" y="60" fill="#fef3c7" fontWeight="400" fontSize="10">request SPN tickets →</text>
          <text x="122" y="76" fill="#fef3c7" fontWeight="400" fontSize="10">crack offline (RC4)</text>
          <text x="122" y="98" fill="#fff" fontSize="10">ARTIFACT: 4769 flood</text>
          <text x="122" y="114" fill="#fef3c7" fontWeight="400" fontSize="10">1 acct → many SPNs</text>
          <text x="122" y="130" fill="#fef3c7" fontWeight="400" fontSize="10">TicketEnc=0x17 (RC4)</text>
          <text x="122" y="152" fill="#fff" fontSize="9">FIX: AES + long SPN pw</text>
          <rect x="247" y="20" width="226" height="160" rx="10" fill="#be123c" />
          <text x="360" y="42" fill="#fff">DCSYNC</text>
          <text x="360" y="60" fill="#ffe4e6" fontWeight="400" fontSize="10">mimic DC replication →</text>
          <text x="360" y="76" fill="#ffe4e6" fontWeight="400" fontSize="10">pull all hashes</text>
          <text x="360" y="98" fill="#fff" fontSize="10">ARTIFACT: 4662</text>
          <text x="360" y="114" fill="#ffe4e6" fontWeight="400" fontSize="10">non-DC acct +</text>
          <text x="360" y="130" fill="#ffe4e6" fontWeight="400" fontSize="10">replication GUID</text>
          <text x="360" y="152" fill="#fff" fontSize="9">SEV-1 · isolate + reset</text>
          <rect x="485" y="20" width="225" height="160" rx="10" fill="#7c3aed" />
          <text x="597" y="42" fill="#fff">AS-REP ROAST</text>
          <text x="597" y="60" fill="#ede9fe" fontWeight="400" fontSize="10">no-preauth accts →</text>
          <text x="597" y="76" fill="#ede9fe" fontWeight="400" fontSize="10">crackable AS-REP</text>
          <text x="597" y="98" fill="#fff" fontSize="10">ARTIFACT: 4768</text>
          <text x="597" y="114" fill="#ede9fe" fontWeight="400" fontSize="10">pre-auth NOT used</text>
          <text x="597" y="130" fill="#ede9fe" fontWeight="400" fontSize="10">+ 4771 spray</text>
          <text x="597" y="152" fill="#fff" fontSize="9">FIX: require pre-auth</text>
        </g>
        <text x="360" y="204" textAnchor="middle" fontSize="11" fill="#64748b">Και οι τρεις τεχνικές απαιτούν προώθηση των DC Security logs στο SIEM· η αποκλειστικά τοπική τήρηση καταγραφών στους DC δημιουργεί τυφλό σημείο σε ολόκληρο το forest</text>
      </svg>
    </Figure>
    <h4>8.2 Υποδομή DNS: το αποκαλυπτικό ίχνος του οργανισμού</h4>
    <p>
      Σχεδόν κάθε εισβολή χρησιμοποιεί το <b>DNS</b>: επίλυση C2, τομείς ηλεκτρονικού ψαρέματος, DNS tunneling και εξαγωγή δεδομένων μέσα σε ετικέτες υποτομέων ή ερωτήματα TXT/NULL, fast-flux με γρήγορη εναλλαγή εγγραφών A και DGA με μαζική παραγωγή ονομάτων. Πηγές αποτελούν οι αναλυτικές καταγραφές Windows DNS, το query.log του BIND, το Sysmon EID 22 στα τερματικά και το dns.log του Zeek στο δίκτυο. Αναζητήστε ασυνήθιστους τύπους ερωτημάτων σε μεγάλο όγκο, ετικέτες υψηλής εντροπίας, νεοεμφανιζόμενους τομείς με μετρονομικά διαστήματα και μεμονωμένους πελάτες που παράγουν δυσανάλογο πλήθος NXDOMAIN. Το DNS συχνά αποκαλύπτει την υποδομή του αντιπάλου ακόμη και όταν άλλα κανάλια έχουν κενά.
    </p>
    <h4>8.3 Μισθώσεις DHCP και απόδοση διευθύνσεων IP</h4>
    <p>
      Οι διακομιστές <b>DHCP</b> απαντούν στο κρίσιμο ερώτημα «ποια συσκευή κατείχε τη διεύθυνση 10.4.17.88 στις 02:14;», το οποίο δεν μπορεί να λυθεί μόνο από καταγραφές ροής σε δυναμικά περιβάλλοντα. Διατηρείτε ιστορικό μισθώσεων από Windows DHCP, ISC dhcpd.leases ή συσκευές δικτύου με MAC, όνομα συστήματος και χρόνο έναρξης και λήξης, ιδανικά για τουλάχιστον ένα έτος. Τα δεδομένα επιτρέπουν τη σύνδεση προσωρινών IP με χρονογραμμές, αποδεικνύουν την παρουσία συσκευής μέσω συνέχειας MAC και αποκαλύπτουν άγνωστες συσκευές. Συσχετίστε όνομα και MAC με 802.1X/NAC και απογραφή EDR. Μια MAC χωρίς διαχειριζόμενη ταυτότητα αποτελεί ένδειξη μη εξουσιοδοτημένης ή προσωπικής συσκευής που απαιτεί διερεύνηση.
    </p>
    <h4>8.4 Τηλεμετρία διακομιστών ιστού: Apache, Nginx και IIS</h4>
    <p>
      Τα αρχεία πρόσβασης διακομιστών ιστού καταγράφουν κάθε αίτημα —μέθοδο, URI, κωδικό κατάστασης, bytes, παραπομπή και User-Agent— και αποτελούν κύρια πηγή για την αρχική πρόσβαση και την αλληλεπίδραση με webshell. Αναζητήστε δοκιμές SQL injection, ακολουθίες που διακόπτουν εισαγωγικά μέσα σε URI, POST προς ασυνήθιστες διαδρομές όπως <span className="mono text-sm">/images/logo.php</span> με επιτυχείς απαντήσεις σε ασυνήθιστες ώρες, σαρώσεις με καταιγισμό 404/403 σε διαδρομές διαχείρισης και συστάδες 500 που υποδηλώνουν αποτυχημένη εκμετάλλευση. Το IIS προσθέτει λεπτομέρεια μέσω cs-uri-query και sc-win32-status, ενώ τα error logs αποκαλύπτουν αστοχίες χειριστών. Διατηρείτε τα ακατέργαστα αρχεία κεντρικά, επειδή οι δράστες συχνά διαγράφουν τις τοπικές καταγραφές μετά την παραβίαση.
    </p>
    <DataTable
      head={["Signal in access log", "Example", "Meaning"]}
      rows={[
        ["POST 200 to image/upload path", "POST /assets/x.php 200 18432", "Likely webshell interaction — pull file + Sysmon EID 1"],
        ["GET 404 sweep, one source", "20+ 404s across /admin*, /wp-*, /.git", "Recon scan; check for the 200 that followed"],
        ["SQLi metacharacters in URI", "id=1' UNION SELECT", "Injection probe; check DB + 500s + WAF"],
        ["401→200 transition, one user", "3× 401 then 200 on /api/login", "Guessed/brute-forced credential OR password spray hit"],
        ["Ancient User-Agent + odd hour", "curl/7.0 at 03:12 from foreign ASN", "Scripted access; correlate with auth + proxy logs"],
      ]}
    />
    <h4>8.5 Πύλες ηλεκτρονικού ταχυδρομείου: εγκληματολογική ανάλυση παράδοσης phishing</h4>
    <p>
      Οι πύλες ηλεκτρονικού ταχυδρομείου —Exchange transport και message tracking, Postfix και Secure Email Gateways— ανασυνθέτουν το στάδιο παράδοσης: ασυμφωνία φακέλου αποστολέα και κεφαλίδας From, αποτελέσματα SPF/DKIM/DMARC, ανάλυση συνημμένων σε sandbox, καταγραφές κλικ μετά από επανεγγραφή URL και δημιουργία κανόνων γραμματοκιβωτίου για αυτόματη προώθηση T1137. Η συσχέτιση <b>message-ID → παραλήπτης → κλικ ή άνοιγμα → εκτέλεση στο τερματικό</b>, όπως Sysmon EID 1 με γονέα Outlook, κλείνει την αλυσίδα από το phishing έως το shell. Σε παραβιασμένο γραμματοκιβώτιο απαιτείται έλεγχος OAuth και συναίνεσης εφαρμογών μαζί με αλλαγή διαπιστευτηρίων, επειδή μια κακόβουλη εξουσιοδότηση εφαρμογής μπορεί να επιβιώσει μετά την αλλαγή κωδικού.
    </p>
    <h4>8.6 Έλεγχος Secure Shell (SSH)</h4>
    <p>
      Το <b>SSH</b> αποτελεί βασικό μέσο πλευρικής μετακίνησης σε Linux. Το <span className="mono text-sm">/var/log/auth.log</span> ή secure καταγράφει προσπάθειες σύνδεσης: μαζικές αποτυχίες από λίγες πηγές, επιτυχείς συνδέσεις από πρωτοεμφανιζόμενες διευθύνσεις, αποδοχή άγνωστου δημόσιου κλειδιού που μπορεί να έχει εμφυτευτεί στο authorized_keys και συνεδρίες προώθησης θυρών με -R ή -L για διοχέτευση C2 ή εξαγωγή δεδομένων. Ενισχύστε την καταγραφή με <span className="mono text-sm">LogLevel VERBOSE</span> ώστε να αποθηκεύονται fingerprints, κεντρικό syslog και ειδοποιήσεις για πρώτη επιτυχή σύνδεση από νέα πηγή ή αλλαγές στο authorized_keys.
    </p>
    <Figure
      id="fig-svc-telemetry"
      label="Fig. 14 · Service → log source → collector map"
      caption={
        <>
          <b>Fig. 14.</b> Every core service emits at least one forensic-grade log; every log needs a collector path
          to the SIEM. Gaps in the middle column are detection blind spots; gaps in the right column are retention
          failures. Agent placement (beats/forwarders) is normative — see Ch. 11.
        </>
      }
    >
      <svg viewBox="0 0 720 300" className="w-full h-auto" role="img" aria-label="Telemetry map">
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <text x="120" y="16" fill="#0f1c2e" fontSize="11">SERVICE</text>
          <text x="360" y="16" fill="#0f1c2e" fontSize="11">FORENSIC LOG SOURCE</text>
          <text x="600" y="16" fill="#0f1c2e" fontSize="11">COLLECTOR → SIEM</text>
          <rect x="20" y="26" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="47" fill="#fbbf24">Active Directory (DC)</text>
          <rect x="250" y="26" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="47" fill="#92400e">Security 4768/69/71 + 4662</text>
          <rect x="500" y="26" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="47" fill="#fff">Winlogbeat / UF</text>
          <rect x="20" y="68" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="89" fill="#fbbf24">DNS resolvers</text>
          <rect x="250" y="68" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="89" fill="#92400e">debug log / query.log</text>
          <rect x="500" y="68" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="89" fill="#fff">Filebeat / syslog</text>
          <rect x="20" y="110" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="131" fill="#fbbf24">DHCP</text>
          <rect x="250" y="110" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="131" fill="#92400e">lease audit trail</text>
          <rect x="500" y="110" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="131" fill="#fff">syslog → SIEM</text>
          <rect x="20" y="152" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="173" fill="#fbbf24">Web (Apache/Nginx/IIS)</text>
          <rect x="250" y="152" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="173" fill="#92400e">access + error logs</text>
          <rect x="500" y="152" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="173" fill="#fff">Filebeat + WAF feed</text>
          <rect x="20" y="194" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="215" fill="#fbbf24">Mail gateway / MTA</text>
          <rect x="250" y="194" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="215" fill="#92400e">tracking + auth verdicts</text>
          <rect x="500" y="194" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="215" fill="#fff">SEG API / syslog</text>
          <rect x="20" y="236" width="200" height="34" rx="8" fill="#0f1c2e" /><text x="120" y="257" fill="#fbbf24">SSH fleet</text>
          <rect x="250" y="236" width="220" height="34" rx="8" fill="#fef3c7" stroke="#b45309" /><text x="360" y="257" fill="#92400e">auth.log VERBOSE</text>
          <rect x="500" y="236" width="200" height="34" rx="8" fill="#0e7490" /><text x="600" y="257" fill="#fff">syslog over TLS</text>
        </g>
        <g stroke="#64748b" strokeWidth="1.5">
          {[43, 85, 127, 169, 211, 253].map((y) => (
            <g key={y}>
              <line x1="220" y1={y} x2="248" y2={y} />
              <line x1="470" y1={y} x2="498" y2={y} />
            </g>
          ))}
        </g>
        <text x="360" y="290" textAnchor="middle" fontSize="11" fill="#64748b">Audit question per row: is the source enabled, parsed, retained, and alerted? A “no” anywhere is a finding</text>
      </svg>
    </Figure>
    <Callout color="emerald">
      <b>Infrastructure maxim.</b> Οι επιτιθέμενοι αξιοποιούν τα κενά μεταξύ υπηρεσιών <i>between</i> services — phish (mail) → shell (web) →
      tickets (AD) → tunnel (DNS) → pivot (SSH). Single-service monitoring sees hops; only cross-service correlation
      (Ch. 11) sees campaigns.
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — cross-service triage one-liners (SIEM-down fallback)"
        code={`# AD: Kerberoast screen — top requesters of RC4 service tickets (EID 4769 export)\ncat dc-4769.csv | awk -F, '$NF==\"0x17\"' | cut -d, -f3 | sort | uniq -c | sort -rn | head\n# DNS: TXT/NULL volume + high-entropy labels\nawk '$6 ~ /TXT|NULL/ {print $7}' query.log | sort | uniq -c | sort -rn | head -n 20\n# Web: POSTs to non-API paths with 200s (webshell interaction shape)\nawk '$6==\"POST\" && $9==200 {print $7}' access.log | grep -Ev '^/api/' | sort | uniq -c | sort -rn | head\n# SSH: first-seen successful sources this week\n grep "Accepted" /var/log/auth.log | grep -oE '[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+' | sort -u > thisweek.txt; comm -23 thisweek.txt baseline-sources.txt`}
      />
    </div>
    <h4>8.7 Cloud και σύγχρονη ταυτότητα: Entra ID, M365, Okta και AiTM</h4>
    <p>
      Η ταυτότητα έχει μεταφερθεί στο cloud και η διερεύνηση πρέπει να ακολουθήσει. Οι καταγραφές σύνδεσης του <b>Entra ID</b> περιλαμβάνουν μέθοδο πιστοποίησης, αποτέλεσμα Conditional Access, ταυτότητα συσκευής και πηγή —το αντίστοιχο του 4624 σε περιβάλλον cloud. Το Identity Protection επισημαίνει διαρροή διαπιστευτηρίων, ασυνήθιστες συνδέσεις και ανωμαλίες token. Το <b>Microsoft 365 Unified Audit Log (UAL)</b> είναι κρίσιμο για την αναζήτηση παραμονής: δημιουργία κανόνων γραμματοκιβωτίου, αναζητήσεις eDiscovery από απρόσμενους διαχειριστές και συναίνεση σε εφαρμογές OAuth. Οι καταγραφές Okta παρέχουν αντίστοιχα προκλήσεις MFA, αλλαγές πολιτικής και χρήση API token. Πριν από ένα περιστατικό, καταγράψτε τη συνήθη γεωγραφία, τις συσκευές και τις εφαρμογές ανά χρήστη· χωρίς βασικές γραμμές, οι νόμιμες μετακινήσεις και ο συγχρονισμός δημιουργούν υπερβολικό θόρυβο.
    </p>
    <Figure
      id="fig-aitm"
      label="Fig. 22 · Adversary-in-the-middle vs. modern auth ★ NEW"
      caption={
        <>
          <b>Fig. 22.</b> AiTM proxies relay the victim's live session — including the MFA challenge — to the real
          IdP, then steal the issued session cookie. Passwords + SMS/TOTP MFA both fall; only phishing-resistant MFA
          (FIDO2) and token protection break the relay. Hunt the right side: impossible travel, new device, replayed
          session.
        </>
      }
    >
      <svg viewBox="0 0 720 260" className="w-full h-auto" role="img" aria-label="AiTM attack">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="150" height="90" rx="10" fill="#0e7490" />
          <text x="85" y="62" fill="#fff">VICTIM</text>
          <text x="85" y="79" fill="#e0f2fe" fontWeight="400" fontSize="10">clicks phish link</text>
          <text x="85" y="95" fill="#e0f2fe" fontWeight="400" fontSize="10">enters creds + MFA</text>
          <text x="85" y="114" fill="#fef08a" fontSize="9">sees real login UX</text>
          <rect x="190" y="40" width="170" height="90" rx="10" fill="#be123c" />
          <text x="275" y="62" fill="#fff">ATTACKER PROXY</text>
          <text x="275" y="79" fill="#ffe4e6" fontWeight="400" fontSize="10">relays to real IdP</text>
          <text x="275" y="95" fill="#ffe4e6" fontWeight="400" fontSize="10">MFA passes through</text>
          <text x="275" y="114" fill="#fff" fontSize="9">steals session cookie</text>
          <rect x="390" y="40" width="150" height="90" rx="10" fill="#166534" />
          <text x="465" y="62" fill="#fff">REAL IdP</text>
          <text x="465" y="79" fill="#dcfce7" fontWeight="400" fontSize="10">Entra / Okta</text>
          <text x="465" y="95" fill="#dcfce7" fontWeight="400" fontSize="10">issues session</text>
          <text x="465" y="114" fill="#fff" fontSize="9">legitimate login!</text>
          <rect x="565" y="40" width="145" height="90" rx="10" fill="#0f1c2e" />
          <text x="637" y="62" fill="#fbbf24">REPLAY</text>
          <text x="637" y="79" fill="#cbd5e1" fontWeight="400" fontSize="10">cookie reused</text>
          <text x="637" y="95" fill="#cbd5e1" fontWeight="400" fontSize="10">no MFA needed</text>
          <text x="637" y="114" fill="#fbbf24" fontSize="9">full account access</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="160" y1="85" x2="186" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="360" y1="85" x2="386" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="540" y1="85" x2="561" y2="85" markerEnd="url(#dfir-a1)" />
        </g>
        <g fontSize="10" fontWeight="700" textAnchor="middle">
          <rect x="10" y="150" width="345" height="64" rx="8" fill="#fef2f2" stroke="#be123c" strokeWidth="1.5" />
          <text x="182" y="171" fill="#be123c">HUNT: impossible travel · new device + success · risk detections · token replay</text>
          <text x="182" y="190" fill="#475569" fontWeight="400">UAL: app-consent grants + mailbox rules within 1 h of sign-in</text>
          <rect x="365" y="150" width="345" height="64" rx="8" fill="#ecfdf5" stroke="#166534" strokeWidth="1.5" />
          <text x="537" y="171" fill="#166534">DEFEND: FIDO2 / passkeys · token protection · CAE · app-consent policy</text>
          <text x="537" y="190" fill="#475569" fontWeight="400">SMS/TOTP MFA does NOT stop AiTM — plan accordingly</text>
        </g>
        <text x="360" y="236" textAnchor="middle" fontSize="11" fill="#64748b">AiTM defeats "MFA enabled" as a control statement — verify phishing-resistant MFA coverage instead</text>
      </svg>
    </Figure>
    <h4>8.8 Εγκληματολογία βάσης τομέα: NTDS.dit, εισιτήρια και διαδρομές επίθεσης</h4>
    <p>
      Η βάση δεδομένων ενός Domain Controller αποτελεί ταυτόχρονα στόχο του αντιπάλου και τόπο εγκλήματος για τον αναλυτή. Η απόκτηση του <b>NTDS.dit</b> γίνεται εκτός σύνδεσης μέσω στιγμιοτύπου IFM με ntdsutil ή από VSS μαζί με την κυψέλη SYSTEM που περιέχει το bootkey· δεν αναλύεται ποτέ πάνω στον ενεργό DC. Μετά από DCSync, συγκρίνετε τα εξαγόμενα hash με τη χρονογραμμή 4662 του SIEM για να οριοθετήσετε το παράθυρο κλοπής. Τα <b>Silver Tickets</b> μπορεί να εμφανίζουν TGS χωρίς προηγούμενο αίτημα TGT, χρήση RC4 σε λογαριασμό που υποστηρίζει AES και ασυνήθιστη διάρκεια. Τα <b>Golden Tickets</b> παρουσιάζουν συχνά krbtgt με υπερβολική ισχύ σε σχέση με την πολιτική του τομέα. Αναζητήστε ανωμαλίες διάρκειας στο 4769 σε όλο το περιβάλλον. Προληπτικά, χρησιμοποιήστε BloodHound/SharpHound για διαδρομές προς Tier 0 και PingCastle για υγιεινή τομέα και παρωχημένους προνομιούχους λογαριασμούς.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="Bash / PowerShell — απόκτηση NTDS και αμυντικός έλεγχος AD"
        code={`# On a DC (forensic copy, then analyze OFFLINE with SYSTEM hive for bootkey)\nntdsutil "ac i ntds" "ifm" "create full c:\\temp\\ifm" q q\n# Defensive: attack-path + hygiene audit (run quarterly, trend the score)\nPingCastle.exe --healthcheck --server dc01.lab.local\n# Hunt: 4769 service tickets with anomalous lifetimes (group by TicketOptions/Lifetime)\n# legitimate ~10 h cluster vs. forged outliers — investigate every outlier`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 8.1 · Έρευνα επιθέσεων Active Directory (90 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Από εξαγωγή Security ενός DC, υπολογίστε τα συμβάντα 4769 ανά λογαριασμό και επιβεβαιώστε ή αποκλείστε την υποψία Kerberoasting.</li>
      <li>Ελέγξτε το 4662 για αναπαραγωγή από μη DC και το 4771 για μοτίβα password spraying και διατυπώστε το συμπέρασμα για την ταυτότητα.</li>
      <li>Αντιστοιχίστε κάθε εύρημα στο Σχήμα 13 και στα βήματα απομάκρυνσης του Κεφαλαίου 13, §13.2.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 8.2 · Εκστρατεία web, mail και SSH (75 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Παρακολουθήστε μία εκστρατεία και στα τρία αρχεία: παράδοση phishing → POST προς webshell → πλευρική μετακίνηση μέσω SSH.</li>
      <li>Αντιστοιχίστε κάθε προσωρινή IP μέσω του ιστορικού μισθώσεων DHCP και προσδιορίστε τις αντίστοιχες MAC.</li>
      <li>Παραδώστε χρονογραμμή πολλαπλών υπηρεσιών με τουλάχιστον 12 συμβάντα σε UTC, μία γραμμή ανά στάδιο και παραπομπή στην πηγή καταγραφής.</li>
    </ol>
  </>
);

export const ch08: Κεφάλαιο = {
  id: "ch8",
  num: 8,
  title: "Εγκληματολογία Βασικών Υπηρεσιών Υποδομής (AD, DNS, DHCP, Mail, Web, SSH)",
  subtitle: "Επιθέσεις ταυτότητας · Έρευνα DNS · Απόδοση DHCP · Webshell · Παράδοση αλληλογραφίας · Πλευρική κίνηση SSH",
  badge: "Tier 3 · Υποδομές",
  time: "12–14 ώρες · περίπου 52 σελίδες",
  outcomes:
    "Εντοπίζετε Kerberoast, DCSync και AS-REP στις καταγραφές DC· αναγνωρίζετε DNS tunneling και DGA· αποδίδετε δυναμικές IP μέσω DHCP· εντοπίζετε webshell σε αρχεία πρόσβασης· παρακολουθείτε πλήρως μια επίθεση phishing· και ελέγχετε SSH για πλευρική μετακίνηση.",
  body,
  labTitle: "Πρακτική Άσκηση 8.1 · Έρευνα επιθέσεων AD + Άσκηση 8.2 · Εκστρατεία web, mail και SSH",
  labsBody,
  workshop: {
    title: "Αρχική διαλογή έξι υπηρεσιών: DC, DNS, DHCP, web, mail και SSH σε μία συνεδρία",
    env: ["Εικονική μηχανή Linux για τον αναλυτή", "Δείγμα καταγραφών από έξι πηγές", "grep, awk, jq και Timeline Explorer"],
    tabs: [
      {
        id: "ad",
        label: "AD και DNS",
        steps: [
          {
            n: "1",
            title: "Έλεγχος Kerberoast και DCSync",
            desc: "Μετρήστε τον όγκο 4769 ανά αιτούντα και αναζητήστε 4662 από μη DC. Κάθε θετικό αποτέλεσμα κλιμακώνει ολόκληρη την υπόθεση.",
            code: [
              {
                title: "Bash — έλεγχοι DC",
                text: `# Top service-ticket requesters (4769)\nawk -F, 'NR>1{print $3}' dc-4769.csv | sort | uniq -c | sort -rn | head\n# RC4-only requesters (crackable)\nawk -F, '$NF=="0x17"{print $3}' dc-4769.csv | sort | uniq -c | sort -rn | head\n# DCSync: 4662 where subject is not a DC account\nawk -F, 'NR>1 && $3 !~ /\\$$/ {print}' dc-4662.csv | head`,
              },
            ],
            expected: "λογαριασμός υπηρεσίας με περισσότερα από 40 εισιτήρια RC4 υποδηλώνει ενεργό Kerberoasting· οποιοδήποτε 4662 από μη DC ταξινομείται ως SEV-1",
          },
          {
            n: "2",
            title: "Έλεγχος DNS tunnel και DGA",
            desc: "Όγκος TXT/NULL, εντροπία ετικετών και NXDOMAIN ανά πελάτη αποτελούν τη βασική τριάδα εντοπισμού tunnel.",
            code: [
              {
                title: "Bash — έλεγχοι DNS",
                text: `awk '$6 ~ /TXT|NULL/ {print $4, $7}' query.log | sort | uniq -c | sort -rn | head\nawk '$9=="NXDOMAIN" {print $4}' query.log | sort | uniq -c | sort -rn | head`,
              },
            ],
          },
        ],
      },
      {
        id: "webmail",
        label: "Web και ηλεκτρονικό ταχυδρομείο",
        steps: [
          {
            n: "3",
            title: "Έλεγχος webshell και σαρώσεων",
            desc: "Αναζητήστε επιτυχημένα POST προς ασυνήθιστες διαδρομές και έπειτα τον καταιγισμό 404 που προηγήθηκε.",
            code: [
              {
                title: "Bash — έλεγχοι web",
                text: `awk '$6=="POST" && $9==200 {print $1, $7}' access.log | sort | uniq -c | sort -rn | head\nawk '$9==404 {print $1}' access.log | sort | uniq -c | sort -rn | head`,
              },
            ],
          },
          {
            n: "4",
            title: "Ιχνηλάτηση παράδοσης phishing",
            desc: "Message-ID → παραλήπτης → αποτέλεσμα ελέγχου → κλικ: η αλυσίδα παράδοσης πρέπει να παραμένει αδιάλειπτη.",
            code: [
              {
                title: "Bash — ιχνηλάτηση αλληλογραφίας",
                text: `grep "MID-88412" mail-tracking.log\n# envelope vs header From + auth verdicts\nawk '/MID-88412/ {print $5, $9, $12, $15}' mail-tracking.log`,
              },
            ],
            expected: "πλαστογραφημένο header-From, αποτυχία SPF, παράδοση και κλικ σημαίνουν επιτυχημένο phishing· συνεχίστε τη διερεύνηση στο τερματικό",
          },
        ],
      },
      {
        id: "ssh",
        label: "SSH και DHCP",
        steps: [
          {
            n: "5",
            title: "Έλεγχος πλευρικής μετακίνησης SSH και απόδοση IP",
            desc: "Μια επιτυχημένη σύνδεση από πρωτοεμφανιζόμενη πηγή αποτελεί ένδειξη πλευρικής μετακίνησης· οι μισθώσεις DHCP αποκαλύπτουν τη συσκευή πίσω από την IP.",
            code: [
              {
                title: "Bash — σύνδεση δεδομένων SSH και DHCP",
                text: `grep "Accepted" auth.log | awk '{print $1, $2, $3, $(NF-3), $NF}' | tail -n 20\n# attribute the suspect IP at the suspect hour\ngrep "10.4.17.88" dhcpd.leases | tail -n 5`,
              },
            ],
          },
          {
            n: "6",
            title: "Ενοποιήστε τη χρονογραμμή της εκστρατείας",
            note: "Παραδοτέο: έξι έλεγχοι, αποδόσεις DHCP και ενοποιημένη χρονογραμμή UTC που αναφέρει την πηγή κάθε σταδίου. Η χρονογραμμή τροφοδοτεί τη δικτυακή επιβεβαίωση του Κεφαλαίου 9.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> τεχνουργήματα AD (§8.1) · μοτίβα DNS (§8.2) · web, mail και SSH (§§8.4–8.6) → απόδειξη πακέτων και ροών (Κεφ. 9) → συσχέτιση SIEM (Κεφ. 11). Παραδοτέο: ενοποιημένη χρονογραμμή έξι πηγών με σαφείς αποδόσεις.
      </>
    ),
  },
  quiz: [
    { q: "Ένας λογαριασμός ζητά 50 εισιτήρια υπηρεσίας RC4 (4769, 0x17). Τι υποδηλώνει αυτό;", o: ["Φυσιολογική χρήση Outlook", "Πιθανό Kerberoasting", "Αποτυχία DNS", "Εγκατάσταση ενημερώσεων"], a: 1, e: "Τα μαζικά αιτήματα εισιτηρίων SPN με RC4 αποτελούν χαρακτηριστική ένδειξη Kerberoasting." },
    { q: "Τι σημαίνει ένα συμβάν 4662 από λογαριασμό σταθμού που δεν είναι Domain Controller;", o: ["Συνήθη περιήγηση", "Πιθανό DCSync, το οποίο αντιμετωπίζεται ως SEV-1 μέχρι να αποκλειστεί", "Εγκατάσταση εκτυπωτή", "Σύνδεση VPN"], a: 1, e: "Πρόσβαση αναπαραγωγής υπηρεσιών καταλόγου αναμένεται κανονικά μόνο από Domain Controllers." },
    { q: "Τι υποδηλώνουν πολλά ερωτήματα TXT με μεγάλες κωδικοποιημένες ετικέτες;", o: ["Windows Update", "DNS tunneling ή εξαγωγή δεδομένων", "Παράδοση ηλεκτρονικού ταχυδρομείου", "Ανανέωση DHCP"], a: 1, e: "Τα δεδομένα μπορούν να μεταφέρονται μέσα στις ετικέτες ασυνήθιστων τύπων ερωτήματος." },
    { q: "Γιατί είναι απαραίτητο το ιστορικό μισθώσεων DHCP σε μια εγκληματολογική έρευνα;", o: ["Κρυπτογραφεί την κίνηση", "Συνδέει προσωρινές IP με MAC και όνομα συστήματος μέσα στον χρόνο", "Αποκλείει κακόβουλο λογισμικό", "Εγκαθιστά διορθώσεις"], a: 1, e: "Χωρίς ιστορικό μισθώσεων, οι δυναμικές IP μιας παλαιότερης χρονογραμμής δεν μπορούν να αποδοθούν αξιόπιστα." },
    { q: "Τι υποδηλώνουν επιτυχημένα POST προς /assets/logo.php στις 03:00;", o: ["Βελτιστοποίηση εικόνας", "Πιθανή αλληλεπίδραση με webshell", "Σάρωση SEO", "Λήψη αντιγράφου"], a: 1, e: "Η εκτέλεση κώδικα σε διαδρομή στατικού περιεχομένου και σε ασυνήθιστη ώρα αποτελεί ισχυρή ένδειξη webshell." },
    { q: "Τι πρέπει να προκαλέσει ένα «Accepted publickey» με άγνωστο fingerprint;", o: ["Καμία ενέργεια", "Έλεγχο του authorized_keys για πιθανό εμφυτευμένο κλειδί", "Μόνο αλλαγή κωδικού", "Εκκαθάριση DNS"], a: 1, e: "Ένα άγνωστο έμπιστο κλειδί αντιμετωπίζεται ως πιθανός μηχανισμός παραμονής SSH μέχρι να αποδειχθεί το αντίθετο." },
  ],
};
