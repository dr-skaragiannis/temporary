import { Callout, CodeBlock, DataTable, Figure, type Κεφάλαιο } from "../ui";

const body = (
  <>
    <h4>7.1 Αρχές ζωντανής αρχικής διαλογής</h4>
    <p>
      Η <b>ζωντανή αρχική διαλογή (live triage)</b> συλλέγει από ένα ενεργό σύστημα ευμετάβλητα δεδομένα επαρκή για τη λήψη αποφάσεων —διεργασίες, sockets, λαβές, συνδεδεμένους χρήστες και την ίδια τη RAM— περιορίζοντας το ίχνος του αναλυτή και τεκμηριώνοντας κάθε μεταβολή. Η σειρά ακολουθεί το RFC 3227 (Σχ. 11): πρώτα συλλέγονται τα πιο εφήμερα στοιχεία, όπως RAM, πίνακας διεργασιών και κατάσταση δικτύου, ενώ ο δίσκος και οι καταγραφές ακολουθούν. Δύο αρχές είναι απαράβατες. Πρώτον, η συλλογή εκτελείται από εξωτερικό μέσο μόνο για ανάγνωση και τα αποτελέσματα αποθηκεύονται εκτός του ύποπτου δίσκου. Δεύτερον, η απόφαση για την τροφοδοσία λαμβάνεται μία φορά: αν η RAM έχει αξία, το σύστημα παραμένει ενεργό αλλά δικτυακά απομονωμένο και δεν επανεκκινείται «για να δούμε αν θα διορθωθεί».
    </p>
    <Figure
      id="fig-triage-order"
      label="Fig. 11 · Live triage collection order"
      caption={
        <>
          <b>Fig. 11.</b> Fifteen-minute triage sequence. RAM capture precedes even process listing when fileless
          tradecraft is suspected, because every executed tool perturbs memory. Each step writes to external media
          with hashes.
        </>
      }
    >
      <svg viewBox="0 0 720 190" className="w-full h-auto" role="img" aria-label="Triage order">
        <g fontSize="10.5" fontWeight="700" textAnchor="middle">
          <rect x="10" y="40" width="130" height="90" rx="8" fill="#be123c" />
          <text x="75" y="62" fill="#fff">0–2 MIN</text>
          <text x="75" y="79" fill="#ffe4e6" fontWeight="400">Photograph screen</text>
          <text x="75" y="95" fill="#ffe4e6" fontWeight="400">Isolate network</text>
          <text x="75" y="111" fill="#fff" fontSize="9">keep POWER on</text>
          <rect x="152" y="40" width="130" height="90" rx="8" fill="#b45309" />
          <text x="217" y="62" fill="#fff">2–7 MIN</text>
          <text x="217" y="79" fill="#fef3c7" fontWeight="400">RAM capture</text>
          <text x="217" y="95" fill="#fef3c7" fontWeight="400">WinPmem/DumpIt</text>
          <text x="217" y="111" fill="#fff" fontSize="9">→ external USB</text>
          <rect x="294" y="40" width="130" height="90" rx="8" fill="#0e7490" />
          <text x="359" y="62" fill="#fff">7–10 MIN</text>
          <text x="359" y="79" fill="#e0f2fe" fontWeight="400">procs + nets</text>
          <text x="359" y="95" fill="#e0f2fe" fontWeight="400">handles + users</text>
          <text x="359" y="111" fill="#fff" fontSize="9">tasklist/netstat</text>
          <rect x="436" y="40" width="130" height="90" rx="8" fill="#7c3aed" />
          <text x="501" y="62" fill="#fff">10–13 MIN</text>
          <text x="501" y="79" fill="#ede9fe" fontWeight="400">event logs</text>
          <text x="501" y="95" fill="#ede9fe" fontWeight="400">prefetch/MFT</text>
          <text x="501" y="111" fill="#fff" fontSize="9">targeted copy</text>
          <rect x="578" y="40" width="132" height="90" rx="8" fill="#166534" />
          <text x="644" y="62" fill="#fff">13–15 MIN</text>
          <text x="644" y="79" fill="#dcfce7" fontWeight="400">hash + log</text>
          <text x="644" y="95" fill="#dcfce7" fontWeight="400">decide: contain</text>
          <text x="644" y="111" fill="#fff" fontSize="9">or escalate</text>
        </g>
        <g stroke="#0f1c2e" strokeWidth="2">
          <line x1="140" y1="85" x2="148" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="282" y1="85" x2="290" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="424" y1="85" x2="432" y2="85" markerEnd="url(#dfir-a1)" />
          <line x1="566" y1="85" x2="574" y2="85" markerEnd="url(#dfir-a1)" />
        </g>
        <text x="360" y="155" textAnchor="middle" fontSize="11" fill="#64748b">Τα εργαλεία εκτελούνται από εξωτερικό μέσο · Κάθε έξοδος αποκτά αμέσως hash · Κάθε εντολή καταγράφεται με χρονοσήμανση UTC</text>
      </svg>
    </Figure>
    <h4>7.2 Απόκτηση RAM: WinPmem, DumpIt και LiME</h4>
    <p>
      Το <b>WinPmem</b>, εργαλείο ανοικτού κώδικα με οδηγό πυρήνα, προσφέρει ευέλικτη και αυτοματοποιήσιμη απόκτηση με υπολογισμό hash και αποτελεί βασική επιλογή για εργαστήρια Windows. Το <b>DumpIt</b> της Comae είναι ένα αυτόνομο εκτελέσιμο που θυσιάζει μέρος της ευελιξίας υπέρ της ταχύτητας και ταιριάζει σε προσωπικό πρώτης απόκρισης υπό πίεση. Το <b>LiME (Linux Memory Extractor)</b> είναι άρθρωμα πυρήνα που συλλέγει RAM Linux σε μορφή LiME ή raw για ανάλυση με Volatility. Και τα τρία φορτώνουν οδηγό ή άρθρωμα, προκαλώντας μικρή αλλά τεκμηριωμένη μεταβολή, η οποία δικαιολογείται από την αξία των πειστηρίων. Η εικόνα γράφεται σε εξωτερικό μέσο με ελεύθερο χώρο τουλάχιστον 1,2 φορές τη RAM, αποκτά αμέσως SHA-256 και συνοδεύεται από εκδόσεις εργαλείων και σημειώσεις προέλευσης.
    </p>
    <DataTable
      head={["Tool", "Platform", "Strength", "Watch-out"]}
      rows={[
        ["WinPmem", "Windows", "Scriptable, hashed, multiple formats", "Driver load = footprint; use matching arch build"],
        ["DumpIt (Comae)", "Windows", "Fastest field capture, single EXE", "Fewer options; verify build authenticity"],
        ["LiME", "Linux", "Standard for Linux images, Volatility-ready", "Requires matching kernel headers/module build"],
        ["AVML (MS)", "Linux", "Signed, user-mode-friendly capture", "Newer; validate Volatility plugin support"],
      ]}
    />
    <h4>7.3 Το πλαίσιο Volatility 3</h4>
    <p>
      Το <b>Volatility 3</b> αναλύει εικόνες μνήμης χωρίς να απαιτεί προκαθορισμένο προφίλ λειτουργικού συστήματος. Εντοπίζει αυτόματα τον πυρήνα μέσω πινάκων συμβόλων —αρχεία ISF JSON που αντιστοιχίζουν τις δομές του πυρήνα για κάθε έκδοση— πάνω από τα επίπεδα διευθύνσεων της εικόνας. Η ροή ξεκινά με <span className="mono text-sm">windows.info</span> για επιβεβαίωση λειτουργικού και έκδοσης και συνεχίζει με στοχευμένα πρόσθετα. Η πολυεπίπεδη αρχιτεκτονική —φυσική μνήμη, εικονική μνήμη και σύμβολα πυρήνα— υποστηρίζει επίσης τα windows.memmap και timeliner. Διατηρείτε τα πακέτα συμβόλων στην ίδια διαχείριση εκδόσεων με το εργαλείο: ασύμβατα σύμβολα μπορεί να προκαλέσουν σιωπηλή λανθασμένη ερμηνεία των δομών.
    </p>
    <h4>7.4 Ανάλυση δέντρου διεργασιών: pslist, pstree και psscan</h4>
    <p>
      Τα rootkit μπορούν να αποκρύψουν διεργασίες αφαιρώντας εγγραφές EPROCESS από την ενεργή λίστα διεργασιών του πυρήνα, την οποία διατρέχει το <span className="mono text-sm">windows.pslist</span>. Το <span className="mono text-sm">windows.psscan</span> αναζητά αντίθετα υπογραφές EPROCESS απευθείας στη μνήμη pool και μπορεί να εντοπίσει αποσυνδεδεμένες ή ήδη τερματισμένες διεργασίες. Η σύγκριση αποτελεί την ανίχνευση (Σχ. 12): διεργασίες που εμφανίζονται στο psscan αλλά όχι στο pslist μπορεί να είναι κρυφές ή να έχουν τερματιστεί· το ExitTime διαχωρίζει τις δύο περιπτώσεις. Το <span className="mono text-sm">windows.pstree</span> παρουσιάζει τις σχέσεις γονέα και τέκνου για ανάλυση LotL, με λογική αντίστοιχη των δέντρων Sysmon EID 1.
    </p>
    <Figure
      id="fig-psscan"
      label="Fig. 12 · Hidden-process detection: list-walk vs. pool-carve"
      caption={
        <>
          <b>Fig. 12.</b> DKOM unlinking defeats list-walking (pslist) but not signature carving (psscan). The set
          difference is the finding; ExitTime separates truly hidden processes from dead ones awaiting scavenging.
        </>
      }
    >
      <svg viewBox="0 0 720 210" className="w-full h-auto" role="img" aria-label="pslist vs psscan">
        <g fontSize="11" fontWeight="700" textAnchor="middle">
          <rect x="10" y="30" width="220" height="120" rx="10" fill="#0f1c2e" />
          <text x="120" y="52" fill="#fbbf24">pslist · LIST WALK</text>
          <text x="120" y="72" fill="#cbd5e1" fontWeight="400" fontSize="10">follows ActiveProcessLinks</text>
          <text x="120" y="90" fill="#cbd5e1" fontSize="10">sees: System, smss,</text>
          <text x="120" y="106" fill="#cbd5e1" fontSize="10">csrss, explorer, …</text>
          <text x="120" y="128" fill="#f87171" fontSize="10">MISSES unlinked evil.exe ✘</text>
          <rect x="250" y="30" width="220" height="120" rx="10" fill="#0e7490" />
          <text x="360" y="52" fill="#fff">psscan · POOL CARVE</text>
          <text x="360" y="72" fill="#e0f2fe" fontWeight="400" fontSize="10">scans for EPROCESS tags</text>
          <text x="360" y="90" fill="#e0f2fe" fontSize="10">sees: ALL of pslist +</text>
          <text x="360" y="106" fill="#e0f2fe" fontSize="10">unlinked + exited</text>
          <text x="360" y="128" fill="#fef08a" fontSize="10">FINDS evil.exe ✔</text>
          <rect x="490" y="30" width="220" height="120" rx="10" fill="#166534" />
          <text x="600" y="52" fill="#fff">VERDICT LOGIC</text>
          <text x="600" y="72" fill="#dcfce7" fontWeight="400" fontSize="10">psscan − pslist = ?</text>
          <text x="600" y="90" fill="#fff" fontSize="10">ExitTime set → exited</text>
          <text x="600" y="106" fill="#fff" fontSize="10">(dead, awaiting free)</text>
          <text x="600" y="128" fill="#bbf7d0" fontSize="10">ExitTime empty → HIDDEN</text>
        </g>
        <text x="360" y="175" textAnchor="middle" fontSize="11" fill="#64748b">DKOM unlinking hides from the OS itself — carving sees what the kernel was told to forget</text>
      </svg>
    </Figure>
    <h4>7.5 Εντοπισμός εγχυμένου κώδικα: malfind και process hollowing</h4>
    <p>
      Το <span className="mono text-sm">windows.malfind</span> αναζητά ιδιωτικές εκτελέσιμες περιοχές μνήμης, δηλαδή σελίδες που έχουν δικαίωμα εκτέλεσης χωρίς να αντιστοιχούν σε αρχείο του δίσκου. Πρόκειται για χαρακτηριστική ένδειξη έγχυσης DLL, ανακλαστικής φόρτωσης και process hollowing T1055. Κάθε αποτέλεσμα παρέχει αποσυναρμολόγηση και δεκαεξαδική προβολή. Κεφαλίδες MZ σε ιδιωτική μνήμη, δικαιώματα RWX και αποσυνδεδεμένες περιοχές VAD αυξάνουν τη βεβαιότητα. Επιβεβαιώστε με <span className="mono text-sm">windows.vadinfo</span> για τα δικαιώματα περιοχών και με σύγκριση <span className="mono text-sm">windows.dlllist</span> και <span className="mono text-sm">ldrmodules</span> για μη συνδεδεμένες DLL. Οι περιοχές JIT του .NET και των περιηγητών μπορούν να μοιάζουν ύποπτες· το συμπέρασμα πρέπει να βασίζεται στο πραγματικό περιεχόμενο, όπως shellcode, κεφαλίδες PE ή συμβολοσειρές C2, όχι μόνο στις σημαίες προστασίας.
    </p>
    <h4>7.6 Τεχνουργήματα υποκλοπής διαπιστευτηρίων</h4>
    <p>
      Η μνήμη περιέχει στοιχεία που συχνά δεν γράφονται ποτέ στον δίσκο: κωδικούς σε απλό κείμενο μέσα σε buffers διεργασιών, hash NTLM και εισιτήρια Kerberos στο LSASS, διαπιστευτήρια RDP στο mstsc και tokens συνεδρίας περιηγητών. Πρόσθετα Volatility όπως <span className="mono text-sm">windows.hashdump</span> και <span className="mono text-sm">windows.cachedump</span>, μαζί με στοχευμένη αναζήτηση συμβολοσειρών και κανόνων YARA, μπορούν να τα ανακτήσουν. Η δυνατότητα αυτή βοηθά τους αναλυτές να αποδείξουν την έκταση της κλοπής, αλλά είναι εξίσου πολύτιμη για τους επιτιθέμενους, γι’ αυτό η προστασία LSASS και το Credential Guard είναι κρίσιμα. Τα διαπιστευτήρια που προέρχονται από μνήμη πρέπει να αντιμετωπίζονται ταυτόχρονα ως πειστήρια και ως επικίνδυνο υλικό: αλλάζετε οτιδήποτε εντοπίζεται και αφαιρείτε αυστηρά τις ευαίσθητες τιμές από τις αναφορές.
    </p>
    <Callout color="amber">
      <b>Scope rule.</b> Memory proves <i>current and recent</i> state, not history: a clean image means "no resident
      tradecraft <i>now</i>," never "never compromised." Pair every memory verdict with disk timelines (Ch. 4) and
      network history (Ch. 9).
    </Callout>
    <div className="not-serif">
      <CodeBlock
        title="Bash — Volatility 3 triage sequence (SIFT/examiner Linux)"
        code={`vol -f EVID-2026-041.mem windows.info              # confirm OS build + symbols OK\nvol -f EVID-2026-041.mem windows.pstree            # parentage overview\nvol -f EVID-2026-041.mem windows.pslist --dump    # (compare next line)\nvol -f EVID-2026-041.mem windows.psscan            # hidden/exited hunt (Fig. 12)\nvol -f EVID-2026-041.mem windows.malfind           # private-RWX injection hunt\nvol -f EVID-2026-041.mem windows.netscan           # sockets at capture time\nvol -f EVID-2026-041.mem windows.hashdump          # credential-theft scope`}
      />
    </div>
    <h4>7.7 Ίχνη μνήμης στον δίσκο και ζωντανή διαλογή Linux</h4>
    <p>
      Η RAM αφήνει κατάλοιπα στον δίσκο. Το <b>hiberfil.sys</b> είναι συμπιεσμένο στιγμιότυπο RAM που δημιουργείται κατά την αδρανοποίηση, οπότε ένα απενεργοποιημένο σύστημα που αδρανοποιήθηκε αποτελεί εν μέρει υπόθεση μνήμης. Τα <b>pagefile.sys και swap</b> μπορεί να διατηρούν για μεγάλο διάστημα σελιδοποιημένο περιεχόμενο διεργασιών· σαρώστε τα με strings και YARA για διαπιστευτήρια, κλειδιά και τμήματα shellcode. Τα <b>MEMORY.DMP</b> και minidumps αποτελούν ευκαιριακές λήψεις: ένα παραβιασμένο σύστημα που κατέρρευσε παραδίδει μέρος της κατάστασης του πυρήνα του για ανάλυση με WinDbg ή Volatility. Σε εικονικοποιημένα περιβάλλοντα προτιμάται η λήψη από τον hypervisor, όπως ανασταλμένα .vmem και .vmsn. Δεν αφήνει ίχνος μέσα στο φιλοξενούμενο σύστημα, μπορεί να υπογραφεί με hash στον κεντρικό υπολογιστή και συχνά μετατρέπεται για χρήση με Volatility.
    </p>
    <p>
      Linux live triage centers on <b>/proc</b>, which cannot lie about running state the way userland tools (possibly
      trojaned) can. The big three checks: <b>deleted-but-running executables</b> (
      <span className="mono text-sm">/proc/&lt;pid&gt;/exe → (deleted)</span> — fileless or self-deleting tradecraft),{" "}
      <b>memfd-resident code</b> (<span className="mono text-sm">memfd:</span> entries in maps — pure in-memory
      payloads), and <b>LD_PRELOAD hijacks</b> (inspect <span className="mono text-sm">/proc/&lt;pid&gt;/environ</span>{" "}
      and /etc/ld.so.preload for injected libraries intercepting syscalls). Add socket inventory (
      <span className="mono text-sm">ss -tunap</span>), kernel-module review (<span className="mono text-sm">lsmod</span>{" "}
      vs. known-good), and deleted-open-handles (<span className="mono text-sm">ls -l /proc/*/fd | grep deleted</span>).
      Full Linux host forensics continues in Appendix B.
    </p>
    <div className="not-serif">
      <CodeBlock
        title="Bash — τριάδα ζωντανής διαλογής Linux μέσω /proc, μόνο για ανάγνωση και με εξωτερική καταγραφή"
        code={`ls -l /proc/[0-9]*/exe 2>/dev/null | grep deleted     # running-but-unlinked binaries\n grep -l "memfd:" /proc/[0-9]*/maps 2>/dev/null        # pure in-memory payloads\ncat /etc/ld.so.preload 2>/dev/null; tr '\\0' '\\n' < /proc/1/environ | grep -i preload\nss -tunap 2>/dev/null | head -n 30                       # sockets with owning PIDs`}
      />
    </div>
  </>
);

const labsBody = (
  <>
    <h4 className="font-extrabold">Άσκηση 7.1 · Ζωντανή διαλογή (60 λεπτά, σε ζεύγη)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Ο ένας εκπαιδευόμενος «παραβιάζει» μια εργαστηριακή VM με EICAR, προγραμματισμένη εργασία και ανοικτό socket, ενώ ο άλλος εκτελεί διαλογή χωρίς προηγούμενη ενημέρωση μέσα σε 15 λεπτά.</li>
      <li>Εκτελέστε τη σειρά του Σχήματος 11 από εξωτερικό μέσο και καταγράψτε κάθε εντολή με χρονική σήμανση UTC.</li>
      <li>Αλλάξτε ρόλους και αξιολογήστε αμοιβαία τα ημερολόγια για παραβίαση σειράς, hash που λείπουν και ανεπιθύμητες εγγραφές στον δίσκο.</li>
    </ol>
    <h4 className="font-extrabold mt-3">Άσκηση 7.2 · Διερεύνηση με Volatility (90 λεπτά)</h4>
    <ol className="list-decimal ml-5 mt-1 space-y-1">
      <li>Εκτελέστε την πλήρη ακολουθία διαλογής στην παρεχόμενη μολυσμένη εικόνα και εντοπίστε την κρυφή διεργασία.</li>
      <li>Επιβεβαιώστε το εύρημα με malfind και netscan και εξαγάγετε την IP C2 και το hash του εγχυμένου ωφέλιμου φορτίου.</li>
      <li>Συντάξτε την ενότητα ευρημάτων μνήμης: διεργασία, έγχυση, δίκτυο και διαπιστευτήρια, με αναφορά στο πρόσθετο και το offset κάθε πειστηρίου.</li>
    </ol>
  </>
);

export const ch07: Κεφάλαιο = {
  id: "ch7",
  num: 7,
  title: "Ζωντανή Διαλογή, Απόκτηση RAM και Εγκληματολογία Πτητικής Μνήμης",
  subtitle: "Σειρά διαλογής · WinPmem/DumpIt/LiME · Volatility 3 · pslist/psscan · malfind · Διαπιστευτήρια",
  badge: "Tier 2 · Εγκληματολογία μνήμης",
  time: "10–12 ώρες · περίπου 42 σελίδες",
  outcomes:
    "Εκτελείτε ζωντανή διαλογή με ορθή σειρά· αποκτάτε RAM με εγκληματολογικά αξιόπιστο τρόπο· χρησιμοποιείτε το Volatility 3· αποκαλύπτετε κρυφές διεργασίες και εγχυμένο κώδικα· και αξιολογείτε από τη μνήμη την έκταση κλοπής διαπιστευτηρίων.",
  body,
  labTitle: "Πρακτική Άσκηση 7.1 · Ζωντανή διαλογή + Άσκηση 7.2 · Διερεύνηση με Volatility",
  labsBody,
  workshop: {
    title: "Ολοκληρωμένη ροή μνήμης: απόκτηση, επαλήθευση και ανάλυση",
    env: ["Εικονική μηχανή Windows-στόχος", "SIFT ή εικονική μηχανή Linux του εξεταστή", "WinPmem, Volatility 3 και σύμβολα"],
    tabs: [
      {
        id: "capture",
        label: "Λήψη και επαλήθευση",
        steps: [
          {
            n: "1",
            title: "Αποτυπώστε τη RAM σε εξωτερικό μέσο",
            desc: "Συνδέστε το USB του εξεταστή, εκτελέστε από εκεί το WinPmem και γράψτε την εικόνα στο ίδιο μέσο, χωρίς να αγγίξετε τον ύποπτο δίσκο.",
            code: [
              {
                title: "PowerShell ως διαχειριστής, από τα εργαλεία του E:\\", 
                text: `E:\\winpmem.exe E:\\EVID-2026-041.mem  # positional output = raw image (flag spelling varies — confirm with --help)\nGet-FileHash E:\\EVID-2026-041.mem -Algorithm SHA256 | Tee-Object E:\\EVID-2026-041.sha256`,
              },
            ],
          },
          {
            n: "2",
            title: "Επαληθεύστε στον σταθμό του εξεταστή",
            desc: "Υπολογίστε ξανά το hash μετά τη μεταφορά και επιβεβαιώστε ότι το Volatility διαβάζει την εικόνα πριν αποδεσμεύσετε τον χώρο.",
            code: [
              {
                title: "Bash — επαλήθευση και βασική δοκιμή",
                text: `sha256sum -c EVID-2026-041.sha256\nvol -f EVID-2026-041.mem windows.info | head -n 20`,
              },
            ],
            expected: "το hash είναι έγκυρο και το windows.info εμφανίζει έκδοση και DTB, με επιτυχή επίλυση συμβόλων",
          },
        ],
      },
      {
        id: "dissect",
        label: "Αναλυτική εξέταση",
        steps: [
          {
            n: "3",
            title: "Απογραφή διεργασιών και αναζήτηση κρυφών διεργασιών",
            desc: "Χρησιμοποιήστε pstree για την ακολουθία και σύγκριση pslist με psscan για τις κρυφές διεργασίες.",
            code: [
              {
                title: "Bash — έρευνα διεργασιών",
                text: `vol -f EVID-2026-041.mem windows.pstree > pstree.txt\nvol -f EVID-2026-041.mem windows.pslist --quiet | awk '{print $2}' | sort -n > pslist.pids\nvol -f EVID-2026-041.mem windows.psscan --quiet | awk '{print $2}' | sort -n > psscan.pids\ncomm -13 pslist.pids psscan.pids > hidden-candidates.txt\ncat hidden-candidates.txt`,
              },
            ],
            expected: "σύντομη λίστα PID· ελέγξτε το ExitTime κάθε εγγραφής για να διακρίνετε τερματισμένη από κρυφή διεργασία",
          },
          {
            n: "4",
            title: "Έλεγχος έγχυσης και δικτύου",
            desc: "Χρησιμοποιήστε malfind για κώδικα, netscan για sockets και hashdump για την έκταση των διαπιστευτηρίων.",
            code: [
              {
                title: "Bash — έγχυση και δίκτυο",
                text: `vol -f EVID-2026-041.mem windows.malfind > malfind.txt; grep -c "Process:" malfind.txt\nvol -f EVID-2026-041.mem windows.netscan > netscan.txt\ngrep -Ei "ESTABLISHED|LISTENING" netscan.txt | head`,
              },
            ],
          },
        ],
      },
      {
        id: "report",
        label: "Συμπέρασμα και αναφορά",
        steps: [
          {
            n: "5",
            title: "Διατυπώστε το συμπέρασμα της ανάλυσης μνήμης",
            desc: "Δημιουργήστε έναν πίνακα με διεργασία, πειστήριο, συμπέρασμα και βαθμό βεβαιότητας. Κανένα συμπέρασμα χωρίς πρόσθετο και offset.",
            note: "Παραδοτέο: εικόνα με hash, αποτελέσματα pstree, psscan, malfind και netscan, πίνακας συμπεράσματος για κρυφές διεργασίες και σημείωση έκτασης διαπιστευτηρίων. Τα συμπεράσματα μνήμης επιβεβαιώνονται πάντοτε με δεδομένα δίσκου και δικτύου.",
          },
        ],
      },
    ],
    note: (
      <>
        <b>Χάρτης εννοιών:</b> σειρά διαλογής (§7.1) · απόκτηση (§7.2) · επίπεδα Volatility (§7.3) → χρονογραμμές δίσκου (Κεφ. 4) + επιβεβαίωση C2 (Κεφ. 9). Παραδοτέο: πλήρης και υπερασπίσιμη τεκμηρίωση διερεύνησης μνήμης.
      </>
    ),
  },
  quiz: [
    { q: "Ποιο είναι το ΠΡΩΤΟ βήμα συλλογής σε ενεργό σύστημα που εμπλέκεται σε εισβολή;", o: ["Απεικόνιση δίσκου", "Λήψη RAM, αφού φωτογραφηθεί και απομονωθεί το σύστημα", "Εξέταση καταγραφών", "Σάρωση με antivirus"], a: 1, e: "Η RAM είναι το πιο ευμετάβλητο στοιχείο. Στο Σχήμα 11 συλλέγεται στα λεπτά 2–7." },
    { q: "Γιατί τα εργαλεία συλλογής πρέπει να εκτελούνται από εξωτερικό μέσο;", o: ["Επειδή λειτουργούν ταχύτερα", "Επειδή η εγγραφή στον ύποπτο δίσκο μεταβάλλει τα πειστήρια", "Επειδή το USB είναι πάντοτε κρυπτογραφημένο", "Επειδή δεν απαιτείται άδεια χρήσης"], a: 1, e: "Κάθε εγγραφή στο εξεταζόμενο μέσο μπορεί να αντικαταστήσει δεδομένα με αποδεικτική αξία." },
    { q: "Με τι αντικατέστησε το Volatility 3 τα χειροκίνητα προφίλ λειτουργικού συστήματος;", o: ["Με εικασία της έκδοσης", "Με αυτόματο εντοπισμό μέσω πινάκων συμβόλων ISF", "Αποκλειστικά με αναζήτηση στο cloud", "Με κατάργηση της υποστήριξης πυρήνα"], a: 1, e: "Οι πίνακες συμβόλων αντιστοιχίζουν αυτόματα τις δομές του πυρήνα για κάθε έκδοση." },
    { q: "Μια διεργασία εμφανίζεται στο psscan αλλά όχι στο pslist και δεν έχει ExitTime. Τι υποδηλώνει αυτό;", o: ["Φυσιολογική κατάσταση", "Κρυφή διεργασία που έχει αποσυνδεθεί από την ενεργή λίστα", "Εργασία εκτύπωσης", "Απόδειξη κρυπτογράφησης"], a: 1, e: "Η απουσία ExitTime δείχνει ότι η διεργασία παραμένει ενεργή, αλλά έχει αφαιρεθεί από την ενεργή λίστα." },
    { q: "Τι εντοπίζει κυρίως το windows.malfind;", o: ["Κατεστραμμένους τομείς δίσκου", "Ιδιωτική εκτελέσιμη μνήμη που μπορεί να περιέχει εγχυμένο κώδικα ή hollowing", "Μηνύματα ηλεκτρονικού ψαρέματος", "Αδύναμους κωδικούς"], a: 1, e: "Εκτελέσιμες σελίδες χωρίς αντίστοιχο αρχείο στον δίσκο αποτελούν χαρακτηριστική ένδειξη έγχυσης." },
    { q: "Τι αποδεικνύει μια εικόνα μνήμης χωρίς ύποπτα ευρήματα;", o: ["Ότι το σύστημα δεν παραβιάστηκε ποτέ", "Ότι δεν εντοπίστηκε ενεργή κακόβουλη τεχνική τη στιγμή της λήψης· το ιστορικό απαιτεί δεδομένα δίσκου και δικτύου", "Ότι ο αναλυτής απέτυχε", "Ότι οι καταγραφές είναι περιττές"], a: 1, e: "Η μνήμη αποτυπώνει την τρέχουσα κατάσταση και πρέπει να συνδυάζεται με ιστορικές χρονογραμμές." },
  ],
};
