import { Callout, CodeBlock, DataTable, Figure, LabBox, QuizBox, WorkshopBox } from "./ui";

export function LinuxAppendix() {
  return (
    <section id="appendix-linux" className="chapter-sec mt-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
      <div className="p-6 lg:p-8 pb-0">
        <div className="flex flex-wrap items-center gap-2">
          <span className="badge bg-slate-900 dark:bg-amber-500 dark:text-slate-900 text-white px-3 py-1 rounded-full">Παράρτημα Β</span>
          <span className="badge bg-violet-100 dark:bg-violet-900 text-violet-800 dark:text-violet-200 px-3 py-1 rounded-full">Προσθήκη ελέγχου · Εγκληματολογική ανάλυση διακομιστών</span>
          <span className="text-xs text-slate-500">⏱ 6–8 ώρες · περίπου 30 σελίδες</span>
        </div>
        <h2 className="text-2xl lg:text-[28px] font-black tracking-tight mt-2">Εισαγωγή στην Εγκληματολογική Ανάλυση Linux</h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">ext4 · journald/auditd · Χάρτης παραμονής · Διαλογή /proc · Υπηρεσίες και containers</p>
        <div className="mt-3 p-3 rounded-xl bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-900 text-sm">
          <b>Μαθησιακά αποτελέσματα παραρτήματος.</b> Ανακτάτε αρχεία και χρονογραμμές από ext4, αξιοποιείτε journald, auditd και καταγραφές
          λογαριασμών, ελέγχετε συστηματικά τους μηχανισμούς παραμονής στο Linux, πραγματοποιείτε διαλογή ενεργών συστημάτων μέσω /proc και οριοθετείτε
          παραβιάσεις υπηρεσιών και containers.
        </div>
      </div>
      <div className="p-6 lg:p-8 pt-4 prose-book serif">
        <h4>B.1 Γιατί το Linux είναι καθοριστικό στις έρευνες διακομιστών</h4>
        <p>
          Οι εταιρικοί διακομιστές, τα cloud instances, οι δικτυακές συσκευές και τα containers λειτουργούν κατά κύριο λόγο σε Linux. Έτσι, οι παραβιάσεις web, mail relay, DNS και βάσεων δεδομένων του Κεφαλαίου 8 συνήθως καταλήγουν σε περιβάλλον Linux. Η εγκληματολογική ανάλυση είναι σχετικά διαφανής: ρυθμίσεις σε απλό κείμενο, αρχεία journal που υποστηρίζουν ερωτήματα, αξιόπιστη κατάσταση μέσω <span className="mono text-sm">/proc</span> και πλούσιο σύνολο εργαλείων, όπως debugfs, journalctl, ausearch και πρόσθετα Linux του Volatility. Η μεθοδολογία των κεφαλαίων Windows μεταφέρεται αυτούσια: αποδεικνύουμε εκτέλεση, ελέγχουμε παραμονή και συνδυάζουμε δεδομένα συστήματος και δικτύου. Αλλάζουν μόνο τα ονόματα των τεχνουργημάτων.
        </p>
        <h4>B.2 ext4: inodes, journals και ανάκτηση διαγραμμένων δεδομένων</h4>
        <p>
          Στο ext4, τα αρχεία αντιστοιχούν σε <b>inodes</b> με μεταδεδομένα και δείκτες μπλοκ, στα οποία παραπέμπουν οι εγγραφές καταλόγου. Η διαγραφή αποσυνδέει το όνομα, ενώ το inode και τα μπλοκ παραμένουν μέχρι να επαναχρησιμοποιηθούν —η ίδια αρχή «διαγραμμένο δεν σημαίνει εξαφανισμένο» που ισχύει για την MFT. Το journal <b>jbd2</b> καταγράφει συναλλαγές μεταδεδομένων για ανάκαμψη και μπορεί να ανασυνθέσει πρόσφατες δημιουργίες, διαγραφές και μετονομασίες. Οι βασικοί χρόνοι είναι atime, mtime, ctime και crtime ή btime. Το ctime, που δείχνει αλλαγή inode, είναι ισχυρό σημείο ελέγχου απέναντι στο timestomping, επειδή τα συνηθισμένα εργαλεία δεν το ορίζουν αυθαίρετα. Για ανάκτηση χρησιμοποιούνται debugfs, extundelete ή ext4magic, ενώ το <span className="mono text-sm">tune2fs -l</span> αποκαλύπτει το ιστορικό και τα χαρακτηριστικά του συστήματος αρχείων.
        </p>
        <h4>B.3 Καταγραφές που έχουν εγκληματολογική αξία</h4>
        <p>
          Η καταγραφή στο Linux είναι πολυεπίπεδη και πλεονάζουσα, άρα ο αντίπαλος πρέπει να καθαρίσει πολλές ανεξάρτητες πηγές για να εξαφανίσει τα ίχνη του. Το <b>journald</b>, μέσω journalctl, συγκεντρώνει υπηρεσίες, πυρήνα και πιστοποίηση με δομημένα πεδία και μπορεί να χρησιμοποιεί Forward Secure Sealing για ένδειξη αλλοίωσης. Το <b>auditd</b>, με ausearch, αποτελεί μάρτυρα σε επίπεδο κλήσεων συστήματος: execve, ανοίγματα αρχείων και αλλαγές δικαιωμάτων με προσαρμοσμένα κλειδιά. Συμπληρωματικές πηγές είναι auth.log/secure, wtmp/btmp/lastlog για επιτυχείς και αποτυχημένες συνδέσεις, cron, ιστορικά shell και καταγραφές διαχειριστή πακέτων. Επειδή το ιστορικό shell μπορεί να τροποποιηθεί, συγκρίνεται με τα execve του auditd. Τα ιστορικά dpkg ή yum μπορούν επίσης να αποκαλύψουν εγκατάσταση πακέτου με κερκόπορτα.
        </p>
        <DataTable
          head={["Καταγραφή", "Ερώτημα", "Τι εντοπίζει"]}
          rows={[
            ["journald", "journalctl -u sshd --since '2026-09-20' -o verbose", "Χρονογραμμές ανά υπηρεσία με _PID/_EXE/_CMDLINE"],
            ["auditd", "ausearch -k execution --start recent", "Κάθε execve, μαζί με δυαδικά που διέγραψε ο επιτιθέμενος"],
            ["wtmp / btmp", "last / lastb", "Επιτυχείς και αποτυχημένες συνδέσεις (spraying έναντι επιτυχίας)"],
            ["shell history", "cat ~user/.bash_history + HISTTIMEFORMAT", "Πληκτρολογημένες εντολές — επαλήθευση με auditd"],
            ["dpkg / yum log", "grep -i install /var/log/dpkg.log", "Πακέτα με κερκόπορτα και επιθέσεις dependency confusion"],
          ]}
        />
        <h4>B.4 Χάρτης μηχανισμών παραμονής</h4>
        <p>
          Οι μηχανισμοί παραμονής στο Linux είναι πολλοί και διάσπαρτοι (Σχ. 25), γι’ αυτό ελέγχονται από τους συχνότερους προς τους βαθύτερους. Τα cron, at και systemd timers καλύπτουν προγραμματισμένη εκτέλεση. Οι μονάδες systemd —συστήματος και χρήστη, ενεργές, static ή masked— αποκαλύπτουν παραμονή μέσω υπηρεσίας. Τα profile.d, bashrc και rc.local καλύπτουν εκκίνηση shell, ενώ τα <b>authorized_keys</b> σε όλο τον στόλο αποκαλύπτουν την πιο συνηθισμένη παραμονή σε διακομιστές. Το <b>LD_PRELOAD</b> και το /etc/ld.so.preload σχετίζονται με rootkit που παρεμβάλλονται σε κλήσεις, ενώ τα modules πυρήνα αποτελούν βαθύτερο σημείο εγκατάστασης. Σε δεύτερο πέρασμα εξετάζονται κανόνες udev, hooks πακέτων, inetd/xinetd και scripts MOTD.
        </p>
        <Figure
          id="fig-linux-persist"
          label="Σχ. 25 · Χάρτης μηχανισμών παραμονής στο Linux"
          caption={
            <>
              <b>Σχ. 25.</b> Ελέγξτε από πάνω προς τα κάτω, όπως στο Σχ. 8: πρώτα timers και units, τελευταίο τον πυρήνα. Κάθε καταχώριση αναφέρει τη
              θέση της στον δίσκο, ώστε κατά την εξέταση ανενεργού συστήματος να είναι σαφές ποιες διαδρομές συγκρίνονται με τις πρότυπες εικόνες.
            </>
          }
        >
          <svg viewBox="0 0 720 240" className="w-full h-auto" role="img" aria-label="Χάρτης μηχανισμών παραμονής στο Linux">
            <g fontSize="10.5" fontWeight="700" textAnchor="middle">
              <rect x="10" y="10" width="225" height="96" rx="8" fill="#be123c" />
              <text x="122" y="30" fill="#fff">CRON / AT + TIMERS</text>
              <text x="122" y="47" fill="#ffe4e6" fontWeight="400">/etc/cron* · spool</text>
              <text x="122" y="63" fill="#ffe4e6" fontWeight="400">systemd *.timer</text>
              <text x="122" y="82" fill="#fff" fontSize="9">έλεγχος ΠΡΩΤΑ</text>
              <rect x="247" y="10" width="226" height="96" rx="8" fill="#b45309" />
              <text x="360" y="30" fill="#fff">ΜΟΝΑΔΕΣ SYSTEMD</text>
              <text x="360" y="47" fill="#fef3c7" fontWeight="400">/etc/systemd/system</text>
              <text x="360" y="63" fill="#fef3c7" fontWeight="400">+ ~/.config/systemd</text>
              <text x="360" y="82" fill="#fff" fontSize="9">ενεργό; masked;</text>
              <rect x="485" y="10" width="225" height="96" rx="8" fill="#0e7490" />
              <text x="597" y="30" fill="#fff">ΕΚΚΙΝΗΣΗ SHELL</text>
              <text x="597" y="47" fill="#e0f2fe" fontWeight="400">profile.d · bashrc</text>
              <text x="597" y="63" fill="#e0f2fe" fontWeight="400">rc.local · motd</text>
              <text x="597" y="82" fill="#fff" fontSize="9">ανά χρήστη + καθολικά</text>
              <rect x="10" y="114" width="225" height="88" rx="8" fill="#7c3aed" />
              <text x="122" y="134" fill="#fff">ΚΛΕΙΔΙΑ SSH</text>
              <text x="122" y="151" fill="#ede9fe" fontWeight="400">~/.ssh/authorized_keys</text>
              <text x="122" y="167" fill="#ede9fe" fontWeight="400">έλεγχος σε όλο τον στόλο</text>
              <text x="122" y="186" fill="#fff" fontSize="9">κύρια παραμονή σε server</text>
              <rect x="247" y="114" width="226" height="88" rx="8" fill="#166534" />
              <text x="360" y="134" fill="#fff">LD_PRELOAD / LD.SO</text>
              <text x="360" y="151" fill="#dcfce7" fontWeight="400">/etc/ld.so.preload</text>
              <text x="360" y="167" fill="#dcfce7" fontWeight="400">+ υποκλοπή env</text>
              <text x="360" y="186" fill="#fff" fontSize="9">rootkit χώρου χρήστη</text>
              <rect x="485" y="114" width="225" height="88" rx="8" fill="#0f1c2e" />
              <text x="597" y="134" fill="#fbbf24">MODULES ΠΥΡΗΝΑ</text>
              <text x="597" y="151" fill="#cbd5e1" fontWeight="400">lsmod έναντι γνωστής καλής κατάστασης</text>
              <text x="597" y="167" fill="#cbd5e1" fontWeight="400">modules-load.d</text>
              <text x="597" y="186" fill="#fbbf24" fontSize="9">βαθύτερο σημείο παραμονής</text>
            </g>
            <text x="360" y="224" textAnchor="middle" fontSize="11" fill="#64748b">Συγκρίνετε με πρότυπες εικόνες· κάθε διαφορά σε διακομιστή θεωρείται εύρημα μέχρι να αποδειχθεί ότι οφείλεται σε ενημέρωση</text>
          </svg>
        </Figure>
        <h4>B.5 Ζωντανή διαλογή μέσω /proc και μνήμης</h4>
        <p>
          Η τριάδα του §7.7 —διαγραμμένα εκτελέσιμα που παραμένουν ανοικτά, memfd και LD_PRELOAD— επεκτείνεται σε πλήρη έλεγχο: ανοικτές λαβές προς διαγραμμένα αρχεία, απογραφή sockets με PID, έλεγχος προσαρτήσεων για απρόσμενα tmpfs ή overlay και αναζήτηση μεταβλητών περιβάλλοντος διεργασιών. Η RAM συλλέγεται με LiME ή AVML και αναλύεται με πρόσθετα Volatility όπως linux.pslist, pstree, lsof και bash. Η σειρά ακολουθεί το Σχήμα 11: RAM → στιγμιότυπο /proc → καταγραφές → δίσκος. Όλα τα αποτελέσματα γράφονται σε εξωτερικό μέσο και αποκτούν αμέσως κρυπτογραφικό αποτύπωμα.
        </p>
        <div className="not-serif">
          <CodeBlock
            title="Bash — έλεγχος παραμονής και διαλογής Linux (μόνο ανάγνωση)"
            code={`# Persistence sweep (Fig. 25, top four rows)\nls -la /etc/cron* /var/spool/cron/ 2>/dev/null; systemctl list-timers --all\nsystemctl list-unit-files --state=enabled | head -n 30\ncat /etc/ld.so.preload 2>/dev/null; find /home /root -name authorized_keys -exec cat {} \\;\n# Live triage additions: mounts + deleted handles\ncat /proc/mounts | grep -Ev 'cgroup|proc |sysfs'; ls -l /proc/[0-9]*/fd 2>/dev/null | grep deleted`}
          />
        </div>
        <h4>B.6 Υπηρεσίες, containers και όρια της έκτασης</h4>
        <p>
          Η εγκληματολογική ανάλυση web και SSH εφαρμόζεται άμεσα και σε Linux, αλλά τα περιβάλλοντα containers απαιτούν πρόσθετη ορατότητα. Το <span className="mono text-sm">docker ps -a</span> αποκαλύπτει άγνωστα containers και το <span className="mono text-sm">docker diff</span> εμφανίζει τις αλλαγές του συστήματος αρχείων σε σχέση με την εικόνα, λειτουργώντας ως χρονογραμμή του container. Οι καταγραφές του daemon και τα audit logs του Kubernetes τεκμηριώνουν ενέργειες ενορχήστρωσης. Ειδικές περιπτώσεις είναι παραβιασμένες εικόνες —επανακατασκευή από έμπιστο registry και επαλήθευση digest—, προσαρτημένες διαδρομές του host που απαιτούν έλεγχο διαφυγής και μυστικά σε μεταβλητές ή layers εικόνας που πρέπει να περιστραφούν. Για πλήρη διερεύνηση Kubernetes, το audit log αποτελεί το πρώτο πειστήριο και ακολουθεί εξειδικευμένη κλιμάκωση.
        </p>
        <Callout color="emerald">
          <b>Βασική αρχή για το Linux.</b> Συγκρίνετε, μην αρκείστε σε οπτικό έλεγχο: πρότυπες εικόνες για την παραμονή, auditd για την πραγματική εκτέλεση
          και /proc για τη ζωντανή κατάσταση. Τα τεχνουργήματα διαφέρουν από τα Windows· η μεθοδολογική πειθαρχία παραμένει ίδια.
        </Callout>
      </div>
      <div className="px-6 lg:px-8 pb-6 lg:pb-8 space-y-4">
        <WorkshopBox
          num="B"
          ws={{
            title: "Διαλογή Linux σε 30 λεπτά: έλεγχος παραμονής και ζωντανής κατάστασης",
            env: ["Εργαστηριακή VM Linux (με στιγμιότυπο)", "Κατάλογος αρχείων πρότυπης εικόνας", "Εξωτερικό USB πειστηρίων"],
            tabs: [
              {
                id: "persist",
                label: "Έλεγχος παραμονής",
                steps: [
                  {
                    n: "1",
                    title: "Έλεγχος timers, units και εκκίνησης shell",
                    desc: "Σχ. 25, σειρές 1–3: οτιδήποτε απουσιάζει από την πρότυπη εικόνα θεωρείται ύποπτο μέχρι να αποδειχθεί ότι προήλθε από ενημέρωση.",
                    code: [
                      {
                        title: "Bash — παραμονή μέσω προγραμματισμού και υπηρεσιών",
                        text: `ls -la /etc/cron.d/ /etc/cron.daily/ /var/spool/cron/crontabs/ 2>/dev/null\nsystemctl list-timers --all --no-pager\nsystemctl list-unit-files --state=enabled --no-pager | tee /mnt/usb/units.txt\ngrep -r "curl\|wget\|bash -i\|python3 -c" /etc/cron* /etc/systemd/system/ 2>/dev/null`,
                      },
                    ],
                    expected: "σύντομη λίστα timers/units που δεν προέρχονται από τον προμηθευτή· καθένα αποτελεί οριοθετημένη ένδειξη προς διερεύνηση",
                  },
                  {
                    n: "2",
                    title: "Έλεγχος κλειδιών SSH και LD_PRELOAD",
                    desc: "Οι δύο πιο αθόρυβοι μηχανισμοί παραμονής: καμία διεργασία, καμία καταγραφή, μόνο πρόσβαση.",
                    code: [
                      {
                        title: "Bash — κλειδιά και preload",
                        text: `find /home /root -name "authorized_keys" -exec echo "== {}" \\; -exec cat {} \\;\ncat /etc/ld.so.preload 2>/dev/null || echo "no global preload"\nls -la /etc/ld.so.conf.d/`,
                      },
                    ],
                  },
                ],
              },
              {
                id: "live",
                label: "Ζωντανή διαλογή",
                steps: [
                  {
                    n: "3",
                    title: "Εκτέλεση της τριάδας /proc και απογραφή sockets",
                    desc: "Η τριάδα της §7.7 μαζί με πλήρη απογραφή sockets συνθέτουν το στιγμιότυπο της ζωντανής κατάστασης.",
                    code: [
                      {
                        title: "Bash — στιγμιότυπο ζωντανής κατάστασης",
                        text: `ls -l /proc/[0-9]*/exe 2>/dev/null | grep deleted | tee /mnt/usb/deleted-exe.txt\ngrep -l "memfd:" /proc/[0-9]*/maps 2>/dev/null | tee /mnt/usb/memfd.txt\nss -tunap 2>/dev/null | tee /mnt/usb/sockets.txt | head -n 30\nsha256sum /mnt/usb/*.txt | tee /mnt/usb/triage.sha256`,
                      },
                    ],
                    expected: "σύνολο στιγμιοτύπων με hash· κάθε εύρημα deleted-exe ή memfd οδηγεί σε συλλογή μνήμης",
                  },
                ],
              },
            ],
            note: (
              <>
                <b>Εννοιολογικός χάρτης:</b> χάρτης παραμονής (§B.4) · διαλογή /proc (§B.5) → ανάλυση μνήμης (Κεφ. 7) → συσχέτιση
                στο SIEM (Κεφ. 11). Παραδοτέο: αποτελέσματα ελέγχου με hash και πίνακας συμπερασμάτων για τους μηχανισμούς παραμονής.
              </>
            ),
          }}
        />
        <LabBox title="Πρακτική Άσκηση Β.1 · Έλεγχος παραμονής + Άσκηση Β.2 · Χρονογραμμή παραβίασης Linux">
          <h4 className="font-extrabold">Άσκηση B.1 · Έλεγχος μηχανισμών παραμονής (60 λεπτά)</h4>
          <ol className="list-decimal ml-5 mt-1 space-y-1">
            <li>Ελέγξτε και τις έξι σειρές του Σχ. 25 στην παρεχόμενη εικόνα και συγκρίνετέ τις με το πρότυπο manifest.</li>
            <li>Ταξινομήστε κάθε διαφορά ως ενημέρωση, διαχειριστική ενέργεια, κακόβουλη ή άγνωστη, τεκμηριώνοντας την απόφαση.</li>
            <li>Μην αφαιρέσετε ακόμη τίποτε· καταγράψτε τη σειρά εξάλειψης, τι θα αφαιρεθεί, με ποια σειρά και πώς θα επαληθευτεί.</li>
          </ol>
          <h4 className="font-extrabold mt-3">Άσκηση B.2 · Χρονογραμμή παραβίασης Linux (75 λεπτά)</h4>
          <ol className="list-decimal ml-5 mt-1 space-y-1">
            <li>Συνδυάστε journald, auditd, auth.log και wtmp σε μία χρονογραμμή UTC για το χρονικό παράθυρο του περιστατικού.</li>
            <li>Εντοπίστε την αρχική πρόσβαση, την εγκατάσταση παραμονής και την πρώτη επικοινωνία C2, με μία παραπομπή καταγραφής ανά στάδιο.</li>
            <li>Παραδώστε την ενότητα ευρημάτων συστήματος: χρονογραμμή, πίνακα παραμονής και δήλωση έκτασης.</li>
          </ol>
        </LabBox>
        <QuizBox
          id="qb-linux"
          num="B"
          questions={[
            { q: "Γιατί το ctime του ext4 αποτελεί αξιόπιστο σημείο αναφοράς απέναντι στο timestomping;", o: ["Είναι κρυπτογραφημένο", "Τα συνήθη εργαλεία δεν μπορούν να το ορίσουν αυθαίρετα· καταγράφει αλλαγές του inode", "Αποθηκεύεται εκτός δίσκου", "Δεν ενημερώνεται ποτέ"], a: 1, e: "Τα mtime/atime μπορούν να οριστούν, ενώ το ctime ακολουθεί τις αλλαγές μεταδεδομένων." },
            { q: "Ποιο είναι το ιδιαίτερο πλεονέκτημα του auditd έναντι του ιστορικού shell;", o: ["Καλύτερη εμφάνιση", "Καταγραφές execve σε επίπεδο πυρήνα που διατηρούνται παρά την αλλοίωση του αρχείου ιστορικού", "Ταχύτερα ερωτήματα", "Μηδενική χρήση δίσκου"], a: 1, e: "Οι επιτιθέμενοι αλλοιώνουν το .bash_history, αλλά σπάνια εξουδετερώνουν και το auditd." },
            { q: "Τι υποδηλώνει όταν το /proc/812/exe παραπέμπει σε «(deleted)»;", o: ["Φυσιολογική συμπεριφορά systemd", "Δυαδικό που εκτελείται χωρίς σύνδεση στο σύστημα αρχείων — τεχνική fileless ή αυτοδιαγραφής", "Εργασία εκτύπωσης", "Γεμάτος δίσκος"], a: 1, e: "Ενεργός κώδικας χωρίς διαδρομή στον δίσκο αποτελεί χαρακτηριστική ένδειξη fileless εκτέλεσης." },
            { q: "Ποιος είναι ο συνηθέστερος μηχανισμός παραμονής σε διακομιστές Linux που πρέπει να ελέγχεται σε όλο τον στόλο;", o: ["Kernel modules", "Μη εξουσιοδοτημένες εγγραφές authorized_keys", "Αλλαγές ταπετσαρίας", "Cookies προγράμματος περιήγησης"], a: 1, e: "Τα εμφυτευμένα κλειδιά SSH είναι αθόρυβα, αξιόπιστα και διαδεδομένα." },
            { q: "Τι δείχνει το docker diff σε μια διερεύνηση;", o: ["Την ταχύτητα λήψης της εικόνας", "Τις αλλαγές του συστήματος αρχείων του container σε σχέση με την εικόνα του — τη χρονογραμμή του container", "Τη χρήση CPU", "Κωδικούς registry"], a: 1, e: "Οι διαφορές αποκαλύπτουν εργαλεία που τοποθετήθηκαν, αλλαγμένες ρυθμίσεις και δεδομένα που προετοιμάστηκαν για εξαγωγή." },
          ]}
        />
      </div>
    </section>
  );
}
