// A safe, simulated Linux terminal engine for the HACKFORGE lab.
// No real commands are executed — everything is a scripted simulation.

export type FileNode = {
  type: "file" | "dir";
  content?: string;
  perms: string; // e.g. "rwxr-xr-x"
  owner: string;
  group: string;
  size: number;
  hidden?: boolean;
  children?: Record<string, FileNode>;
};

export type CmdResult = {
  lines: OutLine[];
  command: string;
};

export type OutLine = { text: string; cls?: string };

// Common surface used by the TerminalView component so it can drive either the
// lab Terminal or the Raven terminal.
export interface TerminalLike {
  history: string[];
  prompt(): string;
  run(raw: string): OutLine[];
  complete(input: string): { completed: string; candidates: string[] };
}

const c = {
  err: "text-red-400",
  ok: "text-neon-green",
  warn: "text-amber-300",
  dim: "text-iron-500",
  info: "text-neon-cyan",
  ember: "text-ember-400",
};

function line(text: string, cls?: string): OutLine {
  return { text, cls };
}

// ------------------------- Virtual File System -------------------------

function file(content: string, perms = "rw-r--r--", owner = "operator"): FileNode {
  return { type: "file", content, perms, owner, group: owner, size: content.length };
}
function dir(children: Record<string, FileNode>, perms = "rwxr-xr-x", owner = "operator"): FileNode {
  return { type: "dir", children, perms, owner, group: owner, size: 4096 };
}

export function buildFS(): FileNode {
  return dir({
    home: dir({
      operator: dir({
        "readme.txt": file(
          "Welcome to HACKFORGE, operator.\nThis is a sandbox. Practice freely.\nRule #1: hack only what you are allowed to.\n"
        ),
        "notes.md": file("# Recon notes\n- gateway is 10.10.10.1\n- target box: 10.10.10.5\n"),
        documents: dir({
          "passwords.txt": file("do-not-store-passwords-in-plaintext\n", "rw-------"),
          "todo.txt": file("1. learn linux\n2. scan network\n3. profit (ethically)\n"),
          ".htpasswd": file("root:x:hidden\nadmin:BACKDOOR:flag{grep_found_the_backdoor}\nguest:x:none\n"),
        }),
        loot: dir({}),
        ".secret": file("flag{hidden_files_start_with_a_dot}\n"),
        ".vault": dir({
          "flag.txt": file("flag{you_navigated_the_hidden_vault}\n"),
        }),
        ".ssh": dir({
          id_rsa: file("-----BEGIN OPENSSH PRIVATE KEY-----\n(simulated private key)\n-----END-----\n", "rw-r--r--"),
          "id_rsa.pub": file("ssh-rsa AAAAB3... operator@kali\n"),
        }),
        "backup.sh": file("#!/bin/bash\ntar -czf backup.tgz documents/\n", "rwxr-xr-x"),
      }),
    }),
    etc: dir({
      passwd: file(
        "root:x:0:0:root:/root:/bin/bash\noperator:x:1000:1000::/home/operator:/bin/bash\nwww-data:x:33:33::/var/www:/usr/sbin/nologin\n",
        "rw-r--r--",
        "root"
      ),
      hosts: file("127.0.0.1 localhost\n10.10.10.5 target.hackforge.lab\n", "rw-r--r--", "root"),
      shadow: file(
        "root:$6$saltsalt$R0oThAsh...:19000:0:99999:7:::\noperator:$6$abc$hAsH...:19000:0:99999:7:::\nflag{root_reads_the_shadow_file}\n",
        "rw-------",
        "root"
      ),
    }),
    var: dir({
      www: dir({ "index.html": file("<h1>It works</h1>\n", "rw-r--r--", "www-data") }, "rwxr-xr-x", "www-data"),
    }),
    root: dir(
      {
        "flag.txt": file("flag{root_access_the_forge_is_complete}\n", "rw-------", "root"),
      },
      "rwx------",
      "root"
    ),
  });
}

// ------------------------- Network model -------------------------

const NETWORK: Record<string, { ports: { port: number; svc: string; ver: string; state?: string }[]; hostname: string }> = {
  "10.10.10.1": { hostname: "gateway.hackforge.lab", ports: [{ port: 53, svc: "domain", ver: "dnsmasq 2.85" }] },
  "10.10.10.5": {
    hostname: "target.hackforge.lab",
    ports: [
      { port: 22, svc: "ssh", ver: "OpenSSH 8.9p1" },
      { port: 80, svc: "http", ver: "Apache 2.4.52" },
      { port: 3306, svc: "mysql", ver: "MySQL 5.7.38" },
    ],
  },
  "10.10.10.7": {
    hostname: "web.hackforge.lab",
    ports: [
      { port: 80, svc: "http", ver: "nginx 1.18.0" },
      { port: 443, svc: "https", ver: "nginx 1.18.0" },
    ],
  },
};
const HOSTALIAS: Record<string, string> = {
  "target.hackforge.lab": "10.10.10.5",
  "web.hackforge.lab": "10.10.10.7",
  "gateway.hackforge.lab": "10.10.10.1",
  "scanme.hackforge.lab": "10.10.10.5",
};

function resolve(host: string): string | null {
  if (NETWORK[host]) return host;
  if (HOSTALIAS[host]) return HOSTALIAS[host];
  return null;
}

// ------------------------- Engine -------------------------

export class Terminal {
  fs: FileNode;
  cwd: string[]; // path segments, e.g. ["home","operator"]
  user: string;
  host: string;
  history: string[] = [];
  commandsRun = 0;
  ran: string[] = []; // normalized command log for objective checks

  // ---- Outcome tracking (method-agnostic) — checks read these, NOT raw text ----
  // Every flag below is set ONLY when a command actually executes successfully in
  // the right context (correct user/permissions/target), never just because the
  // command string was typed.
  capturedFlags = new Set<string>(); // any flag{...} the player has revealed
  pinged = new Set<string>(); // IPs proven reachable (by IP or resolved name)
  resolved = new Set<string>(); // hostnames/IPs resolved via any DNS tool
  nmapSubnet = false; // performed a subnet sweep
  nmapVersionScans = new Set<string>(); // IPs given a service/version scan
  nmapPortScans = new Set<string>(); // IPs given any port scan
  nmapSpecificPorts = new Set<string>(); // `${ip}:${port}` explicitly scanned via -p
  bruteforced = new Set<string>(); // services successfully brute-forced
  sqlmapRun = false; // ran an automated SQLi tool
  sqlmapDumped = false; // ran sqlmap with --dump (extracted data)
  nmapFullScan = new Set<string>(); // IPs scanned with -p- (all ports)
  // simple "this action actually happened" outcomes
  ranHelp = false;
  ranWhoami = false;
  ranId = false;
  ranPwd = false;
  ranClear = false;
  ranIpAddr = false;
  ranIpRoute = false;
  ranNetstat = false;
  ranIfconfig = false;
  ranFindCmd = false; // a find that executed over a valid path
  whoisDone = false;
  listedDirs = new Set<string>(); // dirs successfully listed with ls
  listedHidden = false; // ls -a that actually revealed hidden entries
  listedLong = false; // ls -l performed on a real dir
  readFiles = new Set<string>(); // abs paths of files whose content was printed
  sudoReadFiles = new Set<string>(); // files read while effectively root (via sudo/root)
  grepped = new Set<string>(); // abs file paths where grep returned a match
  curled = new Set<string>(); // hosts successfully fetched with curl
  sshTargets = new Set<string>(); // hosts an ssh session was opened to

  constructor() {
    this.fs = buildFS();
    this.cwd = ["home", "operator"];
    this.user = "operator";
    this.host = "kali";
  }

  cwdStr(): string {
    const p = "/" + this.cwd.join("/");
    if (p === "/home/operator") return "~";
    if (p.startsWith("/home/operator/")) return "~" + p.slice("/home/operator".length);
    return p;
  }

  prompt(): string {
    return `${this.user}@${this.host}:${this.cwdStr()}$`;
  }

  // Public helper for challenge checks: permission string of a path, or null.
  pathPerms(input: string): string | null {
    const segs = this.resolvePath(input);
    const n = segs && this.nodeAt(segs);
    return n ? n.perms : null;
  }

  // Public helper for challenge checks: does a path exist?
  pathExists(input: string): boolean {
    const segs = this.resolvePath(input);
    return !!(segs && this.nodeAt(segs));
  }

  // Tab completion: given the current input, return the completed string and any
  // ambiguous candidates. Completes command names on the first word, otherwise paths.
  complete(input: string): { completed: string; candidates: string[] } {
    const noneChange = { completed: input, candidates: [] as string[] };
    const trailingSpace = /\s$/.test(input);
    const parts = input.split(/\s+/);
    const isFirstWord = parts.length === 1 && !trailingSpace;

    // ---- complete a command name ----
    if (isFirstWord) {
      const frag = parts[0];
      if (!frag) return noneChange;
      const cmds = COMMANDS.filter((c) => c.startsWith(frag));
      if (cmds.length === 0) return noneChange;
      if (cmds.length === 1) return { completed: cmds[0] + " ", candidates: [] };
      const common = longestCommonPrefix(cmds);
      return { completed: common.length > frag.length ? common : frag, candidates: cmds };
    }

    // ---- complete a path argument ----
    const frag = trailingSpace ? "" : parts[parts.length - 1];
    // split fragment into a directory portion and the final name portion
    const slash = frag.lastIndexOf("/");
    const dirPart = slash >= 0 ? frag.slice(0, slash + 1) : "";
    const namePart = slash >= 0 ? frag.slice(slash + 1) : frag;
    const dirSegs = this.resolvePath(dirPart || ".");
    const dirNode = dirSegs && this.nodeAt(dirSegs);
    if (!dirNode || dirNode.type !== "dir" || !dirNode.children) return noneChange;

    let names = Object.keys(dirNode.children).filter((n) => n.startsWith(namePart));
    // only show dotfiles if the user has started typing a dot
    if (!namePart.startsWith(".")) names = names.filter((n) => !n.startsWith("."));
    if (names.length === 0) return noneChange;

    const decorate = (n: string) => (dirNode.children![n].type === "dir" ? n + "/" : n);

    if (names.length === 1) {
      const full = dirPart + decorate(names[0]);
      const rebuilt = [...parts.slice(0, -1), full].join(" ");
      return { completed: rebuilt + (dirNode.children[names[0]].type === "dir" ? "" : " "), candidates: [] };
    }
    const common = longestCommonPrefix(names);
    const full = dirPart + (common.length > namePart.length ? common : namePart);
    const rebuilt = [...parts.slice(0, -1), full].join(" ");
    return { completed: rebuilt, candidates: names.map(decorate) };
  }

  private nodeAt(segs: string[]): FileNode | null {
    let n: FileNode = this.fs;
    for (const s of segs) {
      if (n.type !== "dir" || !n.children || !n.children[s]) return null;
      n = n.children[s];
    }
    return n;
  }

  private resolvePath(input: string): string[] | null {
    let segs: string[];
    if (input.startsWith("/")) segs = input.split("/").filter(Boolean);
    else if (input === "~" || input.startsWith("~/")) {
      segs = ["home", "operator", ...input.slice(1).split("/").filter(Boolean)];
    } else {
      segs = [...this.cwd, ...input.split("/").filter(Boolean)];
    }
    const out: string[] = [];
    for (const s of segs) {
      if (s === ".") continue;
      if (s === "..") out.pop();
      else out.push(s);
    }
    return out;
  }

  run(raw: string): OutLine[] {
    const input = raw.trim();
    if (input) {
      this.history.push(input);
      this.commandsRun++;
      this.ran.push(input.replace(/\s+/g, " "));
    }
    if (!input) return [];
    const out = this.dispatch(input);
    // Any command whose output reveals a flag captures it — method-agnostic.
    for (const l of out) {
      const m = l.text.match(/flag\{[^}]+\}/g);
      if (m) m.forEach((f) => this.capturedFlags.add(f));
    }
    return out;
  }

  private dispatch(input: string): OutLine[] {
    const parts = input.split(/\s+/);
    const cmd = parts[0];
    const args = parts.slice(1);
    const flags = args.filter((a) => a.startsWith("-")).join("").replace(/-/g, "");
    const pos = args.filter((a) => !a.startsWith("-"));

    switch (cmd) {
      case "help":
        this.ranHelp = true;
        return this.help();
      case "clear":
      case "cls":
        this.ranClear = true;
        return [{ text: "__CLEAR__" }];
      case "pwd":
        this.ranPwd = true;
        return [line("/" + this.cwd.join("/"))];
      case "whoami":
        this.ranWhoami = true;
        return [line(this.user)];
      case "id":
        this.ranId = true;
        return [
          line(
            this.user === "root"
              ? "uid=0(root) gid=0(root) groups=0(root)"
              : "uid=1000(operator) gid=1000(operator) groups=1000(operator),27(sudo)"
          ),
        ];
      case "hostname":
        return [line(this.host)];
      case "echo":
        return [line(args.join(" ").replace(/^["']|["']$/g, ""))];
      case "date":
        return [line(new Date().toString())];
      case "history":
        return this.history.map((h, i) => line(`${String(i + 1).padStart(4)}  ${h}`));
      case "ls":
        return this.ls(flags, pos);
      case "cd":
        return this.cd(pos[0]);
      case "cat":
      case "less":
      case "more":
      case "head":
      case "tail":
      case "bat":
        return this.cat(pos);
      case "mkdir":
        return this.mkdir(pos);
      case "touch":
        return this.touch(pos);
      case "rm":
        return this.rm(flags, pos);
      case "cp":
        return this.cp(pos);
      case "mv":
        return this.mv(pos);
      case "find":
        return this.find(pos);
      case "grep":
        return this.grep(args);
      case "chmod":
        return this.chmod(pos);
      case "chown":
        return this.chown(pos);
      case "sudo":
        return this.sudo(args);
      case "man":
        return this.man(pos[0]);
      case "ip":
        return this.ip(args);
      case "ifconfig":
        return this.ifconfig();
      case "ping":
        return this.ping(pos);
      case "netstat":
      case "ss":
        return this.netstat();
      case "nslookup":
      case "host":
      case "resolvectl":
        return this.nslookup(pos[0]);
      case "dig":
        return this.dig(pos[0]);
      case "whois":
        return this.whois(pos[0]);
      case "nmap":
        return this.nmap(args);
      case "hydra":
        return this.hydra(args);
      case "curl":
        return this.curl(args);
      case "sqlmap":
        return this.sqlmap(args);
      case "ssh":
        return this.ssh(args);
      case "exit":
        return [line("logout", c.dim)];
      default:
        return [line(`${cmd}: command not found`, c.err), line(`Type 'help' for available commands.`, c.dim)];
    }
  }

  private help(): OutLine[] {
    const groups: [string, string[]][] = [
      ["files", ["ls", "cd", "pwd", "cat", "echo", "mkdir", "touch", "cp", "mv", "rm", "find", "grep"]],
      ["system", ["whoami", "id", "chmod", "chown", "sudo", "history", "man", "clear"]],
      ["network", ["ip a", "ifconfig", "ping", "netstat", "ss", "nslookup", "dig", "whois"]],
      ["offensive", ["nmap", "hydra", "curl", "sqlmap", "ssh"]],
    ];
    const out: OutLine[] = [line("Available commands (simulated):", c.ember)];
    for (const [g, cmds] of groups) {
      out.push(line("  " + g + ":", c.info));
      out.push(line("    " + cmds.join("  "), c.dim));
    }
    return out;
  }

  private ls(flags: string, pos: string[]): OutLine[] {
    const target = pos[0] ? this.resolvePath(pos[0]) : this.cwd;
    if (!target) return [line(`ls: cannot access '${pos[0]}': No such file or directory`, c.err)];
    const node = this.nodeAt(target);
    if (!node) return [line(`ls: cannot access '${pos[0]}': No such file or directory`, c.err)];
    let names: string[];
    let nodes: Record<string, FileNode>;
    if (node.type === "file") {
      names = [target[target.length - 1]];
      nodes = { [names[0]]: node };
    } else {
      nodes = node.children || {};
      names = Object.keys(nodes).sort();
    }
    const showAll = flags.includes("a");
    const hadHidden = names.some((n) => n.startsWith("."));
    if (!showAll) names = names.filter((n) => !n.startsWith("."));
    const long = flags.includes("l");
    // outcomes: only record a successful directory listing
    if (node.type === "dir") {
      this.listedDirs.add("/" + target.join("/"));
      if (showAll && hadHidden) this.listedHidden = true;
      if (long) this.listedLong = true;
    }
    if (long) {
      const out: OutLine[] = [];
      if (node.type === "dir") out.push(line(`total ${names.length}`, c.dim));
      for (const n of names) {
        const f = nodes[n];
        const type = f.type === "dir" ? "d" : "-";
        const nm = f.type === "dir" ? n + "/" : n;
        const cls = f.type === "dir" ? c.info : f.perms.includes("x") ? c.ok : undefined;
        out.push(
          line(
            `${type}${f.perms}  1 ${f.owner.padEnd(8)} ${f.group.padEnd(8)} ${String(f.size).padStart(5)} Jan 01 09:00 ${nm}`,
            cls
          )
        );
      }
      return out.length ? out : [line("")];
    }
    // grid-ish single line
    const disp = names.map((n) => {
      const f = nodes[n];
      return f.type === "dir" ? n + "/" : n;
    });
    return [line(disp.join("   "), undefined)];
  }

  private cd(target?: string): OutLine[] {
    if (!target || target === "~") {
      this.cwd = ["home", "operator"];
      return [];
    }
    const segs = this.resolvePath(target);
    if (!segs) return [line(`cd: ${target}: No such file or directory`, c.err)];
    const node = this.nodeAt(segs);
    if (!node) return [line(`cd: ${target}: No such file or directory`, c.err)];
    if (node.type !== "dir") return [line(`cd: ${target}: Not a directory`, c.err)];
    this.cwd = segs;
    return [];
  }

  private cat(pos: string[]): OutLine[] {
    if (!pos.length) return [line("cat: missing file operand", c.err)];
    const out: OutLine[] = [];
    for (const p of pos) {
      const segs = this.resolvePath(p);
      const node = segs && this.nodeAt(segs);
      if (!node) out.push(line(`cat: ${p}: No such file or directory`, c.err));
      else if (node.type === "dir") out.push(line(`cat: ${p}: Is a directory`, c.err));
      else if (node.perms.startsWith("rw-------") && this.user !== "root" && node.owner !== this.user)
        out.push(line(`cat: ${p}: Permission denied`, c.err));
      else {
        // outcome: content was actually printed → record the real read
        const abs = "/" + segs!.join("/");
        this.readFiles.add(abs);
        if (this.user === "root") this.sudoReadFiles.add(abs);
        (node.content || "").split("\n").forEach((l, i, arr) => {
          if (i === arr.length - 1 && l === "") return;
          out.push(line(l));
        });
      }
    }
    return out;
  }

  private mkdir(pos: string[]): OutLine[] {
    if (!pos.length) return [line("mkdir: missing operand", c.err)];
    const out: OutLine[] = [];
    for (const p of pos.filter((x) => x !== "-p")) {
      const segs = this.resolvePath(p);
      if (!segs) continue;
      const parent = this.nodeAt(segs.slice(0, -1));
      if (!parent || parent.type !== "dir") {
        out.push(line(`mkdir: cannot create directory '${p}': No such file or directory`, c.err));
        continue;
      }
      const name = segs[segs.length - 1];
      if (parent.children![name]) out.push(line(`mkdir: cannot create directory '${p}': File exists`, c.err));
      else parent.children![name] = dir({}, "rwxr-xr-x", this.user);
    }
    return out;
  }

  private touch(pos: string[]): OutLine[] {
    if (!pos.length) return [line("touch: missing file operand", c.err)];
    for (const p of pos) {
      const segs = this.resolvePath(p);
      if (!segs) continue;
      const parent = this.nodeAt(segs.slice(0, -1));
      if (!parent || parent.type !== "dir") continue;
      const name = segs[segs.length - 1];
      if (!parent.children![name]) parent.children![name] = file("", "rw-r--r--", this.user);
    }
    return [];
  }

  private rm(flags: string, pos: string[]): OutLine[] {
    if (!pos.length) return [line("rm: missing operand", c.err)];
    const out: OutLine[] = [];
    for (const p of pos) {
      const segs = this.resolvePath(p);
      const node = segs && this.nodeAt(segs);
      if (!node) {
        out.push(line(`rm: cannot remove '${p}': No such file or directory`, c.err));
        continue;
      }
      if (node.type === "dir" && !flags.includes("r")) {
        out.push(line(`rm: cannot remove '${p}': Is a directory`, c.err));
        continue;
      }
      const parent = this.nodeAt(segs!.slice(0, -1));
      if (parent && parent.children) delete parent.children[segs![segs!.length - 1]];
    }
    return out;
  }

  private cp(pos: string[]): OutLine[] {
    if (pos.length < 2) return [line("cp: missing destination file operand", c.err)];
    const src = this.resolvePath(pos[0]);
    const node = src && this.nodeAt(src);
    if (!node) return [line(`cp: cannot stat '${pos[0]}': No such file or directory`, c.err)];
    const dst = this.resolvePath(pos[1]);
    if (!dst) return [line(`cp: bad destination`, c.err)];
    const dstNode = this.nodeAt(dst);
    if (dstNode && dstNode.type === "dir") {
      dstNode.children![src![src!.length - 1]] = JSON.parse(JSON.stringify(node));
    } else {
      const parent = this.nodeAt(dst.slice(0, -1));
      if (parent && parent.children) parent.children[dst[dst.length - 1]] = JSON.parse(JSON.stringify(node));
    }
    return [];
  }

  private mv(pos: string[]): OutLine[] {
    if (pos.length < 2) return [line("mv: missing destination file operand", c.err)];
    const out = this.cp(pos);
    if (out.length) return out;
    return this.rm("r", [pos[0]]);
  }

  private find(pos: string[]): OutLine[] {
    const start = pos[0] || ".";
    const nameIdx = pos.indexOf("-name");
    const pattern = nameIdx >= 0 ? pos[nameIdx + 1]?.replace(/["'*]/g, "") : "";
    const base = this.resolvePath(start.startsWith("-") ? "." : start) || this.cwd;
    const node = this.nodeAt(base);
    if (!node) return [line(`find: '${start}': No such file or directory`, c.err)];
    this.ranFindCmd = true; // outcome: a find actually ran over a valid path
    const out: OutLine[] = [];
    const walk = (n: FileNode, path: string) => {
      if (n.type === "dir" && n.children) {
        for (const [k, v] of Object.entries(n.children)) {
          const p = path === "" ? k : `${path}/${k}`;
          if (!pattern || k.includes(pattern)) out.push(line((start === "." ? "./" : start + "/") + p));
          walk(v, p);
        }
      }
    };
    walk(node, "");
    return out.length ? out : [];
  }

  private grep(args: string[]): OutLine[] {
    const flags = args.filter((a) => a.startsWith("-")).join("");
    const nonFlags = args.filter((a) => !a.startsWith("-"));
    if (nonFlags.length < 1) return [line("usage: grep PATTERN FILE", c.err)];
    const pattern = nonFlags[0].replace(/^["']|["']$/g, "");
    const ci = flags.includes("i");
    const recursive = flags.includes("r") || flags.includes("R");
    const matchLine = (l: string) => (ci ? l.toLowerCase().includes(pattern.toLowerCase()) : l.includes(pattern));

    // Recursive search across a directory tree.
    if (recursive) {
      const startArg = nonFlags[1] || ".";
      const base = this.resolvePath(startArg) || this.cwd;
      const node = this.nodeAt(base);
      if (!node) return [line(`grep: ${startArg}: No such file or directory`, c.err)];
      const out: OutLine[] = [];
      const walk = (n: FileNode, path: string, abs: string[]) => {
        if (n.type === "file") {
          (n.content || "").split("\n").forEach((l) => {
            if (l && matchLine(l)) {
              out.push(line(`${path}:${l}`, c.ok));
              this.grepped.add("/" + abs.join("/")); // outcome: match in this file
            }
          });
        } else if (n.children) {
          for (const [k, v] of Object.entries(n.children))
            walk(v, path === "" ? k : `${path}/${k}`, [...abs, k]);
        }
      };
      walk(node, startArg === "." ? "" : startArg, base);
      return out;
    }

    const fileArg = nonFlags[1];
    if (!fileArg) return [line("usage: grep PATTERN FILE", c.err)];
    const segs = this.resolvePath(fileArg);
    const node = segs && this.nodeAt(segs);
    if (!node || node.type !== "file") return [line(`grep: ${fileArg}: No such file or directory`, c.err)];
    const matches = (node.content || "").split("\n").filter(matchLine);
    if (matches.length) this.grepped.add("/" + segs!.join("/")); // outcome: match found
    return matches.map((m) => line(m, c.ok));
  }

  private chmod(pos: string[]): OutLine[] {
    if (pos.length < 2) return [line("chmod: missing operand", c.err)];
    const mode = pos[0];
    const segs = this.resolvePath(pos[1]);
    const node = segs && this.nodeAt(segs);
    if (!node) return [line(`chmod: cannot access '${pos[1]}': No such file or directory`, c.err)];
    if (/^[0-7]{3,4}$/.test(mode)) {
      node.perms = octalToPerms(mode.slice(-3));
      return [];
    }
    // symbolic — supports comma-separated clauses and +, -, = operators
    const clauses = mode.split(",");
    let perms = node.perms;
    for (const cl of clauses) {
      if (!/^[ugoa]*[+\-=][rwx]*$/.test(cl)) {
        return [line(`chmod: invalid mode: '${mode}'`, c.err)];
      }
      perms = applySymbolic(perms, cl);
    }
    node.perms = perms;
    return [];
  }

  private chown(pos: string[]): OutLine[] {
    if (this.user !== "root") return [line("chown: changing ownership: Operation not permitted (try sudo)", c.err)];
    if (pos.length < 2) return [line("chown: missing operand", c.err)];
    const segs = this.resolvePath(pos[1]);
    const node = segs && this.nodeAt(segs);
    if (!node) return [line(`chown: cannot access '${pos[1]}': No such file or directory`, c.err)];
    const owner = pos[0].split(":")[0];
    node.owner = owner;
    if (pos[0].includes(":")) node.group = pos[0].split(":")[1] || owner;
    return [];
  }

  private sudo(args: string[]): OutLine[] {
    if (!args.length) return [line("usage: sudo command", c.err)];
    const prev = this.user;
    this.user = "root";
    const out = this.dispatch(args.join(" "));
    // keep root only for that command
    if (args[0] !== "su" && args.join(" ") !== "-i") this.user = prev;
    // Simulate "sudo su" giving a root shell
    if (args[0] === "su" || (args[0] === "-i")) {
      this.user = "root";
      return [line("root shell acquired. You are now root.", c.ok)];
    }
    return out;
  }

  private man(name?: string): OutLine[] {
    const pages: Record<string, string> = {
      ls: "ls - list directory contents. -l long format, -a show hidden.",
      chmod: "chmod - change file mode bits. e.g. chmod 755 file, chmod +x script.sh",
      nmap: "nmap - network mapper. Scan hosts & ports. -sV service versions, -p ports.",
      hydra: "hydra - parallelized login brute-forcer. e.g. hydra -l user -P wordlist ssh://host",
      ping: "ping - send ICMP ECHO_REQUEST to network hosts. -c count.",
    };
    if (!name) return [line("What manual page do you want?", c.dim)];
    return pages[name] ? [line(pages[name])] : [line(`No manual entry for ${name}`, c.err)];
  }

  private ip(args: string[]): OutLine[] {
    if (args[0] === "a" || args[0] === "addr" || args[0] === "address") {
      this.ranIpAddr = true;
      return [
        line("1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN", c.dim),
        line("    inet 127.0.0.1/8 scope host lo", c.info),
        line("2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP", c.dim),
        line("    link/ether 08:00:27:1a:2b:3c brd ff:ff:ff:ff:ff:ff", c.dim),
        line("    inet 10.10.10.13/24 brd 10.10.10.255 scope global dynamic eth0", c.info),
      ];
    }
    if (args[0] === "r" || args[0] === "route") {
      this.ranIpRoute = true;
      return [line("default via 10.10.10.1 dev eth0 proto dhcp"), line("10.10.10.0/24 dev eth0 proto kernel scope link src 10.10.10.13")];
    }
    return [line("Usage: ip a | ip route", c.dim)];
  }

  private ifconfig(): OutLine[] {
    this.ranIfconfig = true;
    return [
      line("eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500"),
      line("        inet 10.10.10.13  netmask 255.255.255.0  broadcast 10.10.10.255", c.info),
      line("        ether 08:00:27:1a:2b:3c  txqueuelen 1000  (Ethernet)", c.dim),
    ];
  }

  private ping(pos: string[]): OutLine[] {
    const host = pos[0];
    if (!host) return [line("ping: usage error: Destination address required", c.err)];
    const ip = resolve(host) || (/^\d+\.\d+\.\d+\.\d+$/.test(host) ? host : null);
    if (!ip || (!NETWORK[ip] && ip !== "10.10.10.13")) {
      return [line(`ping: ${host}: Name or service not known`, c.err)];
    }
    this.pinged.add(ip); // outcome: this host is proven reachable
    const out: OutLine[] = [line(`PING ${host} (${ip}) 56(84) bytes of data.`)];
    for (let i = 1; i <= 4; i++) {
      const ms = (0.2 + Math.random() * 1.5).toFixed(2);
      out.push(line(`64 bytes from ${ip}: icmp_seq=${i} ttl=64 time=${ms} ms`, c.ok));
    }
    out.push(line(`--- ${host} ping statistics ---`));
    out.push(line("4 packets transmitted, 4 received, 0% packet loss, time 3005ms", c.dim));
    return out;
  }

  private netstat(): OutLine[] {
    this.ranNetstat = true;
    return [
      line("Active Internet connections (only servers)"),
      line("Proto  Local Address        State       PID/Program", c.dim),
      line("tcp    0.0.0.0:22           LISTEN      612/sshd"),
      line("tcp    127.0.0.1:3306       LISTEN      889/mysqld"),
      line("tcp    10.10.10.13:44210    ESTABLISHED 1201/firefox"),
    ];
  }

  private nslookup(host?: string): OutLine[] {
    if (!host) return [line("usage: nslookup HOST", c.err)];
    const ip = resolve(host);
    if (!ip) return [line(`** server can't find ${host}: NXDOMAIN`, c.err)];
    this.resolved.add(host);
    this.resolved.add(ip);
    return [
      line("Server:\t\t10.10.10.1"),
      line("Address:\t10.10.10.1#53", c.dim),
      line(""),
      line(`Name:\t${NETWORK[ip].hostname}`, c.info),
      line(`Address: ${ip}`, c.ok),
    ];
  }

  private dig(host?: string): OutLine[] {
    if (!host) return [line("usage: dig HOST", c.err)];
    const ip = resolve(host);
    if (!ip) return [line(`;; ->>HEADER<<- status: NXDOMAIN`, c.err)];
    this.resolved.add(host);
    this.resolved.add(ip);
    return [
      line(`; <<>> DiG 9.18 <<>> ${host}`, c.dim),
      line(";; ANSWER SECTION:"),
      line(`${NETWORK[ip].hostname}.  300  IN  A  ${ip}`, c.ok),
      line(";; Query time: 4 msec", c.dim),
    ];
  }

  private whois(host?: string): OutLine[] {
    if (!host) return [line("usage: whois DOMAIN", c.err)];
    this.whoisDone = true;
    return [
      line(`Domain Name: ${host.toUpperCase()}`),
      line("Registrar: HACKFORGE Labs Registrar"),
      line("Creation Date: 2024-01-01T00:00:00Z", c.dim),
      line("Name Server: NS1.HACKFORGE.LAB", c.dim),
      line("Registrant Country: (simulated)", c.dim),
    ];
  }

  private nmap(args: string[]): OutLine[] {
    // A target looks like a host/IP/subnet (contains a dot or slash), which also
    // avoids mistaking a port spec like "22,3306" for the target.
    const target = args.find((a) => !a.startsWith("-") && a !== "nmap" && /[.\/]/.test(a));
    if (!target) return [line("Nmap: no target specified.", c.err)];
    // Version detection: -sV, -A (aggressive), or --version-* all imply it.
    const sV =
      args.some((a) => /^-(sV|A)$/.test(a)) ||
      args.join(" ").includes("-sV") ||
      args.some((a) => a.startsWith("--version"));

    // subnet / range scan
    if (target.includes("/") || target.includes("-") || target.includes("*")) {
      this.nmapSubnet = true; // outcome: swept the network
      const out: OutLine[] = [line("Starting Nmap 7.94 ( https://nmap.org )", c.dim)];
      for (const ip of Object.keys(NETWORK)) {
        this.nmapPortScans.add(ip);
        if (sV) this.nmapVersionScans.add(ip);
        out.push(line(`Nmap scan report for ${NETWORK[ip].hostname} (${ip})`, c.info));
        out.push(line("Host is up (0.00042s latency).", c.ok));
      }
      out.push(line(`Nmap done: 254 IP addresses (${Object.keys(NETWORK).length} hosts up) scanned.`, c.dim));
      return out;
    }

    const ip = resolve(target) || (NETWORK[target] ? target : null);
    if (!ip || !NETWORK[ip]) return [line(`Failed to resolve "${target}".`, c.err)];
    this.nmapPortScans.add(ip); // outcome: scanned this host's ports
    if (sV) this.nmapVersionScans.add(ip); // outcome: fingerprinted services
    const host = NETWORK[ip];
    const out: OutLine[] = [
      line("Starting Nmap 7.94 ( https://nmap.org )", c.dim),
      line(`Nmap scan report for ${host.hostname} (${ip})`, c.info),
      line("Host is up (0.00038s latency).", c.ok),
      line(""),
      line("PORT     STATE SERVICE" + (sV ? "   VERSION" : ""), c.ember),
    ];
    let ports = host.ports;
    // Resolve the port spec, which may be attached ('-p22,80', '-p-') or a
    // separate following argument ('-p 22,80').
    const pIdx = args.findIndex((a) => a === "-p" || a.startsWith("-p"));
    if (pIdx >= 0) {
      let spec = args[pIdx].replace(/^-p/, "");
      if (spec === "" && args[pIdx] === "-p") spec = args[pIdx + 1] || "";
      if (spec === "-") {
        // '-p-' scans ALL 65535 ports — keep every port, record the full scan.
        this.nmapFullScan.add(ip);
      } else if (spec) {
        const wanted = spec.split(",").map((x) => parseInt(x, 10)).filter((n) => !isNaN(n));
        wanted.forEach((pn) => this.nmapSpecificPorts.add(`${ip}:${pn}`)); // outcome
        ports = ports.filter((p) => wanted.includes(p.port));
      }
    }
    for (const p of ports) {
      const svc = `${p.port}/tcp`.padEnd(9);
      out.push(line(`${svc}open  ${p.svc.padEnd(8)}${sV ? " " + p.ver : ""}`, c.ok));
    }
    out.push(line(""));
    out.push(line(`Nmap done: 1 IP address (1 host up) scanned in 1.42 seconds`, c.dim));
    return out;
  }

  private hydra(args: string[]): OutLine[] {
    const str = args.join(" ");
    const svcMatch = str.match(/(ssh|ftp|http-post-form|mysql):\/\/([^\s]+)/) || str.match(/\b(ssh|ftp|mysql)\b/);
    const hasList = args.includes("-P") || args.includes("-x");
    const hasUser = args.includes("-l") || args.includes("-L");
    const service = svcMatch ? svcMatch[1] : args[args.length - 1];
    if (!hasUser || !hasList) {
      return [line("Hydra: you must supply a login (-l) and a password list (-P). e.g.", c.err), line("  hydra -l admin -P rockyou.txt ssh://10.10.10.5", c.dim)];
    }
    const userIdx = args.indexOf("-l");
    const user = userIdx >= 0 ? args[userIdx + 1] : "admin";
    if (service) this.bruteforced.add(service.toLowerCase()); // outcome: cracked this service
    return [
      line("Hydra v9.5 (c) by van Hauser/THC - for legal purposes only.", c.dim),
      line(`[DATA] attacking ${service}://target...`, c.dim),
      line("[ATTEMPT] target - login \"" + user + "\" - pass \"123456\"", c.dim),
      line("[ATTEMPT] target - login \"" + user + "\" - pass \"password\"", c.dim),
      line("[ATTEMPT] target - login \"" + user + "\" - pass \"letmein\"", c.dim),
      line(`[22][${service}] host: 10.10.10.5   login: ${user}   password: hunter2`, c.ok),
      line("1 of 1 target successfully completed, 1 valid password found", c.ok),
    ];
  }

  private curl(args: string[]): OutLine[] {
    const url = args.find((a) => a.startsWith("http")) || args[args.length - 1];
    if (!url) return [line("curl: try 'curl <url>'", c.err)];
    const hostMatch = url.match(/^https?:\/\/([^/]+)/);
    if (hostMatch) this.curled.add(hostMatch[1]); // outcome: fetched this host
    if (url.includes("login") && args.join(" ").includes("' OR '1'='1")) {
      return [
        line("HTTP/1.1 200 OK", c.dim),
        line("Set-Cookie: session=admin; HttpOnly", c.warn),
        line("<h1>Welcome back, administrator!</h1>", c.ok),
        line("flag{sql_injection_authentication_bypass}", c.ember),
      ];
    }
    return [
      line("HTTP/1.1 200 OK", c.dim),
      line("Server: Apache/2.4.52", c.dim),
      line("Content-Type: text/html", c.dim),
      line(""),
      line("<html><body><h1>HACKFORGE Demo App</h1>"),
      line('<form action="/login"><input name="user"><input name="pass"></form>'),
      line("</body></html>"),
    ];
  }

  private sqlmap(args: string[]): OutLine[] {
    const url = args.find((a) => a.includes("http")) || "";
    if (!url) return [line("sqlmap: option -u is required. e.g. sqlmap -u \"http://10.10.10.5/item?id=1\"", c.err)];
    this.sqlmapRun = true; // outcome: automated SQLi executed
    const wantsDump = args.some((a) => a === "--dump" || a === "--dump-all");
    const head = [
      line("        ___", c.dim),
      line("       __H__  sqlmap 1.8", c.ember),
      line("[*] starting @ 09:00", c.dim),
      line("[INFO] testing connection to the target URL", c.dim),
      line("[INFO] GET parameter 'id' appears to be injectable", c.warn),
      line("[INFO] the back-end DBMS is MySQL", c.info),
    ];
    if (wantsDump) {
      this.sqlmapDumped = true; // outcome: extracted table data
      return [
        ...head,
        line("[INFO] fetching columns for table 'users'", c.dim),
        line("[INFO] dumping table 'users' entries", c.dim),
        line("Database: webapp", c.ok),
        line("Table: users", c.ok),
        line("+----+----------+------------------+", c.dim),
        line("| id | username | password         |", c.ember),
        line("+----+----------+------------------+", c.dim),
        line("| 1  | admin    | hunter2          |", c.ok),
        line("| 2  | editor   | p@ssw0rd!        |", c.ok),
        line("+----+----------+------------------+", c.dim),
        line("[*] data dumped to CSV. 2 entries extracted.", c.warn),
      ];
    }
    return [
      ...head,
      line("[INFO] fetching database names", c.dim),
      line("available databases [3]:", c.ok),
      line("[*] information_schema", c.ok),
      line("[*] webapp", c.ok),
      line("[*] users", c.ok),
      line("Tip: re-run with --dump to extract a table's data.", c.dim),
    ];
  }

  private ssh(args: string[]): OutLine[] {
    const tgt = args.find((a) => !a.startsWith("-"));
    if (!tgt) return [line("usage: ssh user@host", c.err)];
    // outcome: opened a session to this host (requires user@host form + known host)
    const at = tgt.split("@");
    const host = at.length > 1 ? at[1] : tgt;
    const hip = resolve(host) || (/^\d+\.\d+\.\d+\.\d+$/.test(host) ? host : null);
    if (at.length > 1 && hip && NETWORK[hip]) this.sshTargets.add(hip);
    return [
      line(`The authenticity of host can't be established.`, c.dim),
      line("Warning: Permanently added to the list of known hosts.", c.dim),
      line("operator@target's password: ********", c.dim),
      line("Welcome to Ubuntu 22.04 LTS (simulated)", c.ok),
      line("You are now on the remote box. (In this sim, keep working locally.)", c.info),
    ];
  }
}

// All commands available for tab completion.
export const COMMANDS = [
  "help", "clear", "cls", "pwd", "whoami", "id", "hostname", "echo", "date", "history",
  "ls", "cd", "cat", "less", "more", "head", "tail", "bat", "mkdir", "touch", "rm", "cp", "mv",
  "find", "grep", "chmod", "chown", "sudo", "man",
  "ip", "ifconfig", "ping", "netstat", "ss", "nslookup", "host", "resolvectl", "dig", "whois",
  "nmap", "hydra", "curl", "sqlmap", "ssh", "exit",
];

function longestCommonPrefix(arr: string[]): string {
  if (!arr.length) return "";
  let prefix = arr[0];
  for (const s of arr) {
    while (!s.startsWith(prefix)) prefix = prefix.slice(0, -1);
    if (!prefix) return "";
  }
  return prefix;
}

// helpers
function octalToPerms(oct: string): string {
  const map = ["---", "--x", "-w-", "-wx", "r--", "r-x", "rw-", "rwx"];
  return oct.split("").map((d) => map[parseInt(d, 10)]).join("");
}
function applySymbolic(perms: string, clause: string): string {
  // clause like: a+x, go-rwx, u=rw, o=, +x
  const op = clause.includes("+") ? "+" : clause.includes("-") ? "-" : "=";
  const who = clause.match(/^[ugoa]*/)?.[0] || "";
  const bit = clause.slice(clause.indexOf(op) + 1); // rwx portion (may be empty for '=')
  const applyWho = who === "" || who === "a" ? ["u", "g", "o"] : who.split("");
  const p = perms.split("");
  const chars = ["r", "w", "x"];
  for (const w of applyWho) {
    const base = w === "u" ? 0 : w === "g" ? 3 : 6;
    for (let i = 0; i < 3; i++) {
      const has = bit.includes(chars[i]);
      if (op === "+") {
        if (has) p[base + i] = chars[i];
      } else if (op === "-") {
        if (has) p[base + i] = "-";
      } else {
        // '=' sets exactly the listed bits, clears the rest
        p[base + i] = has ? chars[i] : "-";
      }
    }
  }
  return p.join("");
}
